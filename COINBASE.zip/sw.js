/*! For license information please see sw.js.LICENSE.txt */ ! function(e) {
    var t = {};

    function n(r) {
        if (t[r]) return t[r].exports;
        var i = t[r] = {
            i: r,
            l: !1,
            exports: {}
        };
        return e[r].call(i.exports, i, i.exports, n), i.l = !0, i.exports
    }
    n.m = e, n.c = t, n.d = function(e, t, r) {
        n.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: r
        })
    }, n.r = function(e) {
        "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, n.t = function(e, t) {
        if (1 & t && (e = n(e)), 8 & t) return e;
        if (4 & t && "object" === typeof e && e && e.__esModule) return e;
        var r = Object.create(null);
        if (n.r(r), Object.defineProperty(r, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var i in e) n.d(r, i, function(t) {
                return e[t]
            }.bind(null, i));
        return r
    }, n.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return n.d(t, "a", t), t
    }, n.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, n.p = "", n(n.s = "dJh7")
}({
    "1SjT": function(e, t, n) {
        var r;
        ! function(i, a) {
            "use strict";
            var o = "function",
                s = "undefined",
                c = "object",
                u = "string",
                l = "model",
                d = "name",
                f = "type",
                p = "vendor",
                m = "version",
                v = "architecture",
                h = "console",
                g = "mobile",
                w = "tablet",
                b = "smarttv",
                y = "wearable",
                k = "embedded",
                _ = {
                    extend: function(e, t) {
                        var n = {};
                        for (var r in e) t[r] && t[r].length % 2 === 0 ? n[r] = t[r].concat(e[r]) : n[r] = e[r];
                        return n
                    },
                    has: function(e, t) {
                        return typeof e === u && -1 !== t.toLowerCase().indexOf(e.toLowerCase())
                    },
                    lowerize: function(e) {
                        return e.toLowerCase()
                    },
                    major: function(e) {
                        return typeof e === u ? e.replace(/[^\d\.]/g, "").split(".")[0] : a
                    },
                    trim: function(e, t) {
                        return e = e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, ""), typeof t === s ? e : e.substring(0, 255)
                    }
                },
                x = {
                    rgx: function(e, t) {
                        for (var n, r, i, s, u, l, d = 0; d < t.length && !u;) {
                            var f = t[d],
                                p = t[d + 1];
                            for (n = r = 0; n < f.length && !u;)
                                if (u = f[n++].exec(e))
                                    for (i = 0; i < p.length; i++) l = u[++r], typeof(s = p[i]) === c && s.length > 0 ? 2 == s.length ? typeof s[1] == o ? this[s[0]] = s[1].call(this, l) : this[s[0]] = s[1] : 3 == s.length ? typeof s[1] !== o || s[1].exec && s[1].test ? this[s[0]] = l ? l.replace(s[1], s[2]) : a : this[s[0]] = l ? s[1].call(this, l, s[2]) : a : 4 == s.length && (this[s[0]] = l ? s[3].call(this, l.replace(s[1], s[2])) : a) : this[s] = l || a;
                            d += 2
                        }
                    },
                    str: function(e, t) {
                        for (var n in t)
                            if (typeof t[n] === c && t[n].length > 0) {
                                for (var r = 0; r < t[n].length; r++)
                                    if (_.has(t[n][r], e)) return "?" === n ? a : n
                            } else if (_.has(t[n], e)) return "?" === n ? a : n;
                        return e
                    }
                },
                E = {
                    browser: {
                        oldSafari: {
                            version: {
                                "1.0": "/8",
                                1.2: "/1",
                                1.3: "/3",
                                "2.0": "/412",
                                "2.0.2": "/416",
                                "2.0.3": "/417",
                                "2.0.4": "/419",
                                "?": "/"
                            }
                        },
                        oldEdge: {
                            version: {
                                .1: "12.",
                                21: "13.",
                                31: "14.",
                                39: "15.",
                                41: "16.",
                                42: "17.",
                                44: "18."
                            }
                        }
                    },
                    os: {
                        windows: {
                            version: {
                                ME: "4.90",
                                "NT 3.11": "NT3.51",
                                "NT 4.0": "NT4.0",
                                2e3: "NT 5.0",
                                XP: ["NT 5.1", "NT 5.2"],
                                Vista: "NT 6.0",
                                7: "NT 6.1",
                                8: "NT 6.2",
                                8.1: "NT 6.3",
                                10: ["NT 6.4", "NT 10.0"],
                                RT: "ARM"
                            }
                        }
                    }
                },
                S = {
                    browser: [
                        [/\b(?:crmo|crios)\/([\w\.]+)/i],
                        [m, [d, "Chrome"]],
                        [/edg(?:e|ios|a)?\/([\w\.]+)/i],
                        [m, [d, "Edge"]],
                        [/(opera\smini)\/([\w\.-]+)/i, /(opera\s[mobiletab]{3,6})\b.+version\/([\w\.-]+)/i, /(opera)(?:.+version\/|[\/\s]+)([\w\.]+)/i],
                        [d, m],
                        [/opios[\/\s]+([\w\.]+)/i],
                        [m, [d, "Opera Mini"]],
                        [/\sopr\/([\w\.]+)/i],
                        [m, [d, "Opera"]],
                        [/(kindle)\/([\w\.]+)/i, /(lunascape|maxthon|netfront|jasmine|blazer)[\/\s]?([\w\.]*)/i, /(avant\s|iemobile|slim)(?:browser)?[\/\s]?([\w\.]*)/i, /(ba?idubrowser)[\/\s]?([\w\.]+)/i, /(?:ms|\()(ie)\s([\w\.]+)/i, /(flock|rockmelt|midori|epiphany|silk|skyfire|ovibrowser|bolt|iron|vivaldi|iridium|phantomjs|bowser|quark|qupzilla|falkon)\/([\w\.-]+)/i, /(rekonq|puffin|brave|whale|qqbrowserlite|qq)\/([\w\.]+)/i, /(weibo)__([\d\.]+)/i],
                        [d, m],
                        [/(?:[\s\/]uc?\s?browser|(?:juc.+)ucweb)[\/\s]?([\w\.]+)/i],
                        [m, [d, "UCBrowser"]],
                        [/(?:windowswechat)?\sqbcore\/([\w\.]+)\b.*(?:windowswechat)?/i],
                        [m, [d, "WeChat(Win) Desktop"]],
                        [/micromessenger\/([\w\.]+)/i],
                        [m, [d, "WeChat"]],
                        [/konqueror\/([\w\.]+)/i],
                        [m, [d, "Konqueror"]],
                        [/trident.+rv[:\s]([\w\.]{1,9})\b.+like\sgecko/i],
                        [m, [d, "IE"]],
                        [/yabrowser\/([\w\.]+)/i],
                        [m, [d, "Yandex"]],
                        [/(avast|avg)\/([\w\.]+)/i],
                        [
                            [d, /(.+)/, "$1 Secure Browser"], m
                        ],
                        [/focus\/([\w\.]+)/i],
                        [m, [d, "Firefox Focus"]],
                        [/opt\/([\w\.]+)/i],
                        [m, [d, "Opera Touch"]],
                        [/coc_coc_browser\/([\w\.]+)/i],
                        [m, [d, "Coc Coc"]],
                        [/dolfin\/([\w\.]+)/i],
                        [m, [d, "Dolphin"]],
                        [/coast\/([\w\.]+)/i],
                        [m, [d, "Opera Coast"]],
                        [/xiaomi\/miuibrowser\/([\w\.]+)/i],
                        [m, [d, "MIUI Browser"]],
                        [/fxios\/([\w\.-]+)/i],
                        [m, [d, "Firefox"]],
                        [/(qihu|qhbrowser|qihoobrowser|360browser)/i],
                        [
                            [d, "360 Browser"]
                        ],
                        [/(oculus|samsung|sailfish)browser\/([\w\.]+)/i],
                        [
                            [d, /(.+)/, "$1 Browser"], m
                        ],
                        [/(comodo_dragon)\/([\w\.]+)/i],
                        [
                            [d, /_/g, " "], m
                        ],
                        [/\s(electron)\/([\w\.]+)\ssafari/i, /(tesla)(?:\sqtcarbrowser|\/(20[12]\d\.[\w\.-]+))/i, /m?(qqbrowser|baiduboxapp|2345Explorer)[\/\s]?([\w\.]+)/i],
                        [d, m],
                        [/(MetaSr)[\/\s]?([\w\.]+)/i, /(LBBROWSER)/i],
                        [d],
                        [/;fbav\/([\w\.]+);/i],
                        [m, [d, "Facebook"]],
                        [/FBAN\/FBIOS|FB_IAB\/FB4A/i],
                        [
                            [d, "Facebook"]
                        ],
                        [/safari\s(line)\/([\w\.]+)/i, /\b(line)\/([\w\.]+)\/iab/i, /(chromium|instagram)[\/\s]([\w\.-]+)/i],
                        [d, m],
                        [/\bgsa\/([\w\.]+)\s.*safari\//i],
                        [m, [d, "GSA"]],
                        [/headlesschrome(?:\/([\w\.]+)|\s)/i],
                        [m, [d, "Chrome Headless"]],
                        [/\swv\).+(chrome)\/([\w\.]+)/i],
                        [
                            [d, "Chrome WebView"], m
                        ],
                        [/droid.+\sversion\/([\w\.]+)\b.+(?:mobile\ssafari|safari)/i],
                        [m, [d, "Android Browser"]],
                        [/(chrome|omniweb|arora|[tizenoka]{5}\s?browser)\/v?([\w\.]+)/i],
                        [d, m],
                        [/version\/([\w\.]+)\s.*mobile\/\w+\s(safari)/i],
                        [m, [d, "Mobile Safari"]],
                        [/version\/([\w\.]+)\s.*(mobile\s?safari|safari)/i],
                        [m, d],
                        [/webkit.+?(mobile\s?safari|safari)(\/[\w\.]+)/i],
                        [d, [m, x.str, E.browser.oldSafari.version]],
                        [/(webkit|khtml)\/([\w\.]+)/i],
                        [d, m],
                        [/(navigator|netscape)\/([\w\.-]+)/i],
                        [
                            [d, "Netscape"], m
                        ],
                        [/ile\svr;\srv:([\w\.]+)\).+firefox/i],
                        [m, [d, "Firefox Reality"]],
                        [/ekiohf.+(flow)\/([\w\.]+)/i, /(swiftfox)/i, /(icedragon|iceweasel|camino|chimera|fennec|maemo\sbrowser|minimo|conkeror)[\/\s]?([\w\.\+]+)/i, /(firefox|seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([\w\.-]+)$/i, /(firefox)\/([\w\.]+)\s[\w\s\-]+\/[\w\.]+$/i, /(mozilla)\/([\w\.]+)\s.+rv\:.+gecko\/\d+/i, /(polaris|lynx|dillo|icab|doris|amaya|w3m|netsurf|sleipnir)[\/\s]?([\w\.]+)/i, /(links)\s\(([\w\.]+)/i, /(gobrowser)\/?([\w\.]*)/i, /(ice\s?browser)\/v?([\w\._]+)/i, /(mosaic)[\/\s]([\w\.]+)/i],
                        [d, m]
                    ],
                    cpu: [
                        [/(?:(amd|x(?:(?:86|64)[_-])?|wow|win)64)[;\)]/i],
                        [
                            [v, "amd64"]
                        ],
                        [/(ia32(?=;))/i],
                        [
                            [v, _.lowerize]
                        ],
                        [/((?:i[346]|x)86)[;\)]/i],
                        [
                            [v, "ia32"]
                        ],
                        [/\b(aarch64|armv?8e?l?)\b/i],
                        [
                            [v, "arm64"]
                        ],
                        [/\b(arm(?:v[67])?ht?n?[fl]p?)\b/i],
                        [
                            [v, "armhf"]
                        ],
                        [/windows\s(ce|mobile);\sppc;/i],
                        [
                            [v, "arm"]
                        ],
                        [/((?:ppc|powerpc)(?:64)?)(?:\smac|;|\))/i],
                        [
                            [v, /ower/, "", _.lowerize]
                        ],
                        [/(sun4\w)[;\)]/i],
                        [
                            [v, "sparc"]
                        ],
                        [/((?:avr32|ia64(?=;))|68k(?=\))|\barm(?:64|(?=v(?:[1-7]|[5-7]1)l?|;|eabi))|(?=atmel\s)avr|(?:irix|mips|sparc)(?:64)?\b|pa-risc)/i],
                        [
                            [v, _.lowerize]
                        ]
                    ],
                    device: [
                        [/\b(sch-i[89]0\d|shw-m380s|sm-[pt]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus\s10)/i],
                        [l, [p, "Samsung"],
                            [f, w]
                        ],
                        [/\b((?:s[cgp]h|gt|sm)-\w+|galaxy\snexus)/i, /\ssamsung[\s-]([\w-]+)/i, /sec-(sgh\w+)/i],
                        [l, [p, "Samsung"],
                            [f, g]
                        ],
                        [/\((ip(?:hone|od)[\s\w]*);/i],
                        [l, [p, "Apple"],
                            [f, g]
                        ],
                        [/\((ipad);[\w\s\),;-]+apple/i, /applecoremedia\/[\w\.]+\s\((ipad)/i, /\b(ipad)\d\d?,\d\d?[;\]].+ios/i],
                        [l, [p, "Apple"],
                            [f, w]
                        ],
                        [/\b((?:agr|ags[23]|bah2?|sht?)-a?[lw]\d{2})/i],
                        [l, [p, "Huawei"],
                            [f, w]
                        ],
                        [/d\/huawei([\w\s-]+)[;\)]/i, /\b(nexus\s6p|vog-[at]?l\d\d|ane-[at]?l[x\d]\d|eml-a?l\d\da?|lya-[at]?l\d[\dc]|clt-a?l\d\di?|ele-l\d\d)/i, /\b(\w{2,4}-[atu][ln][01259][019])[;\)\s]/i],
                        [l, [p, "Huawei"],
                            [f, g]
                        ],
                        [/\b(poco[\s\w]+)(?:\sbuild|\))/i, /\b;\s(\w+)\sbuild\/hm\1/i, /\b(hm[\s\-_]?note?[\s_]?(?:\d\w)?)\sbuild/i, /\b(redmi[\s\-_]?(?:note|k)?[\w\s_]+)(?:\sbuild|\))/i, /\b(mi[\s\-_]?(?:a\d|one|one[\s_]plus|note lte)?[\s_]?(?:\d?\w?)[\s_]?(?:plus)?)\sbuild/i],
                        [
                            [l, /_/g, " "],
                            [p, "Xiaomi"],
                            [f, g]
                        ],
                        [/\b(mi[\s\-_]?(?:pad)(?:[\w\s_]+))(?:\sbuild|\))/i],
                        [
                            [l, /_/g, " "],
                            [p, "Xiaomi"],
                            [f, w]
                        ],
                        [/;\s(\w+)\sbuild.+\soppo/i, /\s(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007)\b/i],
                        [l, [p, "OPPO"],
                            [f, g]
                        ],
                        [/\svivo\s(\w+)(?:\sbuild|\))/i, /\s(v[12]\d{3}\w?[at])(?:\sbuild|;)/i],
                        [l, [p, "Vivo"],
                            [f, g]
                        ],
                        [/\s(rmx[12]\d{3})(?:\sbuild|;)/i],
                        [l, [p, "Realme"],
                            [f, g]
                        ],
                        [/\s(milestone|droid(?:[2-4x]|\s(?:bionic|x2|pro|razr))?:?(\s4g)?)\b[\w\s]+build\//i, /\smot(?:orola)?[\s-](\w*)/i, /((?:moto[\s\w\(\)]+|xt\d{3,4}|nexus\s6)(?=\sbuild|\)))/i],
                        [l, [p, "Motorola"],
                            [f, g]
                        ],
                        [/\s(mz60\d|xoom[\s2]{0,2})\sbuild\//i],
                        [l, [p, "Motorola"],
                            [f, w]
                        ],
                        [/((?=lg)?[vl]k\-?\d{3})\sbuild|\s3\.[\s\w;-]{10}lg?-([06cv9]{3,4})/i],
                        [l, [p, "LG"],
                            [f, w]
                        ],
                        [/(lm-?f100[nv]?|nexus\s[45])/i, /lg[e;\s\/-]+((?!browser|netcast)\w+)/i, /\blg(\-?[\d\w]+)\sbuild/i],
                        [l, [p, "LG"],
                            [f, g]
                        ],
                        [/(ideatab[\w\-\s]+)/i, /lenovo\s?(s(?:5000|6000)(?:[\w-]+)|tab(?:[\s\w]+)|yt[\d\w-]{6}|tb[\d\w-]{6})/i],
                        [l, [p, "Lenovo"],
                            [f, w]
                        ],
                        [/(?:maemo|nokia).*(n900|lumia\s\d+)/i, /nokia[\s_-]?([\w\.-]*)/i],
                        [
                            [l, /_/g, " "],
                            [p, "Nokia"],
                            [f, g]
                        ],
                        [/droid.+;\s(pixel\sc)[\s)]/i],
                        [l, [p, "Google"],
                            [f, w]
                        ],
                        [/droid.+;\s(pixel[\s\daxl]{0,6})(?:\sbuild|\))/i],
                        [l, [p, "Google"],
                            [f, g]
                        ],
                        [/droid.+\s([c-g]\d{4}|so[-l]\w+|xq-a\w[4-7][12])(?=\sbuild\/|\).+chrome\/(?![1-6]{0,1}\d\.))/i],
                        [l, [p, "Sony"],
                            [f, g]
                        ],
                        [/sony\stablet\s[ps]\sbuild\//i, /(?:sony)?sgp\w+(?:\sbuild\/|\))/i],
                        [
                            [l, "Xperia Tablet"],
                            [p, "Sony"],
                            [f, w]
                        ],
                        [/\s(kb2005|in20[12]5|be20[12][59])\b/i, /\ba000(1)\sbuild/i, /\boneplus\s(a\d{4})[\s)]/i],
                        [l, [p, "OnePlus"],
                            [f, g]
                        ],
                        [/(alexa)webm/i, /(kf[a-z]{2}wi)(\sbuild\/|\))/i, /(kf[a-z]+)(\sbuild\/|\)).+silk\//i],
                        [l, [p, "Amazon"],
                            [f, w]
                        ],
                        [/(sd|kf)[0349hijorstuw]+(\sbuild\/|\)).+silk\//i],
                        [
                            [l, "Fire Phone"],
                            [p, "Amazon"],
                            [f, g]
                        ],
                        [/\((playbook);[\w\s\),;-]+(rim)/i],
                        [l, p, [f, w]],
                        [/((?:bb[a-f]|st[hv])100-\d)/i, /\(bb10;\s(\w+)/i],
                        [l, [p, "BlackBerry"],
                            [f, g]
                        ],
                        [/(?:\b|asus_)(transfo[prime\s]{4,10}\s\w+|eeepc|slider\s\w+|nexus\s7|padfone|p00[cj])/i],
                        [l, [p, "ASUS"],
                            [f, w]
                        ],
                        [/\s(z[es]6[027][01][km][ls]|zenfone\s\d\w?)\b/i],
                        [l, [p, "ASUS"],
                            [f, g]
                        ],
                        [/(nexus\s9)/i],
                        [l, [p, "HTC"],
                            [f, w]
                        ],
                        [/(htc)[;_\s-]{1,2}([\w\s]+(?=\)|\sbuild)|\w+)/i, /(zte)-(\w*)/i, /(alcatel|geeksphone|nexian|panasonic|(?=;\s)sony)[_\s-]?([\w-]*)/i],
                        [p, [l, /_/g, " "],
                            [f, g]
                        ],
                        [/droid[x\d\.\s;]+\s([ab][1-7]\-?[0178a]\d\d?)/i],
                        [l, [p, "Acer"],
                            [f, w]
                        ],
                        [/droid.+;\s(m[1-5]\snote)\sbuild/i, /\bmz-([\w-]{2,})/i],
                        [l, [p, "Meizu"],
                            [f, g]
                        ],
                        [/(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus|dell|meizu|motorola|polytron)[\s_-]?([\w-]*)/i, /(hp)\s([\w\s]+\w)/i, /(asus)-?(\w+)/i, /(microsoft);\s(lumia[\s\w]+)/i, /(lenovo)[_\s-]?([\w-]+)/i, /linux;.+(jolla);/i, /droid.+;\s(oppo)\s?([\w\s]+)\sbuild/i],
                        [p, l, [f, g]],
                        [/(archos)\s(gamepad2?)/i, /(hp).+(touchpad(?!.+tablet)|tablet)/i, /(kindle)\/([\w\.]+)/i, /\s(nook)[\w\s]+build\/(\w+)/i, /(dell)\s(strea[kpr\s\d]*[\dko])/i, /[;\/]\s?(le[\s\-]+pan)[\s\-]+(\w{1,9})\sbuild/i, /[;\/]\s?(trinity)[\-\s]*(t\d{3})\sbuild/i, /\b(gigaset)[\s\-]+(q\w{1,9})\sbuild/i, /\b(vodafone)\s([\w\s]+)(?:\)|\sbuild)/i],
                        [p, l, [f, w]],
                        [/\s(surface\sduo)\s/i],
                        [l, [p, "Microsoft"],
                            [f, w]
                        ],
                        [/droid\s[\d\.]+;\s(fp\du?)\sbuild/i],
                        [l, [p, "Fairphone"],
                            [f, g]
                        ],
                        [/\s(u304aa)\sbuild/i],
                        [l, [p, "AT&T"],
                            [f, g]
                        ],
                        [/sie-(\w*)/i],
                        [l, [p, "Siemens"],
                            [f, g]
                        ],
                        [/[;\/]\s?(rct\w+)\sbuild/i],
                        [l, [p, "RCA"],
                            [f, w]
                        ],
                        [/[;\/\s](venue[\d\s]{2,7})\sbuild/i],
                        [l, [p, "Dell"],
                            [f, w]
                        ],
                        [/[;\/]\s?(q(?:mv|ta)\w+)\sbuild/i],
                        [l, [p, "Verizon"],
                            [f, w]
                        ],
                        [/[;\/]\s(?:barnes[&\s]+noble\s|bn[rt])([\w\s\+]*)\sbuild/i],
                        [l, [p, "Barnes & Noble"],
                            [f, w]
                        ],
                        [/[;\/]\s(tm\d{3}\w+)\sbuild/i],
                        [l, [p, "NuVision"],
                            [f, w]
                        ],
                        [/;\s(k88)\sbuild/i],
                        [l, [p, "ZTE"],
                            [f, w]
                        ],
                        [/;\s(nx\d{3}j)\sbuild/i],
                        [l, [p, "ZTE"],
                            [f, g]
                        ],
                        [/[;\/]\s?(gen\d{3})\sbuild.*49h/i],
                        [l, [p, "Swiss"],
                            [f, g]
                        ],
                        [/[;\/]\s?(zur\d{3})\sbuild/i],
                        [l, [p, "Swiss"],
                            [f, w]
                        ],
                        [/[;\/]\s?((zeki)?tb.*\b)\sbuild/i],
                        [l, [p, "Zeki"],
                            [f, w]
                        ],
                        [/[;\/]\s([yr]\d{2})\sbuild/i, /[;\/]\s(dragon[\-\s]+touch\s|dt)(\w{5})\sbuild/i],
                        [
                            [p, "Dragon Touch"], l, [f, w]
                        ],
                        [/[;\/]\s?(ns-?\w{0,9})\sbuild/i],
                        [l, [p, "Insignia"],
                            [f, w]
                        ],
                        [/[;\/]\s?((nxa|Next)-?\w{0,9})\sbuild/i],
                        [l, [p, "NextBook"],
                            [f, w]
                        ],
                        [/[;\/]\s?(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05]))\sbuild/i],
                        [
                            [p, "Voice"], l, [f, g]
                        ],
                        [/[;\/]\s?(lvtel\-)?(v1[12])\sbuild/i],
                        [
                            [p, "LvTel"], l, [f, g]
                        ],
                        [/;\s(ph-1)\s/i],
                        [l, [p, "Essential"],
                            [f, g]
                        ],
                        [/[;\/]\s?(v(100md|700na|7011|917g).*\b)\sbuild/i],
                        [l, [p, "Envizen"],
                            [f, w]
                        ],
                        [/[;\/]\s?(trio[\s\w\-\.]+)\sbuild/i],
                        [l, [p, "MachSpeed"],
                            [f, w]
                        ],
                        [/[;\/]\s?tu_(1491)\sbuild/i],
                        [l, [p, "Rotor"],
                            [f, w]
                        ],
                        [/(shield[\w\s]+)\sbuild/i],
                        [l, [p, "Nvidia"],
                            [f, w]
                        ],
                        [/(sprint)\s(\w+)/i],
                        [p, l, [f, g]],
                        [/(kin\.[onetw]{3})/i],
                        [
                            [l, /\./g, " "],
                            [p, "Microsoft"],
                            [f, g]
                        ],
                        [/droid\s[\d\.]+;\s(cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i],
                        [l, [p, "Zebra"],
                            [f, w]
                        ],
                        [/droid\s[\d\.]+;\s(ec30|ps20|tc[2-8]\d[kx])\)/i],
                        [l, [p, "Zebra"],
                            [f, g]
                        ],
                        [/\s(ouya)\s/i, /(nintendo)\s([wids3utch]+)/i],
                        [p, l, [f, h]],
                        [/droid.+;\s(shield)\sbuild/i],
                        [l, [p, "Nvidia"],
                            [f, h]
                        ],
                        [/(playstation\s[345portablevi]+)/i],
                        [l, [p, "Sony"],
                            [f, h]
                        ],
                        [/[\s\(;](xbox(?:\sone)?(?!;\sxbox))[\s\);]/i],
                        [l, [p, "Microsoft"],
                            [f, h]
                        ],
                        [/smart-tv.+(samsung)/i],
                        [p, [f, b]],
                        [/hbbtv.+maple;(\d+)/i],
                        [
                            [l, /^/, "SmartTV"],
                            [p, "Samsung"],
                            [f, b]
                        ],
                        [/(?:linux;\snetcast.+smarttv|lg\snetcast\.tv-201\d)/i],
                        [
                            [p, "LG"],
                            [f, b]
                        ],
                        [/(apple)\s?tv/i],
                        [p, [l, "Apple TV"],
                            [f, b]
                        ],
                        [/crkey/i],
                        [
                            [l, "Chromecast"],
                            [p, "Google"],
                            [f, b]
                        ],
                        [/droid.+aft([\w])(\sbuild\/|\))/i],
                        [l, [p, "Amazon"],
                            [f, b]
                        ],
                        [/\(dtv[\);].+(aquos)/i],
                        [l, [p, "Sharp"],
                            [f, b]
                        ],
                        [/hbbtv\/\d+\.\d+\.\d+\s+\([\w\s]*;\s*(\w[^;]*);([^;]*)/i],
                        [
                            [p, _.trim],
                            [l, _.trim],
                            [f, b]
                        ],
                        [/[\s\/\(](android\s|smart[-\s]?|opera\s)tv[;\)\s]/i],
                        [
                            [f, b]
                        ],
                        [/((pebble))app\/[\d\.]+\s/i],
                        [p, l, [f, y]],
                        [/droid.+;\s(glass)\s\d/i],
                        [l, [p, "Google"],
                            [f, y]
                        ],
                        [/droid\s[\d\.]+;\s(wt63?0{2,3})\)/i],
                        [l, [p, "Zebra"],
                            [f, y]
                        ],
                        [/(tesla)(?:\sqtcarbrowser|\/20[12]\d\.[\w\.-]+)/i],
                        [p, [f, k]],
                        [/droid .+?; ([^;]+?)(?: build|\) applewebkit).+? mobile safari/i],
                        [l, [f, g]],
                        [/droid .+?;\s([^;]+?)(?: build|\) applewebkit).+?(?! mobile) safari/i],
                        [l, [f, w]],
                        [/\s(tablet|tab)[;\/]/i, /\s(mobile)(?:[;\/]|\ssafari)/i],
                        [
                            [f, _.lowerize]
                        ],
                        [/(android[\w\.\s\-]{0,9});.+build/i],
                        [l, [p, "Generic"]],
                        [/(phone)/i],
                        [
                            [f, g]
                        ]
                    ],
                    engine: [
                        [/windows.+\sedge\/([\w\.]+)/i],
                        [m, [d, "EdgeHTML"]],
                        [/webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i],
                        [m, [d, "Blink"]],
                        [/(presto)\/([\w\.]+)/i, /(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna)\/([\w\.]+)/i, /ekioh(flow)\/([\w\.]+)/i, /(khtml|tasman|links)[\/\s]\(?([\w\.]+)/i, /(icab)[\/\s]([23]\.[\d\.]+)/i],
                        [d, m],
                        [/rv\:([\w\.]{1,9})\b.+(gecko)/i],
                        [m, d]
                    ],
                    os: [
                        [/microsoft\s(windows)\s(vista|xp)/i],
                        [d, m],
                        [/(windows)\snt\s6\.2;\s(arm)/i, /(windows\sphone(?:\sos)*)[\s\/]?([\d\.\s\w]*)/i, /(windows\smobile|windows)[\s\/]?([ntce\d\.\s]+\w)(?!.+xbox)/i],
                        [d, [m, x.str, E.os.windows.version]],
                        [/(win(?=3|9|n)|win\s9x\s)([nt\d\.]+)/i],
                        [
                            [d, "Windows"],
                            [m, x.str, E.os.windows.version]
                        ],
                        [/ip[honead]{2,4}\b(?:.*os\s([\w]+)\slike\smac|;\sopera)/i, /cfnetwork\/.+darwin/i],
                        [
                            [m, /_/g, "."],
                            [d, "iOS"]
                        ],
                        [/(mac\sos\sx)\s?([\w\s\.]*)/i, /(macintosh|mac(?=_powerpc)\s)(?!.+haiku)/i],
                        [
                            [d, "Mac OS"],
                            [m, /_/g, "."]
                        ],
                        [/(android|webos|palm\sos|qnx|bada|rim\stablet\sos|meego|sailfish|contiki)[\/\s-]?([\w\.]*)/i, /(blackberry)\w*\/([\w\.]*)/i, /(tizen|kaios)[\/\s]([\w\.]+)/i, /\((series40);/i],
                        [d, m],
                        [/\(bb(10);/i],
                        [m, [d, "BlackBerry"]],
                        [/(?:symbian\s?os|symbos|s60(?=;)|series60)[\/\s-]?([\w\.]*)/i],
                        [m, [d, "Symbian"]],
                        [/mozilla.+\(mobile;.+gecko.+firefox/i],
                        [
                            [d, "Firefox OS"]
                        ],
                        [/web0s;.+rt(tv)/i, /\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i],
                        [m, [d, "webOS"]],
                        [/crkey\/([\d\.]+)/i],
                        [m, [d, "Chromecast"]],
                        [/(cros)\s[\w]+\s([\w\.]+\w)/i],
                        [
                            [d, "Chromium OS"], m
                        ],
                        [/(nintendo|playstation)\s([wids345portablevuch]+)/i, /(xbox);\s+xbox\s([^\);]+)/i, /(mint)[\/\s\(\)]?(\w*)/i, /(mageia|vectorlinux)[;\s]/i, /(joli|[kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?=\slinux)|slackware|fedora|mandriva|centos|pclinuxos|redhat|zenwalk|linpus|raspbian)(?:\sgnu\/linux)?(?:\slinux)?[\/\s-]?(?!chrom|package)([\w\.-]*)/i, /(hurd|linux)\s?([\w\.]*)/i, /(gnu)\s?([\w\.]*)/i, /\s([frentopc-]{0,4}bsd|dragonfly)\s?(?!amd|[ix346]{1,2}86)([\w\.]*)/i, /(haiku)\s(\w+)/i],
                        [d, m],
                        [/(sunos)\s?([\w\.\d]*)/i],
                        [
                            [d, "Solaris"], m
                        ],
                        [/((?:open)?solaris)[\/\s-]?([\w\.]*)/i, /(aix)\s((\d)(?=\.|\)|\s)[\w\.])*/i, /(plan\s9|minix|beos|os\/2|amigaos|morphos|risc\sos|openvms|fuchsia)/i, /(unix)\s?([\w\.]*)/i],
                        [d, m]
                    ]
                },
                T = function(e, t) {
                    if ("object" === typeof e && (t = e, e = a), !(this instanceof T)) return new T(e, t).getResult();
                    var n = e || ("undefined" !== typeof i && i.navigator && i.navigator.userAgent ? i.navigator.userAgent : ""),
                        r = t ? _.extend(S, t) : S;
                    return this.getBrowser = function() {
                        var e = {
                            name: a,
                            version: a
                        };
                        return x.rgx.call(e, n, r.browser), e.major = _.major(e.version), e
                    }, this.getCPU = function() {
                        var e = {
                            architecture: a
                        };
                        return x.rgx.call(e, n, r.cpu), e
                    }, this.getDevice = function() {
                        var e = {
                            vendor: a,
                            model: a,
                            type: a
                        };
                        return x.rgx.call(e, n, r.device), e
                    }, this.getEngine = function() {
                        var e = {
                            name: a,
                            version: a
                        };
                        return x.rgx.call(e, n, r.engine), e
                    }, this.getOS = function() {
                        var e = {
                            name: a,
                            version: a
                        };
                        return x.rgx.call(e, n, r.os), e
                    }, this.getResult = function() {
                        return {
                            ua: this.getUA(),
                            browser: this.getBrowser(),
                            engine: this.getEngine(),
                            os: this.getOS(),
                            device: this.getDevice(),
                            cpu: this.getCPU()
                        }
                    }, this.getUA = function() {
                        return n
                    }, this.setUA = function(e) {
                        return n = typeof e === u && e.length > 255 ? _.trim(e, 255) : e, this
                    }, this.setUA(n), this
                };
            T.VERSION = "0.7.28", T.BROWSER = {
                NAME: d,
                MAJOR: "major",
                VERSION: m
            }, T.CPU = {
                ARCHITECTURE: v
            }, T.DEVICE = {
                MODEL: l,
                VENDOR: p,
                TYPE: f,
                CONSOLE: h,
                MOBILE: g,
                SMARTTV: b,
                TABLET: w,
                WEARABLE: y,
                EMBEDDED: k
            }, T.ENGINE = {
                NAME: d,
                VERSION: m
            }, T.OS = {
                NAME: d,
                VERSION: m
            }, typeof t !== s ? (typeof e !== s && e.exports && (t = e.exports = T), t.UAParser = T) : (r = function() {
                return T
            }.call(t, n, t, e)) === a || (e.exports = r);
            var I = "undefined" !== typeof i && (i.jQuery || i.Zepto);
            if (I && !I.ua) {
                var O = new T;
                I.ua = O.getResult(), I.ua.get = function() {
                    return O.getUA()
                }, I.ua.set = function(e) {
                    O.setUA(e);
                    var t = O.getResult();
                    for (var n in t) I.ua[n] = t[n]
                }
            }
        }("object" === typeof window ? window : this)
    },
    DPV4: function(e, t) {
        ! function() {
            var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
                n = {
                    rotl: function(e, t) {
                        return e << t | e >>> 32 - t
                    },
                    rotr: function(e, t) {
                        return e << 32 - t | e >>> t
                    },
                    endian: function(e) {
                        if (e.constructor == Number) return 16711935 & n.rotl(e, 8) | 4278255360 & n.rotl(e, 24);
                        for (var t = 0; t < e.length; t++) e[t] = n.endian(e[t]);
                        return e
                    },
                    randomBytes: function(e) {
                        for (var t = []; e > 0; e--) t.push(Math.floor(256 * Math.random()));
                        return t
                    },
                    bytesToWords: function(e) {
                        for (var t = [], n = 0, r = 0; n < e.length; n++, r += 8) t[r >>> 5] |= e[n] << 24 - r % 32;
                        return t
                    },
                    wordsToBytes: function(e) {
                        for (var t = [], n = 0; n < 32 * e.length; n += 8) t.push(e[n >>> 5] >>> 24 - n % 32 & 255);
                        return t
                    },
                    bytesToHex: function(e) {
                        for (var t = [], n = 0; n < e.length; n++) t.push((e[n] >>> 4).toString(16)), t.push((15 & e[n]).toString(16));
                        return t.join("")
                    },
                    hexToBytes: function(e) {
                        for (var t = [], n = 0; n < e.length; n += 2) t.push(parseInt(e.substr(n, 2), 16));
                        return t
                    },
                    bytesToBase64: function(e) {
                        for (var n = [], r = 0; r < e.length; r += 3)
                            for (var i = e[r] << 16 | e[r + 1] << 8 | e[r + 2], a = 0; a < 4; a++) 8 * r + 6 * a <= 8 * e.length ? n.push(t.charAt(i >>> 6 * (3 - a) & 63)) : n.push("=");
                        return n.join("")
                    },
                    base64ToBytes: function(e) {
                        e = e.replace(/[^A-Z0-9+\/]/gi, "");
                        for (var n = [], r = 0, i = 0; r < e.length; i = ++r % 4) 0 != i && n.push((t.indexOf(e.charAt(r - 1)) & Math.pow(2, -2 * i + 8) - 1) << 2 * i | t.indexOf(e.charAt(r)) >>> 6 - 2 * i);
                        return n
                    }
                };
            e.exports = n
        }()
    },
    EbX1: function(e, t) {
        function n(e) {
            return !!e.constructor && "function" === typeof e.constructor.isBuffer && e.constructor.isBuffer(e)
        }
        e.exports = function(e) {
            return null != e && (n(e) || function(e) {
                return "function" === typeof e.readFloatLE && "function" === typeof e.slice && n(e.slice(0, 0))
            }(e) || !!e._isBuffer)
        }
    },
    Ee4y: function(e, t, n) {
        "use strict";
        n.r(t);
        var r = {
                t: !1,
                i: !1,
                o: 3e4
            },
            i = window,
            a = i.console,
            o = document,
            s = i.navigator,
            c = i.performance,
            u = function() {
                return s.deviceMemory
            },
            l = function() {
                return s.hardwareConcurrency
            },
            d = function() {
                return c && !!c.getEntriesByType && !!c.now && !!c.mark
            },
            f = "4g",
            p = !1,
            m = function() {
                return !!(l() && l() <= 4) || !!(u() && u() <= 4)
            },
            v = function(e, t) {
                switch (e) {
                    case "slow-2g":
                    case "2g":
                    case "3g":
                        return !0;
                    default:
                        return m() || t
                }
            },
            h = {
                u: !1
            },
            g = function(e) {
                o.hidden && (e(), h.u = o.hidden)
            },
            w = function(e) {
                return parseFloat(e.toFixed(4))
            },
            b = function(e) {
                return "number" != typeof e ? null : w(e / Math.pow(1024, 2))
            },
            y = [2e3, 4e3],
            k = [2500, 4e3],
            _ = [.1, .25],
            x = {
                ttfb: [200, 500],
                fp: y,
                fcp: y,
                lcp: k,
                lcpFinal: k,
                fid: [100, 300],
                cls: _,
                clsFinal: _,
                tbt: [300, 600]
            },
            E = function(e, t) {
                return x[e] ? t <= x[e][0] ? "good" : t <= x[e][1] ? "needsImprovement" : "poor" : null
            },
            S = function(e, t, n) {
                var a;
                a = function() {
                    h.u && e.indexOf("Final") < 0 || !r.analyticsTracker || r.analyticsTracker({
                        metricName: e,
                        data: t,
                        eventProperties: n || {},
                        navigatorInformation: s ? {
                            deviceMemory: u() || 0,
                            hardwareConcurrency: l() || 0,
                            serviceWorkerStatus: "serviceWorker" in s ? s.serviceWorker.controller ? "controlled" : "supported" : "unsupported",
                            isLowEndDevice: m(),
                            isLowEndExperience: v(f, p)
                        } : {},
                        vitalsScore: E(e, t)
                    })
                }, "requestIdleCallback" in i ? i.requestIdleCallback(a, {
                    timeout: 3e3
                }) : a()
            },
            T = function(e, t, n) {
                Object.keys(t).forEach((function(e) {
                    "number" == typeof t[e] && (t[e] = w(t[e]))
                })), S(e, t, n)
            },
            I = function(e, t, n) {
                var i = w(e);
                i <= r.o && i >= 0 && S(t, i, n)
            },
            O = {},
            N = {
                value: 0
            },
            j = {
                value: 0
            },
            P = {
                value: 0
            },
            A = {
                value: {
                    beacon: 0,
                    css: 0,
                    fetch: 0,
                    img: 0,
                    other: 0,
                    script: 0,
                    total: 0,
                    xmlhttprequest: 0
                }
            },
            D = {
                value: 0
            },
            L = function(e) {
                var t = e.pop();
                t && !t.s && t.value && (N.value += t.value)
            },
            B = {},
            M = function(e, t) {
                try {
                    var n = new PerformanceObserver((function(e) {
                        t(e.getEntries())
                    }));
                    return n.observe({
                        type: e,
                        buffered: !0
                    }), n
                } catch (e) {
                    a.warn("Perfume.js:", e)
                }
                return null
            },
            R = function(e) {
                B[e] && B[e].disconnect(), delete B[e]
            },
            q = function(e) {
                var t = e.pop();
                t && I(t.processingStart - t.startTime, "fid", {
                    performanceEntry: t
                }), R(1), I(P.value, "lcp"), B[3] && "function" == typeof B[3].takeRecords && B[3].takeRecords(), I(N.value, "cls"), setTimeout((function() {
                    I(D.value, "tbt"), T("dataConsumption", A.value)
                }), 1e4)
            },
            C = function(e) {
                e.forEach((function(e) {
                    if (!("self" !== e.name || e.startTime < j.value)) {
                        var t = e.duration - 50;
                        t > 0 && (D.value += t)
                    }
                }))
            },
            U = function(e) {
                e.forEach((function(e) {
                    "first-paint" === e.name ? I(e.startTime, "fp") : "first-contentful-paint" === e.name && (j.value = e.startTime, I(j.value, "fcp"), B[4] = M("longtask", C), R(0))
                }))
            },
            z = function(e) {
                var t = e.pop();
                t && (P.value = t.renderTime || t.loadTime)
            },
            F = function(e) {
                e.forEach((function(e) {
                    e.identifier && I(e.startTime, e.identifier)
                }))
            },
            K = function(e) {
                e.forEach((function(e) {
                    if (r.t && T("resourceTiming", e), e.decodedBodySize && e.initiatorType) {
                        var t = e.decodedBodySize / 1e3;
                        A.value[e.initiatorType] += t, A.value.total += t
                    }
                }))
            },
            W = function() {
                B[2] && (I(P.value, "lcpFinal"), R(2)), B[3] && ("function" == typeof B[3].takeRecords && B[3].takeRecords(), I(N.value, "clsFinal"), R(3))
            },
            V = function(e) {
                var t = "usageDetails" in e ? e.usageDetails : {};
                T("storageEstimate", {
                    quota: b(e.quota),
                    usage: b(e.usage),
                    caches: b(t.caches),
                    indexedDB: b(t.indexedDB),
                    serviceWorker: b(t.serviceWorkerRegistrations)
                })
            },
            G = function() {
                function e(e) {
                    if (void 0 === e && (e = {}), this.l = "6.2.0", r.analyticsTracker = e.analyticsTracker, r.t = !!e.resourceTiming, r.i = !!e.elementTiming, r.o = e.maxMeasureTime || r.o, d()) {
                        "PerformanceObserver" in i && (B[0] = M("paint", U), B[1] = M("first-input", q), B[2] = M("largest-contentful-paint", z), r.t && M("resource", K), B[3] = M("layout-shift", L), r.i && M("element", F)), void 0 !== o.hidden && o.addEventListener("visibilitychange", g.bind(this, W));
                        var t = function() {
                            if (!d()) return {};
                            var e = c.getEntriesByType("navigation")[0];
                            if (!e) return {};
                            var t = e.responseStart,
                                n = e.responseEnd;
                            return {
                                fetchTime: n - e.fetchStart,
                                workerTime: e.workerStart > 0 ? n - e.workerStart : 0,
                                totalTime: n - e.requestStart,
                                downloadTime: n - t,
                                timeToFirstByte: t - e.requestStart,
                                headerSize: e.transferSize - e.encodedBodySize || 0,
                                dnsLookupTime: e.domainLookupEnd - e.domainLookupStart
                            }
                        }();
                        T("navigationTiming", t), t.timeToFirstByte && I(t.timeToFirstByte, "ttfb"), T("networkInformation", function() {
                            if ("connection" in s) {
                                var e = s.connection;
                                return "object" != typeof e ? {} : (f = e.effectiveType, p = !!e.saveData, {
                                    downlink: e.downlink,
                                    effectiveType: e.effectiveType,
                                    rtt: e.rtt,
                                    saveData: !!e.saveData
                                })
                            }
                            return {}
                        }()), s && s.storage && "function" == typeof s.storage.estimate && s.storage.estimate().then(V)
                    }
                }
                return e.prototype.start = function(e) {
                    d() && !O[e] && (O[e] = !0, c.mark("mark_" + e + "_start"), h.u = !1)
                }, e.prototype.end = function(e, t) {
                    void 0 === t && (t = {}), d() && O[e] && (c.mark("mark_" + e + "_end"), delete O[e], T(e, w(function(e) {
                        c.measure(e, "mark_" + e + "_start", "mark_" + e + "_end");
                        var t = c.getEntriesByName(e).pop();
                        return t && "measure" === t.entryType ? t.duration : -1
                    }(e)), t))
                }, e.prototype.endPaint = function(e, t) {
                    var n = this;
                    setTimeout((function() {
                        n.end(e, t)
                    }))
                }, e.prototype.clear = function(e) {
                    delete O[e], c.clearMarks && (c.clearMarks("mark_" + e + "_start"), c.clearMarks("mark_" + e + "_end"))
                }, e
            }();
        t.default = G
    },
    NthX: function(e, t, n) {
        e.exports = n("eEQR")
    },
    arkH: function(e, t) {
        var n = {
            utf8: {
                stringToBytes: function(e) {
                    return n.bin.stringToBytes(unescape(encodeURIComponent(e)))
                },
                bytesToString: function(e) {
                    return decodeURIComponent(escape(n.bin.bytesToString(e)))
                }
            },
            bin: {
                stringToBytes: function(e) {
                    for (var t = [], n = 0; n < e.length; n++) t.push(255 & e.charCodeAt(n));
                    return t
                },
                bytesToString: function(e) {
                    for (var t = [], n = 0; n < e.length; n++) t.push(String.fromCharCode(e[n]));
                    return t.join("")
                }
            }
        };
        e.exports = n
    },
    dJh7: function(e, t, n) {
        "use strict";
        n.r(t);
        let r, i;
        const a = new WeakMap,
            o = new WeakMap,
            s = new WeakMap,
            c = new WeakMap,
            u = new WeakMap;
        let l = {
            get(e, t, n) {
                if (e instanceof IDBTransaction) {
                    if ("done" === t) return o.get(e);
                    if ("objectStoreNames" === t) return e.objectStoreNames || s.get(e);
                    if ("store" === t) return n.objectStoreNames[1] ? void 0 : n.objectStore(n.objectStoreNames[0])
                }
                return p(e[t])
            },
            set: (e, t, n) => (e[t] = n, !0),
            has: (e, t) => e instanceof IDBTransaction && ("done" === t || "store" === t) || t in e
        };

        function d(e) {
            return e !== IDBDatabase.prototype.transaction || "objectStoreNames" in IDBTransaction.prototype ? (i || (i = [IDBCursor.prototype.advance, IDBCursor.prototype.continue, IDBCursor.prototype.continuePrimaryKey])).includes(e) ? function(...t) {
                return e.apply(m(this), t), p(a.get(this))
            } : function(...t) {
                return p(e.apply(m(this), t))
            } : function(t, ...n) {
                const r = e.call(m(this), t, ...n);
                return s.set(r, t.sort ? t.sort() : [t]), p(r)
            }
        }

        function f(e) {
            return "function" === typeof e ? d(e) : (e instanceof IDBTransaction && function(e) {
                if (o.has(e)) return;
                const t = new Promise((t, n) => {
                    const r = () => {
                            e.removeEventListener("complete", i), e.removeEventListener("error", a), e.removeEventListener("abort", a)
                        },
                        i = () => {
                            t(), r()
                        },
                        a = () => {
                            n(e.error || new DOMException("AbortError", "AbortError")), r()
                        };
                    e.addEventListener("complete", i), e.addEventListener("error", a), e.addEventListener("abort", a)
                });
                o.set(e, t)
            }(e), t = e, (r || (r = [IDBDatabase, IDBObjectStore, IDBIndex, IDBCursor, IDBTransaction])).some(e => t instanceof e) ? new Proxy(e, l) : e);
            var t
        }

        function p(e) {
            if (e instanceof IDBRequest) return function(e) {
                const t = new Promise((t, n) => {
                    const r = () => {
                            e.removeEventListener("success", i), e.removeEventListener("error", a)
                        },
                        i = () => {
                            t(p(e.result)), r()
                        },
                        a = () => {
                            n(e.error), r()
                        };
                    e.addEventListener("success", i), e.addEventListener("error", a)
                });
                return t.then(t => {
                    t instanceof IDBCursor && a.set(t, e)
                }).catch(() => {}), u.set(t, e), t
            }(e);
            if (c.has(e)) return c.get(e);
            const t = f(e);
            return t !== e && (c.set(e, t), u.set(t, e)), t
        }
        const m = e => u.get(e);

        function v(e, t, {
            blocked: n,
            upgrade: r,
            blocking: i,
            terminated: a
        } = {}) {
            const o = indexedDB.open(e, t),
                s = p(o);
            return r && o.addEventListener("upgradeneeded", e => {
                r(p(o.result), e.oldVersion, e.newVersion, p(o.transaction))
            }), n && o.addEventListener("blocked", () => n()), s.then(e => {
                a && e.addEventListener("close", () => a()), i && e.addEventListener("versionchange", () => i())
            }).catch(() => {}), s
        }
        const h = ["get", "getKey", "getAll", "getAllKeys", "count"],
            g = ["put", "add", "delete", "clear"],
            w = new Map;

        function b(e, t) {
            if (!(e instanceof IDBDatabase) || t in e || "string" !== typeof t) return;
            if (w.get(t)) return w.get(t);
            const n = t.replace(/FromIndex$/, ""),
                r = t !== n,
                i = g.includes(n);
            if (!(n in (r ? IDBIndex : IDBObjectStore).prototype) || !i && !h.includes(n)) return;
            const a = async function(e, ...t) {
                const a = this.transaction(e, i ? "readwrite" : "readonly");
                let o = a.store;
                return r && (o = o.index(t.shift())), (await Promise.all([o[n](...t), i && a.done]))[0]
            };
            return w.set(t, a), a
        }
        let y;
        l = (e => ({ ...e,
                get: (t, n, r) => b(t, n) || e.get(t, n, r),
                has: (t, n) => !!b(t, n) || e.has(t, n)
            }))(l),
            function(e) {
                e.api = "api", e.font = "font", e.html = "html", e.img = "img", e.js = "js", e.unknown = "unknown"
            }(y || (y = {}));
        const k = "cb-keyval",
            _ = v("cb-sw-keyval", 1, {
                upgrade(e) {
                    e.createObjectStore(k)
                }
            });
        try {
            ! function(e, {
                blocked: t
            } = {}) {
                const n = indexedDB.deleteDatabase(e);
                t && n.addEventListener("blocked", () => t()), p(n).then(() => {})
            }("cb-cdn-assets-keyval")
        } catch (En) {}
        const x = (e, t) => !(!e || !e.objectStoreNames) && (!!e.objectStoreNames.contains && e.objectStoreNames.contains(t)),
            E = (e, t) => e.pathname.startsWith("/api/") || e.pathname.startsWith("/graphql/") ? y.api : e.pathname.indexOf(".") < 0 && e.host === t ? y.html : e.pathname.indexOf(".js") > 0 ? y.js : e.pathname.endsWith(".avif") || e.pathname.endsWith(".gif") || e.pathname.endsWith(".jpg") || e.pathname.endsWith(".png") || e.pathname.endsWith(".svg") || e.pathname.endsWith(".webp") ? y.img : e.pathname.endsWith(".woff2") ? y.font : y.unknown;
        var S, T, I, O, N, j, P, A, D, L, B, M;
        ! function(e) {
            e.fbclid = "fbclid", e.gclid = "gclid", e.utm_source = "utm_source", e.utm_medium = "utm_medium", e.utm_campaign = "utm_campaign", e.utm_term = "utm_term", e.utm_content = "utm_content"
        }(S || (S = {})),
        function(e) {
            e.low = "low", e.high = "high"
        }(T || (T = {})),
        function(e) {
            e.count = "count", e.rate = "rate", e.gauge = "gauge", e.distribution = "distribution", e.histogram = "histogram"
        }(I || (I = {})),
        function(e) {
            e.user = "user", e.device = "device"
        }(O || (O = {})),
        function(e) {
            e.unknown = "unknown", e.banner = "banner", e.button = "button", e.card = "card", e.chart = "chart", e.dropdown = "dropdown", e.link = "link", e.page = "page", e.modal = "modal", e.table = "table", e.search_bar = "search_bar", e.text = "text", e.tray = "tray"
        }(N || (N = {})),
        function(e) {
            e.unknown = "unknown", e.blur = "blur", e.click = "click", e.change = "change", e.focus = "focus", e.hover = "hover", e.select = "select", e.measurement = "measurement", e.move = "move", e.render = "render", e.scroll = "scroll", e.view = "view", e.search = "search"
        }(j || (j = {})),
        function(e) {
            e.unknown = "unknown", e.web = "web", e.android = "android", e.ios = "ios", e.mobile_web = "mobile_web", e.server = "server", e.windows = "windows", e.macos = "macos"
        }(P || (P = {})),
        function(e) {
            e.web = "Web", e.ios = "iOS", e.android = "Android"
        }(A || (A = {})),
        function(e) {
            e[e.notLoggedIn = 0] = "notLoggedIn", e[e.loggedIn = 1] = "loggedIn"
        }(D || (D = {})),
        function(e) {
            e.ac = "ac", e.af = "af", e.ah = "ah", e.al = "al", e.am = "am", e.ar = "ar", e.as = "as"
        }(L || (L = {})),
        function(e) {
            e.pv = "pv"
        }(B || (B = {})),
        function(e) {
            e.xs = "xs", e.s = "s", e.m = "m", e.l = "l", e.xl = "xl", e.xxl = "xxl"
        }(M || (M = {}));
        const R = "unknown",
            q = {
                browserName: R,
                isAuthed: !1,
                osName: R,
                platform: P.server
            },
            C = e => ("" + e).replace(/\s/g, "_").toLowerCase(),
            U = e => {
                Object.assign(q, e)
            };
        var z = n("dkYM").a,
            F = "analytics-db",
            K = "Analytics SDK:",
            W = Object.values(S),
            V = "db6d70de-c5ed-4a26-bddb-05191acbc278",
            G = "4164ca36-1d78-4b7f-bbae-3c59d97ca3d9",
            Q = {
                ttfb: {
                    eventName: "perf_time_to_first_byte",
                    loggingId: "7e7a84f5-f1ab-4769-b322-52e198483f85"
                },
                networkInformation: {
                    eventName: "perf_network_information",
                    loggingId: "9229ea1a-2d1e-48e3-b832-669357bcf327"
                },
                storageEstimate: {
                    eventName: "perf_storage_estimate",
                    loggingId: "fef62231-45b9-4796-af8a-7520c3b8dc5d"
                },
                fcp: {
                    eventName: "perf_first_contentful_paint",
                    loggingId: "d5f76a1c-5210-4e2f-9d44-f6b28ce57a6c"
                },
                fid: {
                    eventName: "perf_first_input_delay",
                    loggingId: "b59e6a00-55d4-400e-a09d-f2ae44e4a5fe"
                },
                lcp: {
                    eventName: "perf_largest_contentful_paint",
                    loggingId: "efa86d13-ce1a-47b5-b130-918c028b58ae"
                },
                cls: {
                    eventName: "perf_cumulative_layout_shift",
                    loggingId: "5280dc84-cb97-4587-9904-df9eda8f118e"
                },
                tbt: {
                    eventName: "perf_total_blocking_time",
                    loggingId: "69631829-d3e7-4f8f-8e0e-2ae3be067e0f"
                }
            },
            H = {
                authCookie: "logged_in",
                amplitudeApiKey: "",
                batchEventsPeriod: 5e3,
                batchEventsThreshold: 30,
                batchMetricsPeriod: 5e3,
                batchMetricsThreshold: 30,
                headers: {},
                interactionManager: null,
                isAlwaysAuthed: !1,
                isProd: !1,
                onError: function(e, t) {
                    console.error(K, e, t)
                },
                platform: P.unknown,
                projectName: "",
                ricTimeoutScheduleEvent: 1e3,
                ricTimeoutSetDevice: 500,
                showDebugLogging: !1,
                trackUserId: !1,
                version: null
            },
            J = function(e) {
                Object.assign(H, e)
            },
            X = function() {
                return "android" === H.platform
            },
            Z = function() {
                return "ios" === H.platform
            },
            $ = function() {
                return ["web", "mobile_web"].includes(H.platform)
            },
            Y = function(e) {
                if ($() && navigator && "serviceWorker" in navigator && navigator.serviceWorker.controller) try {
                    navigator.serviceWorker.controller.postMessage(e)
                } catch (t) {
                    H.onError(t)
                }
            },
            ee = {
                eventId: 0,
                sequenceNumber: 0,
                sessionId: 0,
                lastEventTime: 0,
                sessionStart: 0,
                sessionUUID: null,
                userId: null,
                ac: 0,
                af: 0,
                ah: 0,
                al: 0,
                am: 0,
                ar: 0,
                as: 0,
                pv: 0
            },
            te = function(e) {
                Object.assign(ee, e)
            },
            ne = function() {
                return (new Date).getTime()
            },
            re = {
                timeStart: ne(),
                timeOnPagePath: 0,
                timeOnPageKey: 0,
                prevTimeOnPagePath: 0,
                prevTimeOnPageKey: 0,
                sessionDuration: 0,
                sessionEnd: 0,
                sessionStart: 0,
                prevSessionDuration: 0
            },
            ie = function(e) {
                Object.assign(re, e)
            },
            ae = Object.values(j),
            oe = Object.values(N),
            se = function(e) {
                return ae.includes(e) ? e : j.unknown
            },
            ce = function(e) {
                return oe.includes(e) ? e : N.unknown
            },
            ue = function() {
                var e = H.platform,
                    t = void 0 === e ? P.unknown : e;
                return t === P.web && window.matchMedia("(max-width: 430px)").matches ? P.mobile_web : t
            },
            le = function(e, t, n) {
                return {
                    auth: me() ? D.loggedIn : D.notLoggedIn,
                    action: se(e),
                    component_type: ce(t),
                    logging_id: "string" === typeof n ? n : null,
                    platform: H.platform,
                    project_name: H.projectName
                }
            },
            de = {
                amplitudeOSName: null,
                amplitudeOSVersion: null,
                amplitudeDeviceModel: null,
                amplitudePlatform: null,
                browserName: null,
                browserMajor: null,
                osName: null,
                userAgent: null
            },
            fe = {
                countryCode: null,
                deviceId: null,
                isOptOut: !1,
                languageCode: null,
                locale: null,
                jwt: null,
                userId: null
            },
            pe = function e(t) {
                return t ? (t ^ 16 * Math.random() >> t / 4).toString(16) : "10000000-1000-4000-8000-100000000000".replace(/[018]/g, e)
            },
            me = function() {
                return H.isAlwaysAuthed || !!fe.userId
            },
            ve = function() {
                var e = {};
                return fe.countryCode && (e.country_code = fe.countryCode), e
            },
            he = function(e) {
                Object.assign(fe, e), $() && Y({
                    identity: {
                        isAuthed: !!fe.userId,
                        locale: fe.locale || null
                    }
                })
            },
            ge = function() {
                J({
                    platform: ue()
                }), $() && Y({
                    config: {
                        platform: H.platform
                    }
                })
            },
            we = function() {
                performance.mark && performance.mark("ua_parser_start");
                var e = new(n("1SjT"))(de.userAgent).getResult();
                de.browserName = e.browser.name || null, de.browserMajor = e.browser.major || null, de.osName = e.os.name || null, de.amplitudeOSName = de.browserName, de.amplitudeOSVersion = de.browserMajor, de.amplitudeDeviceModel = de.osName, Y({
                    device: {
                        browserName: de.browserName,
                        osName: de.osName
                    }
                }), performance.mark && (performance.mark("ua_parser_end"), performance.measure("ua_parser", "ua_parser_start", "ua_parser_end"))
            },
            be = {
                breadcrumbs: [],
                initialUAAData: {},
                pageKey: "",
                pageKeyRegex: {},
                pagePath: "",
                prevPageKey: "",
                prevPagePath: ""
            },
            ye = function() {
                var e, t;
                return null != (e = null === (t = document) || void 0 === t ? void 0 : t.referrer) ? e : ""
            },
            ke = function() {
                if (!$()) return be.initialUAAData;
                if (Object.keys(be.initialUAAData).length > 0) return be.initialUAAData;
                var e = new URLSearchParams(Ee()),
                    t = _e(e);
                return be.initialUAAData = Object.assign({}, t, function() {
                    var e = ye();
                    if (!e) return {};
                    var t = new URL(e);
                    return t.hostname === xe() ? {} : {
                        referrer: e,
                        referring_domain: t.hostname
                    }
                }()), be.initialUAAData
            },
            _e = function(e) {
                var t = {};
                return W.forEach((function(n) {
                    e.has(n) && (t[n] = (e.get(n) || "").toLowerCase())
                })), t
            },
            xe = function() {
                var e, t;
                return (null === (e = window) || void 0 === e || null === (t = e.location) || void 0 === t ? void 0 : t.hostname) || ""
            },
            Ee = function() {
                var e, t;
                return (null === (e = window) || void 0 === e || null === (t = e.location) || void 0 === t ? void 0 : t.search) || ""
            },
            Se = function() {
                var e, t;
                return (null === (e = window) || void 0 === e || null === (t = e.location) || void 0 === t ? void 0 : t.pathname) || ""
            },
            Te = function() {
                var e = Se() + Ee();
                e && e !== be.pagePath && (e !== be.pagePath && Ie(), be.pagePath = e, be.pageKeyRegex && Object.keys(be.pageKeyRegex).some((function(e) {
                    if (be.pageKeyRegex[e].test(be.pagePath)) return be.pageKey = e, !0
                })))
            },
            Ie = function() {
                if ($()) {
                    var e = ye();
                    if (!be.prevPagePath && e) {
                        var t = new URL(e);
                        if (t.hostname === xe()) return void(be.prevPagePath = t.pathname)
                    }
                }
                be.prevPagePath = be.pagePath, be.prevPageKey = be.pageKey
            },
            Oe = {
                blacklistRegex: [],
                isEnabled: !1
            },
            Ne = function(e) {
                Oe.isEnabled && (Te(), Object.assign(e, {
                    page_key: be.pageKey,
                    page_path: be.pagePath,
                    prev_page_key: be.prevPageKey,
                    prev_page_path: be.prevPagePath
                }))
            },
            je = {
                eventsQueue: [],
                eventsScheduled: !1,
                metricsQueue: [],
                metricsScheduled: !1
            },
            Pe = "application/x-www-form-urlencoded; charset=UTF-8",
            Ae = function(e) {
                var t = e.data,
                    n = e.importance,
                    r = e.isJSON,
                    i = e.onError,
                    a = e.url,
                    o = r ? "application/json" : Pe,
                    s = n || T.low,
                    c = r ? JSON.stringify(t) : new URLSearchParams(t).toString();
                if ($() && !r && "sendBeacon" in navigator && s === T.low) {
                    var u = new Blob([new URLSearchParams(t).toString()], {
                        type: Pe
                    });
                    navigator.sendBeacon(a, u)
                } else if ($() && !r) {
                    var l = new XMLHttpRequest;
                    l.open("POST", a, !0), Object.keys(H.headers).forEach((function(e) {
                        l.setRequestHeader(e, H.headers[e])
                    })), l.setRequestHeader("Content-Type", Pe), fe.jwt && l.setRequestHeader("authorization", "Bearer " + fe.jwt), l.send(c)
                } else {
                    var d = Object.assign({}, H.headers, {
                        "Content-Type": o
                    });
                    fe.jwt && (d.Authorization = "Bearer " + fe.jwt), fetch(a, {
                        method: "POST",
                        mode: "no-cors",
                        headers: d,
                        body: c
                    }).catch((function(e) {
                        i(e, {
                            context: "AnalyticsSDKApiError"
                        })
                    }))
                }
            },
            De = "rgb(5,177,105)",
            Le = 11,
            Be = function(e) {
                var t = e.metricName,
                    n = e.data;
                if (H.showDebugLogging && console) {
                    var r = "color:" + De + ";font-size:" + Le + "px;";
                    console.group("%c Analytics SDK:", r, t), n.forEach((function(e) {
                        e.event_type ? console.log(e.event_type, e) : console.log(e)
                    })), console.groupEnd()
                }
            },
            Me = function(e) {
                var t = e.metricName,
                    n = e.data;
                if (H.showDebugLogging && console) {
                    var r = "color:" + De + ";font-size:" + Le + "px;";
                    console.log("%c Analytics SDK:", r, t, n)
                }
            },
            Re = function(e) {
                return e.map((function(e) {
                    return function(e) {
                        var t = e.tags || {};
                        return {
                            metric_name: e.metricName,
                            page_path: e.pagePath || null,
                            value: e.value,
                            tags: Object.assign({
                                authed: me() ? "true" : "false",
                                platform: H.platform,
                                locale: fe.locale || "unknown"
                            }, t, {
                                project_name: H.projectName,
                                version_name: H.version || null
                            }),
                            type: e.metricType
                        }
                    }(e)
                }))
            },
            qe = n("NthX"),
            Ce = n.n(qe);

        function Ue(e, t, n, r, i, a, o) {
            try {
                var s = e[a](o),
                    c = s.value
            } catch (u) {
                return void n(u)
            }
            s.done ? t(c) : Promise.resolve(c).then(r, i)
        }

        function ze(e) {
            return function() {
                var t = this,
                    n = arguments;
                return new Promise((function(r, i) {
                    var a = e.apply(t, n);

                    function o(e) {
                        Ue(a, r, i, o, s, "next", e)
                    }

                    function s(e) {
                        Ue(a, r, i, o, s, "throw", e)
                    }
                    o(void 0)
                }))
            }
        }
        var Fe = {
                ac: 0,
                af: 0,
                ah: 0,
                al: 0,
                am: 0,
                ar: 0,
                as: 0,
                pv: 0,
                sqs: 0
            },
            Ke = {
                ac: 20,
                af: 5,
                ah: 1,
                al: 1,
                am: 0,
                ar: 10,
                as: 20
            },
            We = {
                pv: 25
            },
            Ve = 15,
            Ge = 60,
            Qe = 240,
            He = 960,
            Je = 3840,
            Xe = {
                xs: 0,
                s: 1,
                m: 1,
                l: 2,
                xl: 2,
                xxl: 2
            },
            Ze = function(e) {
                Object.assign(Fe, e)
            },
            $e = function(e) {
                ! function(e) {
                    switch (e.action) {
                        case j.click:
                            Fe.ac += 1;
                            break;
                        case j.focus:
                            Fe.af += 1;
                            break;
                        case j.hover:
                            Fe.ah += 1;
                            break;
                        case j.move:
                            Fe.am += 1;
                            break;
                        case j.scroll:
                            Fe.al += 1;
                            break;
                        case j.search:
                            Fe.ar += 1;
                            break;
                        case j.select:
                            Fe.as += 1
                    }
                }(e), e.logging_id !== V ? e.logging_id === G && (! function(e) {
                    if (e.session_rank) {
                        var t = e.session_rank;
                        Object.values(L).forEach((function(e) {
                            Fe.sqs += Fe[e] * Ke[e]
                        })), Object.values(B).forEach((function(e) {
                            Fe.sqs += Fe[e] * We[e]
                        })), Fe.sqs = Fe.sqs * Xe[t]
                    }
                }(e), Object.assign(e, Fe), Ze({
                    ac: 0,
                    af: 0,
                    ah: 0,
                    al: 0,
                    am: 0,
                    ar: 0,
                    as: 0,
                    pv: 0,
                    sqs: 0
                })) : Fe.pv += 1
            },
            Ye = function(e) {
                return e - ee.lastEventTime > 18e5
            },
            et = function() {
                if (ee.lastEventTime && re.sessionStart && Ye(ne())) {
                    var e = Math.round((ee.lastEventTime - re.sessionStart) / 1e3);
                    if (!(e < 1 || e > 36e3)) {
                        var t = function(e) {
                            return e < Ve ? M.xs : e < Ge ? M.s : e < Qe ? M.m : e < He ? M.l : e < Je ? M.xl : M.xxl
                        }(e);
                        Pt("session_duration", {
                            action: j.measurement,
                            componentType: N.page,
                            loggingId: G,
                            session_duration: e,
                            session_end: ee.lastEventTime,
                            session_start: re.sessionStart,
                            session_rank: t
                        })
                    }
                }
            },
            tt = {
                isReady: !1,
                idbKeyval: null
            },
            nt = function(e) {
                Object.assign(tt, e)
            },
            rt = {},
            it = function() {
                var e = ze(Ce.a.mark((function e() {
                    return Ce.a.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (tt.idbKeyval) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return", Promise.resolve(null));
                            case 2:
                                return e.prev = 2, e.next = 5, tt.idbKeyval.get(F);
                            case 5:
                                return e.abrupt("return", e.sent);
                            case 8:
                                return e.prev = 8, e.t0 = e.catch(2), H.onError(new Error("IndexedDB:Get:InternalError")), e.abrupt("return", Promise.resolve(null));
                            case 12:
                            case "end":
                                return e.stop()
                        }
                    }), e, null, [
                        [2, 8]
                    ])
                })));
                return function() {
                    return e.apply(this, arguments)
                }
            }(),
            at = function(e) {
                if (tt.idbKeyval) try {
                    tt.idbKeyval.set(F, e)
                } catch (t) {
                    H.onError(new Error("IndexedDB:Set:InternalError"))
                }
            },
            ot = [],
            st = [],
            ct = function() {
                var e = ze(Ce.a.mark((function e() {
                    var t;
                    return Ce.a.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, it();
                            case 2:
                                if (t = e.sent, nt({
                                        isReady: !0
                                    }), ut(), t) {
                                    e.next = 7;
                                    break
                                }
                                return e.abrupt("return");
                            case 7:
                                lt(), te({
                                    eventId: t.eventId || ee.eventId,
                                    sequenceNumber: t.sequenceNumber || ee.sequenceNumber,
                                    sessionId: t.sessionId || ee.sessionId,
                                    lastEventTime: t.lastEventTime || ee.lastEventTime,
                                    sessionUUID: t.sessionUUID || ee.sessionUUID
                                }), ie({
                                    sessionStart: t.sessionStart || ee.sessionStart
                                }), Ze({
                                    ac: t.ac || Fe.ac,
                                    af: t.af || Fe.af,
                                    ah: t.ah || Fe.ah,
                                    al: t.al || Fe.al,
                                    am: t.am || Fe.am,
                                    ar: t.ar || Fe.ar,
                                    as: t.as || Fe.as,
                                    pv: t.pv || Fe.pv
                                }), H.trackUserId && he({
                                    userId: t.userId || fe.userId
                                }), et(), Me({
                                    metricName: "Initialized Analytics IndexedDB:",
                                    data: t
                                });
                            case 14:
                            case "end":
                                return e.stop()
                        }
                    }), e)
                })));
                return function() {
                    return e.apply(this, arguments)
                }
            }(),
            ut = function() {
                var e = ot.shift();
                e && e()
            },
            lt = function() {
                var e = st.shift();
                e && e()
            },
            dt = function() {
                "server" !== H.platform && (te({
                    sessionStart: re.sessionStart,
                    ac: Fe.ac,
                    af: Fe.af,
                    ah: Fe.ah,
                    al: Fe.al,
                    am: Fe.am,
                    ar: Fe.ar,
                    as: Fe.as,
                    pv: Fe.pv
                }), fe.userId && te({
                    userId: fe.userId
                }), at(ee))
            },
            ft = function(e) {
                $e(e);
                var t = e.event_type;
                delete e.event_type;
                var n = e.deviceId ? e.deviceId : null,
                    r = e.timestamp;
                return delete e.timestamp, te({
                        eventId: ee.eventId + 1
                    }), te({
                        sequenceNumber: ee.sequenceNumber + 1
                    }),
                    function() {
                        var e = ne();
                        ee.sessionId && ee.lastEventTime && !Ye(e) || (ee.sessionId = e, ee.sessionUUID = pe(), ie({
                            sessionStart: e
                        }), Me({
                            metricName: "Started new session:",
                            data: {
                                persistentData: ee,
                                timeStone: re
                            }
                        })), ee.lastEventTime = e
                    }(), dt(), {
                        device_id: fe.deviceId || n || null,
                        user_id: fe.userId,
                        timestamp: r,
                        event_id: ee.eventId,
                        session_id: ee.sessionId || -1,
                        event_type: t,
                        version_name: H.version || null,
                        platform: de.amplitudePlatform,
                        os_name: de.amplitudeOSName,
                        os_version: de.amplitudeOSVersion,
                        device_model: de.amplitudeDeviceModel,
                        language: fe.languageCode,
                        event_properties: e,
                        user_properties: ve(),
                        uuid: pe(),
                        library: {
                            name: "@cb/analytics",
                            version: z
                        },
                        sequence_number: ee.sequenceNumber,
                        user_agent: de.userAgent
                    }
            },
            pt = function(e) {
                return e.map((function(e) {
                    return ft(e)
                }))
            },
            mt = function(e) {
                var t;
                $() && (null === (t = window) || void 0 === t ? void 0 : t.requestIdleCallback) ? window.requestIdleCallback(e, {
                    timeout: H.ricTimeoutScheduleEvent
                }) : (X() || Z()) && H.interactionManager ? H.interactionManager.runAfterInteractions(e) : e()
            },
            vt = n("w1Rh"),
            ht = n.n(vt),
            gt = function(e, t, n) {
                var r = e || "";
                return ht()("2" + r + t + n)
            };

        function wt(e, t) {
            (null == t || t > e.length) && (t = e.length);
            for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
            return r
        }

        function bt(e, t) {
            var n;
            if ("undefined" === typeof Symbol || null == e[Symbol.iterator]) {
                if (Array.isArray(e) || (n = function(e, t) {
                        if (e) {
                            if ("string" === typeof e) return wt(e, t);
                            var n = Object.prototype.toString.call(e).slice(8, -1);
                            return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? wt(e, t) : void 0
                        }
                    }(e)) || t && e && "number" === typeof e.length) {
                    n && (e = n);
                    var r = 0;
                    return function() {
                        return r >= e.length ? {
                            done: !0
                        } : {
                            done: !1,
                            value: e[r++]
                        }
                    }
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }
            return (n = e[Symbol.iterator]()).next.bind(n)
        }

        function yt(e, t) {
            e.prototype = Object.create(t.prototype), e.prototype.constructor = e, e.__proto__ = t
        }

        function kt(e) {
            return (kt = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                return e.__proto__ || Object.getPrototypeOf(e)
            })(e)
        }

        function _t(e, t) {
            return (_t = Object.setPrototypeOf || function(e, t) {
                return e.__proto__ = t, e
            })(e, t)
        }

        function xt() {
            if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" === typeof Proxy) return !0;
            try {
                return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
            } catch (e) {
                return !1
            }
        }

        function Et(e, t, n) {
            return (Et = xt() ? Reflect.construct : function(e, t, n) {
                var r = [null];
                r.push.apply(r, t);
                var i = new(Function.bind.apply(e, r));
                return n && _t(i, n.prototype), i
            }).apply(null, arguments)
        }

        function St(e) {
            var t = "function" === typeof Map ? new Map : void 0;
            return (St = function(e) {
                if (null === e || (n = e, -1 === Function.toString.call(n).indexOf("[native code]"))) return e;
                var n;
                if ("function" !== typeof e) throw new TypeError("Super expression must either be null or a function");
                if ("undefined" !== typeof t) {
                    if (t.has(e)) return t.get(e);
                    t.set(e, r)
                }

                function r() {
                    return Et(e, arguments, kt(this).constructor)
                }
                return r.prototype = Object.create(e.prototype, {
                    constructor: {
                        value: r,
                        enumerable: !1,
                        writable: !0,
                        configurable: !0
                    }
                }), _t(r, e)
            })(e)
        }
        var Tt = function(e) {
                function t(t) {
                    var n;
                    return (n = e.call(this, t) || this).name = "CircularJsonReference", n.message = t, "function" === typeof Error.captureStackTrace ? Error.captureStackTrace(function(e) {
                        if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                        return e
                    }(n), n.constructor) : n.stack = new Error(t).stack, n
                }
                return yt(t, e), t
            }(St(Error)),
            It = function(e) {
                function t() {
                    for (var t, n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
                    return (t = e.call.apply(e, [this].concat(r)) || this).name = "DomReferenceInAnalyticsEvent", t
                }
                return yt(t, e), t
            }(Tt),
            Ot = function(e, t) {
                var n;
                (void 0 === t && (t = T.low), e && je.eventsQueue.push(e), tt.isReady) && (!H.trackUserId || fe.userId ? (t === T.high || (n = Nt, 0 !== je.eventsQueue.length && (je.eventsQueue.length >= H.batchEventsThreshold || (je.eventsScheduled || (je.eventsScheduled = !0, setTimeout((function() {
                    je.eventsScheduled = !1, n(pt(je.eventsQueue)), je.eventsQueue = []
                }), H.batchEventsPeriod)), 0)))) && jt() : je.eventsQueue.length > 10 && (H.trackUserId = !1, H.onError(new Error("userId not set in Logged-in"))))
            },
            Nt = function(e, t) {
                if (void 0 === t && (t = T.low), !fe.isOptOut && 0 !== e.length) {
                    var n;
                    try {
                        n = JSON.stringify(e)
                    } catch (d) {
                        var r = e.map((function(e) {
                                return e.event_type
                            })).join(", "),
                            i = function(e) {
                                try {
                                    for (var t, n = [], r = bt(e); !(t = r()).done;) {
                                        var i = t.value,
                                            a = Object.assign({}, i);
                                        i.event_properties && (a.event_properties = Object.assign({}, a.event_properties, {
                                            currentTarget: null,
                                            target: null,
                                            relatedTarget: null,
                                            _dispatchInstances: null,
                                            _targetInst: null,
                                            view: (o = i.event_properties.view, ["string", "number", "boolean"].includes(typeof o) ? i.event_properties.view : null)
                                        })), n.push(a)
                                    }
                                    return [!0, JSON.stringify(n)]
                                } catch (d) {
                                    return [!1, ""]
                                }
                                var o
                            }(e),
                            a = i[0],
                            o = i[1];
                        if (!a) return void H.onError(new Tt(d.message), {
                            listEventType: r
                        });
                        n = o, H.onError(new It("Found DOM element reference"), {
                            listEventType: r,
                            stringifiedEventData: n
                        })
                    }
                    var s = ne().toString(),
                        c = {
                            e: n,
                            v: "2",
                            upload_time: s
                        },
                        u = Object.assign({}, c, {
                            client: H.amplitudeApiKey,
                            checksum: gt(H.amplitudeApiKey, n, s)
                        }),
                        l = H.isProd ? "events-service.coinbase.com/amp" : "analytics-service-dev.cbhq.net/amp";
                    Ae({
                        url: "https://" + l,
                        data: u,
                        importance: t,
                        onError: H.onError
                    }), Be({
                        metricName: "Batch Events",
                        data: e
                    })
                }
            },
            jt = function() {
                var e;
                Nt(pt(je.eventsQueue)), e = {
                    eventsQueue: []
                }, Object.assign(je, e)
            },
            Pt = function(e, t, n) {
                if (void 0 === n && (n = T.low), !fe.isOptOut)
                    if (H.platform !== P.unknown) {
                        var r = function(e) {
                            var t = ne();
                            if (!e) return H.onError(new Error("missing logData")), Object.assign({}, le(j.unknown, N.unknown, null), {
                                locale: fe.locale,
                                session_uuid: ee.sessionUUID,
                                timestamp: t,
                                time_start: re.timeStart
                            });
                            var n = Object.assign({}, e, le(e.action, e.componentType, e.loggingId), {
                                locale: fe.locale,
                                session_uuid: ee.sessionUUID,
                                timestamp: t,
                                time_start: re.timeStart
                            });
                            return delete n.componentType, delete n.loggingId, n
                        }(t);
                        Ne(r),
                            function(e) {
                                $() && Object.assign(e, ke())
                            }(r), r.has_double_fired = !1, r.event_type = e, n === T.high ? Ot(r, n) : mt((function() {
                                Ot(r)
                            }))
                    } else H.onError(new Error("SDK platform not initialized"))
            },
            At = function(e) {
                var t;
                if (H.platform !== P.unknown && (P.server !== H.platform && !e.pagePath && be.pagePath && (e.pagePath = be.pagePath), je.metricsQueue.push(e), t = Dt, 0 !== je.metricsQueue.length && (je.metricsQueue.length >= H.batchMetricsThreshold || (je.metricsScheduled || (je.metricsScheduled = !0, setTimeout((function() {
                        je.metricsScheduled = !1, t(Re(je.metricsQueue)), je.metricsQueue = []
                    }), H.batchMetricsPeriod)), 0)))) {
                    var n = Re(je.metricsQueue);
                    Dt(n), je.metricsQueue = []
                }
            },
            Dt = function(e) {
                var t = H.isProd ? "events-service.coinbase.com/metrics" : "analytics-service-dev.cbhq.net/metrics";
                mt((function() {
                    Ae({
                        url: "https://" + t,
                        data: {
                            metrics: e
                        },
                        isJSON: !0,
                        onError: H.onError
                    })
                })), Be({
                    metricName: "Batch Metrics",
                    data: e
                })
            },
            Lt = !1,
            Bt = !1,
            Mt = function(e) {
                Lt = !e.persisted
            },
            Rt = function(e, t, n) {
                void 0 === t && (t = "hidden"), void 0 === n && (n = !1), Bt || (addEventListener("pagehide", Mt), addEventListener("beforeunload", (function() {})), Bt = !0), addEventListener("visibilitychange", (function(n) {
                    var r = n.timeStamp;
                    document.visibilityState === t && e({
                        timeStamp: r,
                        isUnloading: Lt
                    })
                }), {
                    capture: !0,
                    once: n
                })
            },
            qt = function() {
                var e;
                $() && (e = function() {
                    ge()
                }, addEventListener("resize", (function() {
                    requestAnimationFrame((function() {
                        e()
                    }))
                })))
            },
            Ct = {},
            Ut = function() {
                if ($()) try {
                    new(0, n("Ee4y").default)({
                        analyticsTracker: function(e) {
                            var t = e.data,
                                n = e.eventProperties,
                                r = e.metricName,
                                i = e.navigatorInformation,
                                a = e.vitalsScore,
                                o = Q[r];
                            if (o) {
                                var s = (null === i || void 0 === i ? void 0 : i.deviceMemory) || 0,
                                    c = (null === i || void 0 === i ? void 0 : i.hardwareConcurrency) || 0,
                                    u = (null === i || void 0 === i ? void 0 : i.isLowEndDevice) || !1,
                                    l = (null === i || void 0 === i ? void 0 : i.isLowEndExperience) || !1,
                                    d = (null === i || void 0 === i ? void 0 : i.serviceWorkerStatus) || "unsupported",
                                    f = Object.assign({
                                        deviceMemory: s,
                                        hardwareConcurrency: c,
                                        isLowEndDevice: u,
                                        isLowEndExperience: l,
                                        serviceWorkerStatus: d
                                    }, Ct);
                                if ("ttfb" === r) Pt(o.eventName, Object.assign({
                                    action: j.measurement,
                                    componentType: N.page,
                                    loggingId: Q[r].loggingId,
                                    duration: t || null,
                                    vitalsScore: a || null
                                }, f)), At({
                                    metricName: Q.ttfb.eventName,
                                    metricType: I.histogram,
                                    tags: {
                                        service_worker: d,
                                        page_key: be.pageKey || ""
                                    },
                                    value: t
                                }), a && At({
                                    metricName: "perf_web_vitals_ttfb_" + a,
                                    metricType: I.count,
                                    tags: {
                                        service_worker: d,
                                        page_key: be.pageKey || ""
                                    },
                                    value: 1
                                });
                                else if ("networkInformation" === r) t && t.effectiveType && (Ct = t, Pt(o.eventName, {
                                    action: j.measurement,
                                    componentType: N.page,
                                    loggingId: Q.networkInformation.loggingId,
                                    networkInformationDownlink: t.downlink,
                                    networkInformationEffectiveType: t.effectiveType,
                                    networkInformationRtt: t.rtt,
                                    networkInformationSaveData: t.saveData,
                                    navigatorDeviceMemory: s,
                                    navigatorHardwareConcurrency: c
                                }));
                                else if ("storageEstimate" === r) Pt(o.eventName, Object.assign({
                                    action: j.measurement,
                                    componentType: N.page,
                                    loggingId: Q.storageEstimate.loggingId
                                }, t, f)), At({
                                    metricName: "perf_storage_estimate_caches",
                                    metricType: I.histogram,
                                    tags: {
                                        service_worker: d
                                    },
                                    value: t.caches
                                }), At({
                                    metricName: "perf_storage_estimate_indexed_db",
                                    metricType: I.histogram,
                                    tags: {
                                        service_worker: d
                                    },
                                    value: t.indexedDB
                                });
                                else if ("cls" === r) Pt(o.eventName, Object.assign({
                                    action: j.measurement,
                                    componentType: N.page,
                                    loggingId: Q[r].loggingId,
                                    score: 100 * t || null,
                                    vitalsScore: a || null
                                }, f)), a && At({
                                    metricName: "perf_web_vitals_cls_" + a,
                                    metricType: I.count,
                                    tags: {
                                        service_worker: d,
                                        page_key: be.pageKey || ""
                                    },
                                    value: 1
                                });
                                else if ("fid" === r) {
                                    var p = (null === n || void 0 === n ? void 0 : n.performanceEntry) || null,
                                        m = parseInt((null === p || void 0 === p ? void 0 : p.processingStart) || "");
                                    Pt(o.eventName, Object.assign({
                                        action: j.measurement,
                                        componentType: N.page,
                                        duration: t || null,
                                        loggingId: Q[r].loggingId,
                                        processingStart: (null === p || void 0 === p ? void 0 : p.processingStart) ? m : null,
                                        startTime: (null === p || void 0 === p ? void 0 : p.startTime) ? parseInt(p.startTime) : null,
                                        vitalsScore: a || null
                                    }, f)), a && At({
                                        metricName: "perf_web_vitals_fidVitals_" + a,
                                        metricType: I.count,
                                        tags: {
                                            service_worker: d,
                                            page_key: be.pageKey || ""
                                        },
                                        value: 1
                                    })
                                } else Q[r] && (Pt(o.eventName, Object.assign({
                                    action: j.measurement,
                                    componentType: N.page,
                                    loggingId: Q[r].loggingId,
                                    duration: t || null,
                                    vitalsScore: a || null
                                }, f)), a && At({
                                    metricName: "perf_web_vitals_" + r + "_" + a,
                                    metricType: I.count,
                                    tags: {
                                        service_worker: d,
                                        page_key: be.pageKey || ""
                                    },
                                    value: 1
                                }))
                            }
                        },
                        maxMeasureTime: 3e4
                    })
                } catch (e) {
                    return void H.onError(e)
                }
            };
        const zt = "cb-sw",
            Ft = ["cb-cdn-assets", "cb-dynamic-assets", "cb-static-assets", "cb-assets", "cb-third-party"],
            Kt = "www.coinbase.com",
            Wt = {
                isProd: self.location.hostname === Kt,
                platform: P.server,
                projectName: "consumer",
                showDebugLogging: self.location.hostname !== Kt,
                version: "1.1.0"
            };
        J(Wt),
            function() {
                var e, t;
                $() && (fe.languageCode = (null === (e = navigator) || void 0 === e ? void 0 : e.languages[0]) || (null === (t = navigator) || void 0 === t ? void 0 : t.language) || "")
            }(), ge(),
            function() {
                var e;
                if ($() && (null === (e = window) || void 0 === e ? void 0 : e.indexedDB)) {
                    var t = v("keyval-store", 1, {
                        upgrade: function(e) {
                            e.createObjectStore("keyval")
                        }
                    });
                    nt({
                        idbKeyval: {
                            get: function(e) {
                                return ze(Ce.a.mark((function n() {
                                    return Ce.a.wrap((function(n) {
                                        for (;;) switch (n.prev = n.next) {
                                            case 0:
                                                return n.next = 2, t;
                                            case 2:
                                                return n.abrupt("return", n.sent.get("keyval", e));
                                            case 3:
                                            case "end":
                                                return n.stop()
                                        }
                                    }), n)
                                })))()
                            },
                            set: function(e, n) {
                                return ze(Ce.a.mark((function r() {
                                    return Ce.a.wrap((function(r) {
                                        for (;;) switch (r.prev = r.next) {
                                            case 0:
                                                return r.next = 2, t;
                                            case 2:
                                                return r.abrupt("return", r.sent.put("keyval", n, e));
                                            case 3:
                                            case "end":
                                                return r.stop()
                                        }
                                    }), r)
                                })))()
                            },
                            delete: function(e) {
                                return ze(Ce.a.mark((function n() {
                                    return Ce.a.wrap((function(n) {
                                        for (;;) switch (n.prev = n.next) {
                                            case 0:
                                                return n.next = 2, t;
                                            case 2:
                                                return n.abrupt("return", n.sent.delete("keyval", e));
                                            case 3:
                                            case "end":
                                                return n.stop()
                                        }
                                    }), n)
                                })))()
                            },
                            keys: function() {
                                return ze(Ce.a.mark((function e() {
                                    return Ce.a.wrap((function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                return e.next = 2, t;
                                            case 2:
                                                return e.abrupt("return", e.sent.getAllKeys("keyval"));
                                            case 3:
                                            case "end":
                                                return e.stop()
                                        }
                                    }), e)
                                })))()
                            }
                        }
                    })
                } else nt({
                    idbKeyval: {
                        get: function(e) {
                            return ze(Ce.a.mark((function t() {
                                return Ce.a.wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return t.abrupt("return", new Promise((function(t) {
                                                t(rt[e])
                                            })));
                                        case 1:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t)
                            })))()
                        },
                        set: function(e, t) {
                            return ze(Ce.a.mark((function n() {
                                return Ce.a.wrap((function(n) {
                                    for (;;) switch (n.prev = n.next) {
                                        case 0:
                                            return n.abrupt("return", new Promise((function() {
                                                rt[e] = t
                                            })));
                                        case 1:
                                        case "end":
                                            return n.stop()
                                    }
                                }), n)
                            })))()
                        },
                        delete: function(e) {
                            return ze(Ce.a.mark((function t() {
                                return Ce.a.wrap((function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            return t.abrupt("return", new Promise((function() {
                                                delete rt[e]
                                            })));
                                        case 1:
                                        case "end":
                                            return t.stop()
                                    }
                                }), t)
                            })))()
                        },
                        keys: function() {
                            return ze(Ce.a.mark((function e() {
                                return Ce.a.wrap((function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.abrupt("return", new Promise((function(e) {
                                                e(Object.keys(rt))
                                            })));
                                        case 1:
                                        case "end":
                                            return e.stop()
                                    }
                                }), e)
                            })))()
                        }
                    }
                })
            }(), Me({
                metricName: "Initialized Analytics:",
                data: {
                    deviceId: fe.deviceId
                }
            }), ot.push((function() {
                Ot()
            })), ct(),
            function() {
                var e, t;
                $() ? ("requestIdleCallback" in window ? window.requestIdleCallback(we, {
                    timeout: H.ricTimeoutSetDevice
                }) : we(), de.amplitudePlatform = A.web, de.userAgent = (null === (e = window) || void 0 === e || null === (t = e.navigator) || void 0 === t ? void 0 : t.userAgent) || null) : Z() ? de.amplitudePlatform = A.ios : X() && (de.amplitudePlatform = A.android)
            }(), $() && (Rt((function() {
                te({
                    lastEventTime: ne()
                }), dt(), jt()
            }), "hidden"), Rt((function() {
                et()
            }), "visible")), qt(), Ut();
        const Vt = {
                cached_request: 0,
                cached_response: 0,
                fetch_error: 0,
                fetched_response: 0,
                response_clone_error: 0
            },
            Gt = [],
            Qt = [],
            Ht = (e, t, n = {}) => {
                Vt[e] < t ? Yt(e) : ($t(e), "unknown" !== q.browserName ? (Gt.length > 0 && Xt(Gt), At({
                    metricName: "sw_" + e,
                    metricType: I.count,
                    tags: Object.assign({
                        authed: q.isAuthed ? "true" : "false",
                        browser_name: q.browserName,
                        os_name: q.osName,
                        platform: q.platform
                    }, n),
                    value: t
                })) : Gt.push({
                    metricName: e,
                    value: t,
                    tags: n
                }))
            },
            Jt = (e, t, n = {}) => {
                "unknown" !== q.browserName ? (Qt.length > 0 && Zt(Qt), At({
                    metricName: "sw_" + e,
                    metricType: I.histogram,
                    tags: Object.assign({
                        authed: q.isAuthed ? "true" : "false",
                        browser_name: q.browserName,
                        os_name: q.osName,
                        platform: q.platform
                    }, n),
                    value: t
                })) : Qt.push({
                    metricName: e,
                    value: t,
                    tags: n
                })
            },
            Xt = e => {
                const t = e.shift();
                t && t.metricName && Ht(t.metricName, t.value, t.tags), e.length > 0 && Xt(e)
            },
            Zt = e => {
                const t = e.shift();
                t && t.metricName && Jt(t.metricName, t.value, t.tags), e.length > 0 && Zt(e)
            },
            $t = e => {
                Vt[e] = 0
            },
            Yt = e => {
                Vt[e] += 1
            },
            en = () => Date.now(),
            tn = {
                lastExpirationPurge: en(),
                chaosMonkey: 0
            },
            nn = e => {
                Object.assign(tn, e)
            },
            rn = new Set(["assets.coinbase.com", "dynamic-assets.coinbase.com", "static-assets.coinbase.com", "www.googletagmanager.com"]),
            an = {
                api: 0,
                font: 864e5,
                html: 0,
                img: 864e5,
                js: 432e5,
                unknown: 0
            },
            on = {
                api: 0,
                font: 432e6,
                html: 0,
                img: 432e6,
                js: 3456e5,
                unknown: 0
            },
            sn = e => !(!e || 200 !== e.status),
            cn = async (e, t) => {
                try {
                    return await fetch(e.request.url)
                } catch (n) {
                    return (async (e, t, n) => {
                        if (!e) return;
                        const r = await self.clients.get(e);
                        r && r.postMessage(Object.assign({}, n, {
                            msg: t
                        }))
                    })(e.clientId, "fetch_error", {
                        err: n,
                        hostname: t.hostname,
                        pathname: t.pathname
                    }), null
                }
            };
        let un;
        ! function(e) {
            e.api = "api", e.cm = "cm", e.random = "random", e.status = "status"
        }(un || (un = {}));
        const ln = 3e5,
            dn = ["www.coinbase.com"],
            fn = /^[a-z0-9]+$/i,
            pn = {
                api: "",
                cm: "off",
                random: 100,
                status: 401
            },
            mn = e => {
                return pn.api ? e.pathname.indexOf(pn.api) >= 0 : (t = pn.random, 100 * Math.random() < t);
                var t
            },
            vn = (e = self.location.host) => !dn.includes(e),
            hn = () => en() - tn.chaosMonkey < ln,
            gn = e => {
                console.log("%c ChaosMonkey:", "color:#ff9292;font-size:11px", e)
            },
            wn = e => {
                Object.assign(pn, e)
            },
            bn = e => [P.web, P.mobile_web].includes(e),
            yn = async e => {
                const t = en();
                if (t < tn.lastExpirationPurge + 27e5) return;
                tn.lastExpirationPurge = en();
                const n = await caches.open(zt);
                (await e.keys()).map(async r => {
                    await (async (e, t, n, r) => {
                        const i = await t.get(e),
                            a = E(new URL(e), self.location.host);
                        i < r - on[a] && (await n.delete(e), await t.delete(e))
                    })(r, e, n, t)
                }), setTimeout(() => (async (e, t) => {
                    const n = (await t.keys()).length,
                        r = (await e.keys()).length;
                    Jt("cache_keys", n), Jt("idb_keys", r);
                    const i = n - r;
                    i > 0 && Jt("cache_orphans", i)
                })(e, n), 2e3)
            },
            kn = async (e, t, n, r, i) => {
                const a = await caches.open(zt),
                    o = await a.match(n);
                return e.waitUntil(async function() {
                    if (o) {
                        if (!await (async (e, t, n) => {
                                const r = await t.get(e.url);
                                if (!r) return !0;
                                const i = an[n];
                                return r < en() - i
                            })(n, t, i)) return
                    }
                    await (async (e, t, n, r) => {
                        const i = await cn(e, r);
                        if (!(null === i || void 0 === i ? void 0 : i.clone)) return;
                        const a = i.clone();
                        sn(a) ? (Ht("cached_request", 5), await n.put(e.request, a), await t.set(e.request.url, en())) : Ht("response_clone_error", 1, {
                            hostname: r.hostname
                        })
                    })(e, t, a, r)
                }()), o ? (Ht("cached_response", 5), o) : (Ht("fetched_response", 5), fetch(n))
            },
            _n = (e, t, n = self.location.host) => {
                const r = new URL(e.request.url);
                if ("GET" !== e.request.method || !((e, t) => rn.has(e.hostname) || e.host === t)(r, n)) return;
                const i = E(r, n);
                if (i !== y.unknown)
                    if (i === y.html && vn(n) && (e => {
                            if (!e.searchParams.has(un.cm)) return;
                            const t = String(e.searchParams.get(un.cm));
                            if ("off" === t) wn({
                                cm: "off"
                            }), nn({
                                chaosMonkey: en() - ln
                            });
                            else {
                                if ("on" !== t) return;
                                wn({
                                    cm: "on",
                                    api: "",
                                    random: 100,
                                    status: 401
                                }), nn({
                                    chaosMonkey: en()
                                })
                            }
                            const n = parseInt(e.searchParams.get(un.status) || "", 10);
                            n && wn({
                                status: n
                            });
                            const r = String(e.searchParams.get(un.api) || "");
                            fn.test(r) && wn({
                                api: r
                            });
                            const i = parseInt(e.searchParams.get(un.random) || "", 10);
                            i && wn({
                                random: i
                            }), setTimeout(() => {
                                const e = hn() ? "Enable" : "Disable";
                                gn(e)
                            }, 1e3)
                        })(r), y.api === i && vn(n) && hn() && mn(r)) e.respondWith((async e => {
                        gn("Mocking response " + e.url);
                        const t = {
                            status: pn.status,
                            statusText: "OK",
                            headers: {
                                "Content-Type": "application/json",
                                "X-Mock-Response": "yes"
                            }
                        };
                        return new Response(JSON.stringify({}), t)
                    })(e.request));
                    else if (((e = self.location.host, t, n) => t === y.html && n.host === e && !q.isAuthed)(n, i, r)) e.respondWith((async (e, t, n) => {
                    if (q.isAuthed || !e.headers) return fetch(e);
                    let r = null,
                        i = q.platform;
                    return bn(i) || (r = await t.get("device"), i = r && bn(r.platform) ? r.platform : P.web), At({
                        metricName: "sw_req_device_type",
                        metricType: I.count,
                        pagePath: n.pathname,
                        tags: {
                            authed: "false",
                            browser_name: r ? r.browserName : q.browserName,
                            os_name: r ? r.osName : q.osName,
                            platform: i
                        },
                        value: 1
                    }), fetch(new Request(e, {
                        headers: {
                            "cb-device-type": i
                        }
                    }))
                })(e.request, t, r));
                else {
                    if (!on[i]) return;
                    e.respondWith(kn(e, t, e.request, r, i))
                }
            },
            xn = {
                async get(e) {
                    const t = await _;
                    if (x(t, k)) return t.get(k, e)
                },
                async set(e, t) {
                    const n = await _;
                    if (x(n, k)) return n.put(k, t, e)
                },
                async setDevice(e) {
                    const t = await _;
                    if (x(t, k)) return t.put(k, e, "device")
                },
                async delete(e) {
                    const t = await _;
                    if (x(t, k)) return t.delete(k, e)
                },
                async keys() {
                    const e = await _;
                    return x(e, k) ? e.getAllKeys(k) : []
                }
            };
        xn && (async e => {
            const t = await e.get("device");
            t && U(t)
        })(xn).catch(e => {
            console.error(e)
        });
        [];
        self.addEventListener("fetch", async e => {
            _n(e, xn), yn(xn)
        }), self.addEventListener("install", async () => {
            await self.skipWaiting()
        }), self.addEventListener("activate", e => {
            e.waitUntil((async e => {
                const t = await e.keys();
                await Promise.all(t.filter(e => Ft.includes(e)).map(t => e.delete(t)))
            })(caches)), self.clients.claim()
        }), self.addEventListener("message", e => {
            ((e, t) => {
                e.data && (e.data.config && "object" === typeof e.data.config && Object.values(P).includes(e.data.config.platform) && U({
                    platform: e.data.config.platform
                }), e.data.device && "object" === typeof e.data.device && U({
                    browserName: C(e.data.device.browserName || R),
                    osName: C(e.data.device.osName || R)
                }), e.data.identity && "object" === typeof e.data.identity && U({
                    isAuthed: e.data.identity.isAuthed || !1
                }), t.setDevice(q))
            })(e, xn)
        })
    },
    dkYM: function(e) {
        e.exports = JSON.parse('{"a":"2.5.6"}')
    },
    eEQR: function(e, t, n) {
        var r = function(e) {
            "use strict";
            var t, n = Object.prototype,
                r = n.hasOwnProperty,
                i = "function" === typeof Symbol ? Symbol : {},
                a = i.iterator || "@@iterator",
                o = i.asyncIterator || "@@asyncIterator",
                s = i.toStringTag || "@@toStringTag";

            function c(e, t, n) {
                return Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }), e[t]
            }
            try {
                c({}, "")
            } catch (P) {
                c = function(e, t, n) {
                    return e[t] = n
                }
            }

            function u(e, t, n, r) {
                var i = t && t.prototype instanceof h ? t : h,
                    a = Object.create(i.prototype),
                    o = new O(r || []);
                return a._invoke = function(e, t, n) {
                    var r = d;
                    return function(i, a) {
                        if (r === p) throw new Error("Generator is already running");
                        if (r === m) {
                            if ("throw" === i) throw a;
                            return j()
                        }
                        for (n.method = i, n.arg = a;;) {
                            var o = n.delegate;
                            if (o) {
                                var s = S(o, n);
                                if (s) {
                                    if (s === v) continue;
                                    return s
                                }
                            }
                            if ("next" === n.method) n.sent = n._sent = n.arg;
                            else if ("throw" === n.method) {
                                if (r === d) throw r = m, n.arg;
                                n.dispatchException(n.arg)
                            } else "return" === n.method && n.abrupt("return", n.arg);
                            r = p;
                            var c = l(e, t, n);
                            if ("normal" === c.type) {
                                if (r = n.done ? m : f, c.arg === v) continue;
                                return {
                                    value: c.arg,
                                    done: n.done
                                }
                            }
                            "throw" === c.type && (r = m, n.method = "throw", n.arg = c.arg)
                        }
                    }
                }(e, n, o), a
            }

            function l(e, t, n) {
                try {
                    return {
                        type: "normal",
                        arg: e.call(t, n)
                    }
                } catch (P) {
                    return {
                        type: "throw",
                        arg: P
                    }
                }
            }
            e.wrap = u;
            var d = "suspendedStart",
                f = "suspendedYield",
                p = "executing",
                m = "completed",
                v = {};

            function h() {}

            function g() {}

            function w() {}
            var b = {};
            b[a] = function() {
                return this
            };
            var y = Object.getPrototypeOf,
                k = y && y(y(N([])));
            k && k !== n && r.call(k, a) && (b = k);
            var _ = w.prototype = h.prototype = Object.create(b);

            function x(e) {
                ["next", "throw", "return"].forEach((function(t) {
                    c(e, t, (function(e) {
                        return this._invoke(t, e)
                    }))
                }))
            }

            function E(e, t) {
                var n;
                this._invoke = function(i, a) {
                    function o() {
                        return new t((function(n, o) {
                            ! function n(i, a, o, s) {
                                var c = l(e[i], e, a);
                                if ("throw" !== c.type) {
                                    var u = c.arg,
                                        d = u.value;
                                    return d && "object" === typeof d && r.call(d, "__await") ? t.resolve(d.__await).then((function(e) {
                                        n("next", e, o, s)
                                    }), (function(e) {
                                        n("throw", e, o, s)
                                    })) : t.resolve(d).then((function(e) {
                                        u.value = e, o(u)
                                    }), (function(e) {
                                        return n("throw", e, o, s)
                                    }))
                                }
                                s(c.arg)
                            }(i, a, n, o)
                        }))
                    }
                    return n = n ? n.then(o, o) : o()
                }
            }

            function S(e, n) {
                var r = e.iterator[n.method];
                if (r === t) {
                    if (n.delegate = null, "throw" === n.method) {
                        if (e.iterator.return && (n.method = "return", n.arg = t, S(e, n), "throw" === n.method)) return v;
                        n.method = "throw", n.arg = new TypeError("The iterator does not provide a 'throw' method")
                    }
                    return v
                }
                var i = l(r, e.iterator, n.arg);
                if ("throw" === i.type) return n.method = "throw", n.arg = i.arg, n.delegate = null, v;
                var a = i.arg;
                return a ? a.done ? (n[e.resultName] = a.value, n.next = e.nextLoc, "return" !== n.method && (n.method = "next", n.arg = t), n.delegate = null, v) : a : (n.method = "throw", n.arg = new TypeError("iterator result is not an object"), n.delegate = null, v)
            }

            function T(e) {
                var t = {
                    tryLoc: e[0]
                };
                1 in e && (t.catchLoc = e[1]), 2 in e && (t.finallyLoc = e[2], t.afterLoc = e[3]), this.tryEntries.push(t)
            }

            function I(e) {
                var t = e.completion || {};
                t.type = "normal", delete t.arg, e.completion = t
            }

            function O(e) {
                this.tryEntries = [{
                    tryLoc: "root"
                }], e.forEach(T, this), this.reset(!0)
            }

            function N(e) {
                if (e) {
                    var n = e[a];
                    if (n) return n.call(e);
                    if ("function" === typeof e.next) return e;
                    if (!isNaN(e.length)) {
                        var i = -1,
                            o = function n() {
                                for (; ++i < e.length;)
                                    if (r.call(e, i)) return n.value = e[i], n.done = !1, n;
                                return n.value = t, n.done = !0, n
                            };
                        return o.next = o
                    }
                }
                return {
                    next: j
                }
            }

            function j() {
                return {
                    value: t,
                    done: !0
                }
            }
            return g.prototype = _.constructor = w, w.constructor = g, g.displayName = c(w, s, "GeneratorFunction"), e.isGeneratorFunction = function(e) {
                var t = "function" === typeof e && e.constructor;
                return !!t && (t === g || "GeneratorFunction" === (t.displayName || t.name))
            }, e.mark = function(e) {
                return Object.setPrototypeOf ? Object.setPrototypeOf(e, w) : (e.__proto__ = w, c(e, s, "GeneratorFunction")), e.prototype = Object.create(_), e
            }, e.awrap = function(e) {
                return {
                    __await: e
                }
            }, x(E.prototype), E.prototype[o] = function() {
                return this
            }, e.AsyncIterator = E, e.async = function(t, n, r, i, a) {
                void 0 === a && (a = Promise);
                var o = new E(u(t, n, r, i), a);
                return e.isGeneratorFunction(n) ? o : o.next().then((function(e) {
                    return e.done ? e.value : o.next()
                }))
            }, x(_), c(_, s, "Generator"), _[a] = function() {
                return this
            }, _.toString = function() {
                return "[object Generator]"
            }, e.keys = function(e) {
                var t = [];
                for (var n in e) t.push(n);
                return t.reverse(),
                    function n() {
                        for (; t.length;) {
                            var r = t.pop();
                            if (r in e) return n.value = r, n.done = !1, n
                        }
                        return n.done = !0, n
                    }
            }, e.values = N, O.prototype = {
                constructor: O,
                reset: function(e) {
                    if (this.prev = 0, this.next = 0, this.sent = this._sent = t, this.done = !1, this.delegate = null, this.method = "next", this.arg = t, this.tryEntries.forEach(I), !e)
                        for (var n in this) "t" === n.charAt(0) && r.call(this, n) && !isNaN(+n.slice(1)) && (this[n] = t)
                },
                stop: function() {
                    this.done = !0;
                    var e = this.tryEntries[0].completion;
                    if ("throw" === e.type) throw e.arg;
                    return this.rval
                },
                dispatchException: function(e) {
                    if (this.done) throw e;
                    var n = this;

                    function i(r, i) {
                        return s.type = "throw", s.arg = e, n.next = r, i && (n.method = "next", n.arg = t), !!i
                    }
                    for (var a = this.tryEntries.length - 1; a >= 0; --a) {
                        var o = this.tryEntries[a],
                            s = o.completion;
                        if ("root" === o.tryLoc) return i("end");
                        if (o.tryLoc <= this.prev) {
                            var c = r.call(o, "catchLoc"),
                                u = r.call(o, "finallyLoc");
                            if (c && u) {
                                if (this.prev < o.catchLoc) return i(o.catchLoc, !0);
                                if (this.prev < o.finallyLoc) return i(o.finallyLoc)
                            } else if (c) {
                                if (this.prev < o.catchLoc) return i(o.catchLoc, !0)
                            } else {
                                if (!u) throw new Error("try statement without catch or finally");
                                if (this.prev < o.finallyLoc) return i(o.finallyLoc)
                            }
                        }
                    }
                },
                abrupt: function(e, t) {
                    for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                        var i = this.tryEntries[n];
                        if (i.tryLoc <= this.prev && r.call(i, "finallyLoc") && this.prev < i.finallyLoc) {
                            var a = i;
                            break
                        }
                    }
                    a && ("break" === e || "continue" === e) && a.tryLoc <= t && t <= a.finallyLoc && (a = null);
                    var o = a ? a.completion : {};
                    return o.type = e, o.arg = t, a ? (this.method = "next", this.next = a.finallyLoc, v) : this.complete(o)
                },
                complete: function(e, t) {
                    if ("throw" === e.type) throw e.arg;
                    return "break" === e.type || "continue" === e.type ? this.next = e.arg : "return" === e.type ? (this.rval = this.arg = e.arg, this.method = "return", this.next = "end") : "normal" === e.type && t && (this.next = t), v
                },
                finish: function(e) {
                    for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                        var n = this.tryEntries[t];
                        if (n.finallyLoc === e) return this.complete(n.completion, n.afterLoc), I(n), v
                    }
                },
                catch: function(e) {
                    for (var t = this.tryEntries.length - 1; t >= 0; --t) {
                        var n = this.tryEntries[t];
                        if (n.tryLoc === e) {
                            var r = n.completion;
                            if ("throw" === r.type) {
                                var i = r.arg;
                                I(n)
                            }
                            return i
                        }
                    }
                    throw new Error("illegal catch attempt")
                },
                delegateYield: function(e, n, r) {
                    return this.delegate = {
                        iterator: N(e),
                        resultName: n,
                        nextLoc: r
                    }, "next" === this.method && (this.arg = t), v
                }
            }, e
        }(e.exports);
        try {
            regeneratorRuntime = r
        } catch (i) {
            Function("r", "regeneratorRuntime = r")(r)
        }
    },
    w1Rh: function(e, t, n) {
        ! function() {
            var t = n("DPV4"),
                r = n("arkH").utf8,
                i = n("EbX1"),
                a = n("arkH").bin,
                o = function(e, n) {
                    e.constructor == String ? e = n && "binary" === n.encoding ? a.stringToBytes(e) : r.stringToBytes(e) : i(e) ? e = Array.prototype.slice.call(e, 0) : Array.isArray(e) || (e = e.toString());
                    for (var s = t.bytesToWords(e), c = 8 * e.length, u = 1732584193, l = -271733879, d = -1732584194, f = 271733878, p = 0; p < s.length; p++) s[p] = 16711935 & (s[p] << 8 | s[p] >>> 24) | 4278255360 & (s[p] << 24 | s[p] >>> 8);
                    s[c >>> 5] |= 128 << c % 32, s[14 + (c + 64 >>> 9 << 4)] = c;
                    var m = o._ff,
                        v = o._gg,
                        h = o._hh,
                        g = o._ii;
                    for (p = 0; p < s.length; p += 16) {
                        var w = u,
                            b = l,
                            y = d,
                            k = f;
                        u = m(u, l, d, f, s[p + 0], 7, -680876936), f = m(f, u, l, d, s[p + 1], 12, -389564586), d = m(d, f, u, l, s[p + 2], 17, 606105819), l = m(l, d, f, u, s[p + 3], 22, -1044525330), u = m(u, l, d, f, s[p + 4], 7, -176418897), f = m(f, u, l, d, s[p + 5], 12, 1200080426), d = m(d, f, u, l, s[p + 6], 17, -1473231341), l = m(l, d, f, u, s[p + 7], 22, -45705983), u = m(u, l, d, f, s[p + 8], 7, 1770035416), f = m(f, u, l, d, s[p + 9], 12, -1958414417), d = m(d, f, u, l, s[p + 10], 17, -42063), l = m(l, d, f, u, s[p + 11], 22, -1990404162), u = m(u, l, d, f, s[p + 12], 7, 1804603682), f = m(f, u, l, d, s[p + 13], 12, -40341101), d = m(d, f, u, l, s[p + 14], 17, -1502002290), u = v(u, l = m(l, d, f, u, s[p + 15], 22, 1236535329), d, f, s[p + 1], 5, -165796510), f = v(f, u, l, d, s[p + 6], 9, -1069501632), d = v(d, f, u, l, s[p + 11], 14, 643717713), l = v(l, d, f, u, s[p + 0], 20, -373897302), u = v(u, l, d, f, s[p + 5], 5, -701558691), f = v(f, u, l, d, s[p + 10], 9, 38016083), d = v(d, f, u, l, s[p + 15], 14, -660478335), l = v(l, d, f, u, s[p + 4], 20, -405537848), u = v(u, l, d, f, s[p + 9], 5, 568446438), f = v(f, u, l, d, s[p + 14], 9, -1019803690), d = v(d, f, u, l, s[p + 3], 14, -187363961), l = v(l, d, f, u, s[p + 8], 20, 1163531501), u = v(u, l, d, f, s[p + 13], 5, -1444681467), f = v(f, u, l, d, s[p + 2], 9, -51403784), d = v(d, f, u, l, s[p + 7], 14, 1735328473), u = h(u, l = v(l, d, f, u, s[p + 12], 20, -1926607734), d, f, s[p + 5], 4, -378558), f = h(f, u, l, d, s[p + 8], 11, -2022574463), d = h(d, f, u, l, s[p + 11], 16, 1839030562), l = h(l, d, f, u, s[p + 14], 23, -35309556), u = h(u, l, d, f, s[p + 1], 4, -1530992060), f = h(f, u, l, d, s[p + 4], 11, 1272893353), d = h(d, f, u, l, s[p + 7], 16, -155497632), l = h(l, d, f, u, s[p + 10], 23, -1094730640), u = h(u, l, d, f, s[p + 13], 4, 681279174), f = h(f, u, l, d, s[p + 0], 11, -358537222), d = h(d, f, u, l, s[p + 3], 16, -722521979), l = h(l, d, f, u, s[p + 6], 23, 76029189), u = h(u, l, d, f, s[p + 9], 4, -640364487), f = h(f, u, l, d, s[p + 12], 11, -421815835), d = h(d, f, u, l, s[p + 15], 16, 530742520), u = g(u, l = h(l, d, f, u, s[p + 2], 23, -995338651), d, f, s[p + 0], 6, -198630844), f = g(f, u, l, d, s[p + 7], 10, 1126891415), d = g(d, f, u, l, s[p + 14], 15, -1416354905), l = g(l, d, f, u, s[p + 5], 21, -57434055), u = g(u, l, d, f, s[p + 12], 6, 1700485571), f = g(f, u, l, d, s[p + 3], 10, -1894986606), d = g(d, f, u, l, s[p + 10], 15, -1051523), l = g(l, d, f, u, s[p + 1], 21, -2054922799), u = g(u, l, d, f, s[p + 8], 6, 1873313359), f = g(f, u, l, d, s[p + 15], 10, -30611744), d = g(d, f, u, l, s[p + 6], 15, -1560198380), l = g(l, d, f, u, s[p + 13], 21, 1309151649), u = g(u, l, d, f, s[p + 4], 6, -145523070), f = g(f, u, l, d, s[p + 11], 10, -1120210379), d = g(d, f, u, l, s[p + 2], 15, 718787259), l = g(l, d, f, u, s[p + 9], 21, -343485551), u = u + w >>> 0, l = l + b >>> 0, d = d + y >>> 0, f = f + k >>> 0
                    }
                    return t.endian([u, l, d, f])
                };
            o._ff = function(e, t, n, r, i, a, o) {
                var s = e + (t & n | ~t & r) + (i >>> 0) + o;
                return (s << a | s >>> 32 - a) + t
            }, o._gg = function(e, t, n, r, i, a, o) {
                var s = e + (t & r | n & ~r) + (i >>> 0) + o;
                return (s << a | s >>> 32 - a) + t
            }, o._hh = function(e, t, n, r, i, a, o) {
                var s = e + (t ^ n ^ r) + (i >>> 0) + o;
                return (s << a | s >>> 32 - a) + t
            }, o._ii = function(e, t, n, r, i, a, o) {
                var s = e + (n ^ (t | ~r)) + (i >>> 0) + o;
                return (s << a | s >>> 32 - a) + t
            }, o._blocksize = 16, o._digestsize = 16, e.exports = function(e, n) {
                if (void 0 === e || null === e) throw new Error("Illegal argument " + e);
                var r = t.wordsToBytes(o(e, n));
                return n && n.asBytes ? r : n && n.asString ? a.bytesToString(r) : t.bytesToHex(r)
            }
        }()
    }
});
//# sourceMappingURL=sw.js.map