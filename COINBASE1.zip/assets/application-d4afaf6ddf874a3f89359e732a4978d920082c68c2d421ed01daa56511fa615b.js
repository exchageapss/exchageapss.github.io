function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function downloadDeferedImg() {
    for (var e = document.getElementsByTagName("img"), t = 0; t < e.length; t++) e[t].getAttribute("data-src") && e[t].setAttribute("src", e[t].getAttribute("data-src"))
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
}

function ECB(e, t) {
    this.count = e, this.dataCodewords = t, this.__defineGetter__("Count", function() {
        return this.count
    }), this.__defineGetter__("DataCodewords", function() {
        return this.dataCodewords
    })
}

function ECBlocks(e, t, n) {
    this.ecCodewordsPerBlock = e, n ? this.ecBlocks = new Array(t, n) : this.ecBlocks = new Array(t), this.__defineGetter__("ECCodewordsPerBlock", function() {
        return this.ecCodewordsPerBlock
    }), this.__defineGetter__("TotalECCodewords", function() {
        return this.ecCodewordsPerBlock * this.NumBlocks
    }), this.__defineGetter__("NumBlocks", function() {
        for (var e = 0, t = 0; t < this.ecBlocks.length; t++) e += this.ecBlocks[t].length;
        return e
    }), this.getECBlocks = function() {
        return this.ecBlocks
    }
}

function Version(e, t, n, i, r, o) {
    this.versionNumber = e, this.alignmentPatternCenters = t, this.ecBlocks = new Array(n, i, r, o);
    for (var a = 0, s = n.ECCodewordsPerBlock, u = n.getECBlocks(), c = 0; c < u.length; c++) {
        var l = u[c];
        a += l.Count * (l.DataCodewords + s)
    }
    this.totalCodewords = a, this.__defineGetter__("VersionNumber", function() {
        return this.versionNumber
    }), this.__defineGetter__("AlignmentPatternCenters", function() {
        return this.alignmentPatternCenters
    }), this.__defineGetter__("TotalCodewords", function() {
        return this.totalCodewords
    }), this.__defineGetter__("DimensionForVersion", function() {
        return 17 + 4 * this.versionNumber
    }), this.buildFunctionPattern = function() {
        var e = this.DimensionForVersion,
            t = new BitMatrix(e);
        t.setRegion(0, 0, 9, 9), t.setRegion(e - 8, 0, 8, 9), t.setRegion(0, e - 8, 9, 8);
        for (var n = this.alignmentPatternCenters.length, i = 0; n > i; i++)
            for (var r = this.alignmentPatternCenters[i] - 2, o = 0; n > o; o++) 0 == i && (0 == o || o == n - 1) || i == n - 1 && 0 == o || t.setRegion(this.alignmentPatternCenters[o] - 2, r, 5, 5);
        return t.setRegion(6, 9, 1, e - 17), t.setRegion(9, 6, e - 17, 1), this.versionNumber > 6 && (t.setRegion(e - 11, 0, 3, 6), t.setRegion(0, e - 11, 6, 3)), t
    }, this.getECBlocksForLevel = function(e) {
        return this.ecBlocks[e.ordinal()]
    }
}

function buildVersions() {
    return new Array(new Version(1, new Array, new ECBlocks(7, new ECB(1, 19)), new ECBlocks(10, new ECB(1, 16)), new ECBlocks(13, new ECB(1, 13)), new ECBlocks(17, new ECB(1, 9))), new Version(2, new Array(6, 18), new ECBlocks(10, new ECB(1, 34)), new ECBlocks(16, new ECB(1, 28)), new ECBlocks(22, new ECB(1, 22)), new ECBlocks(28, new ECB(1, 16))), new Version(3, new Array(6, 22), new ECBlocks(15, new ECB(1, 55)), new ECBlocks(26, new ECB(1, 44)), new ECBlocks(18, new ECB(2, 17)), new ECBlocks(22, new ECB(2, 13))), new Version(4, new Array(6, 26), new ECBlocks(20, new ECB(1, 80)), new ECBlocks(18, new ECB(2, 32)), new ECBlocks(26, new ECB(2, 24)), new ECBlocks(16, new ECB(4, 9))), new Version(5, new Array(6, 30), new ECBlocks(26, new ECB(1, 108)), new ECBlocks(24, new ECB(2, 43)), new ECBlocks(18, new ECB(2, 15), new ECB(2, 16)), new ECBlocks(22, new ECB(2, 11), new ECB(2, 12))), new Version(6, new Array(6, 34), new ECBlocks(18, new ECB(2, 68)), new ECBlocks(16, new ECB(4, 27)), new ECBlocks(24, new ECB(4, 19)), new ECBlocks(28, new ECB(4, 15))), new Version(7, new Array(6, 22, 38), new ECBlocks(20, new ECB(2, 78)), new ECBlocks(18, new ECB(4, 31)), new ECBlocks(18, new ECB(2, 14), new ECB(4, 15)), new ECBlocks(26, new ECB(4, 13), new ECB(1, 14))), new Version(8, new Array(6, 24, 42), new ECBlocks(24, new ECB(2, 97)), new ECBlocks(22, new ECB(2, 38), new ECB(2, 39)), new ECBlocks(22, new ECB(4, 18), new ECB(2, 19)), new ECBlocks(26, new ECB(4, 14), new ECB(2, 15))), new Version(9, new Array(6, 26, 46), new ECBlocks(30, new ECB(2, 116)), new ECBlocks(22, new ECB(3, 36), new ECB(2, 37)), new ECBlocks(20, new ECB(4, 16), new ECB(4, 17)), new ECBlocks(24, new ECB(4, 12), new ECB(4, 13))), new Version(10, new Array(6, 28, 50), new ECBlocks(18, new ECB(2, 68), new ECB(2, 69)), new ECBlocks(26, new ECB(4, 43), new ECB(1, 44)), new ECBlocks(24, new ECB(6, 19), new ECB(2, 20)), new ECBlocks(28, new ECB(6, 15), new ECB(2, 16))), new Version(11, new Array(6, 30, 54), new ECBlocks(20, new ECB(4, 81)), new ECBlocks(30, new ECB(1, 50), new ECB(4, 51)), new ECBlocks(28, new ECB(4, 22), new ECB(4, 23)), new ECBlocks(24, new ECB(3, 12), new ECB(8, 13))), new Version(12, new Array(6, 32, 58), new ECBlocks(24, new ECB(2, 92), new ECB(2, 93)), new ECBlocks(22, new ECB(6, 36), new ECB(2, 37)), new ECBlocks(26, new ECB(4, 20), new ECB(6, 21)), new ECBlocks(28, new ECB(7, 14), new ECB(4, 15))), new Version(13, new Array(6, 34, 62), new ECBlocks(26, new ECB(4, 107)), new ECBlocks(22, new ECB(8, 37), new ECB(1, 38)), new ECBlocks(24, new ECB(8, 20), new ECB(4, 21)), new ECBlocks(22, new ECB(12, 11), new ECB(4, 12))), new Version(14, new Array(6, 26, 46, 66), new ECBlocks(30, new ECB(3, 115), new ECB(1, 116)), new ECBlocks(24, new ECB(4, 40), new ECB(5, 41)), new ECBlocks(20, new ECB(11, 16), new ECB(5, 17)), new ECBlocks(24, new ECB(11, 12), new ECB(5, 13))), new Version(15, new Array(6, 26, 48, 70), new ECBlocks(22, new ECB(5, 87), new ECB(1, 88)), new ECBlocks(24, new ECB(5, 41), new ECB(5, 42)), new ECBlocks(30, new ECB(5, 24), new ECB(7, 25)), new ECBlocks(24, new ECB(11, 12), new ECB(7, 13))), new Version(16, new Array(6, 26, 50, 74), new ECBlocks(24, new ECB(5, 98), new ECB(1, 99)), new ECBlocks(28, new ECB(7, 45), new ECB(3, 46)), new ECBlocks(24, new ECB(15, 19), new ECB(2, 20)), new ECBlocks(30, new ECB(3, 15), new ECB(13, 16))), new Version(17, new Array(6, 30, 54, 78), new ECBlocks(28, new ECB(1, 107), new ECB(5, 108)), new ECBlocks(28, new ECB(10, 46), new ECB(1, 47)), new ECBlocks(28, new ECB(1, 22), new ECB(15, 23)), new ECBlocks(28, new ECB(2, 14), new ECB(17, 15))), new Version(18, new Array(6, 30, 56, 82), new ECBlocks(30, new ECB(5, 120), new ECB(1, 121)), new ECBlocks(26, new ECB(9, 43), new ECB(4, 44)), new ECBlocks(28, new ECB(17, 22), new ECB(1, 23)), new ECBlocks(28, new ECB(2, 14), new ECB(19, 15))), new Version(19, new Array(6, 30, 58, 86), new ECBlocks(28, new ECB(3, 113), new ECB(4, 114)), new ECBlocks(26, new ECB(3, 44), new ECB(11, 45)), new ECBlocks(26, new ECB(17, 21), new ECB(4, 22)), new ECBlocks(26, new ECB(9, 13), new ECB(16, 14))), new Version(20, new Array(6, 34, 62, 90), new ECBlocks(28, new ECB(3, 107), new ECB(5, 108)), new ECBlocks(26, new ECB(3, 41), new ECB(13, 42)), new ECBlocks(30, new ECB(15, 24), new ECB(5, 25)), new ECBlocks(28, new ECB(15, 15), new ECB(10, 16))), new Version(21, new Array(6, 28, 50, 72, 94), new ECBlocks(28, new ECB(4, 116), new ECB(4, 117)), new ECBlocks(26, new ECB(17, 42)), new ECBlocks(28, new ECB(17, 22), new ECB(6, 23)), new ECBlocks(30, new ECB(19, 16), new ECB(6, 17))), new Version(22, new Array(6, 26, 50, 74, 98), new ECBlocks(28, new ECB(2, 111), new ECB(7, 112)), new ECBlocks(28, new ECB(17, 46)), new ECBlocks(30, new ECB(7, 24), new ECB(16, 25)), new ECBlocks(24, new ECB(34, 13))), new Version(23, new Array(6, 30, 54, 74, 102), new ECBlocks(30, new ECB(4, 121), new ECB(5, 122)), new ECBlocks(28, new ECB(4, 47), new ECB(14, 48)), new ECBlocks(30, new ECB(11, 24), new ECB(14, 25)), new ECBlocks(30, new ECB(16, 15), new ECB(14, 16))), new Version(24, new Array(6, 28, 54, 80, 106), new ECBlocks(30, new ECB(6, 117), new ECB(4, 118)), new ECBlocks(28, new ECB(6, 45), new ECB(14, 46)), new ECBlocks(30, new ECB(11, 24), new ECB(16, 25)), new ECBlocks(30, new ECB(30, 16), new ECB(2, 17))), new Version(25, new Array(6, 32, 58, 84, 110), new ECBlocks(26, new ECB(8, 106), new ECB(4, 107)), new ECBlocks(28, new ECB(8, 47), new ECB(13, 48)), new ECBlocks(30, new ECB(7, 24), new ECB(22, 25)), new ECBlocks(30, new ECB(22, 15), new ECB(13, 16))), new Version(26, new Array(6, 30, 58, 86, 114), new ECBlocks(28, new ECB(10, 114), new ECB(2, 115)), new ECBlocks(28, new ECB(19, 46), new ECB(4, 47)), new ECBlocks(28, new ECB(28, 22), new ECB(6, 23)), new ECBlocks(30, new ECB(33, 16), new ECB(4, 17))), new Version(27, new Array(6, 34, 62, 90, 118), new ECBlocks(30, new ECB(8, 122), new ECB(4, 123)), new ECBlocks(28, new ECB(22, 45), new ECB(3, 46)), new ECBlocks(30, new ECB(8, 23), new ECB(26, 24)), new ECBlocks(30, new ECB(12, 15), new ECB(28, 16))), new Version(28, new Array(6, 26, 50, 74, 98, 122), new ECBlocks(30, new ECB(3, 117), new ECB(10, 118)), new ECBlocks(28, new ECB(3, 45), new ECB(23, 46)), new ECBlocks(30, new ECB(4, 24), new ECB(31, 25)), new ECBlocks(30, new ECB(11, 15), new ECB(31, 16))), new Version(29, new Array(6, 30, 54, 78, 102, 126), new ECBlocks(30, new ECB(7, 116), new ECB(7, 117)), new ECBlocks(28, new ECB(21, 45), new ECB(7, 46)), new ECBlocks(30, new ECB(1, 23), new ECB(37, 24)), new ECBlocks(30, new ECB(19, 15), new ECB(26, 16))), new Version(30, new Array(6, 26, 52, 78, 104, 130), new ECBlocks(30, new ECB(5, 115), new ECB(10, 116)), new ECBlocks(28, new ECB(19, 47), new ECB(10, 48)), new ECBlocks(30, new ECB(15, 24), new ECB(25, 25)), new ECBlocks(30, new ECB(23, 15), new ECB(25, 16))), new Version(31, new Array(6, 30, 56, 82, 108, 134), new ECBlocks(30, new ECB(13, 115), new ECB(3, 116)), new ECBlocks(28, new ECB(2, 46), new ECB(29, 47)), new ECBlocks(30, new ECB(42, 24), new ECB(1, 25)), new ECBlocks(30, new ECB(23, 15), new ECB(28, 16))), new Version(32, new Array(6, 34, 60, 86, 112, 138), new ECBlocks(30, new ECB(17, 115)), new ECBlocks(28, new ECB(10, 46), new ECB(23, 47)), new ECBlocks(30, new ECB(10, 24), new ECB(35, 25)), new ECBlocks(30, new ECB(19, 15), new ECB(35, 16))), new Version(33, new Array(6, 30, 58, 86, 114, 142), new ECBlocks(30, new ECB(17, 115), new ECB(1, 116)), new ECBlocks(28, new ECB(14, 46), new ECB(21, 47)), new ECBlocks(30, new ECB(29, 24), new ECB(19, 25)), new ECBlocks(30, new ECB(11, 15), new ECB(46, 16))), new Version(34, new Array(6, 34, 62, 90, 118, 146), new ECBlocks(30, new ECB(13, 115), new ECB(6, 116)), new ECBlocks(28, new ECB(14, 46), new ECB(23, 47)), new ECBlocks(30, new ECB(44, 24), new ECB(7, 25)), new ECBlocks(30, new ECB(59, 16), new ECB(1, 17))), new Version(35, new Array(6, 30, 54, 78, 102, 126, 150), new ECBlocks(30, new ECB(12, 121), new ECB(7, 122)), new ECBlocks(28, new ECB(12, 47), new ECB(26, 48)), new ECBlocks(30, new ECB(39, 24), new ECB(14, 25)), new ECBlocks(30, new ECB(22, 15), new ECB(41, 16))), new Version(36, new Array(6, 24, 50, 76, 102, 128, 154), new ECBlocks(30, new ECB(6, 121), new ECB(14, 122)), new ECBlocks(28, new ECB(6, 47), new ECB(34, 48)), new ECBlocks(30, new ECB(46, 24), new ECB(10, 25)), new ECBlocks(30, new ECB(2, 15), new ECB(64, 16))), new Version(37, new Array(6, 28, 54, 80, 106, 132, 158), new ECBlocks(30, new ECB(17, 122), new ECB(4, 123)), new ECBlocks(28, new ECB(29, 46), new ECB(14, 47)), new ECBlocks(30, new ECB(49, 24), new ECB(10, 25)), new ECBlocks(30, new ECB(24, 15), new ECB(46, 16))), new Version(38, new Array(6, 32, 58, 84, 110, 136, 162), new ECBlocks(30, new ECB(4, 122), new ECB(18, 123)), new ECBlocks(28, new ECB(13, 46), new ECB(32, 47)), new ECBlocks(30, new ECB(48, 24), new ECB(14, 25)), new ECBlocks(30, new ECB(42, 15), new ECB(32, 16))), new Version(39, new Array(6, 26, 54, 82, 110, 138, 166), new ECBlocks(30, new ECB(20, 117), new ECB(4, 118)), new ECBlocks(28, new ECB(40, 47), new ECB(7, 48)), new ECBlocks(30, new ECB(43, 24), new ECB(22, 25)), new ECBlocks(30, new ECB(10, 15), new ECB(67, 16))), new Version(40, new Array(6, 30, 58, 86, 114, 142, 170), new ECBlocks(30, new ECB(19, 118), new ECB(6, 119)), new ECBlocks(28, new ECB(18, 47), new ECB(31, 48)), new ECBlocks(30, new ECB(34, 24), new ECB(34, 25)), new ECBlocks(30, new ECB(20, 15), new ECB(61, 16))))
}

function PerspectiveTransform(e, t, n, i, r, o, a, s, u) {
    this.a11 = e, this.a12 = i, this.a13 = a, this.a21 = t, this.a22 = r, this.a23 = s, this.a31 = n, this.a32 = o, this.a33 = u, this.transformPoints1 = function(e) {
        for (var t = e.length, n = this.a11, i = this.a12, r = this.a13, o = this.a21, a = this.a22, s = this.a23, u = this.a31, c = this.a32, l = this.a33, d = 0; t > d; d += 2) {
            var h = e[d],
                f = e[d + 1],
                p = r * h + s * f + l;
            e[d] = (n * h + o * f + u) / p, e[d + 1] = (i * h + a * f + c) / p
        }
    }, this.transformPoints2 = function(e, t) {
        for (var n = e.length, i = 0; n > i; i++) {
            var r = e[i],
                o = t[i],
                a = this.a13 * r + this.a23 * o + this.a33;
            e[i] = (this.a11 * r + this.a21 * o + this.a31) / a, t[i] = (this.a12 * r + this.a22 * o + this.a32) / a
        }
    }, this.buildAdjoint = function() {
        return new PerspectiveTransform(this.a22 * this.a33 - this.a23 * this.a32, this.a23 * this.a31 - this.a21 * this.a33, this.a21 * this.a32 - this.a22 * this.a31, this.a13 * this.a32 - this.a12 * this.a33, this.a11 * this.a33 - this.a13 * this.a31, this.a12 * this.a31 - this.a11 * this.a32, this.a12 * this.a23 - this.a13 * this.a22, this.a13 * this.a21 - this.a11 * this.a23, this.a11 * this.a22 - this.a12 * this.a21)
    }, this.times = function(e) {
        return new PerspectiveTransform(this.a11 * e.a11 + this.a21 * e.a12 + this.a31 * e.a13, this.a11 * e.a21 + this.a21 * e.a22 + this.a31 * e.a23, this.a11 * e.a31 + this.a21 * e.a32 + this.a31 * e.a33, this.a12 * e.a11 + this.a22 * e.a12 + this.a32 * e.a13, this.a12 * e.a21 + this.a22 * e.a22 + this.a32 * e.a23, this.a12 * e.a31 + this.a22 * e.a32 + this.a32 * e.a33, this.a13 * e.a11 + this.a23 * e.a12 + this.a33 * e.a13, this.a13 * e.a21 + this.a23 * e.a22 + this.a33 * e.a23, this.a13 * e.a31 + this.a23 * e.a32 + this.a33 * e.a33)
    }
}

function DetectorResult(e, t) {
    this.bits = e, this.points = t
}

function Detector(e) {
    this.image = e, this.resultPointCallback = null, this.sizeOfBlackWhiteBlackRun = function(e, t, n, i) {
        var r = Math.abs(i - t) > Math.abs(n - e);
        if (r) {
            var o = e;
            e = t, t = o, o = n, n = i, i = o
        }
        for (var a = Math.abs(n - e), s = Math.abs(i - t), u = -a >> 1, c = i > t ? 1 : -1, l = n > e ? 1 : -1, d = 0, h = e, f = t; h != n; h += l) {
            var p = r ? f : h,
                g = r ? h : f;
            if (1 == d ? this.image[p + g * qrcode.width] && d++ : this.image[p + g * qrcode.width] || d++, 3 == d) {
                var m = h - e,
                    v = f - t;
                return Math.sqrt(m * m + v * v)
            }
            if (u += s, u > 0) {
                if (f == i) break;
                f += c, u -= a
            }
        }
        var y = n - e,
            b = i - t;
        return Math.sqrt(y * y + b * b)
    }, this.sizeOfBlackWhiteBlackRunBothWays = function(e, t, n, i) {
        var r = this.sizeOfBlackWhiteBlackRun(e, t, n, i),
            o = 1,
            a = e - (n - e);
        0 > a ? (o = e / (e - a), a = 0) : a >= qrcode.width && (o = (qrcode.width - 1 - e) / (a - e), a = qrcode.width - 1);
        var s = Math.floor(t - (i - t) * o);
        return o = 1, 0 > s ? (o = t / (t - s), s = 0) : s >= qrcode.height && (o = (qrcode.height - 1 - t) / (s - t), s = qrcode.height - 1), a = Math.floor(e + (a - e) * o), r += this.sizeOfBlackWhiteBlackRun(e, t, a, s), r - 1
    }, this.calculateModuleSizeOneWay = function(e, t) {
        var n = this.sizeOfBlackWhiteBlackRunBothWays(Math.floor(e.X), Math.floor(e.Y), Math.floor(t.X), Math.floor(t.Y)),
            i = this.sizeOfBlackWhiteBlackRunBothWays(Math.floor(t.X), Math.floor(t.Y), Math.floor(e.X), Math.floor(e.Y));
        return isNaN(n) ? i / 7 : isNaN(i) ? n / 7 : (n + i) / 14
    }, this.calculateModuleSize = function(e, t, n) {
        return (this.calculateModuleSizeOneWay(e, t) + this.calculateModuleSizeOneWay(e, n)) / 2
    }, this.distance = function(e, t) {
        return xDiff = e.X - t.X, yDiff = e.Y - t.Y, Math.sqrt(xDiff * xDiff + yDiff * yDiff)
    }, this.computeDimension = function(e, t, n, i) {
        var r = Math.round(this.distance(e, t) / i),
            o = Math.round(this.distance(e, n) / i),
            a = (r + o >> 1) + 7;
        switch (3 & a) {
            case 0:
                a++;
                break;
            case 2:
                a--;
                break;
            case 3:
                throw "Error"
        }
        return a
    }, this.findAlignmentInRegion = function(e, t, n, i) {
        var r = Math.floor(i * e),
            o = Math.max(0, t - r),
            a = Math.min(qrcode.width - 1, t + r);
        if (3 * e > a - o) throw "Error";
        var s = Math.max(0, n - r),
            u = Math.min(qrcode.height - 1, n + r),
            c = new AlignmentPatternFinder(this.image, o, s, a - o, u - s, e, this.resultPointCallback);
        return c.find()
    }, this.createTransform = function(e, t, n, i, r) {
        var o, a, s, u, c = r - 3.5;
        null != i ? (o = i.X, a = i.Y, s = u = c - 3) : (o = t.X - e.X + n.X, a = t.Y - e.Y + n.Y, s = u = c);
        var l = PerspectiveTransform.quadrilateralToQuadrilateral(3.5, 3.5, c, 3.5, s, u, 3.5, c, e.X, e.Y, t.X, t.Y, o, a, n.X, n.Y);
        return l
    }, this.sampleGrid = function(e, t, n) {
        var i = GridSampler;
        return i.sampleGrid3(e, n, t)
    }, this.processFinderPatternInfo = function(e) {
        var t = e.TopLeft,
            n = e.TopRight,
            i = e.BottomLeft,
            r = this.calculateModuleSize(t, n, i);
        if (1 > r) throw "Error";
        var o = this.computeDimension(t, n, i, r),
            a = Version.getProvisionalVersionForDimension(o),
            s = a.DimensionForVersion - 7,
            u = null;
        if (a.AlignmentPatternCenters.length > 0)
            for (var c = n.X - t.X + i.X, l = n.Y - t.Y + i.Y, d = 1 - 3 / s, h = Math.floor(t.X + d * (c - t.X)), f = Math.floor(t.Y + d * (l - t.Y)), p = 4; 16 >= p; p <<= 1) {
                u = this.findAlignmentInRegion(r, h, f, p);
                break
            }
        var g, m = this.createTransform(t, n, i, u, o),
            v = this.sampleGrid(this.image, m, o);
        return g = null == u ? new Array(i, t, n) : new Array(i, t, n, u), new DetectorResult(v, g)
    }, this.detect = function() {
        var e = (new FinderPatternFinder).findFinderPattern(this.image);
        return this.processFinderPatternInfo(e)
    }
}

function FormatInformation(e) {
    this.errorCorrectionLevel = ErrorCorrectionLevel.forBits(e >> 3 & 3), this.dataMask = 7 & e, this.__defineGetter__("ErrorCorrectionLevel", function() {
        return this.errorCorrectionLevel
    }), this.__defineGetter__("DataMask", function() {
        return this.dataMask
    }), this.GetHashCode = function() {
        return this.errorCorrectionLevel.ordinal() << 3 | dataMask
    }, this.Equals = function(e) {
        var t = e;
        return this.errorCorrectionLevel == t.errorCorrectionLevel && this.dataMask == t.dataMask
    }
}

function ErrorCorrectionLevel(e, t, n) {
    this.ordinal_Renamed_Field = e, this.bits = t, this.name = n, this.__defineGetter__("Bits", function() {
        return this.bits
    }), this.__defineGetter__("Name", function() {
        return this.name
    }), this.ordinal = function() {
        return this.ordinal_Renamed_Field
    }
}

function BitMatrix(e, t) {
    if (t || (t = e), 1 > e || 1 > t) throw "Both dimensions must be greater than 0";
    this.width = e, this.height = t;
    var n = e >> 5;
    0 != (31 & e) && n++, this.rowSize = n, this.bits = new Array(n * t);
    for (var i = 0; i < this.bits.length; i++) this.bits[i] = 0;
    this.__defineGetter__("Width", function() {
        return this.width
    }), this.__defineGetter__("Height", function() {
        return this.height
    }), this.__defineGetter__("Dimension", function() {
        if (this.width != this.height) throw "Can't call getDimension() on a non-square matrix";
        return this.width
    }), this.get_Renamed = function(e, t) {
        var n = t * this.rowSize + (e >> 5);
        return 0 != (1 & URShift(this.bits[n], 31 & e))
    }, this.set_Renamed = function(e, t) {
        var n = t * this.rowSize + (e >> 5);
        this.bits[n] |= 1 << (31 & e)
    }, this.flip = function(e, t) {
        var n = t * this.rowSize + (e >> 5);
        this.bits[n] ^= 1 << (31 & e)
    }, this.clear = function() {
        for (var e = this.bits.length, t = 0; e > t; t++) this.bits[t] = 0
    }, this.setRegion = function(e, t, n, i) {
        if (0 > t || 0 > e) throw "Left and top must be nonnegative";
        if (1 > i || 1 > n) throw "Height and width must be at least 1";
        var r = e + n,
            o = t + i;
        if (o > this.height || r > this.width) throw "The region must fit inside the matrix";
        for (var a = t; o > a; a++)
            for (var s = a * this.rowSize, u = e; r > u; u++) this.bits[s + (u >> 5)] |= 1 << (31 & u)
    }
}

function DataBlock(e, t) {
    this.numDataCodewords = e, this.codewords = t, this.__defineGetter__("NumDataCodewords", function() {
        return this.numDataCodewords
    }), this.__defineGetter__("Codewords", function() {
        return this.codewords
    })
}

function BitMatrixParser(e) {
    var t = e.Dimension;
    if (21 > t || 1 != (3 & t)) throw "Error BitMatrixParser";
    this.bitMatrix = e, this.parsedVersion = null, this.parsedFormatInfo = null, this.copyBit = function(e, t, n) {
        return this.bitMatrix.get_Renamed(e, t) ? n << 1 | 1 : n << 1
    }, this.readFormatInformation = function() {
        if (null != this.parsedFormatInfo) return this.parsedFormatInfo;
        for (var e = 0, t = 0; 6 > t; t++) e = this.copyBit(t, 8, e);
        e = this.copyBit(7, 8, e), e = this.copyBit(8, 8, e), e = this.copyBit(8, 7, e);
        for (var n = 5; n >= 0; n--) e = this.copyBit(8, n, e);
        if (this.parsedFormatInfo = FormatInformation.decodeFormatInformation(e), null != this.parsedFormatInfo) return this.parsedFormatInfo;
        var i = this.bitMatrix.Dimension;
        e = 0;
        for (var r = i - 8, t = i - 1; t >= r; t--) e = this.copyBit(t, 8, e);
        for (var n = i - 7; i > n; n++) e = this.copyBit(8, n, e);
        if (this.parsedFormatInfo = FormatInformation.decodeFormatInformation(e), null != this.parsedFormatInfo) return this.parsedFormatInfo;
        throw "Error readFormatInformation"
    }, this.readVersion = function() {
        if (null != this.parsedVersion) return this.parsedVersion;
        var e = this.bitMatrix.Dimension,
            t = e - 17 >> 2;
        if (6 >= t) return Version.getVersionForNumber(t);
        for (var n = 0, i = e - 11, r = 5; r >= 0; r--)
            for (var o = e - 9; o >= i; o--) n = this.copyBit(o, r, n);
        if (this.parsedVersion = Version.decodeVersionInformation(n), null != this.parsedVersion && this.parsedVersion.DimensionForVersion == e) return this.parsedVersion;
        n = 0;
        for (var o = 5; o >= 0; o--)
            for (var r = e - 9; r >= i; r--) n = this.copyBit(o, r, n);
        if (this.parsedVersion = Version.decodeVersionInformation(n), null != this.parsedVersion && this.parsedVersion.DimensionForVersion == e) return this.parsedVersion;
        throw "Error readVersion"
    }, this.readCodewords = function() {
        var e = this.readFormatInformation(),
            t = this.readVersion(),
            n = DataMask.forReference(e.DataMask),
            i = this.bitMatrix.Dimension;
        n.unmaskBitMatrix(this.bitMatrix, i);
        for (var r = t.buildFunctionPattern(), o = !0, a = new Array(t.TotalCodewords), s = 0, u = 0, c = 0, l = i - 1; l > 0; l -= 2) {
            6 == l && l--;
            for (var d = 0; i > d; d++)
                for (var h = o ? i - 1 - d : d, f = 0; 2 > f; f++) r.get_Renamed(l - f, h) || (c++, u <<= 1, this.bitMatrix.get_Renamed(l - f, h) && (u |= 1), 8 == c && (a[s++] = u, c = 0, u = 0));
            o ^= !0
        }
        if (s != t.TotalCodewords) throw "Error readCodewords";
        return a
    }
}

function DataMask000() {
    this.unmaskBitMatrix = function(e, t) {
        for (var n = 0; t > n; n++)
            for (var i = 0; t > i; i++) this.isMasked(n, i) && e.flip(i, n)
    }, this.isMasked = function(e, t) {
        return 0 == (e + t & 1)
    }
}

function DataMask001() {
    this.unmaskBitMatrix = function(e, t) {
        for (var n = 0; t > n; n++)
            for (var i = 0; t > i; i++) this.isMasked(n, i) && e.flip(i, n)
    }, this.isMasked = function(e, t) {
        return 0 == (1 & e)
    }
}

function DataMask010() {
    this.unmaskBitMatrix = function(e, t) {
        for (var n = 0; t > n; n++)
            for (var i = 0; t > i; i++) this.isMasked(n, i) && e.flip(i, n)
    }, this.isMasked = function(e, t) {
        return t % 3 == 0
    }
}

function DataMask011() {
    this.unmaskBitMatrix = function(e, t) {
        for (var n = 0; t > n; n++)
            for (var i = 0; t > i; i++) this.isMasked(n, i) && e.flip(i, n)
    }, this.isMasked = function(e, t) {
        return (e + t) % 3 == 0
    }
}

function DataMask100() {
    this.unmaskBitMatrix = function(e, t) {
        for (var n = 0; t > n; n++)
            for (var i = 0; t > i; i++) this.isMasked(n, i) && e.flip(i, n)
    }, this.isMasked = function(e, t) {
        return 0 == (URShift(e, 1) + t / 3 & 1)
    }
}

function DataMask101() {
    this.unmaskBitMatrix = function(e, t) {
        for (var n = 0; t > n; n++)
            for (var i = 0; t > i; i++) this.isMasked(n, i) && e.flip(i, n)
    }, this.isMasked = function(e, t) {
        var n = e * t;
        return (1 & n) + n % 3 == 0
    }
}

function DataMask110() {
    this.unmaskBitMatrix = function(e, t) {
        for (var n = 0; t > n; n++)
            for (var i = 0; t > i; i++) this.isMasked(n, i) && e.flip(i, n)
    }, this.isMasked = function(e, t) {
        var n = e * t;
        return 0 == ((1 & n) + n % 3 & 1)
    }
}

function DataMask111() {
    this.unmaskBitMatrix = function(e, t) {
        for (var n = 0; t > n; n++)
            for (var i = 0; t > i; i++) this.isMasked(n, i) && e.flip(i, n)
    }, this.isMasked = function(e, t) {
        return 0 == ((e + t & 1) + e * t % 3 & 1)
    }
}

function ReedSolomonDecoder(e) {
    this.field = e, this.decode = function(e, t) {
        for (var n = new GF256Poly(this.field, e), i = new Array(t), r = 0; r < i.length; r++) i[r] = 0;
        for (var o = !1, a = !0, r = 0; t > r; r++) {
            var s = n.evaluateAt(this.field.exp(o ? r + 1 : r));
            i[i.length - 1 - r] = s, 0 != s && (a = !1)
        }
        if (!a)
            for (var u = new GF256Poly(this.field, i), c = this.runEuclideanAlgorithm(this.field.buildMonomial(t, 1), u, t), l = c[0], d = c[1], h = this.findErrorLocations(l), f = this.findErrorMagnitudes(d, h, o), r = 0; r < h.length; r++) {
                var p = e.length - 1 - this.field.log(h[r]);
                if (0 > p) throw "ReedSolomonException Bad error location";
                e[p] = GF256.addOrSubtract(e[p], f[r])
            }
    }, this.runEuclideanAlgorithm = function(e, t, n) {
        if (e.Degree < t.Degree) {
            var i = e;
            e = t, t = i
        }
        for (var r = e, o = t, a = this.field.One, s = this.field.Zero, u = this.field.Zero, c = this.field.One; o.Degree >= Math.floor(n / 2);) {
            var l = r,
                d = a,
                h = u;
            if (r = o, a = s, u = c, r.Zero) throw "r_{i-1} was zero";
            o = l;
            for (var f = this.field.Zero, p = r.getCoefficient(r.Degree), g = this.field.inverse(p); o.Degree >= r.Degree && !o.Zero;) {
                var m = o.Degree - r.Degree,
                    v = this.field.multiply(o.getCoefficient(o.Degree), g);
                f = f.addOrSubtract(this.field.buildMonomial(m, v)), o = o.addOrSubtract(r.multiplyByMonomial(m, v))
            }
            s = f.multiply1(a).addOrSubtract(d), c = f.multiply1(u).addOrSubtract(h)
        }
        var y = c.getCoefficient(0);
        if (0 == y) throw "ReedSolomonException sigmaTilde(0) was zero";
        var b = this.field.inverse(y),
            w = c.multiply2(b),
            _ = o.multiply2(b);
        return new Array(w, _)
    }, this.findErrorLocations = function(e) {
        var t = e.Degree;
        if (1 == t) return new Array(e.getCoefficient(1));
        for (var n = new Array(t), i = 0, r = 1; 256 > r && t > i; r++) 0 == e.evaluateAt(r) && (n[i] = this.field.inverse(r), i++);
        if (i != t) throw "Error locator degree does not match number of roots";
        return n
    }, this.findErrorMagnitudes = function(e, t, n) {
        for (var i = t.length, r = new Array(i), o = 0; i > o; o++) {
            for (var a = this.field.inverse(t[o]), s = 1, u = 0; i > u; u++) o != u && (s = this.field.multiply(s, GF256.addOrSubtract(1, this.field.multiply(t[u], a))));
            r[o] = this.field.multiply(e.evaluateAt(a), this.field.inverse(s)), n && (r[o] = this.field.multiply(r[o], a))
        }
        return r
    }
}

function GF256Poly(e, t) {
    if (null == t || 0 == t.length) throw "System.ArgumentException";
    this.field = e;
    var n = t.length;
    if (n > 1 && 0 == t[0]) {
        for (var i = 1; n > i && 0 == t[i];) i++;
        if (i == n) this.coefficients = e.Zero.coefficients;
        else {
            this.coefficients = new Array(n - i);
            for (var r = 0; r < this.coefficients.length; r++) this.coefficients[r] = 0;
            for (var o = 0; o < this.coefficients.length; o++) this.coefficients[o] = t[i + o]
        }
    } else this.coefficients = t;
    this.__defineGetter__("Zero", function() {
        return 0 == this.coefficients[0]
    }), this.__defineGetter__("Degree", function() {
        return this.coefficients.length - 1
    }), this.__defineGetter__("Coefficients", function() {
        return this.coefficients
    }), this.getCoefficient = function(e) {
        return this.coefficients[this.coefficients.length - 1 - e]
    }, this.evaluateAt = function(e) {
        if (0 == e) return this.getCoefficient(0);
        var t = this.coefficients.length;
        if (1 == e) {
            for (var n = 0, i = 0; t > i; i++) n = GF256.addOrSubtract(n, this.coefficients[i]);
            return n
        }
        for (var r = this.coefficients[0], i = 1; t > i; i++) r = GF256.addOrSubtract(this.field.multiply(e, r), this.coefficients[i]);
        return r
    }, this.addOrSubtract = function(t) {
        if (this.field != t.field) throw "GF256Polys do not have same GF256 field";
        if (this.Zero) return t;
        if (t.Zero) return this;
        var n = this.coefficients,
            i = t.coefficients;
        if (n.length > i.length) {
            var r = n;
            n = i, i = r
        }
        for (var o = new Array(i.length), a = i.length - n.length, s = 0; a > s; s++) o[s] = i[s];
        for (var u = a; u < i.length; u++) o[u] = GF256.addOrSubtract(n[u - a], i[u]);
        return new GF256Poly(e, o)
    }, this.multiply1 = function(e) {
        if (this.field != e.field) throw "GF256Polys do not have same GF256 field";
        if (this.Zero || e.Zero) return this.field.Zero;
        for (var t = this.coefficients, n = t.length, i = e.coefficients, r = i.length, o = new Array(n + r - 1), a = 0; n > a; a++)
            for (var s = t[a], u = 0; r > u; u++) o[a + u] = GF256.addOrSubtract(o[a + u], this.field.multiply(s, i[u]));
        return new GF256Poly(this.field, o)
    }, this.multiply2 = function(e) {
        if (0 == e) return this.field.Zero;
        if (1 == e) return this;
        for (var t = this.coefficients.length, n = new Array(t), i = 0; t > i; i++) n[i] = this.field.multiply(this.coefficients[i], e);
        return new GF256Poly(this.field, n)
    }, this.multiplyByMonomial = function(e, t) {
        if (0 > e) throw "System.ArgumentException";
        if (0 == t) return this.field.Zero;
        for (var n = this.coefficients.length, i = new Array(n + e), r = 0; r < i.length; r++) i[r] = 0;
        for (var r = 0; n > r; r++) i[r] = this.field.multiply(this.coefficients[r], t);
        return new GF256Poly(this.field, i)
    }, this.divide = function(e) {
        if (this.field != e.field) throw "GF256Polys do not have same GF256 field";
        if (e.Zero) throw "Divide by 0";
        for (var t = this.field.Zero, n = this, i = e.getCoefficient(e.Degree), r = this.field.inverse(i); n.Degree >= e.Degree && !n.Zero;) {
            var o = n.Degree - e.Degree,
                a = this.field.multiply(n.getCoefficient(n.Degree), r),
                s = e.multiplyByMonomial(o, a),
                u = this.field.buildMonomial(o, a);
            t = t.addOrSubtract(u), n = n.addOrSubtract(s)
        }
        return new Array(t, n)
    }
}

function GF256(e) {
    this.expTable = new Array(256), this.logTable = new Array(256);
    for (var t = 1, n = 0; 256 > n; n++) this.expTable[n] = t, t <<= 1, t >= 256 && (t ^= e);
    for (var n = 0; 255 > n; n++) this.logTable[this.expTable[n]] = n;
    var i = new Array(1);
    i[0] = 0, this.zero = new GF256Poly(this, new Array(i));
    var r = new Array(1);
    r[0] = 1, this.one = new GF256Poly(this, new Array(r)), this.__defineGetter__("Zero", function() {
        return this.zero
    }), this.__defineGetter__("One", function() {
        return this.one
    }), this.buildMonomial = function(e, t) {
        if (0 > e) throw "System.ArgumentException";
        if (0 == t) return zero;
        for (var n = new Array(e + 1), i = 0; i < n.length; i++) n[i] = 0;
        return n[0] = t, new GF256Poly(this, n)
    }, this.exp = function(e) {
        return this.expTable[e]
    }, this.log = function(e) {
        if (0 == e) throw "System.ArgumentException";
        return this.logTable[e]
    }, this.inverse = function(e) {
        if (0 == e) throw "System.ArithmeticException";
        return this.expTable[255 - this.logTable[e]]
    }, this.multiply = function(e, t) {
        return 0 == e || 0 == t ? 0 : 1 == e ? t : 1 == t ? e : this.expTable[(this.logTable[e] + this.logTable[t]) % 255]
    }
}

function URShift(e, t) {
    return e >= 0 ? e >> t : (e >> t) + (2 << ~t)
}

function FinderPattern(e, t, n) {
    this.x = e, this.y = t, this.count = 1, this.estimatedModuleSize = n, this.__defineGetter__("EstimatedModuleSize", function() {
        return this.estimatedModuleSize
    }), this.__defineGetter__("Count", function() {
        return this.count
    }), this.__defineGetter__("X", function() {
        return this.x
    }), this.__defineGetter__("Y", function() {
        return this.y
    }), this.incrementCount = function() {
        this.count++
    }, this.aboutEquals = function(e, t, n) {
        if (Math.abs(t - this.y) <= e && Math.abs(n - this.x) <= e) {
            var i = Math.abs(e - this.estimatedModuleSize);
            return 1 >= i || i / this.estimatedModuleSize <= 1
        }
        return !1
    }
}

function FinderPatternInfo(e) {
    this.bottomLeft = e[0], this.topLeft = e[1], this.topRight = e[2], this.__defineGetter__("BottomLeft", function() {
        return this.bottomLeft
    }), this.__defineGetter__("TopLeft", function() {
        return this.topLeft
    }), this.__defineGetter__("TopRight", function() {
        return this.topRight
    })
}

function FinderPatternFinder() {
    this.image = null, this.possibleCenters = [], this.hasSkipped = !1, this.crossCheckStateCount = new Array(0, 0, 0, 0, 0), this.resultPointCallback = null, this.__defineGetter__("CrossCheckStateCount", function() {
        return this.crossCheckStateCount[0] = 0, this.crossCheckStateCount[1] = 0, this.crossCheckStateCount[2] = 0, this.crossCheckStateCount[3] = 0, this.crossCheckStateCount[4] = 0, this.crossCheckStateCount
    }), this.foundPatternCross = function(e) {
        for (var t = 0, n = 0; 5 > n; n++) {
            var i = e[n];
            if (0 == i) return !1;
            t += i
        }
        if (7 > t) return !1;
        var r = Math.floor((t << INTEGER_MATH_SHIFT) / 7),
            o = Math.floor(r / 2);
        return Math.abs(r - (e[0] << INTEGER_MATH_SHIFT)) < o && Math.abs(r - (e[1] << INTEGER_MATH_SHIFT)) < o && Math.abs(3 * r - (e[2] << INTEGER_MATH_SHIFT)) < 3 * o && Math.abs(r - (e[3] << INTEGER_MATH_SHIFT)) < o && Math.abs(r - (e[4] << INTEGER_MATH_SHIFT)) < o
    }, this.centerFromEnd = function(e, t) {
        return t - e[4] - e[3] - e[2] / 2
    }, this.crossCheckVertical = function(e, t, n, i) {
        for (var r = this.image, o = qrcode.height, a = this.CrossCheckStateCount, s = e; s >= 0 && r[t + s * qrcode.width];) a[2]++, s--;
        if (0 > s) return NaN;
        for (; s >= 0 && !r[t + s * qrcode.width] && a[1] <= n;) a[1]++, s--;
        if (0 > s || a[1] > n) return NaN;
        for (; s >= 0 && r[t + s * qrcode.width] && a[0] <= n;) a[0]++, s--;
        if (a[0] > n) return NaN;
        for (s = e + 1; o > s && r[t + s * qrcode.width];) a[2]++, s++;
        if (s == o) return NaN;
        for (; o > s && !r[t + s * qrcode.width] && a[3] < n;) a[3]++, s++;
        if (s == o || a[3] >= n) return NaN;
        for (; o > s && r[t + s * qrcode.width] && a[4] < n;) a[4]++, s++;
        if (a[4] >= n) return NaN;
        var u = a[0] + a[1] + a[2] + a[3] + a[4];
        return 5 * Math.abs(u - i) >= 2 * i ? NaN : this.foundPatternCross(a) ? this.centerFromEnd(a, s) : NaN
    }, this.crossCheckHorizontal = function(e, t, n, i) {
        for (var r = this.image, o = qrcode.width, a = this.CrossCheckStateCount, s = e; s >= 0 && r[s + t * qrcode.width];) a[2]++, s--;
        if (0 > s) return NaN;
        for (; s >= 0 && !r[s + t * qrcode.width] && a[1] <= n;) a[1]++, s--;
        if (0 > s || a[1] > n) return NaN;
        for (; s >= 0 && r[s + t * qrcode.width] && a[0] <= n;) a[0]++, s--;
        if (a[0] > n) return NaN;
        for (s = e + 1; o > s && r[s + t * qrcode.width];) a[2]++, s++;
        if (s == o) return NaN;
        for (; o > s && !r[s + t * qrcode.width] && a[3] < n;) a[3]++, s++;
        if (s == o || a[3] >= n) return NaN;
        for (; o > s && r[s + t * qrcode.width] && a[4] < n;) a[4]++, s++;
        if (a[4] >= n) return NaN;
        var u = a[0] + a[1] + a[2] + a[3] + a[4];
        return 5 * Math.abs(u - i) >= i ? NaN : this.foundPatternCross(a) ? this.centerFromEnd(a, s) : NaN
    }, this.handlePossibleCenter = function(e, t, n) {
        var i = e[0] + e[1] + e[2] + e[3] + e[4],
            r = this.centerFromEnd(e, n),
            o = this.crossCheckVertical(t, Math.floor(r), e[2], i);
        if (!isNaN(o) && (r = this.crossCheckHorizontal(Math.floor(r), Math.floor(o), e[2], i), !isNaN(r))) {
            for (var a = i / 7, s = !1, u = this.possibleCenters.length, c = 0; u > c; c++) {
                var l = this.possibleCenters[c];
                if (l.aboutEquals(a, o, r)) {
                    l.incrementCount(), s = !0;
                    break
                }
            }
            if (!s) {
                var d = new FinderPattern(r, o, a);
                this.possibleCenters.push(d), null != this.resultPointCallback && this.resultPointCallback.foundPossibleResultPoint(d)
            }
            return !0
        }
        return !1
    }, this.selectBestPatterns = function() {
        var e = this.possibleCenters.length;
        if (3 > e) throw "Couldn't find enough finder patterns";
        if (e > 3) {
            for (var t = 0, n = 0, i = 0; e > i; i++) {
                var r = this.possibleCenters[i].EstimatedModuleSize;
                t += r, n += r * r
            }
            var o = t / e;
            this.possibleCenters.sort(function(e, t) {
                var n = Math.abs(t.EstimatedModuleSize - o),
                    i = Math.abs(e.EstimatedModuleSize - o);
                return i > n ? -1 : n == i ? 0 : 1
            });
            for (var a = Math.sqrt(n / e - o * o), s = Math.max(.2 * o, a), i = 0; i < this.possibleCenters.length && this.possibleCenters.length > 3; i++) {
                var u = this.possibleCenters[i];
                Math.abs(u.EstimatedModuleSize - o) > s && (this.possibleCenters.remove(i), i--)
            }
        }
        return this.possibleCenters.length > 3 && this.possibleCenters.sort(function(e, t) {
            return e.count > t.count ? -1 : e.count < t.count ? 1 : 0
        }), new Array(this.possibleCenters[0], this.possibleCenters[1], this.possibleCenters[2])
    }, this.findRowSkip = function() {
        var e = this.possibleCenters.length;
        if (1 >= e) return 0;
        for (var t = null, n = 0; e > n; n++) {
            var i = this.possibleCenters[n];
            if (i.Count >= CENTER_QUORUM) {
                if (null != t) return this.hasSkipped = !0, Math.floor((Math.abs(t.X - i.X) - Math.abs(t.Y - i.Y)) / 2);
                t = i
            }
        }
        return 0
    }, this.haveMultiplyConfirmedCenters = function() {
        for (var e = 0, t = 0, n = this.possibleCenters.length, i = 0; n > i; i++) {
            var r = this.possibleCenters[i];
            r.Count >= CENTER_QUORUM && (e++, t += r.EstimatedModuleSize)
        }
        if (3 > e) return !1;
        for (var o = t / n, a = 0, i = 0; n > i; i++) r = this.possibleCenters[i], a += Math.abs(r.EstimatedModuleSize - o);
        return .05 * t >= a
    }, this.findFinderPattern = function(e) {
        var t = !1;
        this.image = e;
        var n = qrcode.height,
            i = qrcode.width,
            r = Math.floor(3 * n / (4 * MAX_MODULES));
        (MIN_SKIP > r || t) && (r = MIN_SKIP);
        for (var o = !1, a = new Array(5), s = r - 1; n > s && !o; s += r) {
            a[0] = 0, a[1] = 0, a[2] = 0, a[3] = 0, a[4] = 0;
            for (var u = 0, c = 0; i > c; c++)
                if (e[c + s * qrcode.width]) 1 == (1 & u) && u++, a[u]++;
                else if (0 == (1 & u))
                if (4 == u)
                    if (this.foundPatternCross(a)) {
                        var l = this.handlePossibleCenter(a, s, c);
                        if (l)
                            if (r = 2, this.hasSkipped) o = this.haveMultiplyConfirmedCenters();
                            else {
                                var d = this.findRowSkip();
                                d > a[2] && (s += d - a[2] - r, c = i - 1)
                            }
                        else {
                            do c++; while (i > c && !e[c + s * qrcode.width]);
                            c--
                        }
                        u = 0, a[0] = 0, a[1] = 0, a[2] = 0, a[3] = 0, a[4] = 0
                    } else a[0] = a[2], a[1] = a[3], a[2] = a[4], a[3] = 1, a[4] = 0, u = 3;
            else a[++u]++;
            else a[u]++;
            if (this.foundPatternCross(a)) {
                var l = this.handlePossibleCenter(a, s, i);
                l && (r = a[0], this.hasSkipped && (o = haveMultiplyConfirmedCenters()))
            }
        }
        var h = this.selectBestPatterns();
        return qrcode.orderBestPatterns(h), new FinderPatternInfo(h)
    }
}

function AlignmentPattern(e, t, n) {
    this.x = e, this.y = t, this.count = 1, this.estimatedModuleSize = n, this.__defineGetter__("EstimatedModuleSize", function() {
        return this.estimatedModuleSize
    }), this.__defineGetter__("Count", function() {
        return this.count
    }), this.__defineGetter__("X", function() {
        return Math.floor(this.x)
    }), this.__defineGetter__("Y", function() {
        return Math.floor(this.y)
    }), this.incrementCount = function() {
        this.count++
    }, this.aboutEquals = function(e, t, n) {
        if (Math.abs(t - this.y) <= e && Math.abs(n - this.x) <= e) {
            var i = Math.abs(e - this.estimatedModuleSize);
            return 1 >= i || i / this.estimatedModuleSize <= 1
        }
        return !1
    }
}

function AlignmentPatternFinder(e, t, n, i, r, o, a) {
    this.image = e, this.possibleCenters = new Array, this.startX = t, this.startY = n, this.width = i, this.height = r, this.moduleSize = o, this.crossCheckStateCount = new Array(0, 0, 0), this.resultPointCallback = a, this.centerFromEnd = function(e, t) {
        return t - e[2] - e[1] / 2
    }, this.foundPatternCross = function(e) {
        for (var t = this.moduleSize, n = t / 2, i = 0; 3 > i; i++)
            if (Math.abs(t - e[i]) >= n) return !1;
        return !0
    }, this.crossCheckVertical = function(e, t, n, i) {
        var r = this.image,
            o = qrcode.height,
            a = this.crossCheckStateCount;
        a[0] = 0, a[1] = 0, a[2] = 0;
        for (var s = e; s >= 0 && r[t + s * qrcode.width] && a[1] <= n;) a[1]++, s--;
        if (0 > s || a[1] > n) return NaN;
        for (; s >= 0 && !r[t + s * qrcode.width] && a[0] <= n;) a[0]++, s--;
        if (a[0] > n) return NaN;
        for (s = e + 1; o > s && r[t + s * qrcode.width] && a[1] <= n;) a[1]++, s++;
        if (s == o || a[1] > n) return NaN;
        for (; o > s && !r[t + s * qrcode.width] && a[2] <= n;) a[2]++, s++;
        if (a[2] > n) return NaN;
        var u = a[0] + a[1] + a[2];
        return 5 * Math.abs(u - i) >= 2 * i ? NaN : this.foundPatternCross(a) ? this.centerFromEnd(a, s) : NaN
    }, this.handlePossibleCenter = function(e, t, n) {
        var i = e[0] + e[1] + e[2],
            r = this.centerFromEnd(e, n),
            o = this.crossCheckVertical(t, Math.floor(r), 2 * e[1], i);
        if (!isNaN(o)) {
            for (var a = (e[0] + e[1] + e[2]) / 3, s = this.possibleCenters.length, u = 0; s > u; u++) {
                var c = this.possibleCenters[u];
                if (c.aboutEquals(a, o, r)) return new AlignmentPattern(r, o, a)
            }
            var l = new AlignmentPattern(r, o, a);
            this.possibleCenters.push(l), null != this.resultPointCallback && this.resultPointCallback.foundPossibleResultPoint(l)
        }
        return null
    }, this.find = function() {
        for (var t = this.startX, r = this.height, o = t + i, a = n + (r >> 1), s = new Array(0, 0, 0), u = 0; r > u; u++) {
            var c = a + (0 == (1 & u) ? u + 1 >> 1 : -(u + 1 >> 1));
            s[0] = 0, s[1] = 0, s[2] = 0;
            for (var l = t; o > l && !e[l + qrcode.width * c];) l++;
            for (var d = 0; o > l;) {
                if (e[l + c * qrcode.width])
                    if (1 == d) s[d]++;
                    else if (2 == d) {
                    if (this.foundPatternCross(s)) {
                        var h = this.handlePossibleCenter(s, c, l);
                        if (null != h) return h
                    }
                    s[0] = s[2], s[1] = 1, s[2] = 0, d = 1
                } else s[++d]++;
                else 1 == d && d++, s[d]++;
                l++
            }
            if (this.foundPatternCross(s)) {
                var h = this.handlePossibleCenter(s, c, o);
                if (null != h) return h
            }
        }
        if (0 != this.possibleCenters.length) return this.possibleCenters[0];
        throw "Couldn't find enough alignment patterns"
    }
}

function QRCodeDataBlockReader(e, t, n) {
    this.blockPointer = 0, this.bitPointer = 7, this.dataLength = 0, this.blocks = e, this.numErrorCorrectionCode = n, 9 >= t ? this.dataLengthMode = 0 : t >= 10 && 26 >= t ? this.dataLengthMode = 1 : t >= 27 && 40 >= t && (this.dataLengthMode = 2), this.getNextBits = function(e) {
        var t = 0;
        if (e < this.bitPointer + 1) {
            for (var n = 0, i = 0; e > i; i++) n += 1 << i;
            return n <<= this.bitPointer - e + 1, t = (this.blocks[this.blockPointer] & n) >> this.bitPointer - e + 1, this.bitPointer -= e, t
        }
        if (e < this.bitPointer + 1 + 8) {
            for (var r = 0, i = 0; i < this.bitPointer + 1; i++) r += 1 << i;
            return t = (this.blocks[this.blockPointer] & r) << e - (this.bitPointer + 1), this.blockPointer++, t += this.blocks[this.blockPointer] >> 8 - (e - (this.bitPointer + 1)), this.bitPointer = this.bitPointer - e % 8, this.bitPointer < 0 && (this.bitPointer = 8 + this.bitPointer), t
        }
        if (e < this.bitPointer + 1 + 16) {
            for (var r = 0, o = 0, i = 0; i < this.bitPointer + 1; i++) r += 1 << i;
            var a = (this.blocks[this.blockPointer] & r) << e - (this.bitPointer + 1);
            this.blockPointer++;
            var s = this.blocks[this.blockPointer] << e - (this.bitPointer + 1 + 8);
            this.blockPointer++;
            for (var i = 0; i < e - (this.bitPointer + 1 + 8); i++) o += 1 << i;
            o <<= 8 - (e - (this.bitPointer + 1 + 8));
            var u = (this.blocks[this.blockPointer] & o) >> 8 - (e - (this.bitPointer + 1 + 8));
            return t = a + s + u, this.bitPointer = this.bitPointer - (e - 8) % 8, this.bitPointer < 0 && (this.bitPointer = 8 + this.bitPointer), t
        }
        return 0
    }, this.NextMode = function() {
        return this.blockPointer > this.blocks.length - this.numErrorCorrectionCode - 2 ? 0 : this.getNextBits(4)
    }, this.getDataLength = function(e) {
        for (var t = 0;;) {
            if (e >> t == 1) break;
            t++
        }
        return this.getNextBits(qrcode.sizeOfDataLengthInfo[this.dataLengthMode][t])
    }, this.getRomanAndFigureString = function(e) {
        var t = e,
            n = 0,
            i = "",
            r = new Array("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", " ", "$", "%", "*", "+", "-", ".", "/", ":");
        do
            if (t > 1) {
                n = this.getNextBits(11);
                var o = Math.floor(n / 45),
                    a = n % 45;
                i += r[o], i += r[a], t -= 2
            } else 1 == t && (n = this.getNextBits(6), i += r[n], t -= 1); while (t > 0);
        return i
    }, this.getFigureString = function(e) {
        var t = e,
            n = 0,
            i = "";
        do t >= 3 ? (n = this.getNextBits(10), 100 > n && (i += "0"), 10 > n && (i += "0"), t -= 3) : 2 == t ? (n = this.getNextBits(7), 10 > n && (i += "0"), t -= 2) : 1 == t && (n = this.getNextBits(4), t -= 1), i += n; while (t > 0);
        return i
    }, this.get8bitByteArray = function(e) {
        var t = e,
            n = 0,
            i = new Array;
        do n = this.getNextBits(8), i.push(n), t--; while (t > 0);
        return i
    }, this.getKanjiString = function(e) {
        var t = e,
            n = 0,
            i = "";
        do {
            n = getNextBits(13);
            var r = n % 192,
                o = n / 192,
                a = (o << 8) + r,
                s = 0;
            s = 40956 >= a + 33088 ? a + 33088 : a + 49472, i += String.fromCharCode(s), t--
        } while (t > 0);
        return i
    }, this.__defineGetter__("DataByte", function() {
        for (var e = new Array, t = 1, n = 2, i = 4, r = 8;;) {
            var o = this.NextMode();
            if (0 == o) {
                if (e.length > 0) break;
                throw "Empty data block"
            }
            if (o != t && o != n && o != i && o != r) throw "Invalid mode: " + o + " in (block:" + this.blockPointer + " bit:" + this.bitPointer + ")";
            if (dataLength = this.getDataLength(o), dataLength < 1) throw "Invalid data length: " + dataLength;
            switch (o) {
                case t:
                    for (var a = this.getFigureString(dataLength), s = new Array(a.length), u = 0; u < a.length; u++) s[u] = a.charCodeAt(u);
                    e.push(s);
                    break;
                case n:
                    for (var a = this.getRomanAndFigureString(dataLength), s = new Array(a.length), u = 0; u < a.length; u++) s[u] = a.charCodeAt(u);
                    e.push(s);
                    break;
                case i:
                    var c = this.get8bitByteArray(dataLength);
                    e.push(c);
                    break;
                case r:
                    var a = this.getKanjiString(dataLength);
                    e.push(a)
            }
        }
        return e
    })
}! function(e, t) {
    var n = function() {
        var t = e._data(document, "events");
        return t && t.click && e.grep(t.click, function(e) {
            return "rails" === e.namespace
        }).length
    };
    n() && e.error("jquery-ujs has already been loaded!");
    var i;
    e.rails = i = {
        linkClickSelector: "a[data-confirm], a[data-method], a[data-remote], a[data-disable-with]",
        inputChangeSelector: "select[data-remote], input[data-remote], textarea[data-remote]",
        formSubmitSelector: "form",
        formInputClickSelector: "form input[type=submit], form input[type=image], form button[type=submit], form button:not([type])",
        disableSelector: "input[data-disable-with], button[data-disable-with], textarea[data-disable-with]",
        enableSelector: "input[data-disable-with]:disabled, button[data-disable-with]:disabled, textarea[data-disable-with]:disabled",
        requiredInputSelector: "input[name][required]:not([disabled]),textarea[name][required]:not([disabled])",
        fileInputSelector: "input:file",
        linkDisableSelector: "a[data-disable-with]",
        CSRFProtection: function(t) {
            var n = e('meta[name="csrf-token"]').attr("content");
            n && t.setRequestHeader("X-CSRF-Token", n)
        },
        fire: function(t, n, i) {
            var r = e.Event(n);
            return t.trigger(r, i), r.result !== !1
        },
        confirm: function(e) {
            try {
                return confirm(e)
            } catch (t) {
                return !1
            }
        },
        ajax: function(t) {
            return e.ajax(t)
        },
        href: function(e) {
            return e.attr("href")
        },
        handleRemote: function(n) {
            var r, o, a, s, u, c, l, d;
            if (i.fire(n, "ajax:before")) {
                if (s = n.data("cross-domain"), u = s === t ? null : s, c = n.data("with-credentials") || null, l = n.data("type") || e.ajaxSettings && e.ajaxSettings.dataType, n.is("form")) {
                    r = n.attr("method"), o = n.attr("action"), a = n.serializeArray();
                    var h = n.data("ujs:submit-button");
                    h && (a.push(h), n.data("ujs:submit-button", null))
                } else n.is(i.inputChangeSelector) ? (r = n.data("method"), o = n.data("url"), a = n.serialize(), n.data("params") && (a = a + "&" + n.data("params"))) : (r = n.data("method"), o = i.href(n), a = n.data("params") || null);
                d = {
                    type: r || "GET",
                    data: a,
                    dataType: l,
                    beforeSend: function(e, r) {
                        return r.dataType === t && e.setRequestHeader("accept", "*/*;q=0.5, " + r.accepts.script), i.fire(n, "ajax:beforeSend", [e, r])
                    },
                    success: function(e, t, i) {
                        n.trigger("ajax:success", [e, t, i])
                    },
                    complete: function(e, t) {
                        n.trigger("ajax:complete", [e, t])
                    },
                    error: function(e, t, i) {
                        n.trigger("ajax:error", [e, t, i])
                    },
                    xhrFields: {
                        withCredentials: c
                    },
                    crossDomain: u
                }, o && (d.url = o);
                var f = i.ajax(d);
                return n.trigger("ajax:send", f), f
            }
            return !1
        },
        handleMethod: function(n) {
            var r = i.href(n),
                o = n.data("method"),
                a = n.attr("target"),
                s = e("meta[name=csrf-token]").attr("content"),
                u = e("meta[name=csrf-param]").attr("content"),
                c = e('<form method="post" action="' + r + '"></form>'),
                l = '<input name="_method" value="' + o + '" type="hidden" />';
            u !== t && s !== t && (l += '<input name="' + u + '" value="' + s + '" type="hidden" />'), a && c.attr("target", a), c.hide().append(l).appendTo("body"), c.submit()
        },
        disableFormElements: function(t) {
            t.find(i.disableSelector).each(function() {
                var t = e(this),
                    n = t.is("button") ? "html" : "val";
                t.data("ujs:enable-with", t[n]()), t[n](t.data("disable-with")), t.prop("disabled", !0)
            })
        },
        enableFormElements: function(t) {
            t.find(i.enableSelector).each(function() {
                var t = e(this),
                    n = t.is("button") ? "html" : "val";
                t.data("ujs:enable-with") && t[n](t.data("ujs:enable-with")), t.prop("disabled", !1)
            })
        },
        allowAction: function(e) {
            var t, n = e.data("confirm"),
                r = !1;
            return n ? (i.fire(e, "confirm") && (r = i.confirm(n), t = i.fire(e, "confirm:complete", [r])), r && t) : !0
        },
        blankInputs: function(t, n, i) {
            var r, o, a = e(),
                s = n || "input,textarea",
                u = t.find(s);
            return u.each(function() {
                if (r = e(this), o = r.is(":checkbox,:radio") ? r.is(":checked") : r.val(), !o == !i) {
                    if (r.is(":radio") && u.filter('input:radio:checked[name="' + r.attr("name") + '"]').length) return !0;
                    a = a.add(r)
                }
            }), a.length ? a : !1
        },
        nonBlankInputs: function(e, t) {
            return i.blankInputs(e, t, !0)
        },
        stopEverything: function(t) {
            return e(t.target).trigger("ujs:everythingStopped"), t.stopImmediatePropagation(), !1
        },
        callFormSubmitBindings: function(n, i) {
            var r = n.data("events"),
                o = !0;
            return r !== t && r.submit !== t && e.each(r.submit, function(e, t) {
                return "function" == typeof t.handler ? o = t.handler(i) : void 0
            }), o
        },
        disableElement: function(e) {
            e.data("ujs:enable-with", e.html()), e.html(e.data("disable-with")), e.addClass("disabled"), e.bind("click.railsDisable", function(e) {
                return i.stopEverything(e)
            })
        },
        enableElement: function(e) {
            e.data("ujs:enable-with") !== t && (e.html(e.data("ujs:enable-with")), e.removeClass("disabled"), e.data("ujs:enable-with", !1)), e.unbind("click.railsDisable")
        }
    }, i.fire(e(document), "rails:attachBindings") && (e.ajaxPrefilter(function(e, t, n) {
        e.crossDomain || i.CSRFProtection(n)
    }), e(document).delegate(i.linkDisableSelector, "ajax:complete", function() {
        i.enableElement(e(this))
    }), e(document).delegate(i.linkClickSelector, "click.rails", function(n) {
        var r = e(this),
            o = r.data("method"),
            a = r.data("params");
        if (!i.allowAction(r)) return i.stopEverything(n);
        if (r.is(i.linkDisableSelector) && i.disableElement(r), r.data("remote") !== t) {
            if ((n.metaKey || n.ctrlKey) && (!o || "GET" === o) && !a) return !0;
            var s = i.handleRemote(r);
            return s === !1 ? i.enableElement(r) : s.error(function() {
                i.enableElement(r)
            }), !1
        }
        return r.data("method") ? (i.handleMethod(r), !1) : void 0
    }), e(document).delegate(i.inputChangeSelector, "change.rails", function(t) {
        var n = e(this);
        return i.allowAction(n) ? (i.handleRemote(n), !1) : i.stopEverything(t)
    }), e(document).delegate(i.formSubmitSelector, "submit.rails", function(n) {
        var r = e(this),
            o = r.data("remote") !== t,
            a = i.blankInputs(r, i.requiredInputSelector),
            s = i.nonBlankInputs(r, i.fileInputSelector);
        if (!i.allowAction(r)) return i.stopEverything(n);
        if (a && r.attr("novalidate") == t && i.fire(r, "ajax:aborted:required", [a])) return i.stopEverything(n);
        if (o) {
            if (s) {
                setTimeout(function() {
                    i.disableFormElements(r)
                }, 13);
                var u = i.fire(r, "ajax:aborted:file", [s]);
                return u || setTimeout(function() {
                    i.enableFormElements(r)
                }, 13), u
            }
            return !e.support.submitBubbles && e().jquery < "1.7" && i.callFormSubmitBindings(r, n) === !1 ? i.stopEverything(n) : (i.handleRemote(r), !1)
        }
        setTimeout(function() {
            i.disableFormElements(r)
        }, 13)
    }), e(document).delegate(i.formInputClickSelector, "click.rails", function(t) {
        var n = e(this);
        if (!i.allowAction(n)) return i.stopEverything(t);
        var r = n.attr("name"),
            o = r ? {
                name: r,
                value: n.val()
            } : null;
        n.closest("form").data("ujs:submit-button", o)
    }), e(document).delegate(i.formSubmitSelector, "ajax:beforeSend.rails", function(t) {
        this == t.target && i.disableFormElements(e(this))
    }), e(document).delegate(i.formSubmitSelector, "ajax:complete.rails", function(t) {
        this == t.target && i.enableFormElements(e(this))
    }), e(function() {
        csrf_token = e("meta[name=csrf-token]").attr("content"), csrf_param = e("meta[name=csrf-param]").attr("content"), e('form input[name="' + csrf_param + '"]').val(csrf_token)
    }))
}(jQuery),
function(e, t) {
    function n(e, t) {
        return e && t && e.type === t.type && e.name === t.name && h(e.metaData, t.metaData)
    }

    function i(e) {
        try {
            if ("function" != typeof e) return e;
            if (!e.bugsnag) {
                var t = u();
                e.bugsnag = function() {
                    if (D = t, !M) {
                        var n = e.apply(this, arguments);
                        return D = null, n
                    }
                    try {
                        return e.apply(this, arguments)
                    } catch (i) {
                        throw C("autoNotify", !0) && ($.notifyException(i, null, null, "error"), P()), i
                    } finally {
                        D = null
                    }
                }, e.bugsnag.bugsnag = e.bugsnag
            }
            return e.bugsnag
        } catch (n) {
            return e
        }
    }

    function r() {
        if (L) {
            var t = function(e) {
                if (E("autoBreadcrumbsClicks")) {
                    var t, n;
                    try {
                        t = f(e.target), n = p(e.target)
                    } catch (i) {
                        t = "[hidden]", n = "[hidden]", d("Cross domain error when tracking click event. See https://docs.bugsnag.com/platforms/browsers/faq/#3-cross-origin-script-errors")
                    }
                    $.leaveBreadcrumb({
                        type: "user",
                        name: "UI click",
                        metaData: {
                            targetText: t,
                            targetSelector: n
                        }
                    })
                }
            };
            e.addEventListener("click", t, !0)
        }
    }

    function o() {
        function t(e, t) {
            E("autoBreadcrumbsConsole") && $.leaveBreadcrumb({
                type: "log",
                name: "Console output",
                metaData: {
                    severity: e,
                    message: Array.prototype.slice.call(t).join(", ")
                }
            })
        }
        if ("undefined" != typeof e.console) {
            var n = console.log,
                i = console.warn,
                r = console.error;
            $.enableAutoBreadcrumbsConsole = function() {
                $.autoBreadcrumbsConsole = !0, l(console, "log", function() {
                    t("log", arguments)
                }), l(console, "warn", function() {
                    t("warn", arguments)
                }), l(console, "error", function() {
                    t("error", arguments)
                })
            }, $.disableAutoBreadcrumbsConsole = function() {
                $.autoBreadcrumbsConsole = !1, console.log = n, console.warn = i, console.error = r
            }, E("autoBreadcrumbsConsole") && $.enableAutoBreadcrumbsConsole()
        }
    }

    function a() {
        function t(e) {
            return e.split("#")[1] || ""
        }

        function n(e) {
            var n = e.oldURL,
                i = e.newURL,
                r = {};
            return n && i ? (r.from = t(n), r.to = t(i)) : r.to = location.hash, {
                type: "navigation",
                name: "Hash changed",
                metaData: r
            }
        }

        function i() {
            return {
                type: "navigation",
                name: "Navigated back"
            }
        }

        function r() {
            return {
                type: "navigation",
                name: "Page hidden"
            }
        }

        function o() {
            return {
                type: "navigation",
                name: "Page shown"
            }
        }

        function a() {
            return {
                type: "navigation",
                name: "Page loaded"
            }
        }

        function s() {
            return {
                type: "navigation",
                name: "DOMContentLoaded"
            }
        }

        function u(e, t, n, i) {
            var r = location.pathname + location.search + location.hash;
            return {
                type: "navigation",
                name: "History " + e,
                metaData: {
                    from: r,
                    to: i || r,
                    prevState: history.state,
                    nextState: t
                }
            }
        }

        function c(e, t, n) {
            return u("pushState", e, t, n)
        }

        function d(e, t, n) {
            return u("replaceState", e, t, n)
        }

        function h(e) {
            return function() {
                E("autoBreadcrumbsNavigation") && $.leaveBreadcrumb(e.apply(null, arguments))
            }
        }
        if (L && e.history && e.history.state && e.history.pushState && e.history.pushState.bind) {
            var f = history.pushState,
                p = history.replaceState;
            $.enableAutoBreadcrumbsNavigation = function() {
                $.autoBreadcrumbsNavigation = !0, l(history, "pushState", h(c)), l(history, "replaceState", h(d))
            }, $.disableAutoBreadcrumbsNavigation = function() {
                $.autoBreadcrumbsNavigation = !1, history.pushState = f, history.replaceState = p
            }, e.addEventListener("hashchange", h(n), !0), e.addEventListener("popstate", h(i), !0), e.addEventListener("pagehide", h(r), !0), e.addEventListener("pageshow", h(o), !0), e.addEventListener("load", h(a), !0), e.addEventListener("DOMContentLoaded", h(s), !0), E("autoBreadcrumbsNavigation") && $.enableAutoBreadcrumbsNavigation()
        }
    }

    function s() {
        V = !1
    }

    function u() {
        var e = document.currentScript || D;
        if (!e && V) {
            var t = document.scripts || document.getElementsByTagName("script");
            e = t[t.length - 1]
        }
        return e
    }

    function c(e) {
        var t = u();
        t && (e.script = {
            src: t.src,
            content: C("inlineScript", !0) ? t.innerHTML : ""
        })
    }

    function l(e, t, n) {
        var i = e[t];
        e[t] = function() {
            n.apply(this, arguments), "function" == typeof i && i.apply(this, arguments)
        }
    }

    function d(t) {
        var n = C("disableLog"),
            i = e.console;
        void 0 === i || void 0 === i.log || n || i.log("[Bugsnag] " + t)
    }

    function h(e, t) {
        return y(e) === y(t)
    }

    function f(e) {
        var t = e.textContent || e.innerText || "";
        return ("submit" === e.type || "button" === e.type) && (t = e.value), t = t.replace(/^\s+|\s+$/g, ""), g(t, 140)
    }

    function p(e) {
        var t = [e.tagName];
        if (e.id && t.push("#" + e.id), e.className && e.className.length) {
            var n = "." + e.className.split(" ").join(".");
            t.push(n)
        }
        var i = t.join("");
        if (!document.querySelectorAll || !Array.prototype.indexOf) return i;
        try {
            if (1 === document.querySelectorAll(i).length) return i
        } catch (r) {
            return i
        }
        if (e.parentNode.childNodes.length > 1) {
            var o = Array.prototype.indexOf.call(e.parentNode.childNodes, e) + 1;
            i = i + ":nth-child(" + o + ")"
        }
        return 1 === document.querySelectorAll(i).length ? i : e.parentNode ? p(e.parentNode) + " > " + i : i
    }

    function g(e, t) {
        var n = "(...)";
        return e && e.length > t ? e.slice(0, t - n.length) + n : e
    }

    function m(e) {
        return "[object Array]" === Object.prototype.toString.call(e)
    }

    function v(e, t, n) {
        var i = (n || 0) + 1,
            r = C("maxDepth", U);
        if (n > r) return "[RECURSIVE]";
        if ("string" == typeof e) return g(e, t);
        if (m(e)) {
            for (var o = [], a = 0; a < e.length; a++) o[a] = v(e[a], t, i);
            return o
        }
        if ("object" == typeof e && null != e) {
            var s = {};
            for (var u in e) e.hasOwnProperty(u) && (s[u] = v(e[u], t, i));
            return s
        }
        return e
    }

    function y(t, n, i) {
        var r = C("maxDepth", U);
        if (i >= r) return encodeURIComponent(n) + "=[RECURSIVE]";
        i = i + 1 || 1;
        try {
            if (e.Node && t instanceof e.Node) return encodeURIComponent(n) + "=" + encodeURIComponent(B(t));
            var o = [];
            for (var a in t)
                if (t.hasOwnProperty(a) && null != a && null != t[a]) {
                    var s = n ? n + "[" + a + "]" : a,
                        u = t[a];
                    o.push("object" == typeof u ? y(u, s, i) : encodeURIComponent(s) + "=" + encodeURIComponent(u))
                }
            return o.sort().join("&")
        } catch (c) {
            return encodeURIComponent(n) + "=" + encodeURIComponent("" + c)
        }
    }

    function b(e, t, n) {
        if (null == t) return e;
        if (n >= C("maxDepth", U)) return "[RECURSIVE]";
        e = e || {};
        for (var i in t)
            if (t.hasOwnProperty(i)) try {
                t[i].constructor === Object ? e[i] = b(e[i], t[i], n + 1 || 1) : e[i] = t[i]
            } catch (r) {
                e[i] = t[i]
            }
        return e
    }

    function w(e, t) {
        if (e += "?" + y(t) + "&ct=img&cb=" + (new Date).getTime(), "undefined" != typeof BUGSNAG_TESTING && $.testRequest) $.testRequest(e, t);
        else {
            var n = C("notifyHandler");
            if ("xhr" === n) {
                var i = new XMLHttpRequest;
                i.open("GET", e, !0), i.send()
            } else {
                var r = new Image;
                r.src = e
            }
        }
    }

    function _(e) {
        var t = {},
            n = /^data\-([\w\-]+)$/;
        if (e)
            for (var i = e.attributes, r = 0; r < i.length; r++) {
                var o = i[r];
                if (n.test(o.nodeName)) {
                    var a = o.nodeName.match(n)[1];
                    t[a] = o.value || o.nodeValue
                }
            }
        return t
    }

    function C(e, t) {
        W = W || _(Y);
        var n = void 0 !== $[e] ? $[e] : W[e.toLowerCase()];
        return "false" === n && (n = !1), void 0 !== n ? n : t
    }

    function k(e) {
        return e && e.match(H) ? !0 : (d("Invalid API key '" + e + "'"), !1)
    }

    function E(e) {
        var t = C("autoBreadcrumbs", !0);
        return C(e, t)
    }

    function S(t, n) {
        var i = C("apiKey");
        if (k(i) && N) {
            N -= 1;
            var r = C("releaseStage", "production"),
                o = C("notifyReleaseStages");
            if (o) {
                for (var a = !1, s = 0; s < o.length; s++)
                    if (r === o[s]) {
                        a = !0;
                        break
                    }
                if (!a) return
            }
            var u = [t.name, t.message, t.stacktrace].join("|");
            if (u !== O) {
                O = u;
                var c = {
                        device: {
                            time: (new Date).getTime()
                        }
                    },
                    l = {
                        notifierVersion: X,
                        apiKey: i,
                        projectRoot: C("projectRoot") || e.location.protocol + "//" + e.location.host,
                        context: C("context") || e.location.pathname,
                        user: C("user"),
                        metaData: b(b(c, C("metaData")), n),
                        releaseStage: r,
                        appVersion: C("appVersion"),
                        url: e.location.href,
                        userAgent: navigator.userAgent,
                        language: navigator.language || navigator.userLanguage,
                        severity: t.severity,
                        name: t.name,
                        message: t.message,
                        stacktrace: t.stacktrace,
                        file: t.file,
                        lineNumber: t.lineNumber,
                        columnNumber: t.columnNumber,
                        breadcrumbs: I,
                        payloadVersion: "3"
                    },
                    h = $.beforeNotify;
                if ("function" == typeof h) {
                    var f = h(l, l.metaData);
                    if (f === !1) return
                }
                return 0 === l.lineNumber && /Script error\.?/.test(l.message) ? d("Ignoring cross-domain or eval script error. See https://docs.bugsnag.com/platforms/browsers/faq/#3-cross-origin-script-errors") : void w(C("endpoint") || z, l)
            }
        }
    }

    function x() {
        var e, t, n = 10,
            i = "[anonymous]";
        try {
            throw new Error("")
        } catch (r) {
            e = "<generated>\n", t = T(r)
        }
        if (!t) {
            e = "<generated-ie>\n";
            var o = [];
            try {
                for (var a = arguments.callee.caller.caller; a && o.length < n;) {
                    var s = q.test(a.toString()) ? RegExp.$1 || i : i;
                    o.push(s), a = a.caller
                }
            } catch (u) {
                d(u)
            }
            t = o.join("\n")
        }
        return e + t
    }

    function T(e) {
        return e.stack || e.backtrace || e.stacktrace
    }

    function B(e) {
        if (e) {
            var t = e.attributes;
            if (t) {
                for (var n = "<" + e.nodeName.toLowerCase(), i = 0; i < t.length; i++) t[i].value && "null" !== t[i].value.toString() && (n += " " + t[i].name + '="' + t[i].value + '"');
                return n + ">"
            }
            return e.nodeName
        }
    }

    function P() {
        F += 1, e.setTimeout(function() {
            F -= 1
        })
    }

    function A(t, n, i) {
        var r = t[n],
            o = i(r);
        t[n] = o, "undefined" != typeof BUGSNAG_TESTING && e.undo && e.undo.push(function() {
            t[n] = r
        })
    }
    var D, O, $ = {},
        M = !0,
        F = 0,
        I = [],
        R = 40,
        j = "BugsnagNotify",
        N = 10,
        U = 5;
    $.breadcrumbLimit = 20, $.noConflict = function() {
        return e.Bugsnag = t, "undefined" == typeof t && delete e.Bugsnag, $
    }, $.refresh = function() {
        N = 10
    }, $.notifyException = function(e, t, n, i) {
        if (!e) {
            var r = "Bugsnag.notifyException() was called with no arguments";
            return d(r), void $.notify(j, r)
        }
        return "string" == typeof e ? (d("Bugsnag.notifyException() was called with a string. Expected instance of Error. To send a custom message instantiate a new Error or use Bugsnag.notify('<string>'). see https://docs.bugsnag.com/platforms/browsers/#reporting-handled-exceptions"), void $.notify.apply(null, arguments)) : (t && "string" != typeof t && (n = t, t = void 0), n || (n = {}), c(n), void S({
            name: t || e.name,
            message: e.message || e.description,
            stacktrace: T(e) || x(),
            file: e.fileName || e.sourceURL,
            lineNumber: e.lineNumber || e.line,
            columnNumber: e.columnNumber ? e.columnNumber + 1 : void 0,
            severity: i || "warning"
        }, n))
    }, $.notify = function(t, n, i, r) {
        t || (t = j, n = "Bugsnag.notify() was called with no arguments", d(n)), S({
            name: t,
            message: n,
            stacktrace: x(),
            file: e.location.toString(),
            lineNumber: 1,
            severity: r || "warning"
        }, i)
    }, $.leaveBreadcrumb = function(e, t) {
        var i = "manual",
            r = {
                type: i,
                name: "Manual",
                timestamp: (new Date).getTime()
            };
        switch (typeof e) {
            case "object":
                r = b(r, e);
                break;
            case "string":
                t && "object" == typeof t ? r = b(r, {
                    name: e,
                    metaData: t
                }) : r.metaData = {
                    message: e
                };
                break;
            default:
                return void d("expecting 1st argument to leaveBreadcrumb to be a 'string' or 'object', got " + typeof e)
        }
        for (var o = [i, "error", "log", "navigation", "process", "request", "state", "user"], a = !1, s = 0; s < o.length; s++)
            if (o[s] === r.type) {
                a = !0;
                break
            }
        a || (d("Converted invalid breadcrumb type '" + r.type + "' to '" + i + "'"), r.type = i);
        var u = I.slice(-1)[0];
        if (n(r, u)) u.count = u.count || 1, u.count++;
        else {
            var c = Math.min($.breadcrumbLimit, R);
            r.name = g(r.name, 32),
                I.push(v(r, 140)), I.length > c && (I = I.slice(-c))
        }
    };
    var L = "undefined" != typeof e.addEventListener;
    $.enableAutoBreadcrumbsConsole = function() {}, $.disableAutoBreadcrumbsConsole = function() {}, $.enableAutoBreadcrumbsNavigation = function() {}, $.disableAutoBreadcrumbsNavigation = function() {}, $.enableAutoBreadcrumbsErrors = function() {
        $.autoBreadcrumbsErrors = !0
    }, $.disableAutoBreadcrumbsErrors = function() {
        $.autoBreadcrumbsErrors = !1
    }, $.enableAutoBreadcrumbsClicks = function() {
        $.autoBreadcrumbsClicks = !0
    }, $.disableAutoBreadcrumbsClicks = function() {
        $.autoBreadcrumbsClicks = !1
    }, $.enableAutoBreadcrumbs = function() {
        $.enableAutoBreadcrumbsClicks(), $.enableAutoBreadcrumbsConsole(), $.enableAutoBreadcrumbsErrors(), $.enableAutoBreadcrumbsNavigation()
    }, $.disableAutoBreadcrumbs = function() {
        $.disableAutoBreadcrumbsClicks(), $.disableAutoBreadcrumbsConsole(), $.disableAutoBreadcrumbsErrors(), $.disableAutoBreadcrumbsNavigation()
    }, $.enableNotifyUnhandledRejections = function() {
        $.notifyUnhandledRejections = !0
    }, $.disableNotifyUnhandledRejections = function() {
        $.notifyUnhandledRejections = !1
    };
    var V = "complete" !== document.readyState;
    document.addEventListener ? (document.addEventListener("DOMContentLoaded", s, !0), e.addEventListener("load", s, !0)) : e.attachEvent("onload", s);
    var W, H = /^[0-9a-f]{32}$/i,
        q = /function\s*([\w\-$]+)?\s*\(/i,
        G = "https://notify.bugsnag.com/",
        z = G + "js",
        X = "3.2.0",
        K = document.getElementsByTagName("script"),
        Y = K[K.length - 1];
    if (e.atob) {
        if (e.ErrorEvent) try {
            0 === new e.ErrorEvent("test").colno && (M = !1)
        } catch (Q) {}
    } else M = !1;
    if (C("autoNotify", !0)) {
        A(e, "onerror", function(t) {
            return "undefined" != typeof BUGSNAG_TESTING && ($._onerror = t),
                function(n, i, r, o, a) {
                    var s = C("autoNotify", !0),
                        u = {};
                    if (!o && e.event && (o = e.event.errorCharacter), c(u), D = null, s && !F) {
                        var l = a && a.name || "window.onerror";
                        S({
                            name: l,
                            message: n,
                            file: i,
                            lineNumber: r,
                            columnNumber: o,
                            stacktrace: a && T(a) || x(),
                            severity: "error"
                        }, u), E("autoBreadcrumbsErrors") && $.leaveBreadcrumb({
                            type: "error",
                            name: l,
                            metaData: {
                                severity: "error",
                                file: i,
                                message: n,
                                line: r
                            }
                        })
                    }
                    "undefined" != typeof BUGSNAG_TESTING && (t = $._onerror), t && t(n, i, r, o, a)
                }
        });
        var J = function(e) {
            return function(t, n) {
                if ("function" == typeof t) {
                    t = i(t);
                    var r = Array.prototype.slice.call(arguments, 2);
                    return e(function() {
                        t.apply(this, r)
                    }, n)
                }
                return e(t, n)
            }
        };
        A(e, "setTimeout", J), A(e, "setInterval", J), e.requestAnimationFrame && A(e, "requestAnimationFrame", function(e) {
            return function(t) {
                return e(i(t))
            }
        }), e.setImmediate && A(e, "setImmediate", function(e) {
            return function() {
                var t = Array.prototype.slice.call(arguments);
                return t[0] = i(t[0]), e.apply(this, t)
            }
        }), "onunhandledrejection" in e && e.addEventListener("unhandledrejection", function(e) {
            if (C("notifyUnhandledRejections", !1)) {
                var t = e.reason;
                t && (t instanceof Error || t.message) ? $.notifyException(t) : $.notify("UnhandledRejection", t)
            }
        }), "EventTarget Window Node ApplicationCache AudioTrackList ChannelMergerNode CryptoOperation EventSource FileReader HTMLUnknownElement IDBDatabase IDBRequest IDBTransaction KeyOperation MediaController MessagePort ModalWindow Notification SVGElementInstance Screen TextTrack TextTrackCue TextTrackList WebSocket WebSocketWorker Worker XMLHttpRequest XMLHttpRequestEventTarget XMLHttpRequestUpload".replace(/\w+/g, function(t) {
            var n = e[t] && e[t].prototype;
            n && n.hasOwnProperty && n.hasOwnProperty("addEventListener") && (A(n, "addEventListener", function(e) {
                return function(t, n, r, o) {
                    try {
                        n && n.handleEvent && (n.handleEvent = i(n.handleEvent))
                    } catch (a) {
                        d(a)
                    }
                    return e.call(this, t, i(n), r, o)
                }
            }), A(n, "removeEventListener", function(e) {
                return function(t, n, r, o) {
                    return e.call(this, t, n, r, o), e.call(this, t, i(n), r, o)
                }
            }))
        })
    }
    r(), o(), a(), C("autoBreadcrumbs", !0) && $.leaveBreadcrumb({
        type: "navigation",
        name: "Bugsnag Loaded"
    }), e.Bugsnag = $, "function" == typeof define && define.amd ? define([], function() {
        return $
    }) : "object" == typeof module && "object" == typeof module.exports && (module.exports = $)
}(window, window.Bugsnag),
function() {
    var e;
    Coinbase.constants.BUGSNAG_JS_API_KEY && (null == window.Bugsnag && (window.Bugsnag = {}), Bugsnag.endpoint = "https://exceptions.coinbase.com/js", Bugsnag.apiKey = Coinbase.constants.BUGSNAG_JS_API_KEY, Coinbase.constants.USER && (Bugsnag.user = {
        id: Coinbase.constants.USER.id
    }), e = function() {
        var e;
        return Bugsnag.metaData = {
            state: {
                turbolinksIsDefined: "undefined" != typeof Turbolinks && null !== Turbolinks,
                turbolinksIsSupported: "undefined" != typeof Turbolinks && null !== Turbolinks ? Turbolinks.supported : void 0,
                jqueryTurbolinksIsDefined: null != $.turbo,
                jqueryTurbolinksIsReady: null != (e = $.turbo) ? e.isReady : void 0
            }
        }
    }, Bugsnag.beforeNotify = function() {
        var t, n, i;
        if (t = Coinbase.metrics.browser) {
            if (n = t.name, i = parseInt(t.version, 10), "Internet Explorer" === n && 8 >= i) return !1
        } else console.warn("`Coinbase.metrics.browser` is missing. Skipping old browser filter.");
        return e(), !0
    })
}.call(this);
try {
    !Object.prototype.__defineGetter__ && Object.defineProperty({}, "x", {
        get: function() {
            return !0
        }
    }).x && (Object.defineProperty(Object.prototype, "__defineGetter__", {
        enumerable: !1,
        configurable: !0,
        value: function(e, t) {
            Object.defineProperty(this, e, {
                get: t,
                enumerable: !0,
                configurable: !0
            })
        }
    }), Object.defineProperty(Object.prototype, "__defineSetter__", {
        enumerable: !1,
        configurable: !0,
        value: function(e, t) {
            Object.defineProperty(this, e, {
                set: t,
                enumerable: !0,
                configurable: !0
            })
        }
    }))
} catch (defPropException) {}! function() {
    function e(e) {
        this.message = e
    }
    var t = "undefined" != typeof exports ? exports : this,
        n = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    e.prototype = new Error, e.prototype.name = "InvalidCharacterError", t.btoa || (t.btoa = function(t) {
        for (var i, r, o = String(t), a = 0, s = n, u = ""; o.charAt(0 | a) || (s = "=", a % 1); u += s.charAt(63 & i >> 8 - a % 1 * 8)) {
            if (r = o.charCodeAt(a += .75), r > 255) throw new e("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
            i = i << 8 | r
        }
        return u
    }), t.atob || (t.atob = function(t) {
        var i = String(t).replace(/=+$/, "");
        if (i.length % 4 == 1) throw new e("'atob' failed: The string to be decoded is not correctly encoded.");
        for (var r, o, a = 0, s = 0, u = ""; o = i.charAt(s++); ~o && (r = a % 4 ? 64 * r + o : o, a++ % 4) ? u += String.fromCharCode(255 & r >> (-2 * a & 6)) : 0) o = n.indexOf(o);
        return u
    })
}(),
function(e, t) {
    "function" == typeof define && define.amd ? define(t) : "object" == typeof exports ? module.exports = t() : e.returnExports = t()
}(this, function() {
    function e(e) {
        return e = +e, e !== e ? e = 0 : 0 !== e && e !== 1 / 0 && e !== -(1 / 0) && (e = (e > 0 || -1) * Math.floor(Math.abs(e))), e
    }

    function t(e) {
        var t = typeof e;
        return null === e || "undefined" === t || "boolean" === t || "number" === t || "string" === t
    }

    function n(e) {
        var n, i, r;
        if (t(e)) return e;
        if (i = e.valueOf, g(i) && (n = i.call(e), t(n))) return n;
        if (r = e.toString, g(r) && (n = r.call(e), t(n))) return n;
        throw new TypeError
    }

    function i() {}
    var r, o = Array.prototype,
        a = Object.prototype,
        s = Function.prototype,
        u = String.prototype,
        c = Number.prototype,
        l = o.slice,
        d = o.splice,
        h = (o.push, o.unshift),
        f = s.call,
        p = a.toString,
        g = function(e) {
            return "[object Function]" === a.toString.call(e)
        },
        m = function(e) {
            return "[object RegExp]" === a.toString.call(e)
        },
        v = function(e) {
            return "[object Array]" === p.call(e)
        },
        y = function(e) {
            return "[object String]" === p.call(e)
        },
        b = function(e) {
            var t = p.call(e),
                n = "[object Arguments]" === t;
            return n || (n = !v(e) && null !== e && "object" == typeof e && "number" == typeof e.length && e.length >= 0 && g(e.callee)), n
        },
        w = Object.defineProperty && function() {
            try {
                return Object.defineProperty({}, "x", {}), !0
            } catch (e) {
                return !1
            }
        }();
    r = w ? function(e, t, n, i) {
        !i && t in e || Object.defineProperty(e, t, {
            configurable: !0,
            enumerable: !1,
            writable: !0,
            value: n
        })
    } : function(e, t, n, i) {
        !i && t in e || (e[t] = n)
    };
    var _ = function(e, t, n) {
            for (var i in t) a.hasOwnProperty.call(t, i) && r(e, i, t[i], n)
        },
        C = function(e) {
            if (null == e) throw new TypeError("can't convert " + e + " to object");
            return Object(e)
        },
        k = function(e) {
            return e >>> 0
        };
    _(s, {
        bind: function(e) {
            var t = this;
            if (!g(t)) throw new TypeError("Function.prototype.bind called on incompatible " + t);
            for (var n = l.call(arguments, 1), r = function() {
                    if (this instanceof u) {
                        var i = t.apply(this, n.concat(l.call(arguments)));
                        return Object(i) === i ? i : this
                    }
                    return t.apply(e, n.concat(l.call(arguments)))
                }, o = Math.max(0, t.length - n.length), a = [], s = 0; o > s; s++) a.push("$" + s);
            var u = Function("binder", "return function (" + a.join(",") + "){return binder.apply(this,arguments)}")(r);
            return t.prototype && (i.prototype = t.prototype, u.prototype = new i, i.prototype = null), u
        }
    });
    var E, S, x, T, B, P = f.bind(a.hasOwnProperty);
    (B = P(a, "__defineGetter__")) && (E = f.bind(a.__defineGetter__), S = f.bind(a.__defineSetter__), x = f.bind(a.__lookupGetter__), T = f.bind(a.__lookupSetter__));
    var A = function() {
        var e = [1, 2],
            t = e.splice();
        return 2 === e.length && v(t) && 0 === t.length
    }();
    _(o, {
        splice: function(e, t) {
            return 0 === arguments.length ? [] : d.apply(this, arguments)
        }
    }, A);
    var D = function() {
        var e = {};
        return o.splice.call(e, 0, 0, 1), 1 === e.length
    }();
    _(o, {
        splice: function(t, n) {
            if (0 === arguments.length) return [];
            var i = arguments;
            return this.length = Math.max(e(this.length), 0), arguments.length > 0 && "number" != typeof n && (i = l.call(arguments), i.length < 2 ? i.push(this.length - t) : i[1] = e(n)), d.apply(this, i)
        }
    }, !D);
    var O = 1 !== [].unshift(0);
    _(o, {
        unshift: function() {
            return h.apply(this, arguments), this.length
        }
    }, O), _(Array, {
        isArray: v
    });
    var $ = Object("a"),
        M = "a" !== $[0] || !(0 in $),
        F = function(e) {
            var t = !0,
                n = !0;
            return e && (e.call("foo", function(e, n, i) {
                "object" != typeof i && (t = !1)
            }), e.call([1], function() {
                "use strict";
                n = "string" == typeof this
            }, "x")), !!e && t && n
        };
    _(o, {
        forEach: function(e) {
            var t = C(this),
                n = M && y(this) ? this.split("") : t,
                i = arguments[1],
                r = -1,
                o = n.length >>> 0;
            if (!g(e)) throw new TypeError;
            for (; ++r < o;) r in n && e.call(i, n[r], r, t)
        }
    }, !F(o.forEach)), _(o, {
        map: function(e) {
            var t = C(this),
                n = M && y(this) ? this.split("") : t,
                i = n.length >>> 0,
                r = Array(i),
                o = arguments[1];
            if (!g(e)) throw new TypeError(e + " is not a function");
            for (var a = 0; i > a; a++) a in n && (r[a] = e.call(o, n[a], a, t));
            return r
        }
    }, !F(o.map)), _(o, {
        filter: function(e) {
            var t, n = C(this),
                i = M && y(this) ? this.split("") : n,
                r = i.length >>> 0,
                o = [],
                a = arguments[1];
            if (!g(e)) throw new TypeError(e + " is not a function");
            for (var s = 0; r > s; s++) s in i && (t = i[s], e.call(a, t, s, n) && o.push(t));
            return o
        }
    }, !F(o.filter)), _(o, {
        every: function(e) {
            var t = C(this),
                n = M && y(this) ? this.split("") : t,
                i = n.length >>> 0,
                r = arguments[1];
            if (!g(e)) throw new TypeError(e + " is not a function");
            for (var o = 0; i > o; o++)
                if (o in n && !e.call(r, n[o], o, t)) return !1;
            return !0
        }
    }, !F(o.every)), _(o, {
        some: function(e) {
            var t = C(this),
                n = M && y(this) ? this.split("") : t,
                i = n.length >>> 0,
                r = arguments[1];
            if (!g(e)) throw new TypeError(e + " is not a function");
            for (var o = 0; i > o; o++)
                if (o in n && e.call(r, n[o], o, t)) return !0;
            return !1
        }
    }, !F(o.some));
    var I = !1;
    o.reduce && (I = "object" == typeof o.reduce.call("es5", function(e, t, n, i) {
        return i
    })), _(o, {
        reduce: function(e) {
            var t = C(this),
                n = M && y(this) ? this.split("") : t,
                i = n.length >>> 0;
            if (!g(e)) throw new TypeError(e + " is not a function");
            if (!i && 1 === arguments.length) throw new TypeError("reduce of empty array with no initial value");
            var r, o = 0;
            if (arguments.length >= 2) r = arguments[1];
            else
                for (;;) {
                    if (o in n) {
                        r = n[o++];
                        break
                    }
                    if (++o >= i) throw new TypeError("reduce of empty array with no initial value")
                }
            for (; i > o; o++) o in n && (r = e.call(void 0, r, n[o], o, t));
            return r
        }
    }, !I);
    var R = !1;
    o.reduceRight && (R = "object" == typeof o.reduceRight.call("es5", function(e, t, n, i) {
        return i
    })), _(o, {
        reduceRight: function(e) {
            var t = C(this),
                n = M && y(this) ? this.split("") : t,
                i = n.length >>> 0;
            if (!g(e)) throw new TypeError(e + " is not a function");
            if (!i && 1 === arguments.length) throw new TypeError("reduceRight of empty array with no initial value");
            var r, o = i - 1;
            if (arguments.length >= 2) r = arguments[1];
            else
                for (;;) {
                    if (o in n) {
                        r = n[o--];
                        break
                    }
                    if (--o < 0) throw new TypeError("reduceRight of empty array with no initial value")
                }
            if (0 > o) return r;
            do o in n && (r = e.call(void 0, r, n[o], o, t)); while (o--);
            return r
        }
    }, !R);
    var j = Array.prototype.indexOf && -1 !== [0, 1].indexOf(1, 2);
    _(o, {
        indexOf: function(t) {
            var n = M && y(this) ? this.split("") : C(this),
                i = n.length >>> 0;
            if (!i) return -1;
            var r = 0;
            for (arguments.length > 1 && (r = e(arguments[1])), r = r >= 0 ? r : Math.max(0, i + r); i > r; r++)
                if (r in n && n[r] === t) return r;
            return -1
        }
    }, j);
    var N = Array.prototype.lastIndexOf && -1 !== [0, 1].lastIndexOf(0, -3);
    _(o, {
        lastIndexOf: function(t) {
            var n = M && y(this) ? this.split("") : C(this),
                i = n.length >>> 0;
            if (!i) return -1;
            var r = i - 1;
            for (arguments.length > 1 && (r = Math.min(r, e(arguments[1]))), r = r >= 0 ? r : i - Math.abs(r); r >= 0; r--)
                if (r in n && t === n[r]) return r;
            return -1
        }
    }, N);
    var U = !{
            toString: null
        }.propertyIsEnumerable("toString"),
        L = function() {}.propertyIsEnumerable("prototype"),
        V = ["toString", "toLocaleString", "valueOf", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "constructor"],
        W = V.length;
    _(Object, {
        keys: function(e) {
            var t = g(e),
                n = b(e),
                i = null !== e && "object" == typeof e,
                r = i && y(e);
            if (!i && !t && !n) throw new TypeError("Object.keys called on a non-object");
            var o = [],
                a = L && t;
            if (r || n)
                for (var s = 0; s < e.length; ++s) o.push(String(s));
            else
                for (var u in e) a && "prototype" === u || !P(e, u) || o.push(String(u));
            if (U)
                for (var c = e.constructor, l = c && c.prototype === e, d = 0; W > d; d++) {
                    var h = V[d];
                    l && "constructor" === h || !P(e, h) || o.push(h)
                }
            return o
        }
    });
    var H = Object.keys && function() {
            return 2 === Object.keys(arguments).length
        }(1, 2),
        q = Object.keys;
    _(Object, {
        keys: function(e) {
            return q(b(e) ? o.slice.call(e) : e)
        }
    }, !H);
    var G = -621987552e5,
        z = "-000001",
        X = Date.prototype.toISOString && -1 === new Date(G).toISOString().indexOf(z);
    _(Date.prototype, {
        toISOString: function() {
            var e, t, n, i, r;
            if (!isFinite(this)) throw new RangeError("Date.prototype.toISOString called on non-finite value.");
            for (i = this.getUTCFullYear(), r = this.getUTCMonth(), i += Math.floor(r / 12), r = (r % 12 + 12) % 12, e = [r + 1, this.getUTCDate(), this.getUTCHours(), this.getUTCMinutes(), this.getUTCSeconds()], i = (0 > i ? "-" : i > 9999 ? "+" : "") + ("00000" + Math.abs(i)).slice(i >= 0 && 9999 >= i ? -4 : -6), t = e.length; t--;) n = e[t], 10 > n && (e[t] = "0" + n);
            return i + "-" + e.slice(0, 2).join("-") + "T" + e.slice(2).join(":") + "." + ("000" + this.getUTCMilliseconds()).slice(-3) + "Z"
        }
    }, X);
    var K = !1;
    try {
        K = Date.prototype.toJSON && null === new Date(NaN).toJSON() && -1 !== new Date(G).toJSON().indexOf(z) && Date.prototype.toJSON.call({
            toISOString: function() {
                return !0
            }
        })
    } catch (Y) {}
    K || (Date.prototype.toJSON = function(e) {
        var t, i = Object(this),
            r = n(i);
        if ("number" == typeof r && !isFinite(r)) return null;
        if (t = i.toISOString, "function" != typeof t) throw new TypeError("toISOString property is not callable");
        return t.call(i)
    });
    var Q = 1e15 === Date.parse("+033658-09-27T01:46:40.000Z"),
        J = !isNaN(Date.parse("2012-04-04T24:00:00.500Z")) || !isNaN(Date.parse("2012-11-31T23:59:59.000Z")),
        Z = isNaN(Date.parse("2000-01-01T00:00:00.000Z"));
    (!Date.parse || Z || J || !Q) && (Date = function(e) {
        function t(n, i, r, o, a, s, u) {
            var c = arguments.length;
            if (this instanceof e) {
                var l = 1 === c && String(n) === n ? new e(t.parse(n)) : c >= 7 ? new e(n, i, r, o, a, s, u) : c >= 6 ? new e(n, i, r, o, a, s) : c >= 5 ? new e(n, i, r, o, a) : c >= 4 ? new e(n, i, r, o) : c >= 3 ? new e(n, i, r) : c >= 2 ? new e(n, i) : c >= 1 ? new e(n) : new e;
                return l.constructor = t, l
            }
            return e.apply(this, arguments)
        }

        function n(e, t) {
            var n = t > 1 ? 1 : 0;
            return o[t] + Math.floor((e - 1969 + n) / 4) - Math.floor((e - 1901 + n) / 100) + Math.floor((e - 1601 + n) / 400) + 365 * (e - 1970)
        }

        function i(t) {
            return Number(new e(1970, 0, 1, 0, 0, 0, t))
        }
        var r = new RegExp("^(\\d{4}|[+-]\\d{6})(?:-(\\d{2})(?:-(\\d{2})(?:T(\\d{2}):(\\d{2})(?::(\\d{2})(?:(\\.\\d{1,}))?)?(Z|(?:([-+])(\\d{2}):(\\d{2})))?)?)?)?$"),
            o = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365];
        for (var a in e) t[a] = e[a];
        return t.now = e.now, t.UTC = e.UTC, t.prototype = e.prototype, t.prototype.constructor = t, t.parse = function(t) {
            var o = r.exec(t);
            if (o) {
                var a, s = Number(o[1]),
                    u = Number(o[2] || 1) - 1,
                    c = Number(o[3] || 1) - 1,
                    l = Number(o[4] || 0),
                    d = Number(o[5] || 0),
                    h = Number(o[6] || 0),
                    f = Math.floor(1e3 * Number(o[7] || 0)),
                    p = Boolean(o[4] && !o[8]),
                    g = "-" === o[9] ? 1 : -1,
                    m = Number(o[10] || 0),
                    v = Number(o[11] || 0);
                return (d > 0 || h > 0 || f > 0 ? 24 : 25) > l && 60 > d && 60 > h && 1e3 > f && u > -1 && 12 > u && 24 > m && 60 > v && c > -1 && c < n(s, u + 1) - n(s, u) && (a = 60 * (24 * (n(s, u) + c) + l + m * g), a = 1e3 * (60 * (a + d + v * g) + h) + f, p && (a = i(a)), a >= -864e13 && 864e13 >= a) ? a : NaN
            }
            return e.parse.apply(this, arguments)
        }, t
    }(Date)), Date.now || (Date.now = function() {
        return (new Date).getTime()
    });
    var ee = c.toFixed && ("0.000" !== 8e-5.toFixed(3) || "1" !== .9.toFixed(0) || "1.25" !== 1.255.toFixed(2) || "1000000000000000128" !== 0xde0b6b3a7640080.toFixed(0)),
        te = {
            base: 1e7,
            size: 6,
            data: [0, 0, 0, 0, 0, 0],
            multiply: function(e, t) {
                for (var n = -1; ++n < te.size;) t += e * te.data[n], te.data[n] = t % te.base, t = Math.floor(t / te.base)
            },
            divide: function(e) {
                for (var t = te.size, n = 0; --t >= 0;) n += te.data[t], te.data[t] = Math.floor(n / e), n = n % e * te.base
            },
            numToString: function() {
                for (var e = te.size, t = ""; --e >= 0;)
                    if ("" !== t || 0 === e || 0 !== te.data[e]) {
                        var n = String(te.data[e]);
                        "" === t ? t = n : t += "0000000".slice(0, 7 - n.length) + n
                    }
                return t
            },
            pow: function fe(e, t, n) {
                return 0 === t ? n : t % 2 === 1 ? fe(e, t - 1, n * e) : fe(e * e, t / 2, n)
            },
            log: function(e) {
                for (var t = 0; e >= 4096;) t += 12, e /= 4096;
                for (; e >= 2;) t += 1, e /= 2;
                return t
            }
        };
    _(c, {
        toFixed: function(e) {
            var t, n, i, r, o, a, s, u;
            if (t = Number(e), t = t !== t ? 0 : Math.floor(t), 0 > t || t > 20) throw new RangeError("Number.toFixed called with invalid number of decimals");
            if (n = Number(this), n !== n) return "NaN";
            if (-1e21 >= n || n >= 1e21) return String(n);
            if (i = "", 0 > n && (i = "-", n = -n), r = "0", n > 1e-21)
                if (o = te.log(n * te.pow(2, 69, 1)) - 69, a = 0 > o ? n * te.pow(2, -o, 1) : n / te.pow(2, o, 1), a *= 4503599627370496, o = 52 - o, o > 0) {
                    for (te.multiply(0, a), s = t; s >= 7;) te.multiply(1e7, 0), s -= 7;
                    for (te.multiply(te.pow(10, s, 1), 0), s = o - 1; s >= 23;) te.divide(1 << 23), s -= 23;
                    te.divide(1 << s), te.multiply(1, 1), te.divide(2), r = te.numToString()
                } else te.multiply(0, a), te.multiply(1 << -o, 0), r = te.numToString() + "0.00000000000000000000".slice(2, 2 + t);
            return t > 0 ? (u = r.length, r = t >= u ? i + "0.0000000000000000000".slice(0, t - u + 2) + r : i + r.slice(0, u - t) + "." + r.slice(u - t)) : r = i + r, r
        }
    }, ee);
    var ne = u.split;
    2 !== "ab".split(/(?:ab)*/).length || 4 !== ".".split(/(.?)(.?)/).length || "t" === "tesst".split(/(s)*/)[1] || 4 !== "test".split(/(?:)/, -1).length || "".split(/.?/).length || ".".split(/()()/).length > 1 ? ! function() {
        var e = void 0 === /()??/.exec("")[1];
        u.split = function(t, n) {
            var i = this;
            if (void 0 === t && 0 === n) return [];
            if ("[object RegExp]" !== p.call(t)) return ne.call(this, t, n);
            var r, a, s, u, c = [],
                l = (t.ignoreCase ? "i" : "") + (t.multiline ? "m" : "") + (t.extended ? "x" : "") + (t.sticky ? "y" : ""),
                d = 0;
            for (t = new RegExp(t.source, l + "g"), i += "", e || (r = new RegExp("^" + t.source + "$(?!\\s)", l)), n = void 0 === n ? -1 >>> 0 : k(n);
                (a = t.exec(i)) && (s = a.index + a[0].length, !(s > d && (c.push(i.slice(d, a.index)), !e && a.length > 1 && a[0].replace(r, function() {
                    for (var e = 1; e < arguments.length - 2; e++) void 0 === arguments[e] && (a[e] = void 0)
                }), a.length > 1 && a.index < i.length && o.push.apply(c, a.slice(1)), u = a[0].length, d = s, c.length >= n)));) t.lastIndex === a.index && t.lastIndex++;
            return d === i.length ? (u || !t.test("")) && c.push("") : c.push(i.slice(d)), c.length > n ? c.slice(0, n) : c
        }
    }() : "0".split(void 0, 0).length && (u.split = function(e, t) {
        return void 0 === e && 0 === t ? [] : ne.call(this, e, t)
    });
    var ie = u.replace,
        re = function() {
            var e = [];
            return "x".replace(/x(.)?/g, function(t, n) {
                e.push(n)
            }), 1 === e.length && "undefined" == typeof e[0]
        }();
    re || (u.replace = function(e, t) {
        var n = g(t),
            i = m(e) && /\)[*?]/.test(e.source);
        if (n && i) {
            var r = function(n) {
                var i = arguments.length,
                    r = e.lastIndex;
                e.lastIndex = 0;
                var o = e.exec(n);
                return e.lastIndex = r, o.push(arguments[i - 2], arguments[i - 1]), t.apply(this, o)
            };
            return ie.call(this, e, r)
        }
        return ie.call(this, e, t)
    });
    var oe = u.substr,
        ae = "".substr && "b" !== "0b".substr(-1);
    _(u, {
        substr: function(e, t) {
            return oe.call(this, 0 > e && (e = this.length + e) < 0 ? 0 : e, t)
        }
    }, ae);
    var se = "	\n\f\r \xa0\u1680\u180e\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u202f\u205f\u3000\u2028\u2029\ufeff",
        ue = "\u200b",
        ce = "[" + se + "]",
        le = new RegExp("^" + ce + ce + "*"),
        de = new RegExp(ce + ce + "*$"),
        he = u.trim && (se.trim() || !ue.trim());
    _(u, {
        trim: function() {
            if (void 0 === this || null === this) throw new TypeError("can't convert " + this + " to object");
            return String(this).replace(le, "").replace(de, "")
        }
    }, he), (8 !== parseInt(se + "08") || 22 !== parseInt(se + "0x16")) && (parseInt = function(e) {
        var t = /^0[xX]/;
        return function(n, i) {
            return n = String(n).trim(), Number(i) || (i = t.test(n) ? 16 : 10), e(n, i)
        }
    }(parseInt))
}),
function(e, t) {
    "function" == typeof define && define.amd ? define(t) : "object" == typeof exports ? module.exports = t() : e.returnExports = t()
}(this, function() {
    function e(e) {
        try {
            return e.sentinel = 0, 0 === Object.getOwnPropertyDescriptor(e, "sentinel").value
        } catch (t) {}
    }

    function t(e) {
        try {
            return Object.defineProperty(e, "sentinel", {}), "sentinel" in e
        } catch (t) {}
    }
    var n, i, r, o, a = Function.prototype.call,
        s = Object.prototype,
        u = a.bind(s.hasOwnProperty),
        c = u(s, "__defineGetter__");
    if (c && (n = a.bind(s.__defineGetter__), i = a.bind(s.__defineSetter__), r = a.bind(s.__lookupGetter__), o = a.bind(s.__lookupSetter__)), Object.getPrototypeOf || (Object.getPrototypeOf = function(e) {
            var t = e.__proto__;
            return t || null === t ? t : e.constructor ? e.constructor.prototype : s
        }), Object.defineProperty) {
        var l = e({}),
            d = "undefined" == typeof document || e(document.createElement("div"));
        if (!d || !l) var h = Object.getOwnPropertyDescriptor
    }
    if (!Object.getOwnPropertyDescriptor || h) {
        var f = "Object.getOwnPropertyDescriptor called on a non-object: ";
        Object.getOwnPropertyDescriptor = function(e, t) {
            if ("object" != typeof e && "function" != typeof e || null === e) throw new TypeError(f + e);
            if (h) try {
                return h.call(Object, e, t)
            } catch (n) {}
            if (u(e, t)) {
                var i = {
                    enumerable: !0,
                    configurable: !0
                };
                if (c) {
                    var a = e.__proto__,
                        l = e !== s;
                    l && (e.__proto__ = s);
                    var d = r(e, t),
                        p = o(e, t);
                    if (l && (e.__proto__ = a), d || p) return d && (i.get = d), p && (i.set = p), i
                }
                return i.value = e[t], i.writable = !0, i
            }
        }
    }
    if (Object.getOwnPropertyNames || (Object.getOwnPropertyNames = function(e) {
            return Object.keys(e)
        }), !Object.create) {
        var p, g = !({
                __proto__: null
            }
            instanceof Object);
        p = g || "undefined" == typeof document ? function() {
            return {
                __proto__: null
            }
        } : function() {
            function e() {}
            var t = document.createElement("iframe"),
                n = document.body || document.documentElement;
            t.style.display = "none", n.appendChild(t), t.src = "javascript:";
            var i = t.contentWindow.Object.prototype;
            return n.removeChild(t), t = null, delete i.constructor, delete i.hasOwnProperty, delete i.propertyIsEnumerable, delete i.isPrototypeOf, delete i.toLocaleString, delete i.toString, delete i.valueOf, i.__proto__ = null, e.prototype = i, p = function() {
                return new e
            }, new e
        }, Object.create = function(e, t) {
            function n() {}
            var i;
            if (null === e) i = p();
            else {
                if ("object" != typeof e && "function" != typeof e) throw new TypeError("Object prototype may only be an Object or null");
                n.prototype = e, i = new n, i.__proto__ = e
            }
            return void 0 !== t && Object.defineProperties(i, t), i
        }
    }
    if (Object.defineProperty) {
        var m = t({}),
            v = "undefined" == typeof document || t(document.createElement("div"));
        if (!m || !v) var y = Object.defineProperty,
            b = Object.defineProperties
    }
    if (!Object.defineProperty || y) {
        var w = "Property description must be an object: ",
            _ = "Object.defineProperty called on non-object: ",
            C = "getters & setters can not be defined on this javascript engine";
        Object.defineProperty = function(e, t, a) {
            if ("object" != typeof e && "function" != typeof e || null === e) throw new TypeError(_ + e);
            if ("object" != typeof a && "function" != typeof a || null === a) throw new TypeError(w + a);
            if (y) try {
                return y.call(Object, e, t, a)
            } catch (l) {}
            if (u(a, "value"))
                if (c && (r(e, t) || o(e, t))) {
                    var d = e.__proto__;
                    e.__proto__ = s, delete e[t], e[t] = a.value, e.__proto__ = d
                } else e[t] = a.value;
            else {
                if (!c) throw new TypeError(C);
                u(a, "get") && n(e, t, a.get), u(a, "set") && i(e, t, a.set)
            }
            return e
        }
    }(!Object.defineProperties || b) && (Object.defineProperties = function(e, t) {
        if (b) try {
            return b.call(Object, e, t)
        } catch (n) {}
        for (var i in t) u(t, i) && "__proto__" !== i && Object.defineProperty(e, i, t[i]);
        return e
    }), Object.seal || (Object.seal = function(e) {
        return e
    }), Object.freeze || (Object.freeze = function(e) {
        return e
    });
    try {
        Object.freeze(function() {})
    } catch (k) {
        Object.freeze = function(e) {
            return function(t) {
                return "function" == typeof t ? t : e(t)
            }
        }(Object.freeze)
    }
    Object.preventExtensions || (Object.preventExtensions = function(e) {
        return e
    }), Object.isSealed || (Object.isSealed = function(e) {
        return !1
    }), Object.isFrozen || (Object.isFrozen = function(e) {
        return !1
    }), Object.isExtensible || (Object.isExtensible = function(e) {
        if (Object(e) !== e) throw new TypeError;
        for (var t = ""; u(e, t);) t += "?";
        e[t] = !0;
        var n = u(e, t);
        return delete e[t], n
    })
}),
function(e, t) {
    function n(e) {
        return !!("" === e || e && e.charCodeAt && e.substr)
    }

    function i(e) {
        return d ? d(e) : "[object Array]" === h.call(e)
    }

    function r(e) {
        return e && "[object Object]" === h.call(e)
    }

    function o(e, t) {
        var n;
        e = e || {}, t = t || {};
        for (n in t) t.hasOwnProperty(n) && null == e[n] && (e[n] = t[n]);
        return e
    }

    function a(e, t, n) {
        var i, r, o = [];
        if (!e) return o;
        if (l && e.map === l) return e.map(t, n);
        for (i = 0, r = e.length; r > i; i++) o[i] = t.call(n, e[i], i, e);
        return o
    }

    function s(e, t) {
        return e = Math.round(Math.abs(e)), isNaN(e) ? t : e
    }

    function u(e) {
        var t = c.settings.currency.format;
        return "function" == typeof e && (e = e()), n(e) && e.match("%v") ? {
            pos: e,
            neg: e.replace("-", "").replace("%v", "-%v"),
            zero: e
        } : e && e.pos && e.pos.match("%v") ? e : n(t) ? c.settings.currency.format = {
            pos: t,
            neg: t.replace("%v", "-%v"),
            zero: t
        } : t
    }
    var c = {};
    c.version = "0.4.1", c.settings = {
        currency: {
            symbol: "$",
            format: "%s%v",
            decimal: ".",
            thousand: ",",
            precision: 2,
            grouping: 3
        },
        number: {
            precision: 0,
            grouping: 3,
            thousand: ",",
            decimal: "."
        }
    };
    var l = Array.prototype.map,
        d = Array.isArray,
        h = Object.prototype.toString,
        f = c.unformat = c.parse = function(e, t) {
            if (i(e)) return a(e, function(e) {
                return f(e, t)
            });
            if (e = e || 0, "number" == typeof e) return e;
            t = t || c.settings.number.decimal;
            var n = new RegExp("[^0-9-" + t + "]", ["g"]),
                r = parseFloat(("" + e).replace(/\((.*)\)/, "-$1").replace(n, "").replace(t, "."));
            return isNaN(r) ? 0 : r
        },
        p = c.toFixed = function(e, t) {
            t = s(t, c.settings.number.precision);
            var n = Math.pow(10, t);
            return (Math.round(c.unformat(e) * n) / n).toFixed(t)
        },
        g = c.formatNumber = c.format = function(e, t, n, u) {
            if (i(e)) return a(e, function(e) {
                return g(e, t, n, u)
            });
            e = f(e);
            var l = o(r(t) ? t : {
                    precision: t,
                    thousand: n,
                    decimal: u
                }, c.settings.number),
                d = s(l.precision),
                h = 0 > e ? "-" : "",
                m = parseInt(p(Math.abs(e || 0), d), 10) + "",
                v = m.length > 3 ? m.length % 3 : 0;
            return h + (v ? m.substr(0, v) + l.thousand : "") + m.substr(v).replace(/(\d{3})(?=\d)/g, "$1" + l.thousand) + (d ? l.decimal + p(Math.abs(e), d).split(".")[1] : "")
        },
        m = c.formatMoney = function(e, t, n, l, d, h) {
            if (i(e)) return a(e, function(e) {
                return m(e, t, n, l, d, h)
            });
            e = f(e);
            var p = o(r(t) ? t : {
                    symbol: t,
                    precision: n,
                    thousand: l,
                    decimal: d,
                    format: h
                }, c.settings.currency),
                v = u(p.format),
                y = e > 0 ? v.pos : 0 > e ? v.neg : v.zero;
            return y.replace("%s", p.symbol).replace("%v", g(Math.abs(e), s(p.precision), p.thousand, p.decimal))
        };
    c.formatColumn = function(e, t, l, d, h, p) {
        if (!e) return [];
        var m = o(r(t) ? t : {
                symbol: t,
                precision: l,
                thousand: d,
                decimal: h,
                format: p
            }, c.settings.currency),
            v = u(m.format),
            y = v.pos.indexOf("%s") < v.pos.indexOf("%v"),
            b = 0,
            w = a(e, function(e, t) {
                if (i(e)) return c.formatColumn(e, m);
                e = f(e);
                var n = e > 0 ? v.pos : 0 > e ? v.neg : v.zero,
                    r = n.replace("%s", m.symbol).replace("%v", g(Math.abs(e), s(m.precision), m.thousand, m.decimal));
                return r.length > b && (b = r.length), r
            });
        return a(w, function(e, t) {
            return n(e) && e.length < b ? y ? e.replace(m.symbol, m.symbol + new Array(b - e.length + 1).join(" ")) : new Array(b - e.length + 1).join(" ") + e : e
        })
    }, "undefined" != typeof exports ? ("undefined" != typeof module && module.exports && (exports = module.exports = c), exports.accounting = c) : "function" == typeof define && define.amd ? define([], function() {
        return c
    }) : (c.noConflict = function(n) {
        return function() {
            return e.accounting = n, c.noConflict = t, c
        }
    }(e.accounting), e.accounting = c)
}(this),
function(e) {
    e.fingerprint = function() {
        function t() {
            var t = null;
            try {
                t = e.map(navigator.plugins, function(t) {
                    return [t.name, t.description, e.map(t, function(e) {
                        return [e.type, e.suffixes].join("~")
                    }).join(",")].join("::")
                }).join(";")
            } catch (n) {
                t = "invalid-plugins"
            }
            return [navigator.userAgent, [screen.height, screen.width, screen.colorDepth].join("x"), (new Date).getTimezoneOffset(), t, i().join("+")].join("###")
        }

        function n() {
            if ("function" == typeof window.md5) return md5(t());
            throw "md5 unavailable, please get it from http://github.com/wbond/md5-js/"
        }

        function i() {
            return "function" == typeof e.fontlist_DEPRECATED ? e.fontlist_DEPRECATED() : []
        }
        return n()
    }
}(jQuery);
var swfobject = function() {
    function e() {
        if (!W) {
            try {
                var e = I.getElementsByTagName("body")[0].appendChild(m("span"));
                e.parentNode.removeChild(e)
            } catch (t) {
                return
            }
            W = !0;
            for (var n = N.length, i = 0; n > i; i++) N[i]()
        }
    }

    function t(e) {
        W ? e() : N[N.length] = e
    }

    function n(e) {
        if (typeof F.addEventListener != B) F.addEventListener("load", e, !1);
        else if (typeof I.addEventListener != B) I.addEventListener("load", e, !1);
        else if (typeof F.attachEvent != B) v(F, "onload", e);
        else if ("function" == typeof F.onload) {
            var t = F.onload;
            F.onload = function() {
                t(), e()
            }
        } else F.onload = e
    }

    function i() {
        j ? r() : o()
    }

    function r() {
        var e = I.getElementsByTagName("body")[0],
            t = m(P);
        t.setAttribute("type", O);
        var n = e.appendChild(t);
        if (n) {
            var i = 0;
            ! function() {
                if (typeof n.GetVariable != B) {
                    var r = n.GetVariable("$version");
                    r && (r = r.split(" ")[1].split(","), G.pv = [parseInt(r[0], 10), parseInt(r[1], 10), parseInt(r[2], 10)])
                } else if (10 > i) return i++, void setTimeout(arguments.callee, 10);
                e.removeChild(t), n = null, o()
            }()
        } else o()
    }

    function o() {
        var e = U.length;
        if (e > 0)
            for (var t = 0; e > t; t++) {
                var n = U[t].id,
                    i = U[t].callbackFn,
                    r = {
                        success: !1,
                        id: n
                    };
                if (G.pv[0] > 0) {
                    var o = g(n);
                    if (o)
                        if (!y(U[t].swfVersion) || G.wk && G.wk < 312)
                            if (U[t].expressInstall && s()) {
                                var l = {};
                                l.data = U[t].expressInstall, l.width = o.getAttribute("width") || "0", l.height = o.getAttribute("height") || "0", o.getAttribute("class") && (l.styleclass = o.getAttribute("class")), o.getAttribute("align") && (l.align = o.getAttribute("align"));
                                for (var d = {}, h = o.getElementsByTagName("param"), f = h.length, p = 0; f > p; p++) "movie" != h[p].getAttribute("name").toLowerCase() && (d[h[p].getAttribute("name")] = h[p].getAttribute("value"));
                                u(l, d, n, i)
                            } else c(o), i && i(r);
                    else w(n, !0), i && (r.success = !0, r.ref = a(n), i(r))
                } else if (w(n, !0), i) {
                    var m = a(n);
                    m && typeof m.SetVariable != B && (r.success = !0, r.ref = m), i(r)
                }
            }
    }

    function a(e) {
        var t = null,
            n = g(e);
        if (n && "OBJECT" == n.nodeName)
            if (typeof n.SetVariable != B) t = n;
            else {
                var i = n.getElementsByTagName(P)[0];
                i && (t = i)
            }
        return t
    }

    function s() {
        return !H && y("6.0.65") && (G.win || G.mac) && !(G.wk && G.wk < 312)
    }

    function u(e, t, n, i) {
        H = !0, E = i || null, S = {
            success: !1,
            id: n
        };
        var r = g(n);
        if (r) {
            "OBJECT" == r.nodeName ? (C = l(r), k = null) : (C = r, k = n), e.id = $, (typeof e.width == B || !/%$/.test(e.width) && parseInt(e.width, 10) < 310) && (e.width = "310"), (typeof e.height == B || !/%$/.test(e.height) && parseInt(e.height, 10) < 137) && (e.height = "137"), I.title = I.title.slice(0, 47) + " - Flash Player Installation";
            var o = G.ie && G.win ? "ActiveX" : "PlugIn",
                a = "MMredirectURL=" + F.location.toString().replace(/&/g, "%26") + "&MMplayerType=" + o + "&MMdoctitle=" + I.title;
            if (typeof t.flashvars != B ? t.flashvars += "&" + a : t.flashvars = a, G.ie && G.win && 4 != r.readyState) {
                var s = m("div");
                n += "SWFObjectNew", s.setAttribute("id", n), r.parentNode.insertBefore(s, r), r.style.display = "none",
                    function() {
                        4 == r.readyState ? r.parentNode.removeChild(r) : setTimeout(arguments.callee, 10)
                    }()
            }
            d(e, t, n)
        }
    }

    function c(e) {
        if (G.ie && G.win && 4 != e.readyState) {
            var t = m("div");
            e.parentNode.insertBefore(t, e), t.parentNode.replaceChild(l(e), t), e.style.display = "none",
                function() {
                    4 == e.readyState ? e.parentNode.removeChild(e) : setTimeout(arguments.callee, 10)
                }()
        } else e.parentNode.replaceChild(l(e), e)
    }

    function l(e) {
        var t = m("div");
        if (G.win && G.ie) t.innerHTML = e.innerHTML;
        else {
            var n = e.getElementsByTagName(P)[0];
            if (n) {
                var i = n.childNodes;
                if (i)
                    for (var r = i.length, o = 0; r > o; o++) 1 == i[o].nodeType && "PARAM" == i[o].nodeName || 8 == i[o].nodeType || t.appendChild(i[o].cloneNode(!0))
            }
        }
        return t
    }

    function d(e, t, n) {
        var i, r = g(n);
        if (G.wk && G.wk < 312) return i;
        if (r)
            if (typeof e.id == B && (e.id = n), G.ie && G.win) {
                var o = "";
                for (var a in e) e[a] != Object.prototype[a] && ("data" == a.toLowerCase() ? t.movie = e[a] : "styleclass" == a.toLowerCase() ? o += ' class="' + e[a] + '"' : "classid" != a.toLowerCase() && (o += " " + a + '="' + e[a] + '"'));
                var s = "";
                for (var u in t) t[u] != Object.prototype[u] && (s += '<param name="' + u + '" value="' + t[u] + '" />');
                r.outerHTML = '<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"' + o + ">" + s + "</object>", L[L.length] = e.id, i = g(e.id)
            } else {
                var c = m(P);
                c.setAttribute("type", O);
                for (var l in e) e[l] != Object.prototype[l] && ("styleclass" == l.toLowerCase() ? c.setAttribute("class", e[l]) : "classid" != l.toLowerCase() && c.setAttribute(l, e[l]));
                for (var d in t) t[d] != Object.prototype[d] && "movie" != d.toLowerCase() && h(c, d, t[d]);
                r.parentNode.replaceChild(c, r), i = c
            }
        return i
    }

    function h(e, t, n) {
        var i = m("param");
        i.setAttribute("name", t), i.setAttribute("value", n), e.appendChild(i)
    }

    function f(e) {
        var t = g(e);
        t && "OBJECT" == t.nodeName && (G.ie && G.win ? (t.style.display = "none", function() {
            4 == t.readyState ? p(e) : setTimeout(arguments.callee, 10)
        }()) : t.parentNode.removeChild(t))
    }

    function p(e) {
        var t = g(e);
        if (t) {
            for (var n in t) "function" == typeof t[n] && (t[n] = null);
            t.parentNode.removeChild(t)
        }
    }

    function g(e) {
        var t = null;
        try {
            t = I.getElementById(e)
        } catch (n) {}
        return t
    }

    function m(e) {
        return I.createElement(e)
    }

    function v(e, t, n) {
        e.attachEvent(t, n), V[V.length] = [e, t, n]
    }

    function y(e) {
        var t = G.pv,
            n = e.split(".");
        return n[0] = parseInt(n[0], 10), n[1] = parseInt(n[1], 10) || 0, n[2] = parseInt(n[2], 10) || 0, t[0] > n[0] || t[0] == n[0] && t[1] > n[1] || t[0] == n[0] && t[1] == n[1] && t[2] >= n[2] ? !0 : !1
    }

    function b(e, t, n, i) {
        if (!G.ie || !G.mac) {
            var r = I.getElementsByTagName("head")[0];
            if (r) {
                var o = n && "string" == typeof n ? n : "screen";
                if (i && (x = null, T = null), !x || T != o) {
                    var a = m("style");
                    a.setAttribute("type", "text/css"), a.setAttribute("media", o), x = r.appendChild(a), G.ie && G.win && typeof I.styleSheets != B && I.styleSheets.length > 0 && (x = I.styleSheets[I.styleSheets.length - 1]), T = o
                }
                G.ie && G.win ? x && typeof x.addRule == P && x.addRule(e, t) : x && typeof I.createTextNode != B && x.appendChild(I.createTextNode(e + " {" + t + "}"))
            }
        }
    }

    function w(e, t) {
        if (q) {
            var n = t ? "visible" : "hidden";
            W && g(e) ? g(e).style.visibility = n : b("#" + e, "visibility:" + n)
        }
    }

    function _(e) {
        var t = /[\\\"<>\.;]/,
            n = null != t.exec(e);
        return n && typeof encodeURIComponent != B ? encodeURIComponent(e) : e
    }
    var C, k, E, S, x, T, B = "undefined",
        P = "object",
        A = "Shockwave Flash",
        D = "ShockwaveFlash.ShockwaveFlash",
        O = "application/x-shockwave-flash",
        $ = "SWFObjectExprInst",
        M = "onreadystatechange",
        F = window,
        I = document,
        R = navigator,
        j = !1,
        N = [i],
        U = [],
        L = [],
        V = [],
        W = !1,
        H = !1,
        q = !0,
        G = function() {
            var e = typeof I.getElementById != B && typeof I.getElementsByTagName != B && typeof I.createElement != B,
                t = R.userAgent.toLowerCase(),
                n = R.platform.toLowerCase(),
                i = n ? /win/.test(n) : /win/.test(t),
                r = n ? /mac/.test(n) : /mac/.test(t),
                o = /webkit/.test(t) ? parseFloat(t.replace(/^.*webkit\/(\d+(\.\d+)?).*$/, "$1")) : !1,
                a = !1,
                s = [0, 0, 0],
                u = null;
            if (typeof R.plugins != B && typeof R.plugins[A] == P) u = R.plugins[A].description, !u || typeof R.mimeTypes != B && R.mimeTypes[O] && !R.mimeTypes[O].enabledPlugin || (j = !0, a = !1, u = u.replace(/^.*\s+(\S+\s+\S+$)/, "$1"), s[0] = parseInt(u.replace(/^(.*)\..*$/, "$1"), 10), s[1] = parseInt(u.replace(/^.*\.(.*)\s.*$/, "$1"), 10), s[2] = /[a-zA-Z]/.test(u) ? parseInt(u.replace(/^.*[a-zA-Z]+(.*)$/, "$1"), 10) : 0);
            else if (typeof F.ActiveXObject != B) try {
                var c = new ActiveXObject(D);
                c && (u = c.GetVariable("$version"), u && (a = !0, u = u.split(" ")[1].split(","), s = [parseInt(u[0], 10), parseInt(u[1], 10), parseInt(u[2], 10)]))
            } catch (l) {}
            return {
                w3: e,
                pv: s,
                wk: o,
                ie: a,
                win: i,
                mac: r
            }
        }();
    (function() {
        G.w3 && ((typeof I.readyState != B && "complete" == I.readyState || typeof I.readyState == B && (I.getElementsByTagName("body")[0] || I.body)) && e(), W || (typeof I.addEventListener != B && I.addEventListener("DOMContentLoaded", e, !1), G.ie && G.win && (I.attachEvent(M, function() {
            "complete" == I.readyState && (I.detachEvent(M, arguments.callee), e())
        }), F == top && ! function() {
            if (!W) {
                try {
                    I.documentElement.doScroll("left")
                } catch (t) {
                    return void setTimeout(arguments.callee, 0)
                }
                e()
            }
        }()), G.wk && ! function() {
            return W ? void 0 : /loaded|complete/.test(I.readyState) ? void e() : void setTimeout(arguments.callee, 0)
        }(), n(e)))
    })(),
    function() {
        G.ie && G.win && window.attachEvent("onunload", function() {
            for (var e = V.length, t = 0; e > t; t++) V[t][0].detachEvent(V[t][1], V[t][2]);
            for (var n = L.length, i = 0; n > i; i++) f(L[i]);
            for (var r in G) G[r] = null;
            G = null;
            for (var o in swfobject) swfobject[o] = null;
            swfobject = null
        })
    }();
    return {
        registerObject: function(e, t, n, i) {
            if (G.w3 && e && t) {
                var r = {};
                r.id = e, r.swfVersion = t, r.expressInstall = n, r.callbackFn = i, U[U.length] = r, w(e, !1)
            } else i && i({
                success: !1,
                id: e
            })
        },
        getObjectById: function(e) {
            return G.w3 ? a(e) : void 0
        },
        embedSWF: function(e, n, i, r, o, a, c, l, h, f) {
            var p = {
                success: !1,
                id: n
            };
            G.w3 && !(G.wk && G.wk < 312) && e && n && i && r && o ? (w(n, !1), t(function() {
                i += "", r += "";
                var t = {};
                if (h && typeof h === P)
                    for (var g in h) t[g] = h[g];
                t.data = e, t.width = i, t.height = r;
                var m = {};
                if (l && typeof l === P)
                    for (var v in l) m[v] = l[v];
                if (c && typeof c === P)
                    for (var b in c) typeof m.flashvars != B ? m.flashvars += "&" + b + "=" + c[b] : m.flashvars = b + "=" + c[b];
                if (y(o)) {
                    var _ = d(t, m, n);
                    t.id == n && w(n, !0), p.success = !0, p.ref = _
                } else {
                    if (a && s()) return t.data = a, void u(t, m, n, f);
                    w(n, !0)
                }
                f && f(p)
            })) : f && f(p)
        },
        switchOffAutoHideShow: function() {
            q = !1
        },
        ua: G,
        getFlashPlayerVersion: function() {
            return {
                major: G.pv[0],
                minor: G.pv[1],
                release: G.pv[2]
            }
        },
        hasFlashPlayerVersion: y,
        createSWF: function(e, t, n) {
            return G.w3 ? d(e, t, n) : void 0
        },
        showExpressInstall: function(e, t, n, i) {
            G.w3 && s() && u(e, t, n, i)
        },
        removeSWF: function(e) {
            G.w3 && f(e)
        },
        createCSS: function(e, t, n, i) {
            G.w3 && b(e, t, n, i)
        },
        addDomLoadEvent: t,
        addLoadEvent: n,
        getQueryParamValue: function(e) {
            var t = I.location.search || I.location.hash;
            if (t) {
                if (/\?/.test(t) && (t = t.split("?")[1]), null == e) return _(t);
                for (var n = t.split("&"), i = 0; i < n.length; i++)
                    if (n[i].substring(0, n[i].indexOf("=")) == e) return _(n[i].substring(n[i].indexOf("=") + 1))
            }
            return ""
        },
        expressInstallCallback: function() {
            if (H) {
                var e = g($);
                e && C && (e.parentNode.replaceChild(C, e), k && (w(k, !0), G.ie && G.win && (C.style.display = "block")), E && E(S)), H = !1
            }
        }
    }
}();
(function() {
    function e(n, i) {
        t(n), i = i || {};
        var r = this;
        this.key = n, this.config = e.Util.extend(e.getGlobalConfig(), i.cluster ? e.getClusterConfig(i.cluster) : {}, i), this.channels = new e.Channels, this.global_emitter = new e.EventsDispatcher, this.sessionID = Math.floor(1e9 * Math.random()), this.timeline = new e.Timeline(this.key, this.sessionID, {
            cluster: this.config.cluster,
            features: e.Util.getClientFeatures(),
            params: this.config.timelineParams || {},
            limit: 50,
            level: e.Timeline.INFO,
            version: e.VERSION
        }), this.config.disableStats || (this.timelineSender = new e.TimelineSender(this.timeline, {
            host: this.config.statsHost,
            path: "/timeline/v2/jsonp"
        }));
        var o = function(t) {
            var n = e.Util.extend({}, r.config, t);
            return e.StrategyBuilder.build(e.getDefaultStrategy(n), n)
        };
        this.connection = new e.ConnectionManager(this.key, e.Util.extend({
            getStrategy: o,
            timeline: this.timeline,
            activityTimeout: this.config.activity_timeout,
            pongTimeout: this.config.pong_timeout,
            unavailableTimeout: this.config.unavailable_timeout
        }, this.config, {
            encrypted: this.isEncrypted()
        })), this.connection.bind("connected", function() {
            r.subscribeAll(), r.timelineSender && r.timelineSender.send(r.connection.isEncrypted())
        }), this.connection.bind("message", function(e) {
            var t = 0 === e.event.indexOf("pusher_internal:");
            if (e.channel) {
                var n = r.channel(e.channel);
                n && n.handleEvent(e.event, e.data)
            }
            t || r.global_emitter.emit(e.event, e.data)
        }), this.connection.bind("disconnected", function() {
            r.channels.disconnect()
        }), this.connection.bind("error", function(t) {
            e.warn("Error", t)
        }), e.instances.push(this), this.timeline.info({
            instances: e.instances.length
        }), e.isReady && r.connect()
    }

    function t(t) {
        (null === t || void 0 === t) && e.warn("Warning", "You must pass your app key when you instantiate Pusher.")
    }
    var n = e.prototype;
    e.instances = [], e.isReady = !1, e.debug = function() {
        e.log && e.log(e.Util.stringify.apply(this, arguments))
    }, e.warn = function() {
        var t = e.Util.stringify.apply(this, arguments);
        window.console && (window.console.warn ? window.console.warn(t) : window.console.log && window.console.log(t)), e.log && e.log(t)
    }, e.ready = function() {
        e.isReady = !0;
        for (var t = 0, n = e.instances.length; n > t; t++) e.instances[t].connect()
    }, n.channel = function(e) {
        return this.channels.find(e)
    }, n.allChannels = function() {
        return this.channels.all()
    }, n.connect = function() {
        if (this.connection.connect(), this.timelineSender && !this.timelineSenderTimer) {
            var t = this.connection.isEncrypted(),
                n = this.timelineSender;
            this.timelineSenderTimer = new e.PeriodicTimer(6e4, function() {
                n.send(t)
            })
        }
    }, n.disconnect = function() {
        this.connection.disconnect(), this.timelineSenderTimer && (this.timelineSenderTimer.ensureAborted(), this.timelineSenderTimer = null)
    }, n.bind = function(e, t) {
        return this.global_emitter.bind(e, t), this
    }, n.bind_all = function(e) {
        return this.global_emitter.bind_all(e), this
    }, n.subscribeAll = function() {
        var e;
        for (e in this.channels.channels) this.channels.channels.hasOwnProperty(e) && this.subscribe(e)
    }, n.subscribe = function(e) {
        var t = this.channels.add(e, this);
        return "connected" === this.connection.state && t.subscribe(), t
    }, n.unsubscribe = function(e) {
        var t = this.channels.remove(e);
        "connected" === this.connection.state && t.unsubscribe()
    }, n.send_event = function(e, t, n) {
        return this.connection.send_event(e, t, n)
    }, n.isEncrypted = function() {
        return "https:" === e.Util.getDocument().location.protocol ? !0 : Boolean(this.config.encrypted)
    }, e.HTTP = {}, this.Pusher = e
}).call(this),
    function() {
        function e(e) {
            window.clearTimeout(e)
        }

        function t(e) {
            window.clearInterval(e)
        }

        function n(e, t, n, i) {
            var r = this;
            this.clear = t, this.timer = e(function() {
                null !== r.timer && (r.timer = i(r.timer))
            }, n)
        }
        var i = n.prototype;
        i.isRunning = function() {
            return null !== this.timer
        }, i.ensureAborted = function() {
            this.timer && (this.clear(this.timer), this.timer = null)
        }, Pusher.Timer = function(t, i) {
            return new n(setTimeout, e, t, function(e) {
                return i(), null
            })
        }, Pusher.PeriodicTimer = function(e, i) {
            return new n(setInterval, t, e, function(e) {
                return i(), e
            })
        }
    }.call(this),
    function() {
        Pusher.Util = {
            now: function() {
                return Date.now ? Date.now() : (new Date).valueOf()
            },
            defer: function(e) {
                return new Pusher.Timer(0, e)
            },
            extend: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t];
                    for (var i in n) n[i] && n[i].constructor && n[i].constructor === Object ? e[i] = Pusher.Util.extend(e[i] || {}, n[i]) : e[i] = n[i]
                }
                return e
            },
            stringify: function() {
                for (var e = ["Pusher"], t = 0; t < arguments.length; t++) "string" == typeof arguments[t] ? e.push(arguments[t]) : void 0 === window.JSON ? e.push(arguments[t].toString()) : e.push(JSON.stringify(arguments[t]));
                return e.join(" : ")
            },
            arrayIndexOf: function(e, t) {
                var n = Array.prototype.indexOf;
                if (null === e) return -1;
                if (n && e.indexOf === n) return e.indexOf(t);
                for (var i = 0, r = e.length; r > i; i++)
                    if (e[i] === t) return i;
                return -1
            },
            objectApply: function(e, t) {
                for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t(e[n], n, e)
            },
            keys: function(e) {
                var t = [];
                return Pusher.Util.objectApply(e, function(e, n) {
                    t.push(n)
                }), t
            },
            values: function(e) {
                var t = [];
                return Pusher.Util.objectApply(e, function(e) {
                    t.push(e)
                }), t
            },
            apply: function(e, t, n) {
                for (var i = 0; i < e.length; i++) t.call(n || window, e[i], i, e)
            },
            map: function(e, t) {
                for (var n = [], i = 0; i < e.length; i++) n.push(t(e[i], i, e, n));
                return n
            },
            mapObject: function(e, t) {
                var n = {};
                return Pusher.Util.objectApply(e, function(e, i) {
                    n[i] = t(e)
                }), n
            },
            filter: function(e, t) {
                t = t || function(e) {
                    return !!e
                };
                for (var n = [], i = 0; i < e.length; i++) t(e[i], i, e, n) && n.push(e[i]);
                return n
            },
            filterObject: function(e, t) {
                var n = {};
                return Pusher.Util.objectApply(e, function(i, r) {
                    (t && t(i, r, e, n) || Boolean(i)) && (n[r] = i)
                }), n
            },
            flatten: function(e) {
                var t = [];
                return Pusher.Util.objectApply(e, function(e, n) {
                    t.push([n, e])
                }), t
            },
            any: function(e, t) {
                for (var n = 0; n < e.length; n++)
                    if (t(e[n], n, e)) return !0;
                return !1
            },
            all: function(e, t) {
                for (var n = 0; n < e.length; n++)
                    if (!t(e[n], n, e)) return !1;
                return !0
            },
            method: function(e) {
                var t = Array.prototype.slice.call(arguments, 1);
                return function(n) {
                    return n[e].apply(n, t.concat(arguments))
                }
            },
            getWindow: function() {
                return window
            },
            getDocument: function() {
                return document
            },
            getNavigator: function() {
                return navigator
            },
            getLocalStorage: function() {
                try {
                    return window.localStorage
                } catch (e) {
                    return void 0
                }
            },
            getClientFeatures: function() {
                return Pusher.Util.keys(Pusher.Util.filterObject({
                    ws: Pusher.WSTransport,
                    flash: Pusher.FlashTransport
                }, function(e) {
                    return e.isSupported({})
                }))
            },
            addWindowListener: function(e, t) {
                var n = Pusher.Util.getWindow();
                void 0 !== n.addEventListener ? n.addEventListener(e, t, !1) : n.attachEvent("on" + e, t)
            },
            removeWindowListener: function(e, t) {
                var n = Pusher.Util.getWindow();
                void 0 !== n.addEventListener ? n.removeEventListener(e, t, !1) : n.detachEvent("on" + e, t)
            },
            isXHRSupported: function() {
                var e = window.XMLHttpRequest;
                return Boolean(e) && void 0 !== (new e).withCredentials
            },
            isXDRSupported: function(e) {
                var t = e ? "https:" : "http:",
                    n = Pusher.Util.getDocument().location.protocol;
                return Boolean(window.XDomainRequest) && n === t
            }
        }
    }.call(this),
    function() {
        Pusher.VERSION = "2.2.3", Pusher.PROTOCOL = 7, Pusher.host = "ws.pusherapp.com", Pusher.ws_port = 80, Pusher.wss_port = 443, Pusher.sockjs_host = "sockjs.pusher.com", Pusher.sockjs_http_port = 80, Pusher.sockjs_https_port = 443, Pusher.sockjs_path = "/pusher", Pusher.stats_host = "stats.pusher.com", Pusher.channel_auth_endpoint = "/pusher/auth", Pusher.channel_auth_transport = "ajax", Pusher.activity_timeout = 12e4, Pusher.pong_timeout = 3e4, Pusher.unavailable_timeout = 1e4, Pusher.cdn_http = "http://js.pusher.com/", Pusher.cdn_https = "https://js.pusher.com/", Pusher.dependency_suffix = "", Pusher.getDefaultStrategy = function(e) {
            var t;
            return t = e.encrypted ? [":best_connected_ever", ":ws_loop", [":delayed", 2e3, [":http_fallback_loop"]]] : [":best_connected_ever", ":ws_loop", [":delayed", 2e3, [":wss_loop"]],
                [":delayed", 5e3, [":http_fallback_loop"]]
            ], [
                [":def", "ws_options", {
                    hostUnencrypted: e.wsHost + ":" + e.wsPort,
                    hostEncrypted: e.wsHost + ":" + e.wssPort
                }],
                [":def", "wss_options", [":extend", ":ws_options", {
                    encrypted: !0
                }]],
                [":def", "sockjs_options", {
                    hostUnencrypted: e.httpHost + ":" + e.httpPort,
                    hostEncrypted: e.httpHost + ":" + e.httpsPort,
                    httpPath: e.httpPath
                }],
                [":def", "timeouts", {
                    loop: !0,
                    timeout: 15e3,
                    timeoutLimit: 6e4
                }],
                [":def", "ws_manager", [":transport_manager", {
                    lives: 2,
                    minPingDelay: 1e4,
                    maxPingDelay: e.activity_timeout
                }]],
                [":def", "streaming_manager", [":transport_manager", {
                    lives: 2,
                    minPingDelay: 1e4,
                    maxPingDelay: e.activity_timeout
                }]],
                [":def_transport", "ws", "ws", 3, ":ws_options", ":ws_manager"],
                [":def_transport", "wss", "ws", 3, ":wss_options", ":ws_manager"],
                [":def_transport", "flash", "flash", 2, ":ws_options", ":ws_manager"],
                [":def_transport", "sockjs", "sockjs", 1, ":sockjs_options"],
                [":def_transport", "xhr_streaming", "xhr_streaming", 1, ":sockjs_options", ":streaming_manager"],
                [":def_transport", "xdr_streaming", "xdr_streaming", 1, ":sockjs_options", ":streaming_manager"],
                [":def_transport", "xhr_polling", "xhr_polling", 1, ":sockjs_options"],
                [":def_transport", "xdr_polling", "xdr_polling", 1, ":sockjs_options"],
                [":def", "ws_loop", [":sequential", ":timeouts", ":ws"]],
                [":def", "wss_loop", [":sequential", ":timeouts", ":wss"]],
                [":def", "flash_loop", [":sequential", ":timeouts", ":flash"]],
                [":def", "sockjs_loop", [":sequential", ":timeouts", ":sockjs"]],
                [":def", "streaming_loop", [":sequential", ":timeouts", [":if", [":is_supported", ":xhr_streaming"], ":xhr_streaming", ":xdr_streaming"]]],
                [":def", "polling_loop", [":sequential", ":timeouts", [":if", [":is_supported", ":xhr_polling"], ":xhr_polling", ":xdr_polling"]]],
                [":def", "http_loop", [":if", [":is_supported", ":streaming_loop"],
                    [":best_connected_ever", ":streaming_loop", [":delayed", 4e3, [":polling_loop"]]],
                    [":polling_loop"]
                ]],
                [":def", "http_fallback_loop", [":if", [":is_supported", ":http_loop"],
                    [":http_loop"],
                    [":sockjs_loop"]
                ]],
                [":def", "strategy", [":cached", 18e5, [":first_connected", [":if", [":is_supported", ":ws"], t, [":if", [":is_supported", ":flash"],
                    [":best_connected_ever", ":flash_loop", [":delayed", 2e3, [":http_fallback_loop"]]],
                    [":http_fallback_loop"]
                ]]]]]
            ]
        }
    }.call(this),
    function() {
        Pusher.getGlobalConfig = function() {
            return {
                wsHost: Pusher.host,
                wsPort: Pusher.ws_port,
                wssPort: Pusher.wss_port,
                httpHost: Pusher.sockjs_host,
                httpPort: Pusher.sockjs_http_port,
                httpsPort: Pusher.sockjs_https_port,
                httpPath: Pusher.sockjs_path,
                statsHost: Pusher.stats_host,
                authEndpoint: Pusher.channel_auth_endpoint,
                authTransport: Pusher.channel_auth_transport,
                activity_timeout: Pusher.activity_timeout,
                pong_timeout: Pusher.pong_timeout,
                unavailable_timeout: Pusher.unavailable_timeout
            }
        }, Pusher.getClusterConfig = function(e) {
            return {
                wsHost: "ws-" + e + ".pusher.com",
                httpHost: "sockjs-" + e + ".pusher.com"
            }
        }
    }.call(this),
    function() {
        function e(e) {
            var t = function(t) {
                Error.call(this, t), this.name = e
            };
            return Pusher.Util.extend(t.prototype, Error.prototype), t
        }
        Pusher.Errors = {
            BadEventName: e("BadEventName"),
            RequestTimedOut: e("RequestTimedOut"),
            TransportPriorityTooLow: e("TransportPriorityTooLow"),
            TransportClosed: e("TransportClosed"),
            UnsupportedTransport: e("UnsupportedTransport"),
            UnsupportedStrategy: e("UnsupportedStrategy")
        }
    }.call(this),
    function() {
        function e(e) {
            this.callbacks = new t, this.global_callbacks = [], this.failThrough = e
        }

        function t() {
            this._callbacks = {}
        }

        function n(e) {
            return "_" + e
        }
        var i = e.prototype;
        i.bind = function(e, t, n) {
            return this.callbacks.add(e, t, n), this
        }, i.bind_all = function(e) {
            return this.global_callbacks.push(e), this
        }, i.unbind = function(e, t, n) {
            return this.callbacks.remove(e, t, n), this
        }, i.unbind_all = function(e, t) {
            return this.callbacks.remove(e, t), this
        }, i.emit = function(e, t) {
            var n;
            for (n = 0; n < this.global_callbacks.length; n++) this.global_callbacks[n](e, t);
            var i = this.callbacks.get(e);
            if (i && i.length > 0)
                for (n = 0; n < i.length; n++) i[n].fn.call(i[n].context || window, t);
            else this.failThrough && this.failThrough(e, t);
            return this
        }, t.prototype.get = function(e) {
            return this._callbacks[n(e)]
        }, t.prototype.add = function(e, t, i) {
            var r = n(e);
            this._callbacks[r] = this._callbacks[r] || [], this._callbacks[r].push({
                fn: t,
                context: i
            })
        }, t.prototype.remove = function(e, t, i) {
            if (!e && !t && !i) return void(this._callbacks = {});
            var r = e ? [n(e)] : Pusher.Util.keys(this._callbacks);
            t || i ? Pusher.Util.apply(r, function(e) {
                this._callbacks[e] = Pusher.Util.filter(this._callbacks[e] || [], function(e) {
                    return t && t !== e.fn || i && i !== e.context
                }), 0 === this._callbacks[e].length && delete this._callbacks[e]
            }, this) : Pusher.Util.apply(r, function(e) {
                delete this._callbacks[e]
            }, this)
        }, Pusher.EventsDispatcher = e
    }.call(this),
    function() {
        function e(e, t) {
            this.lastId = 0, this.prefix = e, this.name = t
        }
        var t = e.prototype;
        t.create = function(e) {
            this.lastId++;
            var t = this.lastId,
                n = this.prefix + t,
                i = this.name + "[" + t + "]",
                r = !1,
                o = function() {
                    r || (e.apply(null, arguments), r = !0)
                };
            return this[t] = o, {
                number: t,
                id: n,
                name: i,
                callback: o
            }
        }, t.remove = function(e) {
            delete this[e.number]
        }, Pusher.ScriptReceiverFactory = e, Pusher.ScriptReceivers = new e("_pusher_script_", "Pusher.ScriptReceivers")
    }.call(this),
    function() {
        function e(e) {
            this.src = e
        }
        var t = e.prototype;
        t.send = function(e) {
            var t = this,
                n = "Error loading " + t.src;
            t.script = document.createElement("script"), t.script.id = e.id, t.script.src = t.src, t.script.type = "text/javascript", t.script.charset = "UTF-8", t.script.addEventListener ? (t.script.onerror = function() {
                e.callback(n)
            }, t.script.onload = function() {
                e.callback(null)
            }) : t.script.onreadystatechange = function() {
                ("loaded" === t.script.readyState || "complete" === t.script.readyState) && e.callback(null)
            }, void 0 === t.script.async && document.attachEvent && /opera/i.test(navigator.userAgent) ? (t.errorScript = document.createElement("script"), t.errorScript.id = e.id + "_error", t.errorScript.text = e.name + "('" + n + "');", t.script.async = t.errorScript.async = !1) : t.script.async = !0;
            var i = document.getElementsByTagName("head")[0];
            i.insertBefore(t.script, i.firstChild), t.errorScript && i.insertBefore(t.errorScript, t.script.nextSibling)
        }, t.cleanup = function() {
            this.script && (this.script.onload = this.script.onerror = null, this.script.onreadystatechange = null), this.script && this.script.parentNode && this.script.parentNode.removeChild(this.script), this.errorScript && this.errorScript.parentNode && this.errorScript.parentNode.removeChild(this.errorScript), this.script = null, this.errorScript = null
        }, Pusher.ScriptRequest = e
    }.call(this),
    function() {
        function e(e) {
            this.options = e, this.receivers = e.receivers || Pusher.ScriptReceivers, this.loading = {}
        }
        var t = e.prototype;
        t.load = function(e, t) {
            var n = this;
            if (n.loading[e] && n.loading[e].length > 0) n.loading[e].push(t);
            else {
                n.loading[e] = [t];
                var i = new Pusher.ScriptRequest(n.getPath(e)),
                    r = n.receivers.create(function(t) {
                        if (n.receivers.remove(r), n.loading[e]) {
                            var o = n.loading[e];
                            delete n.loading[e];
                            for (var a = function(e) {
                                    e || i.cleanup()
                                }, s = 0; s < o.length; s++) o[s](t, a)
                        }
                    });
                i.send(r)
            }
        }, t.getRoot = function(e) {
            var t, n = Pusher.Util.getDocument().location.protocol;
            return t = e && e.encrypted || "https:" === n ? this.options.cdn_https : this.options.cdn_http, t.replace(/\/*$/, "") + "/" + this.options.version
        }, t.getPath = function(e, t) {
            return this.getRoot(t) + "/" + e + this.options.suffix + ".js"
        }, Pusher.DependencyLoader = e
    }.call(this),
    function() {
        function e() {
            Pusher.ready()
        }

        function t(e) {
            document.body ? e() : setTimeout(function() {
                t(e)
            }, 0)
        }

        function n() {
            t(e)
        }
        Pusher.DependenciesReceivers = new Pusher.ScriptReceiverFactory("_pusher_dependencies", "Pusher.DependenciesReceivers"), Pusher.Dependencies = new Pusher.DependencyLoader({
            cdn_http: Pusher.cdn_http,
            cdn_https: Pusher.cdn_https,
            version: Pusher.VERSION,
            suffix: Pusher.dependency_suffix,
            receivers: Pusher.DependenciesReceivers
        }), window.JSON ? n() : Pusher.Dependencies.load("json2", n)
    }(),
    function() {
        for (var e = {
                encode: function(e) {
                    return c(s(e))
                }
            }, t = String.fromCharCode, n = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", i = {}, r = 0, o = n.length; o > r; r++) i[n.charAt(r)] = r;
        var a = function(e) {
                var n = e.charCodeAt(0);
                return 128 > n ? e : 2048 > n ? t(192 | n >>> 6) + t(128 | 63 & n) : t(224 | n >>> 12 & 15) + t(128 | n >>> 6 & 63) + t(128 | 63 & n)
            },
            s = function(e) {
                return e.replace(/[^\x00-\x7F]/g, a)
            },
            u = function(e) {
                var t = [0, 2, 1][e.length % 3],
                    i = e.charCodeAt(0) << 16 | (e.length > 1 ? e.charCodeAt(1) : 0) << 8 | (e.length > 2 ? e.charCodeAt(2) : 0),
                    r = [n.charAt(i >>> 18), n.charAt(i >>> 12 & 63), t >= 2 ? "=" : n.charAt(i >>> 6 & 63), t >= 1 ? "=" : n.charAt(63 & i)];
                return r.join("")
            },
            c = window.btoa || function(e) {
                return e.replace(/[\s\S]{1,3}/g, u)
            };
        Pusher.Base64 = e
    }.call(this),
    function() {
        function e(e, t) {
            this.url = e, this.data = t
        }

        function t(e) {
            return Pusher.Util.mapObject(e, function(e) {
                return "object" == typeof e && (e = JSON.stringify(e)), encodeURIComponent(Pusher.Base64.encode(e.toString()))
            })
        }
        var n = e.prototype;
        n.send = function(e) {
            if (!this.request) {
                var n = Pusher.Util.filterObject(this.data, function(e) {
                        return void 0 !== e
                    }),
                    i = Pusher.Util.map(Pusher.Util.flatten(t(n)), Pusher.Util.method("join", "=")).join("&"),
                    r = this.url + "/" + e.number + "?" + i;
                this.request = new Pusher.ScriptRequest(r), this.request.send(e)
            }
        }, n.cleanup = function() {
            this.request && this.request.cleanup()
        }, Pusher.JSONPRequest = e
    }.call(this),
    function() {
        function e(e, t, n) {
            this.key = e, this.session = t, this.events = [], this.options = n || {}, this.sent = 0, this.uniqueID = 0
        }
        var t = e.prototype;
        e.ERROR = 3, e.INFO = 6, e.DEBUG = 7, t.log = function(e, t) {
            e <= this.options.level && (this.events.push(Pusher.Util.extend({}, t, {
                timestamp: Pusher.Util.now()
            })), this.options.limit && this.events.length > this.options.limit && this.events.shift())
        }, t.error = function(t) {
            this.log(e.ERROR, t)
        }, t.info = function(t) {
            this.log(e.INFO, t)
        }, t.debug = function(t) {
            this.log(e.DEBUG, t)
        }, t.isEmpty = function() {
            return 0 === this.events.length
        }, t.send = function(e, t) {
            var n = this,
                i = Pusher.Util.extend({
                    session: n.session,
                    bundle: n.sent + 1,
                    key: n.key,
                    lib: "js",
                    version: n.options.version,
                    cluster: n.options.cluster,
                    features: n.options.features,
                    timeline: n.events
                }, n.options.params);
            return n.events = [], e(i, function(e, i) {
                e || n.sent++, t && t(e, i)
            }), !0
        }, t.generateUniqueID = function() {
            return this.uniqueID++, this.uniqueID
        }, Pusher.Timeline = e
    }.call(this),
    function() {
        function e(e, t) {
            this.timeline = e, this.options = t || {}
        }
        var t = e.prototype;
        t.send = function(e, t) {
            var n = this;
            if (!n.timeline.isEmpty()) {
                var i = function(t, i) {
                    var r = "http" + (e ? "s" : "") + "://",
                        o = r + (n.host || n.options.host) + n.options.path,
                        a = new Pusher.JSONPRequest(o, t),
                        s = Pusher.ScriptReceivers.create(function(e, t) {
                            Pusher.ScriptReceivers.remove(s), a.cleanup(), t && t.host && (n.host = t.host), i && i(e, t)
                        });
                    a.send(s)
                };
                n.timeline.send(i, t)
            }
        }, Pusher.TimelineSender = e
    }.call(this),
    function() {
        function e(e) {
            this.strategies = e
        }

        function t(e, t, n) {
            var r = Pusher.Util.map(e, function(e, i, r, o) {
                return e.connect(t, n(i, o))
            });
            return {
                abort: function() {
                    Pusher.Util.apply(r, i)
                },
                forceMinPriority: function(e) {
                    Pusher.Util.apply(r, function(t) {
                        t.forceMinPriority(e)
                    })
                }
            }
        }

        function n(e) {
            return Pusher.Util.all(e, function(e) {
                return Boolean(e.error)
            })
        }

        function i(e) {
            e.error || e.aborted || (e.abort(), e.aborted = !0)
        }
        var r = e.prototype;
        r.isSupported = function() {
            return Pusher.Util.any(this.strategies, Pusher.Util.method("isSupported"))
        }, r.connect = function(e, i) {
            return t(this.strategies, e, function(e, t) {
                return function(r, o) {
                    return t[e].error = r, r ? void(n(t) && i(!0)) : (Pusher.Util.apply(t, function(e) {
                        e.forceMinPriority(o.transport.priority)
                    }), void i(null, o))
                }
            })
        }, Pusher.BestConnectedEverStrategy = e
    }.call(this),
    function() {
        function e(e, t, n) {
            this.strategy = e, this.transports = t, this.ttl = n.ttl || 18e5, this.encrypted = n.encrypted, this.timeline = n.timeline
        }

        function t(e) {
            return "pusherTransport" + (e ? "Encrypted" : "Unencrypted")
        }

        function n(e) {
            var n = Pusher.Util.getLocalStorage();
            if (n) try {
                var i = n[t(e)];
                if (i) return JSON.parse(i)
            } catch (o) {
                r(e)
            }
            return null
        }

        function i(e, n, i) {
            var r = Pusher.Util.getLocalStorage();
            if (r) try {
                r[t(e)] = JSON.stringify({
                    timestamp: Pusher.Util.now(),
                    transport: n,
                    latency: i
                })
            } catch (o) {}
        }

        function r(e) {
            var n = Pusher.Util.getLocalStorage();
            if (n) try {
                delete n[t(e)]
            } catch (i) {}
        }
        var o = e.prototype;
        o.isSupported = function() {
            return this.strategy.isSupported()
        }, o.connect = function(e, t) {
            var o = this.encrypted,
                a = n(o),
                s = [this.strategy];
            if (a && a.timestamp + this.ttl >= Pusher.Util.now()) {
                var u = this.transports[a.transport];
                u && (this.timeline.info({
                    cached: !0,
                    transport: a.transport,
                    latency: a.latency
                }), s.push(new Pusher.SequentialStrategy([u], {
                    timeout: 2 * a.latency + 1e3,
                    failFast: !0
                })))
            }
            var c = Pusher.Util.now(),
                l = s.pop().connect(e, function d(n, a) {
                    n ? (r(o), s.length > 0 ? (c = Pusher.Util.now(), l = s.pop().connect(e, d)) : t(n)) : (i(o, a.transport.name, Pusher.Util.now() - c), t(null, a))
                });
            return {
                abort: function() {
                    l.abort()
                },
                forceMinPriority: function(t) {
                    e = t, l && l.forceMinPriority(t)
                }
            }
        }, Pusher.CachedStrategy = e
    }.call(this),
    function() {
        function e(e, t) {
            this.strategy = e, this.options = {
                delay: t.delay
            }
        }
        var t = e.prototype;
        t.isSupported = function() {
            return this.strategy.isSupported()
        }, t.connect = function(e, t) {
            var n, i = this.strategy,
                r = new Pusher.Timer(this.options.delay, function() {
                    n = i.connect(e, t)
                });
            return {
                abort: function() {
                    r.ensureAborted(), n && n.abort()
                },
                forceMinPriority: function(t) {
                    e = t, n && n.forceMinPriority(t)
                }
            }
        }, Pusher.DelayedStrategy = e
    }.call(this),
    function() {
        function e(e) {
            this.strategy = e
        }
        var t = e.prototype;
        t.isSupported = function() {
            return this.strategy.isSupported()
        }, t.connect = function(e, t) {
            var n = this.strategy.connect(e, function(e, i) {
                i && n.abort(), t(e, i)
            });
            return n
        }, Pusher.FirstConnectedStrategy = e
    }.call(this),
    function() {
        function e(e, t, n) {
            this.test = e, this.trueBranch = t, this.falseBranch = n
        }
        var t = e.prototype;
        t.isSupported = function() {
            var e = this.test() ? this.trueBranch : this.falseBranch;
            return e.isSupported()
        }, t.connect = function(e, t) {
            var n = this.test() ? this.trueBranch : this.falseBranch;
            return n.connect(e, t)
        }, Pusher.IfStrategy = e
    }.call(this),
    function() {
        function e(e, t) {
            this.strategies = e, this.loop = Boolean(t.loop), this.failFast = Boolean(t.failFast), this.timeout = t.timeout, this.timeoutLimit = t.timeoutLimit
        }
        var t = e.prototype;
        t.isSupported = function() {
            return Pusher.Util.any(this.strategies, Pusher.Util.method("isSupported"))
        }, t.connect = function(e, t) {
            var n = this,
                i = this.strategies,
                r = 0,
                o = this.timeout,
                a = null,
                s = function(u, c) {
                    c ? t(null, c) : (r += 1, n.loop && (r %= i.length), r < i.length ? (o && (o = 2 * o, n.timeoutLimit && (o = Math.min(o, n.timeoutLimit))), a = n.tryStrategy(i[r], e, {
                        timeout: o,
                        failFast: n.failFast
                    }, s)) : t(!0))
                };
            return a = this.tryStrategy(i[r], e, {
                timeout: o,
                failFast: this.failFast
            }, s), {
                abort: function() {
                    a.abort()
                },
                forceMinPriority: function(t) {
                    e = t, a && a.forceMinPriority(t)
                }
            }
        }, t.tryStrategy = function(e, t, n, i) {
            var r = null,
                o = null;
            return n.timeout > 0 && (r = new Pusher.Timer(n.timeout, function() {
                o.abort(), i(!0)
            })), o = e.connect(t, function(e, t) {
                e && r && r.isRunning() && !n.failFast || (r && r.ensureAborted(), i(e, t))
            }), {
                abort: function() {
                    r && r.ensureAborted(), o.abort()
                },
                forceMinPriority: function(e) {
                    o.forceMinPriority(e)
                }
            }
        }, Pusher.SequentialStrategy = e
    }.call(this),
    function() {
        function e(e, t, n, i) {
            this.name = e, this.priority = t, this.transport = n, this.options = i || {}
        }

        function t(e, t) {
            return Pusher.Util.defer(function() {
                t(e)
            }), {
                abort: function() {},
                forceMinPriority: function() {}
            }
        }
        var n = e.prototype;
        n.isSupported = function() {
            return this.transport.isSupported({
                encrypted: this.options.encrypted
            })
        }, n.connect = function(e, n) {
            if (!this.isSupported()) return t(new Pusher.Errors.UnsupportedStrategy, n);
            if (this.priority < e) return t(new Pusher.Errors.TransportPriorityTooLow, n);
            var i = this,
                r = !1,
                o = this.transport.createConnection(this.name, this.priority, this.options.key, this.options),
                a = null,
                s = function() {
                    o.unbind("initialized", s), o.connect()
                },
                u = function() {
                    a = new Pusher.Handshake(o, function(e) {
                        r = !0, d(), n(null, e)
                    })
                },
                c = function(e) {
                    d(), n(e)
                },
                l = function() {
                    d(), n(new Pusher.Errors.TransportClosed(o))
                },
                d = function() {
                    o.unbind("initialized", s), o.unbind("open", u), o.unbind("error", c), o.unbind("closed", l)
                };
            return o.bind("initialized", s), o.bind("open", u), o.bind("error", c), o.bind("closed", l), o.initialize(), {
                abort: function() {
                    r || (d(), a ? a.close() : o.close())
                },
                forceMinPriority: function(e) {
                    r || i.priority < e && (a ? a.close() : o.close())
                }
            }
        }, Pusher.TransportStrategy = e
    }.call(this),
    function() {
        function e(e, t, n) {
            var i = e + (t.encrypted ? "s" : ""),
                r = t.encrypted ? t.hostEncrypted : t.hostUnencrypted;
            return i + "://" + r + n
        }

        function t(e, t) {
            var n = "/app/" + e,
                i = "?protocol=" + Pusher.PROTOCOL + "&client=js&version=" + Pusher.VERSION + (t ? "&" + t : "");
            return n + i
        }
        Pusher.URLSchemes = {
            ws: {
                getInitial: function(n, i) {
                    return e("ws", i, t(n, "flash=false"))
                }
            },
            flash: {
                getInitial: function(n, i) {
                    return e("ws", i, t(n, "flash=true"))
                }
            },
            sockjs: {
                getInitial: function(t, n) {
                    return e("http", n, n.httpPath || "/pusher", "")
                },
                getPath: function(e, n) {
                    return t(e)
                }
            },
            http: {
                getInitial: function(n, i) {
                    var r = (i.httpPath || "/pusher") + t(n);
                    return e("http", i, r)
                }
            }
        }
    }.call(this),
    function() {
        function e(e, t, n, i, r) {
            Pusher.EventsDispatcher.call(this), this.hooks = e, this.name = t, this.priority = n, this.key = i, this.options = r, this.state = "new", this.timeline = r.timeline, this.activityTimeout = r.activityTimeout, this.id = this.timeline.generateUniqueID()
        }
        var t = e.prototype;
        Pusher.Util.extend(t, Pusher.EventsDispatcher.prototype), t.handlesActivityChecks = function() {
            return Boolean(this.hooks.handlesActivityChecks)
        }, t.supportsPing = function() {
            return Boolean(this.hooks.supportsPing)
        }, t.initialize = function() {
            var e = this;
            e.timeline.info(e.buildTimelineMessage({
                transport: e.name + (e.options.encrypted ? "s" : "")
            })), e.hooks.beforeInitialize && e.hooks.beforeInitialize(), e.hooks.isInitialized() ? e.changeState("initialized") : e.hooks.file ? (e.changeState("initializing"), Pusher.Dependencies.load(e.hooks.file, function(t, n) {
                e.hooks.isInitialized() ? (e.changeState("initialized"), n(!0)) : (t && e.onError(t), e.onClose(), n(!1))
            })) : e.onClose()
        }, t.connect = function() {
            var e = this;
            if (e.socket || "initialized" !== e.state) return !1;
            var t = e.hooks.urls.getInitial(e.key, e.options);
            try {
                e.socket = e.hooks.getSocket(t, e.options)
            } catch (n) {
                return Pusher.Util.defer(function() {
                    e.onError(n), e.changeState("closed")
                }), !1
            }
            return e.bindListeners(), Pusher.debug("Connecting", {
                transport: e.name,
                url: t
            }), e.changeState("connecting"), !0
        }, t.close = function() {
            return this.socket ? (this.socket.close(), !0) : !1
        }, t.send = function(e) {
            var t = this;
            return "open" === t.state ? (Pusher.Util.defer(function() {
                t.socket && t.socket.send(e)
            }), !0) : !1
        }, t.ping = function() {
            "open" === this.state && this.supportsPing() && this.socket.ping()
        }, t.onOpen = function() {
            this.hooks.beforeOpen && this.hooks.beforeOpen(this.socket, this.hooks.urls.getPath(this.key, this.options)), this.changeState("open"), this.socket.onopen = void 0
        }, t.onError = function(e) {
            this.emit("error", {
                type: "WebSocketError",
                error: e
            }), this.timeline.error(this.buildTimelineMessage({
                error: e.toString()
            }))
        }, t.onClose = function(e) {
            e ? this.changeState("closed", {
                code: e.code,
                reason: e.reason,
                wasClean: e.wasClean
            }) : this.changeState("closed"), this.unbindListeners(), this.socket = void 0
        }, t.onMessage = function(e) {
            this.emit("message", e)
        }, t.onActivity = function() {
            this.emit("activity")
        }, t.bindListeners = function() {
            var e = this;
            e.socket.onopen = function() {
                e.onOpen()
            }, e.socket.onerror = function(t) {
                e.onError(t)
            }, e.socket.onclose = function(t) {
                e.onClose(t)
            }, e.socket.onmessage = function(t) {
                e.onMessage(t)
            }, e.supportsPing() && (e.socket.onactivity = function() {
                e.onActivity()
            })
        }, t.unbindListeners = function() {
            this.socket && (this.socket.onopen = void 0, this.socket.onerror = void 0, this.socket.onclose = void 0, this.socket.onmessage = void 0, this.supportsPing() && (this.socket.onactivity = void 0))
        }, t.changeState = function(e, t) {
            this.state = e, this.timeline.info(this.buildTimelineMessage({
                state: e,
                params: t
            })), this.emit(e, t)
        }, t.buildTimelineMessage = function(e) {
            return Pusher.Util.extend({
                cid: this.id
            }, e)
        }, Pusher.TransportConnection = e
    }.call(this),
    function() {
        function e(e) {
            this.hooks = e
        }
        var t = e.prototype;
        t.isSupported = function(e) {
            return this.hooks.isSupported(e)
        }, t.createConnection = function(e, t, n, i) {
            return new Pusher.TransportConnection(this.hooks, e, t, n, i)
        }, Pusher.Transport = e
    }.call(this),
    function() {
        Pusher.WSTransport = new Pusher.Transport({
            urls: Pusher.URLSchemes.ws,
            handlesActivityChecks: !1,
            supportsPing: !1,
            isInitialized: function() {
                return Boolean(window.WebSocket || window.MozWebSocket)
            },
            isSupported: function() {
                return Boolean(window.WebSocket || window.MozWebSocket)
            },
            getSocket: function(e) {
                var t = window.WebSocket || window.MozWebSocket;
                return new t(e)
            }
        }), Pusher.FlashTransport = new Pusher.Transport({
            file: "flashfallback",
            urls: Pusher.URLSchemes.flash,
            handlesActivityChecks: !1,
            supportsPing: !1,
            isSupported: function() {
                try {
                    return Boolean(new ActiveXObject("ShockwaveFlash.ShockwaveFlash"))
                } catch (e) {
                    try {
                        var t = Pusher.Util.getNavigator();
                        return Boolean(t && t.mimeTypes && void 0 !== t.mimeTypes["application/x-shockwave-flash"])
                    } catch (n) {
                        return !1
                    }
                }
            },
            beforeInitialize: function() {
                void 0 === window.WEB_SOCKET_SUPPRESS_CROSS_DOMAIN_SWF_ERROR && (window.WEB_SOCKET_SUPPRESS_CROSS_DOMAIN_SWF_ERROR = !0), window.WEB_SOCKET_SWF_LOCATION = Pusher.Dependencies.getRoot() + "/WebSocketMain.swf"
            },
            isInitialized: function() {
                return void 0 !== window.FlashWebSocket
            },
            getSocket: function(e) {
                return new FlashWebSocket(e)
            }
        }), Pusher.SockJSTransport = new Pusher.Transport({
            file: "sockjs",
            urls: Pusher.URLSchemes.sockjs,
            handlesActivityChecks: !0,
            supportsPing: !1,
            isSupported: function() {
                return !0
            },
            isInitialized: function() {
                return void 0 !== window.SockJS
            },
            getSocket: function(e, t) {
                return new SockJS(e, null, {
                    js_path: Pusher.Dependencies.getPath("sockjs", {
                        encrypted: t.encrypted
                    }),
                    ignore_null_origin: t.ignoreNullOrigin
                })
            },
            beforeOpen: function(e, t) {
                e.send(JSON.stringify({
                    path: t
                }))
            }
        });
        var e = {
                urls: Pusher.URLSchemes.http,
                handlesActivityChecks: !1,
                supportsPing: !0,
                isInitialized: function() {
                    return Boolean(Pusher.HTTP.Socket)
                }
            },
            t = Pusher.Util.extend({
                getSocket: function(e) {
                    return Pusher.HTTP.getStreamingSocket(e)
                }
            }, e),
            n = Pusher.Util.extend({
                getSocket: function(e) {
                    return Pusher.HTTP.getPollingSocket(e)
                }
            }, e),
            i = {
                file: "xhr",
                isSupported: Pusher.Util.isXHRSupported
            },
            r = {
                file: "xdr",
                isSupported: function(e) {
                    return Pusher.Util.isXDRSupported(e.encrypted)
                }
            };
        Pusher.XHRStreamingTransport = new Pusher.Transport(Pusher.Util.extend({}, t, i)), Pusher.XDRStreamingTransport = new Pusher.Transport(Pusher.Util.extend({}, t, r)), Pusher.XHRPollingTransport = new Pusher.Transport(Pusher.Util.extend({}, n, i)), Pusher.XDRPollingTransport = new Pusher.Transport(Pusher.Util.extend({}, n, r))
    }.call(this),
    function() {
        function e(e, t, n) {
            this.manager = e, this.transport = t, this.minPingDelay = n.minPingDelay, this.maxPingDelay = n.maxPingDelay, this.pingDelay = void 0
        }
        var t = e.prototype;
        t.createConnection = function(e, t, n, i) {
            var r = this;
            i = Pusher.Util.extend({}, i, {
                activityTimeout: r.pingDelay
            });
            var o = r.transport.createConnection(e, t, n, i),
                a = null,
                s = function() {
                    o.unbind("open", s), o.bind("closed", u), a = Pusher.Util.now()
                },
                u = function(e) {
                    if (o.unbind("closed", u), 1002 === e.code || 1003 === e.code) r.manager.reportDeath();
                    else if (!e.wasClean && a) {
                        var t = Pusher.Util.now() - a;
                        t < 2 * r.maxPingDelay && (r.manager.reportDeath(), r.pingDelay = Math.max(t / 2, r.minPingDelay))
                    }
                };
            return o.bind("open", s), o
        }, t.isSupported = function(e) {
            return this.manager.isAlive() && this.transport.isSupported(e)
        }, Pusher.AssistantToTheTransportManager = e;
    }.call(this),
    function() {
        function e(e) {
            this.options = e || {}, this.livesLeft = this.options.lives || 1 / 0
        }
        var t = e.prototype;
        t.getAssistant = function(e) {
            return new Pusher.AssistantToTheTransportManager(this, e, {
                minPingDelay: this.options.minPingDelay,
                maxPingDelay: this.options.maxPingDelay
            })
        }, t.isAlive = function() {
            return this.livesLeft > 0
        }, t.reportDeath = function() {
            this.livesLeft -= 1
        }, Pusher.TransportManager = e
    }.call(this),
    function() {
        function e(e) {
            return function(t) {
                return [e.apply(this, arguments), t]
            }
        }

        function t(e) {
            return "string" == typeof e && ":" === e.charAt(0)
        }

        function n(e, t) {
            return t[e.slice(1)]
        }

        function i(e, t) {
            if (0 === e.length) return [
                [], t
            ];
            var n = a(e[0], t),
                r = i(e.slice(1), n[1]);
            return [
                [n[0]].concat(r[0]), r[1]
            ]
        }

        function r(e, i) {
            if (!t(e)) return [e, i];
            var r = n(e, i);
            if (void 0 === r) throw "Undefined symbol " + e;
            return [r, i]
        }

        function o(e, r) {
            if (t(e[0])) {
                var o = n(e[0], r);
                if (e.length > 1) {
                    if ("function" != typeof o) throw "Calling non-function " + e[0];
                    var s = [Pusher.Util.extend({}, r)].concat(Pusher.Util.map(e.slice(1), function(e) {
                        return a(e, Pusher.Util.extend({}, r))[0]
                    }));
                    return o.apply(this, s)
                }
                return [o, r]
            }
            return i(e, r)
        }

        function a(e, t) {
            return "string" == typeof e ? r(e, t) : "object" == typeof e && e instanceof Array && e.length > 0 ? o(e, t) : [e, t]
        }
        var s = {
                build: function(e, t) {
                    var n = Pusher.Util.extend({}, l, t);
                    return a(e, n)[1].strategy
                }
            },
            u = {
                ws: Pusher.WSTransport,
                flash: Pusher.FlashTransport,
                sockjs: Pusher.SockJSTransport,
                xhr_streaming: Pusher.XHRStreamingTransport,
                xdr_streaming: Pusher.XDRStreamingTransport,
                xhr_polling: Pusher.XHRPollingTransport,
                xdr_polling: Pusher.XDRPollingTransport
            },
            c = {
                isSupported: function() {
                    return !1
                },
                connect: function(e, t) {
                    var n = Pusher.Util.defer(function() {
                        t(new Pusher.Errors.UnsupportedStrategy)
                    });
                    return {
                        abort: function() {
                            n.ensureAborted()
                        },
                        forceMinPriority: function() {}
                    }
                }
            },
            l = {
                extend: function(e, t, n) {
                    return [Pusher.Util.extend({}, t, n), e]
                },
                def: function(e, t, n) {
                    if (void 0 !== e[t]) throw "Redefining symbol " + t;
                    return e[t] = n, [void 0, e]
                },
                def_transport: function(e, t, n, i, r, o) {
                    var a = u[n];
                    if (!a) throw new Pusher.Errors.UnsupportedTransport(n);
                    var s, l = !(e.enabledTransports && -1 === Pusher.Util.arrayIndexOf(e.enabledTransports, t) || e.disabledTransports && -1 !== Pusher.Util.arrayIndexOf(e.disabledTransports, t) || "flash" === t && e.disableFlash === !0);
                    s = l ? new Pusher.TransportStrategy(t, i, o ? o.getAssistant(a) : a, Pusher.Util.extend({
                        key: e.key,
                        encrypted: e.encrypted,
                        timeline: e.timeline,
                        ignoreNullOrigin: e.ignoreNullOrigin
                    }, r)) : c;
                    var d = e.def(e, t, s)[1];
                    return d.transports = e.transports || {}, d.transports[t] = s, [void 0, d]
                },
                transport_manager: e(function(e, t) {
                    return new Pusher.TransportManager(t)
                }),
                sequential: e(function(e, t) {
                    var n = Array.prototype.slice.call(arguments, 2);
                    return new Pusher.SequentialStrategy(n, t)
                }),
                cached: e(function(e, t, n) {
                    return new Pusher.CachedStrategy(n, e.transports, {
                        ttl: t,
                        timeline: e.timeline,
                        encrypted: e.encrypted
                    })
                }),
                first_connected: e(function(e, t) {
                    return new Pusher.FirstConnectedStrategy(t)
                }),
                best_connected_ever: e(function() {
                    var e = Array.prototype.slice.call(arguments, 1);
                    return new Pusher.BestConnectedEverStrategy(e)
                }),
                delayed: e(function(e, t, n) {
                    return new Pusher.DelayedStrategy(n, {
                        delay: t
                    })
                }),
                "if": e(function(e, t, n, i) {
                    return new Pusher.IfStrategy(t, n, i)
                }),
                is_supported: e(function(e, t) {
                    return function() {
                        return t.isSupported()
                    }
                })
            };
        Pusher.StrategyBuilder = s
    }.call(this),
    function() {
        var e = {};
        e.decodeMessage = function(e) {
            try {
                var t = JSON.parse(e.data);
                if ("string" == typeof t.data) try {
                    t.data = JSON.parse(t.data)
                } catch (n) {
                    if (!(n instanceof SyntaxError)) throw n
                }
                return t
            } catch (n) {
                throw {
                    type: "MessageParseError",
                    error: n,
                    data: e.data
                }
            }
        }, e.encodeMessage = function(e) {
            return JSON.stringify(e)
        }, e.processHandshake = function(e) {
            if (e = this.decodeMessage(e), "pusher:connection_established" === e.event) {
                if (!e.data.activity_timeout) throw "No activity timeout specified in handshake";
                return {
                    action: "connected",
                    id: e.data.socket_id,
                    activityTimeout: 1e3 * e.data.activity_timeout
                }
            }
            if ("pusher:error" === e.event) return {
                action: this.getCloseAction(e.data),
                error: this.getCloseError(e.data)
            };
            throw "Invalid handshake"
        }, e.getCloseAction = function(e) {
            return e.code < 4e3 ? e.code >= 1002 && e.code <= 1004 ? "backoff" : null : 4e3 === e.code ? "ssl_only" : e.code < 4100 ? "refused" : e.code < 4200 ? "backoff" : e.code < 4300 ? "retry" : "refused"
        }, e.getCloseError = function(e) {
            return 1e3 !== e.code && 1001 !== e.code ? {
                type: "PusherError",
                data: {
                    code: e.code,
                    message: e.reason || e.message
                }
            } : null
        }, Pusher.Protocol = e
    }.call(this),
    function() {
        function e(e, t) {
            Pusher.EventsDispatcher.call(this), this.id = e, this.transport = t, this.activityTimeout = t.activityTimeout, this.bindListeners()
        }
        var t = e.prototype;
        Pusher.Util.extend(t, Pusher.EventsDispatcher.prototype), t.handlesActivityChecks = function() {
            return this.transport.handlesActivityChecks()
        }, t.send = function(e) {
            return this.transport.send(e)
        }, t.send_event = function(e, t, n) {
            var i = {
                event: e,
                data: t
            };
            return n && (i.channel = n), Pusher.debug("Event sent", i), this.send(Pusher.Protocol.encodeMessage(i))
        }, t.ping = function() {
            this.transport.supportsPing() ? this.transport.ping() : this.send_event("pusher:ping", {})
        }, t.close = function() {
            this.transport.close()
        }, t.bindListeners = function() {
            var e = this,
                t = {
                    message: function(t) {
                        var n;
                        try {
                            n = Pusher.Protocol.decodeMessage(t)
                        } catch (i) {
                            e.emit("error", {
                                type: "MessageParseError",
                                error: i,
                                data: t.data
                            })
                        }
                        if (void 0 !== n) {
                            switch (Pusher.debug("Event recd", n), n.event) {
                                case "pusher:error":
                                    e.emit("error", {
                                        type: "PusherError",
                                        data: n.data
                                    });
                                    break;
                                case "pusher:ping":
                                    e.emit("ping");
                                    break;
                                case "pusher:pong":
                                    e.emit("pong")
                            }
                            e.emit("message", n)
                        }
                    },
                    activity: function() {
                        e.emit("activity")
                    },
                    error: function(t) {
                        e.emit("error", {
                            type: "WebSocketError",
                            error: t
                        })
                    },
                    closed: function(t) {
                        n(), t && t.code && e.handleCloseEvent(t), e.transport = null, e.emit("closed")
                    }
                },
                n = function() {
                    Pusher.Util.objectApply(t, function(t, n) {
                        e.transport.unbind(n, t)
                    })
                };
            Pusher.Util.objectApply(t, function(t, n) {
                e.transport.bind(n, t)
            })
        }, t.handleCloseEvent = function(e) {
            var t = Pusher.Protocol.getCloseAction(e),
                n = Pusher.Protocol.getCloseError(e);
            n && this.emit("error", n), t && this.emit(t)
        }, Pusher.Connection = e
    }.call(this),
    function() {
        function e(e, t) {
            this.transport = e, this.callback = t, this.bindListeners()
        }
        var t = e.prototype;
        t.close = function() {
            this.unbindListeners(), this.transport.close()
        }, t.bindListeners = function() {
            var e = this;
            e.onMessage = function(t) {
                e.unbindListeners();
                try {
                    var n = Pusher.Protocol.processHandshake(t);
                    "connected" === n.action ? e.finish("connected", {
                        connection: new Pusher.Connection(n.id, e.transport),
                        activityTimeout: n.activityTimeout
                    }) : (e.finish(n.action, {
                        error: n.error
                    }), e.transport.close())
                } catch (i) {
                    e.finish("error", {
                        error: i
                    }), e.transport.close()
                }
            }, e.onClosed = function(t) {
                e.unbindListeners();
                var n = Pusher.Protocol.getCloseAction(t) || "backoff",
                    i = Pusher.Protocol.getCloseError(t);
                e.finish(n, {
                    error: i
                })
            }, e.transport.bind("message", e.onMessage), e.transport.bind("closed", e.onClosed)
        }, t.unbindListeners = function() {
            this.transport.unbind("message", this.onMessage), this.transport.unbind("closed", this.onClosed)
        }, t.finish = function(e, t) {
            this.callback(Pusher.Util.extend({
                transport: this.transport,
                action: e
            }, t))
        }, Pusher.Handshake = e
    }.call(this),
    function() {
        function e(e, t) {
            Pusher.EventsDispatcher.call(this), this.key = e, this.options = t || {}, this.state = "initialized", this.connection = null, this.encrypted = !!t.encrypted, this.timeline = this.options.timeline, this.connectionCallbacks = this.buildConnectionCallbacks(), this.errorCallbacks = this.buildErrorCallbacks(), this.handshakeCallbacks = this.buildHandshakeCallbacks(this.errorCallbacks);
            var n = this;
            Pusher.Network.bind("online", function() {
                n.timeline.info({
                    netinfo: "online"
                }), ("connecting" === n.state || "unavailable" === n.state) && n.retryIn(0)
            }), Pusher.Network.bind("offline", function() {
                n.timeline.info({
                    netinfo: "offline"
                }), n.connection && n.sendActivityCheck()
            }), this.updateStrategy()
        }
        var t = e.prototype;
        Pusher.Util.extend(t, Pusher.EventsDispatcher.prototype), t.connect = function() {
            if (!this.connection && !this.runner) {
                if (!this.strategy.isSupported()) return void this.updateState("failed");
                this.updateState("connecting"), this.startConnecting(), this.setUnavailableTimer()
            }
        }, t.send = function(e) {
            return this.connection ? this.connection.send(e) : !1
        }, t.send_event = function(e, t, n) {
            return this.connection ? this.connection.send_event(e, t, n) : !1
        }, t.disconnect = function() {
            this.disconnectInternally(), this.updateState("disconnected")
        }, t.isEncrypted = function() {
            return this.encrypted
        }, t.startConnecting = function() {
            var e = this,
                t = function(n, i) {
                    n ? e.runner = e.strategy.connect(0, t) : "error" === i.action ? (e.emit("error", {
                        type: "HandshakeError",
                        error: i.error
                    }), e.timeline.error({
                        handshakeError: i.error
                    })) : (e.abortConnecting(), e.handshakeCallbacks[i.action](i))
                };
            e.runner = e.strategy.connect(0, t)
        }, t.abortConnecting = function() {
            this.runner && (this.runner.abort(), this.runner = null)
        }, t.disconnectInternally = function() {
            if (this.abortConnecting(), this.clearRetryTimer(), this.clearUnavailableTimer(), this.connection) {
                var e = this.abandonConnection();
                e.close()
            }
        }, t.updateStrategy = function() {
            this.strategy = this.options.getStrategy({
                key: this.key,
                timeline: this.timeline,
                encrypted: this.encrypted
            })
        }, t.retryIn = function(e) {
            var t = this;
            t.timeline.info({
                action: "retry",
                delay: e
            }), e > 0 && t.emit("connecting_in", Math.round(e / 1e3)), t.retryTimer = new Pusher.Timer(e || 0, function() {
                t.disconnectInternally(), t.connect()
            })
        }, t.clearRetryTimer = function() {
            this.retryTimer && (this.retryTimer.ensureAborted(), this.retryTimer = null)
        }, t.setUnavailableTimer = function() {
            var e = this;
            e.unavailableTimer = new Pusher.Timer(e.options.unavailableTimeout, function() {
                e.updateState("unavailable")
            })
        }, t.clearUnavailableTimer = function() {
            this.unavailableTimer && this.unavailableTimer.ensureAborted()
        }, t.sendActivityCheck = function() {
            var e = this;
            e.stopActivityCheck(), e.connection.ping(), e.activityTimer = new Pusher.Timer(e.options.pongTimeout, function() {
                e.timeline.error({
                    pong_timed_out: e.options.pongTimeout
                }), e.retryIn(0)
            })
        }, t.resetActivityCheck = function() {
            var e = this;
            e.stopActivityCheck(), e.connection.handlesActivityChecks() || (e.activityTimer = new Pusher.Timer(e.activityTimeout, function() {
                e.sendActivityCheck()
            }))
        }, t.stopActivityCheck = function() {
            this.activityTimer && this.activityTimer.ensureAborted()
        }, t.buildConnectionCallbacks = function() {
            var e = this;
            return {
                message: function(t) {
                    e.resetActivityCheck(), e.emit("message", t)
                },
                ping: function() {
                    e.send_event("pusher:pong", {})
                },
                activity: function() {
                    e.resetActivityCheck()
                },
                error: function(t) {
                    e.emit("error", {
                        type: "WebSocketError",
                        error: t
                    })
                },
                closed: function() {
                    e.abandonConnection(), e.shouldRetry() && e.retryIn(1e3)
                }
            }
        }, t.buildHandshakeCallbacks = function(e) {
            var t = this;
            return Pusher.Util.extend({}, e, {
                connected: function(e) {
                    t.activityTimeout = Math.min(t.options.activityTimeout, e.activityTimeout, e.connection.activityTimeout || 1 / 0), t.clearUnavailableTimer(), t.setConnection(e.connection), t.socket_id = t.connection.id, t.updateState("connected", {
                        socket_id: t.socket_id
                    })
                }
            })
        }, t.buildErrorCallbacks = function() {
            function e(e) {
                return function(n) {
                    n.error && t.emit("error", {
                        type: "WebSocketError",
                        error: n.error
                    }), e(n)
                }
            }
            var t = this;
            return {
                ssl_only: e(function() {
                    t.encrypted = !0, t.updateStrategy(), t.retryIn(0)
                }),
                refused: e(function() {
                    t.disconnect()
                }),
                backoff: e(function() {
                    t.retryIn(1e3)
                }),
                retry: e(function() {
                    t.retryIn(0)
                })
            }
        }, t.setConnection = function(e) {
            this.connection = e;
            for (var t in this.connectionCallbacks) this.connection.bind(t, this.connectionCallbacks[t]);
            this.resetActivityCheck()
        }, t.abandonConnection = function() {
            if (this.connection) {
                this.stopActivityCheck();
                for (var e in this.connectionCallbacks) this.connection.unbind(e, this.connectionCallbacks[e]);
                var t = this.connection;
                return this.connection = null, t
            }
        }, t.updateState = function(e, t) {
            var n = this.state;
            this.state = e, n !== e && (Pusher.debug("State changed", n + " -> " + e), this.timeline.info({
                state: e,
                params: t
            }), this.emit("state_change", {
                previous: n,
                current: e
            }), this.emit(e, t))
        }, t.shouldRetry = function() {
            return "connecting" === this.state || "connected" === this.state
        }, Pusher.ConnectionManager = e
    }.call(this),
    function() {
        function e() {
            Pusher.EventsDispatcher.call(this);
            var e = this;
            void 0 !== window.addEventListener && (window.addEventListener("online", function() {
                e.emit("online")
            }, !1), window.addEventListener("offline", function() {
                e.emit("offline")
            }, !1))
        }
        Pusher.Util.extend(e.prototype, Pusher.EventsDispatcher.prototype);
        var t = e.prototype;
        t.isOnline = function() {
            return void 0 === window.navigator.onLine ? !0 : window.navigator.onLine
        }, Pusher.NetInfo = e, Pusher.Network = new e
    }.call(this),
    function() {
        function e() {
            this.reset()
        }
        var t = e.prototype;
        t.get = function(e) {
            return Object.prototype.hasOwnProperty.call(this.members, e) ? {
                id: e,
                info: this.members[e]
            } : null
        }, t.each = function(e) {
            var t = this;
            Pusher.Util.objectApply(t.members, function(n, i) {
                e(t.get(i))
            })
        }, t.setMyID = function(e) {
            this.myID = e
        }, t.onSubscription = function(e) {
            this.members = e.presence.hash, this.count = e.presence.count, this.me = this.get(this.myID)
        }, t.addMember = function(e) {
            return null === this.get(e.user_id) && this.count++, this.members[e.user_id] = e.user_info, this.get(e.user_id)
        }, t.removeMember = function(e) {
            var t = this.get(e.user_id);
            return t && (delete this.members[e.user_id], this.count--), t
        }, t.reset = function() {
            this.members = {}, this.count = 0, this.myID = null, this.me = null
        }, Pusher.Members = e
    }.call(this),
    function() {
        function e(e, t) {
            Pusher.EventsDispatcher.call(this, function(t, n) {
                Pusher.debug("No callbacks on " + e + " for " + t)
            }), this.name = e, this.pusher = t, this.subscribed = !1
        }
        var t = e.prototype;
        Pusher.Util.extend(t, Pusher.EventsDispatcher.prototype), t.authorize = function(e, t) {
            return t(!1, {})
        }, t.trigger = function(e, t) {
            if (0 !== e.indexOf("client-")) throw new Pusher.Errors.BadEventName("Event '" + e + "' does not start with 'client-'");
            return this.pusher.send_event(e, t, this.name)
        }, t.disconnect = function() {
            this.subscribed = !1
        }, t.handleEvent = function(e, t) {
            0 === e.indexOf("pusher_internal:") ? "pusher_internal:subscription_succeeded" === e && (this.subscribed = !0, this.emit("pusher:subscription_succeeded", t)) : this.emit(e, t)
        }, t.subscribe = function() {
            var e = this;
            e.authorize(e.pusher.connection.socket_id, function(t, n) {
                t ? e.handleEvent("pusher:subscription_error", n) : e.pusher.send_event("pusher:subscribe", {
                    auth: n.auth,
                    channel_data: n.channel_data,
                    channel: e.name
                })
            })
        }, t.unsubscribe = function() {
            this.pusher.send_event("pusher:unsubscribe", {
                channel: this.name
            })
        }, Pusher.Channel = e
    }.call(this),
    function() {
        function e(e, t) {
            Pusher.Channel.call(this, e, t)
        }
        var t = e.prototype;
        Pusher.Util.extend(t, Pusher.Channel.prototype), t.authorize = function(e, t) {
            var n = new Pusher.Channel.Authorizer(this, this.pusher.config);
            return n.authorize(e, t)
        }, Pusher.PrivateChannel = e
    }.call(this),
    function() {
        function e(e, t) {
            Pusher.PrivateChannel.call(this, e, t), this.members = new Pusher.Members
        }
        var t = e.prototype;
        Pusher.Util.extend(t, Pusher.PrivateChannel.prototype), t.authorize = function(e, t) {
            var n = Pusher.PrivateChannel.prototype.authorize,
                i = this;
            n.call(i, e, function(e, n) {
                if (!e) {
                    if (void 0 === n.channel_data) return Pusher.warn("Invalid auth response for channel '" + i.name + "', expected 'channel_data' field"), void t("Invalid auth response");
                    var r = JSON.parse(n.channel_data);
                    i.members.setMyID(r.user_id)
                }
                t(e, n)
            })
        }, t.handleEvent = function(e, t) {
            switch (e) {
                case "pusher_internal:subscription_succeeded":
                    this.members.onSubscription(t), this.subscribed = !0, this.emit("pusher:subscription_succeeded", this.members);
                    break;
                case "pusher_internal:member_added":
                    var n = this.members.addMember(t);
                    this.emit("pusher:member_added", n);
                    break;
                case "pusher_internal:member_removed":
                    var i = this.members.removeMember(t);
                    i && this.emit("pusher:member_removed", i);
                    break;
                default:
                    Pusher.PrivateChannel.prototype.handleEvent.call(this, e, t)
            }
        }, t.disconnect = function() {
            this.members.reset(), Pusher.PrivateChannel.prototype.disconnect.call(this)
        }, Pusher.PresenceChannel = e
    }.call(this),
    function() {
        function e() {
            this.channels = {}
        }

        function t(e, t) {
            return 0 === e.indexOf("private-") ? new Pusher.PrivateChannel(e, t) : 0 === e.indexOf("presence-") ? new Pusher.PresenceChannel(e, t) : new Pusher.Channel(e, t)
        }
        var n = e.prototype;
        n.add = function(e, n) {
            return this.channels[e] || (this.channels[e] = t(e, n)), this.channels[e]
        }, n.all = function(e) {
            return Pusher.Util.values(this.channels)
        }, n.find = function(e) {
            return this.channels[e]
        }, n.remove = function(e) {
            var t = this.channels[e];
            return delete this.channels[e], t
        }, n.disconnect = function() {
            Pusher.Util.objectApply(this.channels, function(e) {
                e.disconnect()
            })
        }, Pusher.Channels = e
    }.call(this),
    function() {
        Pusher.Channel.Authorizer = function(e, t) {
            this.channel = e, this.type = t.authTransport, this.options = t, this.authOptions = (t || {}).auth || {}
        }, Pusher.Channel.Authorizer.prototype = {
            composeQuery: function(e) {
                var t = "socket_id=" + encodeURIComponent(e) + "&channel_name=" + encodeURIComponent(this.channel.name);
                for (var n in this.authOptions.params) t += "&" + encodeURIComponent(n) + "=" + encodeURIComponent(this.authOptions.params[n]);
                return t
            },
            authorize: function(e, t) {
                return Pusher.authorizers[this.type].call(this, e, t)
            }
        };
        var e = 1;
        Pusher.auth_callbacks = {}, Pusher.authorizers = {
            ajax: function(e, t) {
                var n, i = this;
                n = Pusher.XHR ? new Pusher.XHR : window.XMLHttpRequest ? new window.XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP"), n.open("POST", i.options.authEndpoint, !0), n.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                for (var r in this.authOptions.headers) n.setRequestHeader(r, this.authOptions.headers[r]);
                return n.onreadystatechange = function() {
                    if (4 === n.readyState)
                        if (200 === n.status) {
                            var e, i = !1;
                            try {
                                e = JSON.parse(n.responseText), i = !0
                            } catch (r) {
                                t(!0, "JSON returned from webapp was invalid, yet status code was 200. Data was: " + n.responseText)
                            }
                            i && t(!1, e)
                        } else Pusher.warn("Couldn't get auth info from your webapp", n.status), t(!0, n.status)
                }, n.send(this.composeQuery(e)), n
            },
            jsonp: function(t, n) {
                void 0 !== this.authOptions.headers && Pusher.warn("Warn", "To send headers with the auth request, you must use AJAX, rather than JSONP.");
                var i = e.toString();
                e++;
                var r = Pusher.Util.getDocument(),
                    o = r.createElement("script");
                Pusher.auth_callbacks[i] = function(e) {
                    n(!1, e)
                };
                var a = "Pusher.auth_callbacks['" + i + "']";
                o.src = this.options.authEndpoint + "?callback=" + encodeURIComponent(a) + "&" + this.composeQuery(t);
                var s = r.getElementsByTagName("head")[0] || r.documentElement;
                s.insertBefore(o, s.firstChild)
            }
        }
    }.call(this),
    function(e) {
        "function" == typeof define && define.amd ? define(["jquery"], e) : e(jQuery)
    }(function(e) {
        return e.ui = e.ui || {}, e.ui.version = "1.12.1"
    }),
    function(e) {
        "function" == typeof define && define.amd ? define(["jquery", "./version"], e) : e(jQuery)
    }(function(e) {
        var t = "ui-effects-",
            n = "ui-effects-style",
            i = "ui-effects-animated",
            r = e;
        return e.effects = {
                effect: {}
            },
            function(e, t) {
                function n(e, t, n) {
                    var i = d[t.type] || {};
                    return null == e ? n || !t.def ? null : t.def : (e = i.floor ? ~~e : parseFloat(e), isNaN(e) ? t.def : i.mod ? (e + i.mod) % i.mod : 0 > e ? 0 : i.max < e ? i.max : e)
                }

                function i(t) {
                    var n = c(),
                        i = n._rgba = [];
                    return t = t.toLowerCase(), p(u, function(e, r) {
                        var o, a = r.re.exec(t),
                            s = a && r.parse(a),
                            u = r.space || "rgba";
                        return s ? (o = n[u](s), n[l[u].cache] = o[l[u].cache], i = n._rgba = o._rgba, !1) : void 0
                    }), i.length ? ("0,0,0,0" === i.join() && e.extend(i, o.transparent), n) : o[t]
                }

                function r(e, t, n) {
                    return n = (n + 1) % 1, 1 > 6 * n ? e + (t - e) * n * 6 : 1 > 2 * n ? t : 2 > 3 * n ? e + (t - e) * (2 / 3 - n) * 6 : e
                }
                var o, a = "backgroundColor borderBottomColor borderLeftColor borderRightColor borderTopColor color columnRuleColor outlineColor textDecorationColor textEmphasisColor",
                    s = /^([\-+])=\s*(\d+\.?\d*)/,
                    u = [{
                        re: /rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                        parse: function(e) {
                            return [e[1], e[2], e[3], e[4]]
                        }
                    }, {
                        re: /rgba?\(\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                        parse: function(e) {
                            return [2.55 * e[1], 2.55 * e[2], 2.55 * e[3], e[4]]
                        }
                    }, {
                        re: /#([a-f0-9]{2})([a-f0-9]{2})([a-f0-9]{2})/,
                        parse: function(e) {
                            return [parseInt(e[1], 16), parseInt(e[2], 16), parseInt(e[3], 16)]
                        }
                    }, {
                        re: /#([a-f0-9])([a-f0-9])([a-f0-9])/,
                        parse: function(e) {
                            return [parseInt(e[1] + e[1], 16), parseInt(e[2] + e[2], 16), parseInt(e[3] + e[3], 16)]
                        }
                    }, {
                        re: /hsla?\(\s*(\d+(?:\.\d+)?)\s*,\s*(\d+(?:\.\d+)?)\%\s*,\s*(\d+(?:\.\d+)?)\%\s*(?:,\s*(\d?(?:\.\d+)?)\s*)?\)/,
                        space: "hsla",
                        parse: function(e) {
                            return [e[1], e[2] / 100, e[3] / 100, e[4]]
                        }
                    }],
                    c = e.Color = function(t, n, i, r) {
                        return new e.Color.fn.parse(t, n, i, r)
                    },
                    l = {
                        rgba: {
                            props: {
                                red: {
                                    idx: 0,
                                    type: "byte"
                                },
                                green: {
                                    idx: 1,
                                    type: "byte"
                                },
                                blue: {
                                    idx: 2,
                                    type: "byte"
                                }
                            }
                        },
                        hsla: {
                            props: {
                                hue: {
                                    idx: 0,
                                    type: "degrees"
                                },
                                saturation: {
                                    idx: 1,
                                    type: "percent"
                                },
                                lightness: {
                                    idx: 2,
                                    type: "percent"
                                }
                            }
                        }
                    },
                    d = {
                        "byte": {
                            floor: !0,
                            max: 255
                        },
                        percent: {
                            max: 1
                        },
                        degrees: {
                            mod: 360,
                            floor: !0
                        }
                    },
                    h = c.support = {},
                    f = e("<p>")[0],
                    p = e.each;
                f.style.cssText = "background-color:rgba(1,1,1,.5)", h.rgba = f.style.backgroundColor.indexOf("rgba") > -1, p(l, function(e, t) {
                    t.cache = "_" + e, t.props.alpha = {
                        idx: 3,
                        type: "percent",
                        def: 1
                    }
                }), c.fn = e.extend(c.prototype, {
                    parse: function(r, a, s, u) {
                        if (r === t) return this._rgba = [null, null, null, null], this;
                        (r.jquery || r.nodeType) && (r = e(r).css(a), a = t);
                        var d = this,
                            h = e.type(r),
                            f = this._rgba = [];
                        return a !== t && (r = [r, a, s, u], h = "array"), "string" === h ? this.parse(i(r) || o._default) : "array" === h ? (p(l.rgba.props, function(e, t) {
                            f[t.idx] = n(r[t.idx], t)
                        }), this) : "object" === h ? (r instanceof c ? p(l, function(e, t) {
                            r[t.cache] && (d[t.cache] = r[t.cache].slice())
                        }) : p(l, function(t, i) {
                            var o = i.cache;
                            p(i.props, function(e, t) {
                                if (!d[o] && i.to) {
                                    if ("alpha" === e || null == r[e]) return;
                                    d[o] = i.to(d._rgba)
                                }
                                d[o][t.idx] = n(r[e], t, !0)
                            }), d[o] && e.inArray(null, d[o].slice(0, 3)) < 0 && (d[o][3] = 1, i.from && (d._rgba = i.from(d[o])))
                        }), this) : void 0
                    },
                    is: function(e) {
                        var t = c(e),
                            n = !0,
                            i = this;
                        return p(l, function(e, r) {
                            var o, a = t[r.cache];
                            return a && (o = i[r.cache] || r.to && r.to(i._rgba) || [], p(r.props, function(e, t) {
                                return null != a[t.idx] ? n = a[t.idx] === o[t.idx] : void 0
                            })), n
                        }), n
                    },
                    _space: function() {
                        var e = [],
                            t = this;
                        return p(l, function(n, i) {
                            t[i.cache] && e.push(n)
                        }), e.pop()
                    },
                    transition: function(e, t) {
                        var i = c(e),
                            r = i._space(),
                            o = l[r],
                            a = 0 === this.alpha() ? c("transparent") : this,
                            s = a[o.cache] || o.to(a._rgba),
                            u = s.slice();
                        return i = i[o.cache], p(o.props, function(e, r) {
                            var o = r.idx,
                                a = s[o],
                                c = i[o],
                                l = d[r.type] || {};
                            null !== c && (null === a ? u[o] = c : (l.mod && (c - a > l.mod / 2 ? a += l.mod : a - c > l.mod / 2 && (a -= l.mod)), u[o] = n((c - a) * t + a, r)))
                        }), this[r](u)
                    },
                    blend: function(t) {
                        if (1 === this._rgba[3]) return this;
                        var n = this._rgba.slice(),
                            i = n.pop(),
                            r = c(t)._rgba;
                        return c(e.map(n, function(e, t) {
                            return (1 - i) * r[t] + i * e
                        }))
                    },
                    toRgbaString: function() {
                        var t = "rgba(",
                            n = e.map(this._rgba, function(e, t) {
                                return null == e ? t > 2 ? 1 : 0 : e
                            });
                        return 1 === n[3] && (n.pop(), t = "rgb("), t + n.join() + ")"
                    },
                    toHslaString: function() {
                        var t = "hsla(",
                            n = e.map(this.hsla(), function(e, t) {
                                return null == e && (e = t > 2 ? 1 : 0), t && 3 > t && (e = Math.round(100 * e) + "%"), e
                            });
                        return 1 === n[3] && (n.pop(), t = "hsl("), t + n.join() + ")"
                    },
                    toHexString: function(t) {
                        var n = this._rgba.slice(),
                            i = n.pop();
                        return t && n.push(~~(255 * i)), "#" + e.map(n, function(e) {
                            return e = (e || 0).toString(16), 1 === e.length ? "0" + e : e
                        }).join("")
                    },
                    toString: function() {
                        return 0 === this._rgba[3] ? "transparent" : this.toRgbaString()
                    }
                }), c.fn.parse.prototype = c.fn, l.hsla.to = function(e) {
                    if (null == e[0] || null == e[1] || null == e[2]) return [null, null, null, e[3]];
                    var t, n, i = e[0] / 255,
                        r = e[1] / 255,
                        o = e[2] / 255,
                        a = e[3],
                        s = Math.max(i, r, o),
                        u = Math.min(i, r, o),
                        c = s - u,
                        l = s + u,
                        d = .5 * l;
                    return t = u === s ? 0 : i === s ? 60 * (r - o) / c + 360 : r === s ? 60 * (o - i) / c + 120 : 60 * (i - r) / c + 240, n = 0 === c ? 0 : .5 >= d ? c / l : c / (2 - l), [Math.round(t) % 360, n, d, null == a ? 1 : a]
                }, l.hsla.from = function(e) {
                    if (null == e[0] || null == e[1] || null == e[2]) return [null, null, null, e[3]];
                    var t = e[0] / 360,
                        n = e[1],
                        i = e[2],
                        o = e[3],
                        a = .5 >= i ? i * (1 + n) : i + n - i * n,
                        s = 2 * i - a;
                    return [Math.round(255 * r(s, a, t + 1 / 3)), Math.round(255 * r(s, a, t)), Math.round(255 * r(s, a, t - 1 / 3)), o]
                }, p(l, function(i, r) {
                    var o = r.props,
                        a = r.cache,
                        u = r.to,
                        l = r.from;
                    c.fn[i] = function(i) {
                        if (u && !this[a] && (this[a] = u(this._rgba)), i === t) return this[a].slice();
                        var r, s = e.type(i),
                            d = "array" === s || "object" === s ? i : arguments,
                            h = this[a].slice();
                        return p(o, function(e, t) {
                            var i = d["object" === s ? e : t.idx];
                            null == i && (i = h[t.idx]), h[t.idx] = n(i, t)
                        }), l ? (r = c(l(h)), r[a] = h, r) : c(h)
                    }, p(o, function(t, n) {
                        c.fn[t] || (c.fn[t] = function(r) {
                            var o, a = e.type(r),
                                u = "alpha" === t ? this._hsla ? "hsla" : "rgba" : i,
                                c = this[u](),
                                l = c[n.idx];
                            return "undefined" === a ? l : ("function" === a && (r = r.call(this, l), a = e.type(r)), null == r && n.empty ? this : ("string" === a && (o = s.exec(r), o && (r = l + parseFloat(o[2]) * ("+" === o[1] ? 1 : -1))), c[n.idx] = r, this[u](c)))
                        })
                    })
                }), c.hook = function(t) {
                    var n = t.split(" ");
                    p(n, function(t, n) {
                        e.cssHooks[n] = {
                            set: function(t, r) {
                                var o, a, s = "";
                                if ("transparent" !== r && ("string" !== e.type(r) || (o = i(r)))) {
                                    if (r = c(o || r), !h.rgba && 1 !== r._rgba[3]) {
                                        for (a = "backgroundColor" === n ? t.parentNode : t;
                                            ("" === s || "transparent" === s) && a && a.style;) try {
                                            s = e.css(a, "backgroundColor"), a = a.parentNode
                                        } catch (u) {}
                                        r = r.blend(s && "transparent" !== s ? s : "_default")
                                    }
                                    r = r.toRgbaString()
                                }
                                try {
                                    t.style[n] = r
                                } catch (u) {}
                            }
                        }, e.fx.step[n] = function(t) {
                            t.colorInit || (t.start = c(t.elem, n), t.end = c(t.end), t.colorInit = !0), e.cssHooks[n].set(t.elem, t.start.transition(t.end, t.pos))
                        }
                    })
                }, c.hook(a), e.cssHooks.borderColor = {
                    expand: function(e) {
                        var t = {};
                        return p(["Top", "Right", "Bottom", "Left"], function(n, i) {
                            t["border" + i + "Color"] = e
                        }), t
                    }
                }, o = e.Color.names = {
                    aqua: "#00ffff",
                    black: "#000000",
                    blue: "#0000ff",
                    fuchsia: "#ff00ff",
                    gray: "#808080",
                    green: "#008000",
                    lime: "#00ff00",
                    maroon: "#800000",
                    navy: "#000080",
                    olive: "#808000",
                    purple: "#800080",
                    red: "#ff0000",
                    silver: "#c0c0c0",
                    teal: "#008080",
                    white: "#ffffff",
                    yellow: "#ffff00",
                    transparent: [null, null, null, 0],
                    _default: "#ffffff"
                }
            }(r),
            function() {
                function t(t) {
                    var n, i, r = t.ownerDocument.defaultView ? t.ownerDocument.defaultView.getComputedStyle(t, null) : t.currentStyle,
                        o = {};
                    if (r && r.length && r[0] && r[r[0]])
                        for (i = r.length; i--;) n = r[i], "string" == typeof r[n] && (o[e.camelCase(n)] = r[n]);
                    else
                        for (n in r) "string" == typeof r[n] && (o[n] = r[n]);
                    return o
                }

                function n(t, n) {
                    var i, r, a = {};
                    for (i in n) r = n[i], t[i] !== r && (o[i] || (e.fx.step[i] || !isNaN(parseFloat(r))) && (a[i] = r));
                    return a
                }
                var i = ["add", "remove", "toggle"],
                    o = {
                        border: 1,
                        borderBottom: 1,
                        borderColor: 1,
                        borderLeft: 1,
                        borderRight: 1,
                        borderTop: 1,
                        borderWidth: 1,
                        margin: 1,
                        padding: 1
                    };
                e.each(["borderLeftStyle", "borderRightStyle", "borderBottomStyle", "borderTopStyle"], function(t, n) {
                    e.fx.step[n] = function(e) {
                        ("none" !== e.end && !e.setAttr || 1 === e.pos && !e.setAttr) && (r.style(e.elem, n, e.end), e.setAttr = !0)
                    }
                }), e.fn.addBack || (e.fn.addBack = function(e) {
                    return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
                }), e.effects.animateClass = function(r, o, a, s) {
                    var u = e.speed(o, a, s);
                    return this.queue(function() {
                        var o, a = e(this),
                            s = a.attr("class") || "",
                            c = u.children ? a.find("*").addBack() : a;
                        c = c.map(function() {
                            var n = e(this);
                            return {
                                el: n,
                                start: t(this)
                            }
                        }), o = function() {
                            e.each(i, function(e, t) {
                                r[t] && a[t + "Class"](r[t])
                            })
                        }, o(), c = c.map(function() {
                            return this.end = t(this.el[0]), this.diff = n(this.start, this.end), this
                        }), a.attr("class", s), c = c.map(function() {
                            var t = this,
                                n = e.Deferred(),
                                i = e.extend({}, u, {
                                    queue: !1,
                                    complete: function() {
                                        n.resolve(t)
                                    }
                                });
                            return this.el.animate(this.diff, i), n.promise()
                        }), e.when.apply(e, c.get()).done(function() {
                            o(), e.each(arguments, function() {
                                var t = this.el;
                                e.each(this.diff, function(e) {
                                    t.css(e, "")
                                })
                            }), u.complete.call(a[0])
                        })
                    })
                }, e.fn.extend({
                    addClass: function(t) {
                        return function(n, i, r, o) {
                            return i ? e.effects.animateClass.call(this, {
                                add: n
                            }, i, r, o) : t.apply(this, arguments)
                        }
                    }(e.fn.addClass),
                    removeClass: function(t) {
                        return function(n, i, r, o) {
                            return arguments.length > 1 ? e.effects.animateClass.call(this, {
                                remove: n
                            }, i, r, o) : t.apply(this, arguments)
                        }
                    }(e.fn.removeClass),
                    toggleClass: function(t) {
                        return function(n, i, r, o, a) {
                            return "boolean" == typeof i || void 0 === i ? r ? e.effects.animateClass.call(this, i ? {
                                add: n
                            } : {
                                remove: n
                            }, r, o, a) : t.apply(this, arguments) : e.effects.animateClass.call(this, {
                                toggle: n
                            }, i, r, o)
                        }
                    }(e.fn.toggleClass),
                    switchClass: function(t, n, i, r, o) {
                        return e.effects.animateClass.call(this, {
                            add: n,
                            remove: t
                        }, i, r, o)
                    }
                })
            }(),
            function() {
                function r(t, n, i, r) {
                    return e.isPlainObject(t) && (n = t, t = t.effect), t = {
                        effect: t
                    }, null == n && (n = {}), e.isFunction(n) && (r = n, i = null, n = {}), ("number" == typeof n || e.fx.speeds[n]) && (r = i, i = n, n = {}), e.isFunction(i) && (r = i, i = null), n && e.extend(t, n), i = i || n.duration, t.duration = e.fx.off ? 0 : "number" == typeof i ? i : i in e.fx.speeds ? e.fx.speeds[i] : e.fx.speeds._default, t.complete = r || n.complete, t
                }

                function o(t) {
                    return !t || "number" == typeof t || e.fx.speeds[t] ? !0 : "string" != typeof t || e.effects.effect[t] ? e.isFunction(t) ? !0 : "object" != typeof t || t.effect ? !1 : !0 : !0
                }

                function a(e, t) {
                    var n = t.outerWidth(),
                        i = t.outerHeight(),
                        r = /^rect\((-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto),?\s*(-?\d*\.?\d*px|-?\d+%|auto)\)$/,
                        o = r.exec(e) || ["", 0, n, i, 0];
                    return {
                        top: parseFloat(o[1]) || 0,
                        right: "auto" === o[2] ? n : parseFloat(o[2]),
                        bottom: "auto" === o[3] ? i : parseFloat(o[3]),
                        left: parseFloat(o[4]) || 0
                    }
                }
                e.expr && e.expr.filters && e.expr.filters.animated && (e.expr.filters.animated = function(t) {
                    return function(n) {
                        return !!e(n).data(i) || t(n)
                    }
                }(e.expr.filters.animated)), e.uiBackCompat !== !1 && e.extend(e.effects, {
                    save: function(e, n) {
                        for (var i = 0, r = n.length; r > i; i++) null !== n[i] && e.data(t + n[i], e[0].style[n[i]])
                    },
                    restore: function(e, n) {
                        for (var i, r = 0, o = n.length; o > r; r++) null !== n[r] && (i = e.data(t + n[r]), e.css(n[r], i))
                    },
                    setMode: function(e, t) {
                        return "toggle" === t && (t = e.is(":hidden") ? "show" : "hide"), t
                    },
                    createWrapper: function(t) {
                        if (t.parent().is(".ui-effects-wrapper")) return t.parent();
                        var n = {
                                width: t.outerWidth(!0),
                                height: t.outerHeight(!0),
                                "float": t.css("float")
                            },
                            i = e("<div></div>").addClass("ui-effects-wrapper").css({
                                fontSize: "100%",
                                background: "transparent",
                                border: "none",
                                margin: 0,
                                padding: 0
                            }),
                            r = {
                                width: t.width(),
                                height: t.height()
                            },
                            o = document.activeElement;
                        try {
                            o.id
                        } catch (a) {
                            o = document.body
                        }
                        return t.wrap(i), (t[0] === o || e.contains(t[0], o)) && e(o).trigger("focus"), i = t.parent(), "static" === t.css("position") ? (i.css({
                            position: "relative"
                        }), t.css({
                            position: "relative"
                        })) : (e.extend(n, {
                            position: t.css("position"),
                            zIndex: t.css("z-index")
                        }), e.each(["top", "left", "bottom", "right"], function(e, i) {
                            n[i] = t.css(i), isNaN(parseInt(n[i], 10)) && (n[i] = "auto")
                        }), t.css({
                            position: "relative",
                            top: 0,
                            left: 0,
                            right: "auto",
                            bottom: "auto"
                        })), t.css(r), i.css(n).show()
                    },
                    removeWrapper: function(t) {
                        var n = document.activeElement;
                        return t.parent().is(".ui-effects-wrapper") && (t.parent().replaceWith(t), (t[0] === n || e.contains(t[0], n)) && e(n).trigger("focus")), t
                    }
                }), e.extend(e.effects, {
                    version: "1.12.1",
                    define: function(t, n, i) {
                        return i || (i = n, n = "effect"), e.effects.effect[t] = i, e.effects.effect[t].mode = n, i
                    },
                    scaledDimensions: function(e, t, n) {
                        if (0 === t) return {
                            height: 0,
                            width: 0,
                            outerHeight: 0,
                            outerWidth: 0
                        };
                        var i = "horizontal" !== n ? (t || 100) / 100 : 1,
                            r = "vertical" !== n ? (t || 100) / 100 : 1;
                        return {
                            height: e.height() * r,
                            width: e.width() * i,
                            outerHeight: e.outerHeight() * r,
                            outerWidth: e.outerWidth() * i
                        }
                    },
                    clipToBox: function(e) {
                        return {
                            width: e.clip.right - e.clip.left,
                            height: e.clip.bottom - e.clip.top,
                            left: e.clip.left,
                            top: e.clip.top
                        }
                    },
                    unshift: function(e, t, n) {
                        var i = e.queue();
                        t > 1 && i.splice.apply(i, [1, 0].concat(i.splice(t, n))), e.dequeue()
                    },
                    saveStyle: function(e) {
                        e.data(n, e[0].style.cssText)
                    },
                    restoreStyle: function(e) {
                        e[0].style.cssText = e.data(n) || "", e.removeData(n)
                    },
                    mode: function(e, t) {
                        var n = e.is(":hidden");
                        return "toggle" === t && (t = n ? "show" : "hide"), (n ? "hide" === t : "show" === t) && (t = "none"), t
                    },
                    getBaseline: function(e, t) {
                        var n, i;
                        switch (e[0]) {
                            case "top":
                                n = 0;
                                break;
                            case "middle":
                                n = .5;
                                break;
                            case "bottom":
                                n = 1;
                                break;
                            default:
                                n = e[0] / t.height
                        }
                        switch (e[1]) {
                            case "left":
                                i = 0;
                                break;
                            case "center":
                                i = .5;
                                break;
                            case "right":
                                i = 1;
                                break;
                            default:
                                i = e[1] / t.width
                        }
                        return {
                            x: i,
                            y: n
                        }
                    },
                    createPlaceholder: function(n) {
                        var i, r = n.css("position"),
                            o = n.position();
                        return n.css({
                            marginTop: n.css("marginTop"),
                            marginBottom: n.css("marginBottom"),
                            marginLeft: n.css("marginLeft"),
                            marginRight: n.css("marginRight")
                        }).outerWidth(n.outerWidth()).outerHeight(n.outerHeight()), /^(static|relative)/.test(r) && (r = "absolute", i = e("<" + n[0].nodeName + ">").insertAfter(n).css({
                            display: /^(inline|ruby)/.test(n.css("display")) ? "inline-block" : "block",
                            visibility: "hidden",
                            marginTop: n.css("marginTop"),
                            marginBottom: n.css("marginBottom"),
                            marginLeft: n.css("marginLeft"),
                            marginRight: n.css("marginRight"),
                            "float": n.css("float")
                        }).outerWidth(n.outerWidth()).outerHeight(n.outerHeight()).addClass("ui-effects-placeholder"), n.data(t + "placeholder", i)), n.css({
                            position: r,
                            left: o.left,
                            top: o.top
                        }), i
                    },
                    removePlaceholder: function(e) {
                        var n = t + "placeholder",
                            i = e.data(n);
                        i && (i.remove(), e.removeData(n))
                    },
                    cleanUp: function(t) {
                        e.effects.restoreStyle(t), e.effects.removePlaceholder(t)
                    },
                    setTransition: function(t, n, i, r) {
                        return r = r || {}, e.each(n, function(e, n) {
                            var o = t.cssUnit(n);
                            o[0] > 0 && (r[n] = o[0] * i + o[1])
                        }), r
                    }
                }), e.fn.extend({
                    effect: function() {
                        function t(t) {
                            function r() {
                                u.removeData(i), e.effects.cleanUp(u), "hide" === n.mode && u.hide(), s()
                            }

                            function s() {
                                e.isFunction(c) && c.call(u[0]), e.isFunction(t) && t()
                            }
                            var u = e(this);
                            n.mode = d.shift(), e.uiBackCompat === !1 || a ? "none" === n.mode ? (u[l](), s()) : o.call(u[0], n, r) : (u.is(":hidden") ? "hide" === l : "show" === l) ? (u[l](), s()) : o.call(u[0], n, s)
                        }
                        var n = r.apply(this, arguments),
                            o = e.effects.effect[n.effect],
                            a = o.mode,
                            s = n.queue,
                            u = s || "fx",
                            c = n.complete,
                            l = n.mode,
                            d = [],
                            h = function(t) {
                                var n = e(this),
                                    r = e.effects.mode(n, l) || a;
                                n.data(i, !0), d.push(r), a && ("show" === r || r === a && "hide" === r) && n.show(), a && "none" === r || e.effects.saveStyle(n), e.isFunction(t) && t()
                            };
                        return e.fx.off || !o ? l ? this[l](n.duration, c) : this.each(function() {
                            c && c.call(this)
                        }) : s === !1 ? this.each(h).each(t) : this.queue(u, h).queue(u, t)
                    },
                    show: function(e) {
                        return function(t) {
                            if (o(t)) return e.apply(this, arguments);
                            var n = r.apply(this, arguments);
                            return n.mode = "show", this.effect.call(this, n)
                        }
                    }(e.fn.show),
                    hide: function(e) {
                        return function(t) {
                            if (o(t)) return e.apply(this, arguments);
                            var n = r.apply(this, arguments);
                            return n.mode = "hide", this.effect.call(this, n)
                        }
                    }(e.fn.hide),
                    toggle: function(e) {
                        return function(t) {
                            if (o(t) || "boolean" == typeof t) return e.apply(this, arguments);
                            var n = r.apply(this, arguments);
                            return n.mode = "toggle", this.effect.call(this, n)
                        }
                    }(e.fn.toggle),
                    cssUnit: function(t) {
                        var n = this.css(t),
                            i = [];
                        return e.each(["em", "px", "%", "pt"], function(e, t) {
                            n.indexOf(t) > 0 && (i = [parseFloat(n), t])
                        }), i
                    },
                    cssClip: function(e) {
                        return e ? this.css("clip", "rect(" + e.top + "px " + e.right + "px " + e.bottom + "px " + e.left + "px)") : a(this.css("clip"), this)
                    },
                    transfer: function(t, n) {
                        var i = e(this),
                            r = e(t.to),
                            o = "fixed" === r.css("position"),
                            a = e("body"),
                            s = o ? a.scrollTop() : 0,
                            u = o ? a.scrollLeft() : 0,
                            c = r.offset(),
                            l = {
                                top: c.top - s,
                                left: c.left - u,
                                height: r.innerHeight(),
                                width: r.innerWidth()
                            },
                            d = i.offset(),
                            h = e("<div class='ui-effects-transfer'></div>").appendTo("body").addClass(t.className).css({
                                top: d.top - s,
                                left: d.left - u,
                                height: i.innerHeight(),
                                width: i.innerWidth(),
                                position: o ? "fixed" : "absolute"
                            }).animate(l, t.duration, t.easing, function() {
                                h.remove(), e.isFunction(n) && n()
                            })
                    }
                }), e.fx.step.clip = function(t) {
                    t.clipInit || (t.start = e(t.elem).cssClip(), "string" == typeof t.end && (t.end = a(t.end, t.elem)), t.clipInit = !0), e(t.elem).cssClip({
                        top: t.pos * (t.end.top - t.start.top) + t.start.top,
                        right: t.pos * (t.end.right - t.start.right) + t.start.right,
                        bottom: t.pos * (t.end.bottom - t.start.bottom) + t.start.bottom,
                        left: t.pos * (t.end.left - t.start.left) + t.start.left
                    })
                }
            }(),
            function() {
                var t = {};
                e.each(["Quad", "Cubic", "Quart", "Quint", "Expo"], function(e, n) {
                    t[n] = function(t) {
                        return Math.pow(t, e + 2)
                    }
                }), e.extend(t, {
                    Sine: function(e) {
                        return 1 - Math.cos(e * Math.PI / 2)
                    },
                    Circ: function(e) {
                        return 1 - Math.sqrt(1 - e * e)
                    },
                    Elastic: function(e) {
                        return 0 === e || 1 === e ? e : -Math.pow(2, 8 * (e - 1)) * Math.sin((80 * (e - 1) - 7.5) * Math.PI / 15)
                    },
                    Back: function(e) {
                        return e * e * (3 * e - 2)
                    },
                    Bounce: function(e) {
                        for (var t, n = 4; e < ((t = Math.pow(2, --n)) - 1) / 11;);
                        return 1 / Math.pow(4, 3 - n) - 7.5625 * Math.pow((3 * t - 2) / 22 - e, 2)
                    }
                }), e.each(t, function(t, n) {
                    e.easing["easeIn" + t] = n, e.easing["easeOut" + t] = function(e) {
                        return 1 - n(1 - e)
                    }, e.easing["easeInOut" + t] = function(e) {
                        return .5 > e ? n(2 * e) / 2 : 1 - n(-2 * e + 2) / 2
                    }
                })
            }(), e.effects
    }),
    function(e) {
        "function" == typeof define && define.amd ? define(["jquery", "../version", "../effect"], e) : e(jQuery)
    }(function(e) {
        return e.effects.define("highlight", "show", function(t, n) {
            var i = e(this),
                r = {
                    backgroundColor: i.css("backgroundColor")
                };
            "hide" === t.mode && (r.opacity = 0), e.effects.saveStyle(i), i.css({
                backgroundImage: "none",
                backgroundColor: t.color || "#ffff99"
            }).animate(r, {
                queue: !1,
                duration: t.duration,
                easing: t.easing,
                complete: n
            })
        })
    }), ! function(e) {
        "use strict";
        e(function() {
            e.support.transition = function() {
                var e = function() {
                    var e, t = document.createElement("bootstrap"),
                        n = {
                            WebkitTransition: "webkitTransitionEnd",
                            MozTransition: "transitionend",
                            OTransition: "oTransitionEnd otransitionend",
                            transition: "transitionend"
                        };
                    for (e in n)
                        if (void 0 !== t.style[e]) return n[e]
                }();
                return e && {
                    end: e
                }
            }()
        })
    }(window.jQuery), ! function(e) {
        "use strict";
        var t = function(t, n) {
            this.options = e.extend({}, e.fn.affix.defaults, n), this.$window = e(window).on("scroll.affix.data-api", e.proxy(this.checkPosition, this)).on("click.affix.data-api", e.proxy(function() {
                setTimeout(e.proxy(this.checkPosition, this), 1)
            }, this)), this.$element = e(t), this.checkPosition()
        };
        t.prototype.checkPosition = function() {
            if (this.$element.is(":visible")) {
                var t, n = e(document).height(),
                    i = this.$window.scrollTop(),
                    r = this.$element.offset(),
                    o = this.options.offset,
                    a = o.bottom,
                    s = o.top,
                    u = "affix affix-top affix-bottom";
                "object" != typeof o && (a = s = o), "function" == typeof s && (s = o.top()), "function" == typeof a && (a = o.bottom()), t = null != this.unpin && i + this.unpin <= r.top ? !1 : null != a && r.top + this.$element.height() >= n - a ? "bottom" : null != s && s >= i ? "top" : !1, this.affixed !== t && (this.affixed = t, this.unpin = "bottom" == t ? r.top - i : null, this.$element.removeClass(u).addClass("affix" + (t ? "-" + t : "")))
            }
        };
        var n = e.fn.affix;
        e.fn.affix = function(n) {
            return this.each(function() {
                var i = e(this),
                    r = i.data("affix"),
                    o = "object" == typeof n && n;
                r || i.data("affix", r = new t(this, o)), "string" == typeof n && r[n]()
            })
        }, e.fn.affix.Constructor = t, e.fn.affix.defaults = {
            offset: 0
        }, e.fn.affix.noConflict = function() {
            return e.fn.affix = n, this
        }, e(window).on("load", function() {
            e('[data-spy="affix"]').each(function() {
                var t = e(this),
                    n = t.data();
                n.offset = n.offset || {}, n.offsetBottom && (n.offset.bottom = n.offsetBottom), n.offsetTop && (n.offset.top = n.offsetTop), t.affix(n)
            })
        })
    }(window.jQuery), ! function(e) {
        "use strict";
        var t = '[data-dismiss="alert"]',
            n = function(n) {
                e(n).on("click", t, this.close)
            };
        n.prototype.close = function(t) {
            function n() {
                i.trigger("closed").remove()
            }
            var i, r = e(this),
                o = r.attr("data-target");
            o || (o = r.attr("href"), o = o && o.replace(/.*(?=#[^\s]*$)/, "")), i = e(o), t && t.preventDefault(), i.length || (i = r.hasClass("alert") ? r : r.parent()), i.trigger(t = e.Event("close")), t.isDefaultPrevented() || (i.removeClass("in"), e.support.transition && i.hasClass("fade") ? i.on(e.support.transition.end, n) : n())
        };
        var i = e.fn.alert;
        e.fn.alert = function(t) {
            return this.each(function() {
                var i = e(this),
                    r = i.data("alert");
                r || i.data("alert", r = new n(this)), "string" == typeof t && r[t].call(i)
            })
        }, e.fn.alert.Constructor = n, e.fn.alert.noConflict = function() {
            return e.fn.alert = i, this
        }, e(document).on("click.alert.data-api", t, n.prototype.close)
    }(window.jQuery), ! function(e) {
        "use strict";
        var t = function(t, n) {
            this.$element = e(t), this.options = e.extend({}, e.fn.button.defaults, n)
        };
        t.prototype.setState = function(e) {
            var t = "disabled",
                n = this.$element,
                i = n.data(),
                r = n.is("input") ? "val" : "html";
            e += "Text", i.resetText || n.data("resetText", n[r]()), n[r](i[e] || this.options[e]), setTimeout(function() {
                "loadingText" == e ? n.addClass(t).attr(t, t) : n.removeClass(t).removeAttr(t)
            }, 0)
        }, t.prototype.toggle = function() {
            var e = this.$element.closest('[data-toggle="buttons-radio"]');
            e && e.find(".active").removeClass("active"), this.$element.toggleClass("active")
        };
        var n = e.fn.button;
        e.fn.button = function(n) {
            return this.each(function() {
                var i = e(this),
                    r = i.data("button"),
                    o = "object" == typeof n && n;
                r || i.data("button", r = new t(this, o)), "toggle" == n ? r.toggle() : n && r.setState(n)
            })
        }, e.fn.button.defaults = {
            loadingText: "loading..."
        }, e.fn.button.Constructor = t, e.fn.button.noConflict = function() {
            return e.fn.button = n, this
        }, e(document).on("click.button.data-api", "[data-toggle^=button]", function(t) {
            var n = e(t.target);
            n.hasClass("btn") || (n = n.closest(".btn")), n.button("toggle")
        })
    }(window.jQuery), ! function(e) {
        "use strict";
        var t = function(t, n) {
            this.$element = e(t), this.$indicators = this.$element.find(".carousel-indicators"), this.options = n, "hover" == this.options.pause && this.$element.on("mouseenter", e.proxy(this.pause, this)).on("mouseleave", e.proxy(this.cycle, this))
        };
        t.prototype = {
            cycle: function(t) {
                return t || (this.paused = !1), this.interval && clearInterval(this.interval), this.options.interval && !this.paused && (this.interval = setInterval(e.proxy(this.next, this), this.options.interval)), this
            },
            getActiveIndex: function() {
                return this.$active = this.$element.find(".item.active"), this.$items = this.$active.parent().children(), this.$items.index(this.$active)
            },
            to: function(t) {
                var n = this.getActiveIndex(),
                    i = this;
                if (!(t > this.$items.length - 1 || 0 > t)) return this.sliding ? this.$element.one("slid", function() {
                    i.to(t)
                }) : n == t ? this.pause().cycle() : this.slide(t > n ? "next" : "prev", e(this.$items[t]))
            },
            pause: function(t) {
                return t || (this.paused = !0), this.$element.find(".next, .prev").length && e.support.transition.end && (this.$element.trigger(e.support.transition.end), this.cycle(!0)), clearInterval(this.interval), this.interval = null, this
            },
            next: function() {
                return this.sliding ? void 0 : this.slide("next")
            },
            prev: function() {
                return this.sliding ? void 0 : this.slide("prev")
            },
            slide: function(t, n) {
                var i, r = this.$element.find(".item.active"),
                    o = n || r[t](),
                    a = this.interval,
                    s = "next" == t ? "left" : "right",
                    u = "next" == t ? "first" : "last",
                    c = this;
                if (this.sliding = !0, a && this.pause(), o = o.length ? o : this.$element.find(".item")[u](), i = e.Event("slide", {
                        relatedTarget: o[0],
                        direction: s
                    }), !o.hasClass("active")) {
                    if (this.$indicators.length && (this.$indicators.find(".active").removeClass("active"), this.$element.one("slid", function() {
                            var t = e(c.$indicators.children()[c.getActiveIndex()]);
                            t && t.addClass("active")
                        })), e.support.transition && this.$element.hasClass("slide")) {
                        if (this.$element.trigger(i), i.isDefaultPrevented()) return;
                        o.addClass(t), o[0].offsetWidth, r.addClass(s), o.addClass(s), this.$element.one(e.support.transition.end, function() {
                            o.removeClass([t, s].join(" ")).addClass("active"), r.removeClass(["active", s].join(" ")), c.sliding = !1, setTimeout(function() {
                                c.$element.trigger("slid")
                            }, 0)
                        })
                    } else {
                        if (this.$element.trigger(i), i.isDefaultPrevented()) return;
                        r.removeClass("active"), o.addClass("active"), this.sliding = !1, this.$element.trigger("slid")
                    }
                    return a && this.cycle(), this
                }
            }
        };
        var n = e.fn.carousel;
        e.fn.carousel = function(n) {
            return this.each(function() {
                var i = e(this),
                    r = i.data("carousel"),
                    o = e.extend({}, e.fn.carousel.defaults, "object" == typeof n && n),
                    a = "string" == typeof n ? n : o.slide;
                r || i.data("carousel", r = new t(this, o)), "number" == typeof n ? r.to(n) : a ? r[a]() : o.interval && r.pause().cycle()
            })
        }, e.fn.carousel.defaults = {
            interval: 5e3,
            pause: "hover"
        }, e.fn.carousel.Constructor = t, e.fn.carousel.noConflict = function() {
            return e.fn.carousel = n, this
        }, e(document).on("click.carousel.data-api", "[data-slide], [data-slide-to]", function(t) {
            var n, i, r = e(this),
                o = e(r.attr("data-target") || (n = r.attr("href")) && n.replace(/.*(?=#[^\s]+$)/, "")),
                a = e.extend({}, o.data(), r.data());
            o.carousel(a), (i = r.attr("data-slide-to")) && o.data("carousel").pause().to(i).cycle(), t.preventDefault()
        })
    }(window.jQuery), ! function(e) {
        "use strict";
        var t = function(t, n) {
            this.$element = e(t), this.options = e.extend({}, e.fn.collapse.defaults, n), this.options.parent && (this.$parent = e(this.options.parent)), this.options.toggle && this.toggle()
        };
        t.prototype = {
            constructor: t,
            dimension: function() {
                var e = this.$element.hasClass("width");
                return e ? "width" : "height"
            },
            show: function() {
                var t, n, i, r;
                if (!this.transitioning && !this.$element.hasClass("in")) {
                    if (t = this.dimension(), n = e.camelCase(["scroll", t].join("-")), i = this.$parent && this.$parent.find("> .accordion-group > .in"), i && i.length) {
                        if (r = i.data("collapse"), r && r.transitioning) return;
                        i.collapse("hide"), r || i.data("collapse", null)
                    }
                    this.$element[t](0), this.transition("addClass", e.Event("show"), "shown"), e.support.transition && this.$element[t](this.$element[0][n])
                }
            },
            hide: function() {
                var t;
                !this.transitioning && this.$element.hasClass("in") && (t = this.dimension(), this.reset(this.$element[t]()), this.transition("removeClass", e.Event("hide"), "hidden"), this.$element[t](0))
            },
            reset: function(e) {
                var t = this.dimension();
                return this.$element.removeClass("collapse")[t](e || "auto")[0].offsetWidth, this.$element[null !== e ? "addClass" : "removeClass"]("collapse"), this
            },
            transition: function(t, n, i) {
                var r = this,
                    o = function() {
                        "show" == n.type && r.reset(), r.transitioning = 0, r.$element.trigger(i)
                    };
                this.$element.trigger(n), n.isDefaultPrevented() || (this.transitioning = 1, this.$element[t]("in"), e.support.transition && this.$element.hasClass("collapse") ? this.$element.one(e.support.transition.end, o) : o())
            },
            toggle: function() {
                this[this.$element.hasClass("in") ? "hide" : "show"]()
            }
        };
        var n = e.fn.collapse;
        e.fn.collapse = function(n) {
            return this.each(function() {
                var i = e(this),
                    r = i.data("collapse"),
                    o = e.extend({}, e.fn.collapse.defaults, i.data(), "object" == typeof n && n);
                r || i.data("collapse", r = new t(this, o)), "string" == typeof n && r[n]()
            })
        }, e.fn.collapse.defaults = {
            toggle: !0
        }, e.fn.collapse.Constructor = t, e.fn.collapse.noConflict = function() {
            return e.fn.collapse = n, this
        }, e(document).on("click.collapse.data-api", "[data-toggle=collapse]", function(t) {
            var n, i = e(this),
                r = i.attr("data-target") || t.preventDefault() || (n = i.attr("href")) && n.replace(/.*(?=#[^\s]+$)/, ""),
                o = e(r).data("collapse") ? "toggle" : i.data();
            i[e(r).hasClass("in") ? "addClass" : "removeClass"]("collapsed"), e(r).collapse(o)
        })
    }(window.jQuery), ! function(e) {
        "use strict";

        function t() {
            e(".dropdown-backdrop").remove(), e(i).each(function() {
                n(e(this)).removeClass("open")
            })
        }

        function n(t) {
            var n, i = t.attr("data-target");
            return i || (i = t.attr("href"), i = i && /#/.test(i) && i.replace(/.*(?=#[^\s]*$)/, "")), n = i && e(i), n && n.length || (n = t.parent()), n
        }
        var i = "[data-toggle=dropdown]",
            r = function(t) {
                var n = e(t).on("click.dropdown.data-api", this.toggle);
                e("html").on("click.dropdown.data-api", function() {
                    n.parent().removeClass("open")
                })
            };
        r.prototype = {
            constructor: r,
            toggle: function(i) {
                var r, o, a = e(this);
                if (!a.is(".disabled, :disabled")) return r = n(a), o = r.hasClass("open"), t(), o || ("ontouchstart" in document.documentElement && e('<div class="dropdown-backdrop"/>').insertBefore(e(this)).on("click", t), r.toggleClass("open")), a.focus(), !1
            },
            keydown: function(t) {
                var r, o, a, s, u;
                if (/(38|40|27)/.test(t.keyCode) && (r = e(this), t.preventDefault(), t.stopPropagation(), !r.is(".disabled, :disabled"))) {
                    if (a = n(r), s = a.hasClass("open"), !s || s && 27 == t.keyCode) return 27 == t.which && a.find(i).focus(), r.click();
                    o = e("[role=menu] li:not(.divider):visible a", a), o.length && (u = o.index(o.filter(":focus")), 38 == t.keyCode && u > 0 && u--, 40 == t.keyCode && u < o.length - 1 && u++, ~u || (u = 0), o.eq(u).focus())
                }
            }
        };
        var o = e.fn.dropdown;
        e.fn.dropdown = function(t) {
            return this.each(function() {
                var n = e(this),
                    i = n.data("dropdown");
                i || n.data("dropdown", i = new r(this)), "string" == typeof t && i[t].call(n)
            })
        }, e.fn.dropdown.Constructor = r, e.fn.dropdown.noConflict = function() {
            return e.fn.dropdown = o, this
        }, e(document).on("click.dropdown.data-api", t).on("click.dropdown.data-api", ".dropdown form", function(e) {
            e.stopPropagation()
        }).on("click.dropdown.data-api", i, r.prototype.toggle).on("keydown.dropdown.data-api", i + ", [role=menu]", r.prototype.keydown)
    }(window.jQuery), ! function(e) {
        "use strict";
        var t = function(t, n) {
            this.options = n, this.$element = e(t).delegate('[data-dismiss="modal"]', "click.dismiss.modal", e.proxy(this.hide, this)), this.options.remote && this.$element.find(".modal-body").load(this.options.remote)
        };
        t.prototype = {
            constructor: t,
            toggle: function() {
                return this[this.isShown ? "hide" : "show"]()
            },
            show: function() {
                var t = this,
                    n = e.Event("show");
                this.$element.trigger(n), this.isShown || n.isDefaultPrevented() || (this.isShown = !0, this.escape(), this.backdrop(function() {
                    var n = e.support.transition && t.$element.hasClass("fade");
                    t.$element.parent().length || t.$element.appendTo(document.body), t.$element.show(), n && t.$element[0].offsetWidth, t.$element.addClass("in").attr("aria-hidden", !1), t.enforceFocus(), n ? t.$element.one(e.support.transition.end, function() {
                        t.$element.focus().trigger("shown")
                    }) : t.$element.focus().trigger("shown")
                }))
            },
            hide: function(t) {
                t && t.preventDefault();
                t = e.Event("hide"), this.$element.trigger(t), this.isShown && !t.isDefaultPrevented() && (this.isShown = !1, this.escape(), e(document).off("focusin.modal"), this.$element.removeClass("in").attr("aria-hidden", !0), e.support.transition && this.$element.hasClass("fade") ? this.hideWithTransition() : this.hideModal())
            },
            enforceFocus: function() {
                var t = this;
                e(document).on("focusin.modal", function(e) {
                    t.$element[0] === e.target || t.$element.has(e.target).length || t.$element.focus()
                })
            },
            escape: function() {
                var e = this;
                this.isShown && this.options.keyboard ? this.$element.on("keyup.dismiss.modal", function(t) {
                    27 == t.which && e.hide()
                }) : this.isShown || this.$element.off("keyup.dismiss.modal")
            },
            hideWithTransition: function() {
                var t = this,
                    n = setTimeout(function() {
                        t.$element.off(e.support.transition.end), t.hideModal()
                    }, 500);
                this.$element.one(e.support.transition.end, function() {
                    clearTimeout(n), t.hideModal()
                })
            },
            hideModal: function() {
                var e = this;
                this.$element.hide(), this.backdrop(function() {
                    e.removeBackdrop(), e.$element.trigger("hidden")
                })
            },
            removeBackdrop: function() {
                this.$backdrop && this.$backdrop.remove(), this.$backdrop = null
            },
            backdrop: function(t) {
                var n = this.$element.hasClass("fade") ? "fade" : "";
                if (this.isShown && this.options.backdrop) {
                    var i = e.support.transition && n;
                    if (this.$backdrop = e('<div class="modal-backdrop ' + n + '" />').appendTo(document.body), this.$backdrop.click("static" == this.options.backdrop ? e.proxy(this.$element[0].focus, this.$element[0]) : e.proxy(this.hide, this)), i && this.$backdrop[0].offsetWidth, this.$backdrop.addClass("in"), !t) return;
                    i ? this.$backdrop.one(e.support.transition.end, t) : t()
                } else !this.isShown && this.$backdrop ? (this.$backdrop.removeClass("in"), e.support.transition && this.$element.hasClass("fade") ? this.$backdrop.one(e.support.transition.end, t) : t()) : t && t()
            }
        };
        var n = e.fn.modal;
        e.fn.modal = function(n) {
            return this.each(function() {
                var i = e(this),
                    r = i.data("modal"),
                    o = e.extend({}, e.fn.modal.defaults, i.data(), "object" == typeof n && n);
                r || i.data("modal", r = new t(this, o)), "string" == typeof n ? r[n]() : o.show && r.show()
            })
        }, e.fn.modal.defaults = {
            backdrop: !0,
            keyboard: !0,
            show: !0
        }, e.fn.modal.Constructor = t, e.fn.modal.noConflict = function() {
            return e.fn.modal = n, this
        }, e(document).on("click.modal.data-api", '[data-toggle="modal"]', function(t) {
            var n = e(this),
                i = n.attr("href"),
                r = e(n.attr("data-target") || i && i.replace(/.*(?=#[^\s]+$)/, "")),
                o = r.data("modal") ? "toggle" : e.extend({
                    remote: !/#/.test(i) && i
                }, r.data(), n.data());
            t.preventDefault(), r.modal(o).one("hide", function() {
                n.focus()
            })
        })
    }(window.jQuery), ! function(e) {
        "use strict";

        function t(t, n) {
            var i, r = e.proxy(this.process, this),
                o = e(e(t).is("body") ? window : t);
            this.options = e.extend({}, e.fn.scrollspy.defaults, n), this.$scrollElement = o.on("scroll.scroll-spy.data-api", r), this.selector = (this.options.target || (i = e(t).attr("href")) && i.replace(/.*(?=#[^\s]+$)/, "") || "") + " .nav li > a", this.$body = e("body"), this.refresh(), this.process()
        }
        t.prototype = {
            constructor: t,
            refresh: function() {
                var t, n = this;
                this.offsets = e([]), this.targets = e([]), t = this.$body.find(this.selector).map(function() {
                    var t = e(this),
                        i = t.data("target") || t.attr("href"),
                        r = /^#\w/.test(i) && e(i);
                    return r && r.length && [
                        [r.position().top + (!e.isWindow(n.$scrollElement.get(0)) && n.$scrollElement.scrollTop()), i]
                    ] || null
                }).sort(function(e, t) {
                    return e[0] - t[0]
                }).each(function() {
                    n.offsets.push(this[0]), n.targets.push(this[1])
                })
            },
            process: function() {
                var e, t = this.$scrollElement.scrollTop() + this.options.offset,
                    n = this.$scrollElement[0].scrollHeight || this.$body[0].scrollHeight,
                    i = n - this.$scrollElement.height(),
                    r = this.offsets,
                    o = this.targets,
                    a = this.activeTarget;
                if (t >= i) return a != (e = o.last()[0]) && this.activate(e);
                for (e = r.length; e--;) a != o[e] && t >= r[e] && (!r[e + 1] || t <= r[e + 1]) && this.activate(o[e])
            },
            activate: function(t) {
                var n, i;
                this.activeTarget = t, e(this.selector).parent(".active").removeClass("active"), i = this.selector + '[data-target="' + t + '"],' + this.selector + '[href="' + t + '"]', n = e(i).parent("li").addClass("active"), n.parent(".dropdown-menu").length && (n = n.closest("li.dropdown").addClass("active")), n.trigger("activate")
            }
        };
        var n = e.fn.scrollspy;
        e.fn.scrollspy = function(n) {
            return this.each(function() {
                var i = e(this),
                    r = i.data("scrollspy"),
                    o = "object" == typeof n && n;
                r || i.data("scrollspy", r = new t(this, o)), "string" == typeof n && r[n]()
            })
        }, e.fn.scrollspy.Constructor = t, e.fn.scrollspy.defaults = {
            offset: 10
        }, e.fn.scrollspy.noConflict = function() {
            return e.fn.scrollspy = n, this
        }, e(window).on("load", function() {
            e('[data-spy="scroll"]').each(function() {
                var t = e(this);
                t.scrollspy(t.data())
            })
        })
    }(window.jQuery), ! function(e) {
        "use strict";
        var t = function(t) {
            this.element = e(t)
        };
        t.prototype = {
            constructor: t,
            show: function() {
                var t, n, i, r = this.element,
                    o = r.closest("ul:not(.dropdown-menu)"),
                    a = r.attr("data-target");
                a || (a = r.attr("href"), a = a && a.replace(/.*(?=#[^\s]*$)/, "")), r.parent("li").hasClass("active") || (t = o.find(".active:last a")[0], i = e.Event("show", {
                    relatedTarget: t
                }), r.trigger(i), i.isDefaultPrevented() || (n = e(a), this.activate(r.parent("li"), o), this.activate(n, n.parent(), function() {
                    r.trigger({
                        type: "shown",
                        relatedTarget: t
                    })
                })))
            },
            activate: function(t, n, i) {
                function r() {
                    o.removeClass("active").find("> .dropdown-menu > .active").removeClass("active"), t.addClass("active"), a ? (t[0].offsetWidth, t.addClass("in")) : t.removeClass("fade"), t.parent(".dropdown-menu") && t.closest("li.dropdown").addClass("active"), i && i()
                }
                var o = n.find("> .active"),
                    a = i && e.support.transition && o.hasClass("fade");
                a ? o.one(e.support.transition.end, r) : r(), o.removeClass("in")
            }
        };
        var n = e.fn.tab;
        e.fn.tab = function(n) {
            return this.each(function() {
                var i = e(this),
                    r = i.data("tab");
                r || i.data("tab", r = new t(this)), "string" == typeof n && r[n]()
            })
        }, e.fn.tab.Constructor = t, e.fn.tab.noConflict = function() {
            return e.fn.tab = n, this
        }, e(document).on("click.tab.data-api", '[data-toggle="tab"], [data-toggle="pill"]', function(t) {
            t.preventDefault(), e(this).tab("show")
        })
    }(window.jQuery), ! function(e) {
        "use strict";
        var t = function(e, t) {
            this.init("tooltip", e, t)
        };
        t.prototype = {
            constructor: t,
            init: function(t, n, i) {
                var r, o, a, s, u;
                for (this.type = t, this.$element = e(n), this.options = this.getOptions(i), this.enabled = !0, a = this.options.trigger.split(" "), u = a.length; u--;) s = a[u], "click" == s ? this.$element.on("click." + this.type, this.options.selector, e.proxy(this.toggle, this)) : "manual" != s && (r = "hover" == s ? "mouseenter" : "focus", o = "hover" == s ? "mouseleave" : "blur", this.$element.on(r + "." + this.type, this.options.selector, e.proxy(this.enter, this)), this.$element.on(o + "." + this.type, this.options.selector, e.proxy(this.leave, this)));
                this.options.selector ? this._options = e.extend({}, this.options, {
                    trigger: "manual",
                    selector: ""
                }) : this.fixTitle()
            },
            getOptions: function(t) {
                return t = e.extend({}, e.fn[this.type].defaults, this.$element.data(), t), t.delay && "number" == typeof t.delay && (t.delay = {
                    show: t.delay,
                    hide: t.delay
                }), t
            },
            enter: function(t) {
                var n, i = e.fn[this.type].defaults,
                    r = {};
                return this._options && e.each(this._options, function(e, t) {
                    i[e] != t && (r[e] = t)
                }, this), n = e(t.currentTarget)[this.type](r).data(this.type), n.options.delay && n.options.delay.show ? (clearTimeout(this.timeout), n.hoverState = "in", void(this.timeout = setTimeout(function() {
                    "in" == n.hoverState && n.show()
                }, n.options.delay.show))) : n.show()
            },
            leave: function(t) {
                var n = e(t.currentTarget)[this.type](this._options).data(this.type);
                return this.timeout && clearTimeout(this.timeout), n.options.delay && n.options.delay.hide ? (n.hoverState = "out", void(this.timeout = setTimeout(function() {
                    "out" == n.hoverState && n.hide()
                }, n.options.delay.hide))) : n.hide()
            },
            show: function() {
                var t, n, i, r, o, a, s = e.Event("show");
                if (this.hasContent() && this.enabled) {
                    if (this.$element.trigger(s), s.isDefaultPrevented()) return;
                    switch (t = this.tip(), this.setContent(), this.options.animation && t.addClass("fade"), o = "function" == typeof this.options.placement ? this.options.placement.call(this, t[0], this.$element[0]) : this.options.placement, t.detach().css({
                        top: 0,
                        left: 0,
                        display: "block"
                    }), this.options.container ? t.appendTo(this.options.container) : t.insertAfter(this.$element), n = this.getPosition(), i = t[0].offsetWidth, r = t[0].offsetHeight, o) {
                        case "bottom":
                            a = {
                                top: n.top + n.height,
                                left: n.left + n.width / 2 - i / 2
                            };
                            break;
                        case "top":
                            a = {
                                top: n.top - r,
                                left: n.left + n.width / 2 - i / 2
                            };
                            break;
                        case "left":
                            a = {
                                top: n.top + n.height / 2 - r / 2,
                                left: n.left - i
                            };
                            break;
                        case "right":
                            a = {
                                top: n.top + n.height / 2 - r / 2,
                                left: n.left + n.width
                            }
                    }
                    this.applyPlacement(a, o), this.$element.trigger("shown")
                }
            },
            applyPlacement: function(e, t) {
                var n, i, r, o, a = this.tip(),
                    s = a[0].offsetWidth,
                    u = a[0].offsetHeight;
                a.offset(e).addClass(t).addClass("in"), n = a[0].offsetWidth, i = a[0].offsetHeight, "top" == t && i != u && (e.top = e.top + u - i, o = !0), "bottom" == t || "top" == t ? (r = 0, e.left < 0 && (r = -2 * e.left, e.left = 0, a.offset(e), n = a[0].offsetWidth, i = a[0].offsetHeight), this.replaceArrow(r - s + n, n, "left")) : this.replaceArrow(i - u, i, "top"), o && a.offset(e)
            },
            replaceArrow: function(e, t, n) {
                this.arrow().css(n, e ? 50 * (1 - e / t) + "%" : "")
            },
            setContent: function() {
                var e = this.tip(),
                    t = this.getTitle();
                e.find(".tooltip-inner")[this.options.html ? "html" : "text"](t), e.removeClass("fade in top bottom left right")
            },
            hide: function() {
                function t() {
                    var t = setTimeout(function() {
                        n.off(e.support.transition.end).detach()
                    }, 500);
                    n.one(e.support.transition.end, function() {
                        clearTimeout(t), n.detach()
                    })
                }
                var n = this.tip(),
                    i = e.Event("hide");
                return this.$element.trigger(i), i.isDefaultPrevented() ? void 0 : (n.removeClass("in"), e.support.transition && this.$tip.hasClass("fade") ? t() : n.detach(), this.$element.trigger("hidden"), this)
            },
            fixTitle: function() {
                var e = this.$element;
                (e.attr("title") || "string" != typeof e.attr("data-original-title")) && e.attr("data-original-title", e.attr("title") || "").attr("title", "")
            },
            hasContent: function() {
                return this.getTitle()
            },
            getPosition: function() {
                var t = this.$element[0];
                return e.extend({}, "function" == typeof t.getBoundingClientRect ? t.getBoundingClientRect() : {
                    width: t.offsetWidth,
                    height: t.offsetHeight
                }, this.$element.offset())
            },
            getTitle: function() {
                var e, t = this.$element,
                    n = this.options;
                return e = t.attr("data-original-title") || ("function" == typeof n.title ? n.title.call(t[0]) : n.title)
            },
            tip: function() {
                return this.$tip = this.$tip || e(this.options.template)
            },
            arrow: function() {
                return this.$arrow = this.$arrow || this.tip().find(".tooltip-arrow")
            },
            validate: function() {
                this.$element[0].parentNode || (this.hide(), this.$element = null, this.options = null)
            },
            enable: function() {
                this.enabled = !0
            },
            disable: function() {
                this.enabled = !1
            },
            toggleEnabled: function() {
                this.enabled = !this.enabled
            },
            toggle: function(t) {
                var n = t ? e(t.currentTarget)[this.type](this._options).data(this.type) : this;
                n.tip().hasClass("in") ? n.hide() : n.show()
            },
            destroy: function() {
                this.hide().$element.off("." + this.type).removeData(this.type)
            }
        };
        var n = e.fn.tooltip;
        e.fn.tooltip = function(n) {
            return this.each(function() {
                var i = e(this),
                    r = i.data("tooltip"),
                    o = "object" == typeof n && n;
                r || i.data("tooltip", r = new t(this, o)), "string" == typeof n && r[n]()
            })
        }, e.fn.tooltip.Constructor = t, e.fn.tooltip.defaults = {
            animation: !0,
            placement: "top",
            selector: !1,
            template: '<div class="tooltip"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>',
            trigger: "hover focus",
            title: "",
            delay: 0,
            html: !1,
            container: !1
        }, e.fn.tooltip.noConflict = function() {
            return e.fn.tooltip = n, this
        }
    }(window.jQuery), ! function(e) {
        "use strict";
        var t = function(e, t) {
            this.init("popover", e, t)
        };
        t.prototype = e.extend({}, e.fn.tooltip.Constructor.prototype, {
            constructor: t,
            setContent: function() {
                var e = this.tip(),
                    t = this.getTitle(),
                    n = this.getContent();
                e.find(".popover-title")[this.options.html ? "html" : "text"](t), e.find(".popover-content")[this.options.html ? "html" : "text"](n), e.removeClass("fade top bottom left right in")
            },
            hasContent: function() {
                return this.getTitle() || this.getContent()
            },
            getContent: function() {
                var e, t = this.$element,
                    n = this.options;
                return e = ("function" == typeof n.content ? n.content.call(t[0]) : n.content) || t.attr("data-content")
            },
            tip: function() {
                return this.$tip || (this.$tip = e(this.options.template)), this.$tip
            },
            destroy: function() {
                this.hide().$element.off("." + this.type).removeData(this.type)
            }
        });
        var n = e.fn.popover;
        e.fn.popover = function(n) {
            return this.each(function() {
                var i = e(this),
                    r = i.data("popover"),
                    o = "object" == typeof n && n;
                r || i.data("popover", r = new t(this, o)), "string" == typeof n && r[n]()
            })
        }, e.fn.popover.Constructor = t, e.fn.popover.defaults = e.extend({}, e.fn.tooltip.defaults, {
            placement: "right",
            trigger: "click",
            content: "",
            template: '<div class="popover"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>'
        }), e.fn.popover.noConflict = function() {
            return e.fn.popover = n, this
        }
    }(window.jQuery), ! function(e) {
        "use strict";
        var t = function(t, n) {
            this.$element = e(t), this.options = e.extend({}, e.fn.typeahead.defaults, n), this.matcher = this.options.matcher || this.matcher, this.sorter = this.options.sorter || this.sorter, this.highlighter = this.options.highlighter || this.highlighter, this.updater = this.options.updater || this.updater, this.source = this.options.source, this.$menu = e(this.options.menu), this.shown = !1, this.listen()
        };
        t.prototype = {
            constructor: t,
            select: function() {
                var e = this.$menu.find(".active").attr("data-value");
                return this.$element.val(this.updater(e)).change(), this.hide()
            },
            updater: function(e) {
                return e
            },
            show: function() {
                var t = e.extend({}, this.$element.position(), {
                    height: this.$element[0].offsetHeight
                });
                return this.$menu.insertAfter(this.$element).css({
                    top: t.top + t.height,
                    left: t.left
                }).show(), this.shown = !0, this
            },
            hide: function() {
                return this.$menu.hide(), this.shown = !1, this
            },
            lookup: function(t) {
                var n;
                return this.query = this.$element.val(), !this.query || this.query.length < this.options.minLength ? this.shown ? this.hide() : this : (n = e.isFunction(this.source) ? this.source(this.query, e.proxy(this.process, this)) : this.source, n ? this.process(n) : this)
            },
            process: function(t) {
                var n = this;
                return t = e.grep(t, function(e) {
                    return n.matcher(e)
                }), t = this.sorter(t), t.length ? this.render(t.slice(0, this.options.items)).show() : this.shown ? this.hide() : this
            },
            matcher: function(e) {
                return ~e.toLowerCase().indexOf(this.query.toLowerCase())
            },
            sorter: function(e) {
                for (var t, n = [], i = [], r = []; t = e.shift();) t.toLowerCase().indexOf(this.query.toLowerCase()) ? ~t.indexOf(this.query) ? i.push(t) : r.push(t) : n.push(t);
                return n.concat(i, r)
            },
            highlighter: function(e) {
                var t = this.query.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&");
                return e.replace(new RegExp("(" + t + ")", "ig"), function(e, t) {
                    return "<strong>" + t + "</strong>"
                })
            },
            render: function(t) {
                var n = this;
                return t = e(t).map(function(t, i) {
                    return t = e(n.options.item).attr("data-value", i), t.find("a").html(n.highlighter(i)), t[0]
                }), t.first().addClass("active"), this.$menu.html(t), this
            },
            next: function(t) {
                var n = this.$menu.find(".active").removeClass("active"),
                    i = n.next();
                i.length || (i = e(this.$menu.find("li")[0])), i.addClass("active")
            },
            prev: function(e) {
                var t = this.$menu.find(".active").removeClass("active"),
                    n = t.prev();
                n.length || (n = this.$menu.find("li").last()), n.addClass("active")
            },
            listen: function() {
                this.$element.on("focus", e.proxy(this.focus, this)).on("blur", e.proxy(this.blur, this)).on("keypress", e.proxy(this.keypress, this)).on("keyup", e.proxy(this.keyup, this)), this.eventSupported("keydown") && this.$element.on("keydown", e.proxy(this.keydown, this)), this.$menu.on("click", e.proxy(this.click, this)).on("mouseenter", "li", e.proxy(this.mouseenter, this)).on("mouseleave", "li", e.proxy(this.mouseleave, this))
            },
            eventSupported: function(e) {
                var t = e in this.$element;
                return t || (this.$element.setAttribute(e, "return;"), t = "function" == typeof this.$element[e]), t
            },
            move: function(e) {
                if (this.shown) {
                    switch (e.keyCode) {
                        case 9:
                        case 13:
                        case 27:
                            e.preventDefault();
                            break;
                        case 38:
                            e.preventDefault(), this.prev();
                            break;
                        case 40:
                            e.preventDefault(), this.next()
                    }
                    e.stopPropagation()
                }
            },
            keydown: function(t) {
                this.suppressKeyPressRepeat = ~e.inArray(t.keyCode, [40, 38, 9, 13, 27]), this.move(t)
            },
            keypress: function(e) {
                this.suppressKeyPressRepeat || this.move(e)
            },
            keyup: function(e) {
                switch (e.keyCode) {
                    case 40:
                    case 38:
                    case 16:
                    case 17:
                    case 18:
                        break;
                    case 9:
                    case 13:
                        if (!this.shown) return;
                        this.select();
                        break;
                    case 27:
                        if (!this.shown) return;
                        this.hide();
                        break;
                    default:
                        this.lookup()
                }
                e.stopPropagation(), e.preventDefault()
            },
            focus: function(e) {
                this.focused = !0
            },
            blur: function(e) {
                this.focused = !1, !this.mousedover && this.shown && this.hide()
            },
            click: function(e) {
                e.stopPropagation(), e.preventDefault(), this.select(), this.$element.focus()
            },
            mouseenter: function(t) {
                this.mousedover = !0, this.$menu.find(".active").removeClass("active"), e(t.currentTarget).addClass("active")
            },
            mouseleave: function(e) {
                this.mousedover = !1, !this.focused && this.shown && this.hide()
            }
        };
        var n = e.fn.typeahead;
        e.fn.typeahead = function(n) {
            return this.each(function() {
                var i = e(this),
                    r = i.data("typeahead"),
                    o = "object" == typeof n && n;
                r || i.data("typeahead", r = new t(this, o)), "string" == typeof n && r[n]()
            })
        }, e.fn.typeahead.defaults = {
            source: [],
            items: 8,
            menu: '<ul class="typeahead dropdown-menu"></ul>',
            item: '<li><a href="#"></a></li>',
            minLength: 1
        }, e.fn.typeahead.Constructor = t, e.fn.typeahead.noConflict = function() {
            return e.fn.typeahead = n, this
        }, e(document).on("focus.typeahead.data-api", '[data-provide="typeahead"]', function(t) {
            var n = e(this);
            n.data("typeahead") || n.typeahead(n.data())
        })
    }(window.jQuery),
    function(e, t) {
        function n() {
            return new Date(Date.UTC.apply(Date, arguments))
        }

        function i() {
            var e = new Date;
            return n(e.getFullYear(), e.getMonth(), e.getDate())
        }

        function r(e) {
            return function() {
                return this[e].apply(this, arguments)
            }
        }

        function o(t, n) {
            function i(e, t) {
                return t.toLowerCase()
            }
            var r, o = e(t).data(),
                a = {},
                s = new RegExp("^" + n.toLowerCase() + "([A-Z])");
            n = new RegExp("^" + n.toLowerCase());
            for (var u in o) n.test(u) && (r = u.replace(s, i), a[r] = o[u]);
            return a
        }

        function a(t) {
            var n = {};
            if (p[t] || (t = t.split("-")[0], p[t])) {
                var i = p[t];
                return e.each(f, function(e, t) {
                    t in i && (n[t] = i[t])
                }), n
            }
        }
        var s = e(window),
            u = function() {
                var t = {
                    get: function(e) {
                        return this.slice(e)[0]
                    },
                    contains: function(e) {
                        for (var t = e && e.valueOf(), n = 0, i = this.length; i > n; n++)
                            if (this[n].valueOf() === t) return n;
                        return -1
                    },
                    remove: function(e) {
                        this.splice(e, 1)
                    },
                    replace: function(t) {
                        t && (e.isArray(t) || (t = [t]), this.clear(), this.push.apply(this, t))
                    },
                    clear: function() {
                        this.splice(0)
                    },
                    copy: function() {
                        var e = new u;
                        return e.replace(this), e
                    }
                };
                return function() {
                    var n = [];
                    return n.push.apply(n, arguments), e.extend(n, t), n
                }
            }(),
            c = function(t, n) {
                this.dates = new u, this.viewDate = i(), this.focusDate = null, this._process_options(n), this.element = e(t), this.isInline = !1, this.isInput = this.element.is("input"), this.component = this.element.is(".date") ? this.element.find(".add-on, .input-group-addon, .btn") : !1, this.hasInput = this.component && this.element.find("input").length, this.component && 0 === this.component.length && (this.component = !1), this.picker = e(g.template), this._buildEvents(), this._attachEvents(), this.isInline ? this.picker.addClass("datepicker-inline").appendTo(this.element) : this.picker.addClass("datepicker-dropdown dropdown-menu"), this.o.rtl && this.picker.addClass("datepicker-rtl"), this.viewMode = this.o.startView, this.o.calendarWeeks && this.picker.find("tfoot th.today").attr("colspan", function(e, t) {
                    return parseInt(t) + 1
                }), this._allow_update = !1, this.setStartDate(this._o.startDate), this.setEndDate(this._o.endDate), this.setDaysOfWeekDisabled(this.o.daysOfWeekDisabled), this.fillDow(), this.fillMonths(), this._allow_update = !0, this.update(), this.showMode(), this.isInline && this.show()
            };
        c.prototype = {
            constructor: c,
            _process_options: function(t) {
                this._o = e.extend({}, this._o, t);
                var n = this.o = e.extend({}, this._o),
                    i = n.language;
                switch (p[i] || (i = i.split("-")[0], p[i] || (i = h.language)), n.language = i, n.startView) {
                    case 2:
                    case "decade":
                        n.startView = 2;
                        break;
                    case 1:
                    case "year":
                        n.startView = 1;
                        break;
                    default:
                        n.startView = 0
                }
                switch (n.minViewMode) {
                    case 1:
                    case "months":
                        n.minViewMode = 1;
                        break;
                    case 2:
                    case "years":
                        n.minViewMode = 2;
                        break;
                    default:
                        n.minViewMode = 0
                }
                n.startView = Math.max(n.startView, n.minViewMode), n.multidate !== !0 && (n.multidate = Number(n.multidate) || !1, n.multidate !== !1 ? n.multidate = Math.max(0, n.multidate) : n.multidate = 1), n.multidateSeparator = String(n.multidateSeparator), n.weekStart %= 7, n.weekEnd = (n.weekStart + 6) % 7;
                var r = g.parseFormat(n.format);
                n.startDate !== -(1 / 0) && (n.startDate ? n.startDate instanceof Date ? n.startDate = this._local_to_utc(this._zero_time(n.startDate)) : n.startDate = g.parseDate(n.startDate, r, n.language) : n.startDate = -(1 / 0)), n.endDate !== 1 / 0 && (n.endDate ? n.endDate instanceof Date ? n.endDate = this._local_to_utc(this._zero_time(n.endDate)) : n.endDate = g.parseDate(n.endDate, r, n.language) : n.endDate = 1 / 0), n.daysOfWeekDisabled = n.daysOfWeekDisabled || [], e.isArray(n.daysOfWeekDisabled) || (n.daysOfWeekDisabled = n.daysOfWeekDisabled.split(/[,\s]*/)), n.daysOfWeekDisabled = e.map(n.daysOfWeekDisabled, function(e) {
                    return parseInt(e, 10)
                });
                var o = String(n.orientation).toLowerCase().split(/\s+/g),
                    a = n.orientation.toLowerCase();
                if (o = e.grep(o, function(e) {
                        return /^auto|left|right|top|bottom$/.test(e)
                    }), n.orientation = {
                        x: "auto",
                        y: "auto"
                    }, a && "auto" !== a)
                    if (1 === o.length) switch (o[0]) {
                        case "top":
                        case "bottom":
                            n.orientation.y = o[0];
                            break;
                        case "left":
                        case "right":
                            n.orientation.x = o[0]
                    } else a = e.grep(o, function(e) {
                        return /^left|right$/.test(e)
                    }), n.orientation.x = a[0] || "auto", a = e.grep(o, function(e) {
                        return /^top|bottom$/.test(e)
                    }), n.orientation.y = a[0] || "auto";
                    else;
            },
            _events: [],
            _secondaryEvents: [],
            _applyEvents: function(e) {
                for (var n, i, r, o = 0; o < e.length; o++) n = e[o][0], 2 === e[o].length ? (i = t, r = e[o][1]) : 3 === e[o].length && (i = e[o][1], r = e[o][2]), n.on(r, i)
            },
            _unapplyEvents: function(e) {
                for (var n, i, r, o = 0; o < e.length; o++) n = e[o][0], 2 === e[o].length ? (r = t, i = e[o][1]) : 3 === e[o].length && (r = e[o][1], i = e[o][2]), n.off(i, r)
            },
            _buildEvents: function() {
                this.isInput ? this._events = [
                    [this.element, {
                        focus: e.proxy(this.show, this),
                        keyup: e.proxy(function(t) {
                            -1 === e.inArray(t.keyCode, [27, 37, 39, 38, 40, 32, 13, 9]) && this.update()
                        }, this),
                        keydown: e.proxy(this.keydown, this)
                    }]
                ] : this.component && this.hasInput ? this._events = [
                    [this.element.find("input"), {
                        focus: e.proxy(this.show, this),
                        keyup: e.proxy(function(t) {
                            -1 === e.inArray(t.keyCode, [27, 37, 39, 38, 40, 32, 13, 9]) && this.update()
                        }, this),
                        keydown: e.proxy(this.keydown, this)
                    }],
                    [this.component, {
                        click: e.proxy(this.show, this)
                    }]
                ] : this.element.is("div") ? this.isInline = !0 : this._events = [
                    [this.element, {
                        click: e.proxy(this.show, this)
                    }]
                ], this._events.push([this.element, "*", {
                    blur: e.proxy(function(e) {
                        this._focused_from = e.target
                    }, this)
                }], [this.element, {
                    blur: e.proxy(function(e) {
                        this._focused_from = e.target
                    }, this)
                }]), this._secondaryEvents = [
                    [this.picker, {
                        click: e.proxy(this.click, this)
                    }],
                    [e(window), {
                        resize: e.proxy(this.place, this)
                    }],
                    [e(document), {
                        "mousedown touchstart": e.proxy(function(e) {
                            this.element.is(e.target) || this.element.find(e.target).length || this.picker.is(e.target) || this.picker.find(e.target).length || this.hide()
                        }, this)
                    }]
                ]
            },
            _attachEvents: function() {
                this._detachEvents(), this._applyEvents(this._events)
            },
            _detachEvents: function() {
                this._unapplyEvents(this._events)
            },
            _attachSecondaryEvents: function() {
                this._detachSecondaryEvents(), this._applyEvents(this._secondaryEvents)
            },
            _detachSecondaryEvents: function() {
                this._unapplyEvents(this._secondaryEvents)
            },
            _trigger: function(t, n) {
                var i = n || this.dates.get(-1),
                    r = this._utc_to_local(i);
                this.element.trigger({
                    type: t,
                    date: r,
                    dates: e.map(this.dates, this._utc_to_local),
                    format: e.proxy(function(e, t) {
                        0 === arguments.length ? (e = this.dates.length - 1, t = this.o.format) : "string" == typeof e && (t = e, e = this.dates.length - 1), t = t || this.o.format;
                        var n = this.dates.get(e);
                        return g.formatDate(n, t, this.o.language)
                    }, this)
                })
            },
            show: function() {
                this.isInline || this.picker.appendTo("body"), this.picker.show(), this.place(), this._attachSecondaryEvents(), this._trigger("show")
            },
            hide: function() {
                this.isInline || this.picker.is(":visible") && (this.focusDate = null, this.picker.hide().detach(), this._detachSecondaryEvents(), this.viewMode = this.o.startView, this.showMode(), this.o.forceParse && (this.isInput && this.element.val() || this.hasInput && this.element.find("input").val()) && this.setValue(), this._trigger("hide"))
            },
            remove: function() {
                this.hide(), this._detachEvents(), this._detachSecondaryEvents(), this.picker.remove(), delete this.element.data().datepicker, this.isInput || delete this.element.data().date
            },
            _utc_to_local: function(e) {
                return e && new Date(e.getTime() + 6e4 * e.getTimezoneOffset())
            },
            _local_to_utc: function(e) {
                return e && new Date(e.getTime() - 6e4 * e.getTimezoneOffset())
            },
            _zero_time: function(e) {
                return e && new Date(e.getFullYear(), e.getMonth(), e.getDate())
            },
            _zero_utc_time: function(e) {
                return e && new Date(Date.UTC(e.getUTCFullYear(), e.getUTCMonth(), e.getUTCDate()))
            },
            getDates: function() {
                return e.map(this.dates, this._utc_to_local)
            },
            getUTCDates: function() {
                return e.map(this.dates, function(e) {
                    return new Date(e)
                })
            },
            getDate: function() {
                return this._utc_to_local(this.getUTCDate())
            },
            getUTCDate: function() {
                return new Date(this.dates.get(-1))
            },
            setDates: function() {
                var t = e.isArray(arguments[0]) ? arguments[0] : arguments;
                this.update.apply(this, t), this._trigger("changeDate"), this.setValue()
            },
            setUTCDates: function() {
                var t = e.isArray(arguments[0]) ? arguments[0] : arguments;
                this.update.apply(this, e.map(t, this._utc_to_local)), this._trigger("changeDate"), this.setValue()
            },
            setDate: r("setDates"),
            setUTCDate: r("setUTCDates"),
            setValue: function() {
                var e = this.getFormattedDate();
                this.isInput ? this.element.val(e).change() : this.component && this.element.find("input").val(e).change()
            },
            getFormattedDate: function(n) {
                n === t && (n = this.o.format);
                var i = this.o.language;
                return e.map(this.dates, function(e) {
                    return g.formatDate(e, n, i)
                }).join(this.o.multidateSeparator)
            },
            setStartDate: function(e) {
                this._process_options({
                    startDate: e
                }), this.update(), this.updateNavArrows()
            },
            setEndDate: function(e) {
                this._process_options({
                    endDate: e
                }), this.update(), this.updateNavArrows()
            },
            setDaysOfWeekDisabled: function(e) {
                this._process_options({
                    daysOfWeekDisabled: e
                }), this.update(), this.updateNavArrows()
            },
            place: function() {
                if (!this.isInline) {
                    var t = this.picker.outerWidth(),
                        n = this.picker.outerHeight(),
                        i = 10,
                        r = s.width(),
                        o = s.height(),
                        a = s.scrollTop(),
                        u = parseInt(this.element.parents().filter(function() {
                            return "auto" !== e(this).css("z-index")
                        }).first().css("z-index")) + 10,
                        c = this.component ? this.component.parent().offset() : this.element.offset(),
                        l = this.component ? this.component.outerHeight(!0) : this.element.outerHeight(!1),
                        d = this.component ? this.component.outerWidth(!0) : this.element.outerWidth(!1),
                        h = c.left,
                        f = c.top;
                    this.picker.removeClass("datepicker-orient-top datepicker-orient-bottom datepicker-orient-right datepicker-orient-left"), "auto" !== this.o.orientation.x ? (this.picker.addClass("datepicker-orient-" + this.o.orientation.x), "right" === this.o.orientation.x && (h -= t - d)) : (this.picker.addClass("datepicker-orient-left"), c.left < 0 ? h -= c.left - i : c.left + t > r && (h = r - t - i));
                    var p, g, m = this.o.orientation.y;
                    "auto" === m && (p = -a + c.top - n, g = a + o - (c.top + l + n), m = Math.max(p, g) === g ? "top" : "bottom"), this.picker.addClass("datepicker-orient-" + m), "top" === m ? f += l : f -= n + parseInt(this.picker.css("padding-top")), this.picker.css({
                        top: f,
                        left: h,
                        zIndex: u
                    })
                }
            },
            _allow_update: !0,
            update: function() {
                if (this._allow_update) {
                    var t = this.dates.copy(),
                        n = [],
                        i = !1;
                    arguments.length ? (e.each(arguments, e.proxy(function(e, t) {
                        t instanceof Date && (t = this._local_to_utc(t)), n.push(t)
                    }, this)), i = !0) : (n = this.isInput ? this.element.val() : this.element.data("date") || this.element.find("input").val(), n = n && this.o.multidate ? n.split(this.o.multidateSeparator) : [n], delete this.element.data().date), n = e.map(n, e.proxy(function(e) {
                        return g.parseDate(e, this.o.format, this.o.language)
                    }, this)), n = e.grep(n, e.proxy(function(e) {
                        return e < this.o.startDate || e > this.o.endDate || !e
                    }, this), !0), this.dates.replace(n), this.dates.length ? this.viewDate = new Date(this.dates.get(-1)) : this.viewDate < this.o.startDate ? this.viewDate = new Date(this.o.startDate) : this.viewDate > this.o.endDate && (this.viewDate = new Date(this.o.endDate)), i ? this.setValue() : n.length && String(t) !== String(this.dates) && this._trigger("changeDate"), !this.dates.length && t.length && this._trigger("clearDate"), this.fill()
                }
            },
            fillDow: function() {
                var e = this.o.weekStart,
                    t = "<tr>";
                if (this.o.calendarWeeks) {
                    var n = '<th class="cw">&nbsp;</th>';
                    t += n, this.picker.find(".datepicker-days thead tr:first-child").prepend(n)
                }
                for (; e < this.o.weekStart + 7;) t += '<th class="dow">' + p[this.o.language].daysMin[e++ % 7] + "</th>";
                t += "</tr>", this.picker.find(".datepicker-days thead").append(t)
            },
            fillMonths: function() {
                for (var e = "", t = 0; 12 > t;) e += '<span class="month">' + p[this.o.language].monthsShort[t++] + "</span>";
                this.picker.find(".datepicker-months td").html(e)
            },
            setRange: function(t) {
                t && t.length ? this.range = e.map(t, function(e) {
                    return e.valueOf()
                }) : delete this.range, this.fill()
            },
            getClassNames: function(t) {
                var n = [],
                    i = this.viewDate.getUTCFullYear(),
                    r = this.viewDate.getUTCMonth(),
                    o = new Date;
                return t.getUTCFullYear() < i || t.getUTCFullYear() === i && t.getUTCMonth() < r ? n.push("old") : (t.getUTCFullYear() > i || t.getUTCFullYear() === i && t.getUTCMonth() > r) && n.push("new"), this.focusDate && t.valueOf() === this.focusDate.valueOf() && n.push("focused"), this.o.todayHighlight && t.getUTCFullYear() === o.getFullYear() && t.getUTCMonth() === o.getMonth() && t.getUTCDate() === o.getDate() && n.push("today"), -1 !== this.dates.contains(t) && n.push("active"), (t.valueOf() < this.o.startDate || t.valueOf() > this.o.endDate || -1 !== e.inArray(t.getUTCDay(), this.o.daysOfWeekDisabled)) && n.push("disabled"), this.range && (t > this.range[0] && t < this.range[this.range.length - 1] && n.push("range"), -1 !== e.inArray(t.valueOf(), this.range) && n.push("selected")), n
            },
            fill: function() {
                var i, r = new Date(this.viewDate),
                    o = r.getUTCFullYear(),
                    a = r.getUTCMonth(),
                    s = this.o.startDate !== -(1 / 0) ? this.o.startDate.getUTCFullYear() : -(1 / 0),
                    u = this.o.startDate !== -(1 / 0) ? this.o.startDate.getUTCMonth() : -(1 / 0),
                    c = this.o.endDate !== 1 / 0 ? this.o.endDate.getUTCFullYear() : 1 / 0,
                    l = this.o.endDate !== 1 / 0 ? this.o.endDate.getUTCMonth() : 1 / 0,
                    d = p[this.o.language].today || p.en.today || "",
                    h = p[this.o.language].clear || p.en.clear || "";
                this.picker.find(".datepicker-days thead th.datepicker-switch").text(p[this.o.language].months[a] + " " + o), this.picker.find("tfoot th.today").text(d).toggle(this.o.todayBtn !== !1), this.picker.find("tfoot th.clear").text(h).toggle(this.o.clearBtn !== !1), this.updateNavArrows(), this.fillMonths();
                var f = n(o, a - 1, 28),
                    m = g.getDaysInMonth(f.getUTCFullYear(), f.getUTCMonth());
                f.setUTCDate(m), f.setUTCDate(m - (f.getUTCDay() - this.o.weekStart + 7) % 7);
                var v = new Date(f);
                v.setUTCDate(v.getUTCDate() + 42), v = v.valueOf();
                for (var y, b = []; f.valueOf() < v;) {
                    if (f.getUTCDay() === this.o.weekStart && (b.push("<tr>"), this.o.calendarWeeks)) {
                        var w = new Date(+f + (this.o.weekStart - f.getUTCDay() - 7) % 7 * 864e5),
                            _ = new Date(Number(w) + (11 - w.getUTCDay()) % 7 * 864e5),
                            C = new Date(Number(C = n(_.getUTCFullYear(), 0, 1)) + (11 - C.getUTCDay()) % 7 * 864e5),
                            k = (_ - C) / 864e5 / 7 + 1;
                        b.push('<td class="cw">' + k + "</td>")
                    }
                    if (y = this.getClassNames(f), y.push("day"), this.o.beforeShowDay !== e.noop) {
                        var E = this.o.beforeShowDay(this._utc_to_local(f));
                        E === t ? E = {} : "boolean" == typeof E ? E = {
                            enabled: E
                        } : "string" == typeof E && (E = {
                            classes: E
                        }), E.enabled === !1 && y.push("disabled"), E.classes && (y = y.concat(E.classes.split(/\s+/))), E.tooltip && (i = E.tooltip)
                    }
                    y = e.unique(y), b.push('<td class="' + y.join(" ") + '"' + (i ? ' title="' + i + '"' : "") + ">" + f.getUTCDate() + "</td>"), f.getUTCDay() === this.o.weekEnd && b.push("</tr>"), f.setUTCDate(f.getUTCDate() + 1)
                }
                this.picker.find(".datepicker-days tbody").empty().append(b.join(""));
                var S = this.picker.find(".datepicker-months").find("th:eq(1)").text(o).end().find("span").removeClass("active");
                e.each(this.dates, function(e, t) {
                    t.getUTCFullYear() === o && S.eq(t.getUTCMonth()).addClass("active")
                }), (s > o || o > c) && S.addClass("disabled"), o === s && S.slice(0, u).addClass("disabled"), o === c && S.slice(l + 1).addClass("disabled"), b = "", o = 10 * parseInt(o / 10, 10);
                var x = this.picker.find(".datepicker-years").find("th:eq(1)").text(o + "-" + (o + 9)).end().find("td");
                o -= 1;
                for (var T, B = e.map(this.dates, function(e) {
                        return e.getUTCFullYear()
                    }), P = -1; 11 > P; P++) T = ["year"], -1 === P ? T.push("old") : 10 === P && T.push("new"), -1 !== e.inArray(o, B) && T.push("active"), (s > o || o > c) && T.push("disabled"), b += '<span class="' + T.join(" ") + '">' + o + "</span>", o += 1;
                x.html(b)
            },
            updateNavArrows: function() {
                if (this._allow_update) {
                    var e = new Date(this.viewDate),
                        t = e.getUTCFullYear(),
                        n = e.getUTCMonth();
                    switch (this.viewMode) {
                        case 0:
                            this.o.startDate !== -(1 / 0) && t <= this.o.startDate.getUTCFullYear() && n <= this.o.startDate.getUTCMonth() ? this.picker.find(".prev").css({
                                visibility: "hidden"
                            }) : this.picker.find(".prev").css({
                                visibility: "visible"
                            }), this.o.endDate !== 1 / 0 && t >= this.o.endDate.getUTCFullYear() && n >= this.o.endDate.getUTCMonth() ? this.picker.find(".next").css({
                                visibility: "hidden"
                            }) : this.picker.find(".next").css({
                                visibility: "visible"
                            });
                            break;
                        case 1:
                        case 2:
                            this.o.startDate !== -(1 / 0) && t <= this.o.startDate.getUTCFullYear() ? this.picker.find(".prev").css({
                                visibility: "hidden"
                            }) : this.picker.find(".prev").css({
                                visibility: "visible"
                            }), this.o.endDate !== 1 / 0 && t >= this.o.endDate.getUTCFullYear() ? this.picker.find(".next").css({
                                visibility: "hidden"
                            }) : this.picker.find(".next").css({
                                visibility: "visible"
                            })
                    }
                }
            },
            click: function(t) {
                t.preventDefault();
                var i, r, o, a = e(t.target).closest("span, td, th");
                if (1 === a.length) switch (a[0].nodeName.toLowerCase()) {
                    case "th":
                        switch (a[0].className) {
                            case "datepicker-switch":
                                this.showMode(1);
                                break;
                            case "prev":
                            case "next":
                                var s = g.modes[this.viewMode].navStep * ("prev" === a[0].className ? -1 : 1);
                                switch (this.viewMode) {
                                    case 0:
                                        this.viewDate = this.moveMonth(this.viewDate, s), this._trigger("changeMonth", this.viewDate);
                                        break;
                                    case 1:
                                    case 2:
                                        this.viewDate = this.moveYear(this.viewDate, s), 1 === this.viewMode && this._trigger("changeYear", this.viewDate)
                                }
                                this.fill();
                                break;
                            case "today":
                                var u = new Date;
                                u = n(u.getFullYear(), u.getMonth(), u.getDate(), 0, 0, 0), this.showMode(-2);
                                var c = "linked" === this.o.todayBtn ? null : "view";
                                this._setDate(u, c);
                                break;
                            case "clear":
                                var l;
                                this.isInput ? l = this.element : this.component && (l = this.element.find("input")), l && l.val("").change(), this.update(), this._trigger("changeDate"), this.o.autoclose && this.hide()
                        }
                        break;
                    case "span":
                        a.is(".disabled") || (this.viewDate.setUTCDate(1), a.is(".month") ? (o = 1, r = a.parent().find("span").index(a), i = this.viewDate.getUTCFullYear(), this.viewDate.setUTCMonth(r), this._trigger("changeMonth", this.viewDate), 1 === this.o.minViewMode && this._setDate(n(i, r, o))) : (o = 1, r = 0, i = parseInt(a.text(), 10) || 0, this.viewDate.setUTCFullYear(i), this._trigger("changeYear", this.viewDate), 2 === this.o.minViewMode && this._setDate(n(i, r, o))), this.showMode(-1), this.fill());
                        break;
                    case "td":
                        a.is(".day") && !a.is(".disabled") && (o = parseInt(a.text(), 10) || 1, i = this.viewDate.getUTCFullYear(), r = this.viewDate.getUTCMonth(), a.is(".old") ? 0 === r ? (r = 11, i -= 1) : r -= 1 : a.is(".new") && (11 === r ? (r = 0, i += 1) : r += 1), this._setDate(n(i, r, o)))
                }
                this.picker.is(":visible") && this._focused_from && e(this._focused_from).focus(), delete this._focused_from
            },
            _toggle_multidate: function(e) {
                var t = this.dates.contains(e);
                if (e ? -1 !== t ? this.dates.remove(t) : this.dates.push(e) : this.dates.clear(), "number" == typeof this.o.multidate)
                    for (; this.dates.length > this.o.multidate;) this.dates.remove(0)
            },
            _setDate: function(e, t) {
                t && "date" !== t || this._toggle_multidate(e && new Date(e)), t && "view" !== t || (this.viewDate = e && new Date(e)), this.fill(), this.setValue(), this._trigger("changeDate");
                var n;
                this.isInput ? n = this.element : this.component && (n = this.element.find("input")), n && n.change(), !this.o.autoclose || t && "date" !== t || this.hide()
            },
            moveMonth: function(e, n) {
                if (!e) return t;
                if (!n) return e;
                var i, r, o = new Date(e.valueOf()),
                    a = o.getUTCDate(),
                    s = o.getUTCMonth(),
                    u = Math.abs(n);
                if (n = n > 0 ? 1 : -1, 1 === u) r = -1 === n ? function() {
                    return o.getUTCMonth() === s
                } : function() {
                    return o.getUTCMonth() !== i
                }, i = s + n, o.setUTCMonth(i), (0 > i || i > 11) && (i = (i + 12) % 12);
                else {
                    for (var c = 0; u > c; c++) o = this.moveMonth(o, n);
                    i = o.getUTCMonth(), o.setUTCDate(a), r = function() {
                        return i !== o.getUTCMonth()
                    }
                }
                for (; r();) o.setUTCDate(--a), o.setUTCMonth(i);
                return o
            },
            moveYear: function(e, t) {
                return this.moveMonth(e, 12 * t)
            },
            dateWithinRange: function(e) {
                return e >= this.o.startDate && e <= this.o.endDate
            },
            keydown: function(e) {
                if (this.picker.is(":not(:visible)")) return void(27 === e.keyCode && this.show());
                var t, n, r, o = !1,
                    a = this.focusDate || this.viewDate;
                switch (e.keyCode) {
                    case 27:
                        this.focusDate ? (this.focusDate = null, this.viewDate = this.dates.get(-1) || this.viewDate, this.fill()) : this.hide(), e.preventDefault();
                        break;
                    case 37:
                    case 39:
                        if (!this.o.keyboardNavigation) break;
                        t = 37 === e.keyCode ? -1 : 1, e.ctrlKey ? (n = this.moveYear(this.dates.get(-1) || i(), t), r = this.moveYear(a, t), this._trigger("changeYear", this.viewDate)) : e.shiftKey ? (n = this.moveMonth(this.dates.get(-1) || i(), t), r = this.moveMonth(a, t), this._trigger("changeMonth", this.viewDate)) : (n = new Date(this.dates.get(-1) || i()), n.setUTCDate(n.getUTCDate() + t), r = new Date(a), r.setUTCDate(a.getUTCDate() + t)), this.dateWithinRange(n) && (this.focusDate = this.viewDate = r, this.setValue(), this.fill(), e.preventDefault());
                        break;
                    case 38:
                    case 40:
                        if (!this.o.keyboardNavigation) break;
                        t = 38 === e.keyCode ? -1 : 1, e.ctrlKey ? (n = this.moveYear(this.dates.get(-1) || i(), t), r = this.moveYear(a, t), this._trigger("changeYear", this.viewDate)) : e.shiftKey ? (n = this.moveMonth(this.dates.get(-1) || i(), t), r = this.moveMonth(a, t), this._trigger("changeMonth", this.viewDate)) : (n = new Date(this.dates.get(-1) || i()), n.setUTCDate(n.getUTCDate() + 7 * t), r = new Date(a), r.setUTCDate(a.getUTCDate() + 7 * t)), this.dateWithinRange(n) && (this.focusDate = this.viewDate = r, this.setValue(), this.fill(), e.preventDefault());
                        break;
                    case 32:
                        break;
                    case 13:
                        a = this.focusDate || this.dates.get(-1) || this.viewDate, this._toggle_multidate(a), o = !0, this.focusDate = null, this.viewDate = this.dates.get(-1) || this.viewDate, this.setValue(), this.fill(), this.picker.is(":visible") && (e.preventDefault(), this.o.autoclose && this.hide());
                        break;
                    case 9:
                        this.focusDate = null, this.viewDate = this.dates.get(-1) || this.viewDate, this.fill(), this.hide()
                }
                if (o) {
                    this.dates.length ? this._trigger("changeDate") : this._trigger("clearDate");
                    var s;
                    this.isInput ? s = this.element : this.component && (s = this.element.find("input")), s && s.change()
                }
            },
            showMode: function(e) {
                e && (this.viewMode = Math.max(this.o.minViewMode, Math.min(2, this.viewMode + e))), this.picker.find(">div").hide().filter(".datepicker-" + g.modes[this.viewMode].clsName).css("display", "block"), this.updateNavArrows()
            }
        };
        var l = function(t, n) {
            this.element = e(t), this.inputs = e.map(n.inputs, function(e) {
                return e.jquery ? e[0] : e
            }), delete n.inputs, e(this.inputs).datepicker(n).bind("changeDate", e.proxy(this.dateUpdated, this)), this.pickers = e.map(this.inputs, function(t) {
                return e(t).data("datepicker")
            }), this.updateDates()
        };
        l.prototype = {
            updateDates: function() {
                this.dates = e.map(this.pickers, function(e) {
                    return e.getUTCDate()
                }), this.updateRanges()
            },
            updateRanges: function() {
                var t = e.map(this.dates, function(e) {
                    return e.valueOf()
                });
                e.each(this.pickers, function(e, n) {
                    n.setRange(t)
                })
            },
            dateUpdated: function(t) {
                if (!this.updating) {
                    this.updating = !0;
                    var n = e(t.target).data("datepicker"),
                        i = n.getUTCDate(),
                        r = e.inArray(t.target, this.inputs),
                        o = this.inputs.length;
                    if (-1 !== r) {
                        if (e.each(this.pickers, function(e, t) {
                                t.getUTCDate() || t.setUTCDate(i)
                            }), i < this.dates[r])
                            for (; r >= 0 && i < this.dates[r];) this.pickers[r--].setUTCDate(i);
                        else if (i > this.dates[r])
                            for (; o > r && i > this.dates[r];) this.pickers[r++].setUTCDate(i);
                        this.updateDates(), delete this.updating
                    }
                }
            },
            remove: function() {
                e.map(this.pickers, function(e) {
                    e.remove()
                }), delete this.element.data().datepicker
            }
        };
        var d = e.fn.datepicker;
        e.fn.datepicker = function(n) {
            var i = Array.apply(null, arguments);
            i.shift();
            var r;
            return this.each(function() {
                var s = e(this),
                    u = s.data("datepicker"),
                    d = "object" == typeof n && n;
                if (!u) {
                    var f = o(this, "date"),
                        p = e.extend({}, h, f, d),
                        g = a(p.language),
                        m = e.extend({}, h, g, f, d);
                    if (s.is(".input-daterange") || m.inputs) {
                        var v = {
                            inputs: m.inputs || s.find("input").toArray()
                        };
                        s.data("datepicker", u = new l(this, e.extend(m, v)))
                    } else s.data("datepicker", u = new c(this, m))
                }
                return "string" == typeof n && "function" == typeof u[n] && (r = u[n].apply(u, i), r !== t) ? !1 : void 0
            }), r !== t ? r : this
        };
        var h = e.fn.datepicker.defaults = {
                autoclose: !1,
                beforeShowDay: e.noop,
                calendarWeeks: !1,
                clearBtn: !1,
                daysOfWeekDisabled: [],
                endDate: 1 / 0,
                forceParse: !0,
                format: "mm/dd/yyyy",
                keyboardNavigation: !0,
                language: "en",
                minViewMode: 0,
                multidate: !1,
                multidateSeparator: ",",
                orientation: "auto",
                rtl: !1,
                startDate: -(1 / 0),
                startView: 0,
                todayBtn: !1,
                todayHighlight: !1,
                weekStart: 0
            },
            f = e.fn.datepicker.locale_opts = ["format", "rtl", "weekStart"];
        e.fn.datepicker.Constructor = c;
        var p = e.fn.datepicker.dates = {
                en: {
                    days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
                    daysShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
                    daysMin: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"],
                    months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                    monthsShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                    today: "Today",
                    clear: "Clear"
                }
            },
            g = {
                modes: [{
                    clsName: "days",
                    navFnc: "Month",
                    navStep: 1
                }, {
                    clsName: "months",
                    navFnc: "FullYear",
                    navStep: 1
                }, {
                    clsName: "years",
                    navFnc: "FullYear",
                    navStep: 10
                }],
                isLeapYear: function(e) {
                    return e % 4 === 0 && e % 100 !== 0 || e % 400 === 0
                },
                getDaysInMonth: function(e, t) {
                    return [31, g.isLeapYear(e) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][t]
                },
                validParts: /dd?|DD?|mm?|MM?|yy(?:yy)?/g,
                nonpunctuation: /[^ -\/:-@\[\u3400-\u9fff-`{-~\t\n\r]+/g,
                parseFormat: function(e) {
                    var t = e.replace(this.validParts, "\x00").split("\x00"),
                        n = e.match(this.validParts);
                    if (!t || !t.length || !n || 0 === n.length) throw new Error("Invalid date format.");
                    return {
                        separators: t,
                        parts: n
                    }
                },
                parseDate: function(i, r, o) {
                    function a() {
                        var e = this.slice(0, h[l].length),
                            t = h[l].slice(0, e.length);
                        return e === t
                    }
                    if (!i) return t;
                    if (i instanceof Date) return i;
                    "string" == typeof r && (r = g.parseFormat(r));
                    var s, u, l, d = /([\-+]\d+)([dmwy])/,
                        h = i.match(/([\-+]\d+)([dmwy])/g);
                    if (/^[\-+]\d+[dmwy]([\s,]+[\-+]\d+[dmwy])*$/.test(i)) {
                        for (i = new Date, l = 0; l < h.length; l++) switch (s = d.exec(h[l]), u = parseInt(s[1]), s[2]) {
                            case "d":
                                i.setUTCDate(i.getUTCDate() + u);
                                break;
                            case "m":
                                i = c.prototype.moveMonth.call(c.prototype, i, u);
                                break;
                            case "w":
                                i.setUTCDate(i.getUTCDate() + 7 * u);
                                break;
                            case "y":
                                i = c.prototype.moveYear.call(c.prototype, i, u)
                        }
                        return n(i.getUTCFullYear(), i.getUTCMonth(), i.getUTCDate(), 0, 0, 0)
                    }
                    h = i && i.match(this.nonpunctuation) || [], i = new Date;
                    var f, m, v = {},
                        y = ["yyyy", "yy", "M", "MM", "m", "mm", "d", "dd"],
                        b = {
                            yyyy: function(e, t) {
                                return e.setUTCFullYear(t)
                            },
                            yy: function(e, t) {
                                return e.setUTCFullYear(2e3 + t)
                            },
                            m: function(e, t) {
                                if (isNaN(e)) return e;
                                for (t -= 1; 0 > t;) t += 12;
                                for (t %= 12, e.setUTCMonth(t); e.getUTCMonth() !== t;) e.setUTCDate(e.getUTCDate() - 1);
                                return e
                            },
                            d: function(e, t) {
                                return e.setUTCDate(t)
                            }
                        };
                    b.M = b.MM = b.mm = b.m, b.dd = b.d, i = n(i.getFullYear(), i.getMonth(), i.getDate(), 0, 0, 0);
                    var w = r.parts.slice();
                    if (h.length !== w.length && (w = e(w).filter(function(t, n) {
                            return -1 !== e.inArray(n, y)
                        }).toArray()), h.length === w.length) {
                        var _;
                        for (l = 0, _ = w.length; _ > l; l++) {
                            if (f = parseInt(h[l], 10), s = w[l], isNaN(f)) switch (s) {
                                case "MM":
                                    m = e(p[o].months).filter(a), f = e.inArray(m[0], p[o].months) + 1;
                                    break;
                                case "M":
                                    m = e(p[o].monthsShort).filter(a), f = e.inArray(m[0], p[o].monthsShort) + 1
                            }
                            v[s] = f
                        }
                        var C, k;
                        for (l = 0; l < y.length; l++) k = y[l], k in v && !isNaN(v[k]) && (C = new Date(i), b[k](C, v[k]), isNaN(C) || (i = C))
                    }
                    return i
                },
                formatDate: function(t, n, i) {
                    if (!t) return "";
                    "string" == typeof n && (n = g.parseFormat(n));
                    var r = {
                        d: t.getUTCDate(),
                        D: p[i].daysShort[t.getUTCDay()],
                        DD: p[i].days[t.getUTCDay()],
                        m: t.getUTCMonth() + 1,
                        M: p[i].monthsShort[t.getUTCMonth()],
                        MM: p[i].months[t.getUTCMonth()],
                        yy: t.getUTCFullYear().toString().substring(2),
                        yyyy: t.getUTCFullYear()
                    };
                    r.dd = (r.d < 10 ? "0" : "") + r.d, r.mm = (r.m < 10 ? "0" : "") + r.m, t = [];
                    for (var o = e.extend([], n.separators), a = 0, s = n.parts.length; s >= a; a++) o.length && t.push(o.shift()), t.push(r[n.parts[a]]);
                    return t.join("")
                },
                headTemplate: '<thead><tr><th class="prev">&laquo;</th><th colspan="5" class="datepicker-switch"></th><th class="next">&raquo;</th></tr></thead>',
                contTemplate: '<tbody><tr><td colspan="7"></td></tr></tbody>',
                footTemplate: '<tfoot><tr><th colspan="7" class="today"></th></tr><tr><th colspan="7" class="clear"></th></tr></tfoot>'
            };
        g.template = '<div class="datepicker"><div class="datepicker-days"><table class=" table-condensed">' + g.headTemplate + "<tbody></tbody>" + g.footTemplate + '</table></div><div class="datepicker-months"><table class="table-condensed">' + g.headTemplate + g.contTemplate + g.footTemplate + '</table></div><div class="datepicker-years"><table class="table-condensed">' + g.headTemplate + g.contTemplate + g.footTemplate + "</table></div></div>", e.fn.datepicker.DPGlobal = g, e.fn.datepicker.noConflict = function() {
            return e.fn.datepicker = d, this
        }, e(document).on("focus.datepicker.data-api click.datepicker.data-api", '[data-provide="datepicker"]', function(t) {
            var n = e(this);
            n.data("datepicker") || (t.preventDefault(), n.datepicker("show"))
        }), e(function() {
            e('[data-provide="datepicker-inline"]').datepicker()
        })
    }(window.jQuery), ! function(e) {
        "use strict";

        function t(e) {
            return function(t) {
                return t && this === t.target ? e.apply(this, arguments) : void 0
            }
        }
        var n = function(e, t) {
            this.init(e, t)
        };
        n.prototype = {
            constructor: n,
            init: function(t, n) {
                if (this.$element = e(t), this.options = e.extend({}, e.fn.modalmanager.defaults, this.$element.data(), "object" == typeof n && n), this.stack = [], this.backdropCount = 0, this.options.resize) {
                    var i, r = this;
                    e(window).on("resize.modal", function() {
                        i && clearTimeout(i), i = setTimeout(function() {
                            for (var e = 0; e < r.stack.length; e++) r.stack[e].isShown && r.stack[e].layout()
                        }, 10)
                    })
                }
            },
            createModal: function(t, n) {
                e(t).modal(e.extend({
                    manager: this
                }, n))
            },
            appendModal: function(n) {
                this.stack.push(n);
                var i = this;
                n.$element.on("show.modalmanager", t(function(t) {
                    var r = function() {
                        n.isShown = !0;
                        var t = e.support.transition && n.$element.hasClass("fade");
                        i.$element.toggleClass("modal-open", i.hasOpenModal()).toggleClass("page-overflow", e(window).height() < i.$element.height()), n.$parent = n.$element.parent(), n.$container = i.createContainer(n), n.$element.appendTo(n.$container), i.backdrop(n, function() {
                            n.$element.show(), t && n.$element[0].offsetWidth, n.layout(), n.$element.addClass("in").attr("aria-hidden", !1);
                            var r = function() {
                                i.setFocus(), n.$element.trigger("shown")
                            };
                            t ? n.$element.one(e.support.transition.end, r) : r()
                        })
                    };
                    n.options.replace ? i.replace(r) : r()
                })), n.$element.on("hidden.modalmanager", t(function(t) {
                    if (i.backdrop(n), n.$element.parent().length)
                        if (n.$backdrop) {
                            var r = e.support.transition && n.$element.hasClass("fade");
                            r && n.$element[0].offsetWidth, e.support.transition && n.$element.hasClass("fade") ? n.$backdrop.one(e.support.transition.end, function() {
                                n.destroy()
                            }) : n.destroy()
                        } else n.destroy();
                    else i.destroyModal(n)
                })), n.$element.on("destroyed.modalmanager", t(function(e) {
                    i.destroyModal(n)
                }))
            },
            getOpenModals: function() {
                for (var e = [], t = 0; t < this.stack.length; t++) this.stack[t].isShown && e.push(this.stack[t]);
                return e
            },
            hasOpenModal: function() {
                return this.getOpenModals().length > 0
            },
            setFocus: function() {
                for (var e, t = 0; t < this.stack.length; t++) this.stack[t].isShown && (e = this.stack[t]);
                e && e.focus()
            },
            destroyModal: function(e) {
                e.$element.off(".modalmanager"), e.$backdrop && this.removeBackdrop(e), this.stack.splice(this.getIndexOfModal(e), 1);
                var t = this.hasOpenModal();
                this.$element.toggleClass("modal-open", t), t || this.$element.removeClass("page-overflow"), this.removeContainer(e), this.setFocus()
            },
            getModalAt: function(e) {
                return this.stack[e]
            },
            getIndexOfModal: function(e) {
                for (var t = 0; t < this.stack.length; t++)
                    if (e === this.stack[t]) return t
            },
            replace: function(n) {
                for (var i, r = 0; r < this.stack.length; r++) this.stack[r].isShown && (i = this.stack[r]);
                i ? (this.$backdropHandle = i.$backdrop, i.$backdrop = null, n && i.$element.one("hidden", t(e.proxy(n, this))), i.hide()) : n && n()
            },
            removeBackdrop: function(e) {
                e.$backdrop.remove(), e.$backdrop = null
            },
            createBackdrop: function(t, n) {
                var i;
                return this.$backdropHandle ? (i = this.$backdropHandle, i.off(".modalmanager"), this.$backdropHandle = null, this.isLoading && this.removeSpinner()) : i = e(n).addClass(t).appendTo(this.$element), i
            },
            removeContainer: function(e) {
                e.$container.remove(), e.$container = null
            },
            createContainer: function(n) {
                var r;
                return r = e('<div class="modal-scrollable">').css("z-index", i("modal", this.getOpenModals().length)).appendTo(this.$element), n && "static" != n.options.backdrop ? r.on("click.modal", t(function(e) {
                    n.hide()
                })) : n && r.on("click.modal", t(function(e) {
                    n.attention()
                })), r
            },
            backdrop: function(t, n) {
                var r = t.$element.hasClass("fade") ? "fade" : "",
                    o = t.options.backdrop && this.backdropCount < this.options.backdropLimit;
                if (t.isShown && o) {
                    var a = e.support.transition && r && !this.$backdropHandle;
                    t.$backdrop = this.createBackdrop(r, t.options.backdropTemplate), t.$backdrop.css("z-index", i("backdrop", this.getOpenModals().length)), a && t.$backdrop[0].offsetWidth, t.$backdrop.addClass("in"), this.backdropCount += 1, a ? t.$backdrop.one(e.support.transition.end, n) : n()
                } else if (!t.isShown && t.$backdrop) {
                    t.$backdrop.removeClass("in"), this.backdropCount -= 1;
                    var s = this;
                    e.support.transition && t.$element.hasClass("fade") ? t.$backdrop.one(e.support.transition.end, function() {
                        s.removeBackdrop(t)
                    }) : s.removeBackdrop(t)
                } else n && n()
            },
            removeSpinner: function() {
                this.$spinner && this.$spinner.remove(), this.$spinner = null, this.isLoading = !1
            },
            removeLoading: function() {
                this.$backdropHandle && this.$backdropHandle.remove(), this.$backdropHandle = null, this.removeSpinner()
            },
            loading: function(t) {
                if (t = t || function() {}, this.$element.toggleClass("modal-open", !this.isLoading || this.hasOpenModal()).toggleClass("page-overflow", e(window).height() < this.$element.height()), this.isLoading)
                    if (this.isLoading && this.$backdropHandle) {
                        this.$backdropHandle.removeClass("in");
                        var n = this;
                        e.support.transition ? this.$backdropHandle.one(e.support.transition.end, function() {
                            n.removeLoading()
                        }) : n.removeLoading()
                    } else t && t(this.isLoading);
                else {
                    this.$backdropHandle = this.createBackdrop("fade", this.options.backdropTemplate), this.$backdropHandle[0].offsetWidth;
                    var r = this.getOpenModals();
                    this.$backdropHandle.css("z-index", i("backdrop", r.length + 1)).addClass("in");
                    var o = e(this.options.spinner).css("z-index", i("modal", r.length + 1)).appendTo(this.$element).addClass("in");
                    this.$spinner = e(this.createContainer()).append(o).on("click.modalmanager", e.proxy(this.loading, this)), this.isLoading = !0, e.support.transition ? this.$backdropHandle.one(e.support.transition.end, t) : t()
                }
            }
        };
        var i = function() {
            var t, n = {};
            return function(i, r) {
                if ("undefined" == typeof t) {
                    var o = e('<div class="modal hide" />').appendTo("body"),
                        a = e('<div class="modal-backdrop hide" />').appendTo("body");
                    n.modal = +o.css("z-index"), n.backdrop = +a.css("z-index"), t = n.modal - n.backdrop, o.remove(), a.remove(), a = o = null
                }
                return n[i] + t * r
            }
        }();
        e.fn.modalmanager = function(t, i) {
            return this.each(function() {
                var r = e(this),
                    o = r.data("modalmanager");
                o || r.data("modalmanager", o = new n(this, t)), "string" == typeof t && o[t].apply(o, [].concat(i))
            })
        }, e.fn.modalmanager.defaults = {
            backdropLimit: 999,
            resize: !0,
            spinner: '<div class="loading-spinner fade" style="width: 200px; margin-left: -100px;"><div class="progress progress-striped active"><div class="bar" style="width: 100%;"></div></div></div>',
            backdropTemplate: '<div class="modal-backdrop" />'
        }, e.fn.modalmanager.Constructor = n, e(function() {
            e(document).off("show.bs.modal").off("hidden.bs.modal")
        })
    }(jQuery), ! function(e) {
        "use strict";
        var t = function(e, t) {
            this.init(e, t)
        };
        t.prototype = {
            constructor: t,
            init: function(t, n) {
                var i = this;
                this.options = n, this.$element = e(t).delegate('[data-dismiss="modal"]', "click.dismiss.modal", e.proxy(this.hide, this)), this.options.remote && this.$element.find(".modal-body").load(this.options.remote, function() {
                    var t = e.Event("loaded");
                    i.$element.trigger(t)
                });
                var r = "function" == typeof this.options.manager ? this.options.manager.call(this) : this.options.manager;
                r = r.appendModal ? r : e(r).modalmanager().data("modalmanager"), r.appendModal(this)
            },
            toggle: function() {
                return this[this.isShown ? "hide" : "show"]()
            },
            show: function() {
                var t = e.Event("show");
                this.isShown || (this.$element.trigger(t), t.isDefaultPrevented() || (this.escape(), this.tab(), this.options.loading && this.loading()))
            },
            hide: function(t) {
                t && t.preventDefault(), t = e.Event("hide"), this.$element.trigger(t), this.isShown && !t.isDefaultPrevented() && (this.isShown = !1, this.escape(), this.tab(), this.isLoading && this.loading(), e(document).off("focusin.modal"), this.$element.removeClass("in").removeClass("animated").removeClass(this.options.attentionAnimation).removeClass("modal-overflow").attr("aria-hidden", !0), e.support.transition && this.$element.hasClass("fade") ? this.hideWithTransition() : this.hideModal())
            },
            layout: function() {
                var t = this.options.height ? "height" : "max-height",
                    n = this.options.height || this.options.maxHeight;
                if (this.options.width) {
                    this.$element.css("width", this.options.width);
                    var i = this;
                    this.$element.css("margin-left", function() {
                        return /%/gi.test(i.options.width) ? -(parseInt(i.options.width) / 2) + "%" : -(e(this).width() / 2) + "px"
                    })
                } else this.$element.css("width", ""), this.$element.css("margin-left", "");
                this.$element.find(".modal-body").css("overflow", "").css(t, ""), n && this.$element.find(".modal-body").css("overflow", "auto").css(t, n);
                var r = e(window).height() - 10 < this.$element.height();
                r || this.options.modalOverflow ? this.$element.css("margin-top", 0).addClass("modal-overflow") : this.$element.css("margin-top", 0 - this.$element.height() / 2).removeClass("modal-overflow");
            },
            tab: function() {
                var t = this;
                this.isShown && this.options.consumeTab ? this.$element.on("keydown.tabindex.modal", "[data-tabindex]", function(n) {
                    if (n.keyCode && 9 == n.keyCode) {
                        var i = e(this),
                            r = e(this);
                        t.$element.find("[data-tabindex]:enabled:not([readonly])").each(function(t) {
                            i = t.shiftKey ? i.data("tabindex") > e(this).data("tabindex") ? i = e(this) : r = e(this) : i.data("tabindex") < e(this).data("tabindex") ? i = e(this) : r = e(this)
                        }), i[0] !== e(this)[0] ? i.focus() : r.focus(), n.preventDefault()
                    }
                }) : this.isShown || this.$element.off("keydown.tabindex.modal")
            },
            escape: function() {
                var e = this;
                this.isShown && this.options.keyboard ? (this.$element.attr("tabindex") || this.$element.attr("tabindex", -1), this.$element.on("keyup.dismiss.modal", function(t) {
                    27 == t.which && e.hide()
                })) : this.isShown || this.$element.off("keyup.dismiss.modal")
            },
            hideWithTransition: function() {
                var t = this,
                    n = setTimeout(function() {
                        t.$element.off(e.support.transition.end), t.hideModal()
                    }, 500);
                this.$element.one(e.support.transition.end, function() {
                    clearTimeout(n), t.hideModal()
                })
            },
            hideModal: function() {
                var e = this.options.height ? "height" : "max-height",
                    t = this.options.height || this.options.maxHeight;
                t && this.$element.find(".modal-body").css("overflow", "").css(e, ""), this.$element.hide().trigger("hidden")
            },
            removeLoading: function() {
                this.$loading.remove(), this.$loading = null, this.isLoading = !1
            },
            loading: function(t) {
                t = t || function() {};
                var n = this.$element.hasClass("fade") ? "fade" : "";
                if (this.isLoading)
                    if (this.isLoading && this.$loading) {
                        this.$loading.removeClass("in");
                        var i = this;
                        e.support.transition && this.$element.hasClass("fade") ? this.$loading.one(e.support.transition.end, function() {
                            i.removeLoading()
                        }) : i.removeLoading()
                    } else t && t(this.isLoading);
                else {
                    var r = e.support.transition && n;
                    this.$loading = e('<div class="loading-mask ' + n + '">').append(this.options.spinner).appendTo(this.$element), r && this.$loading[0].offsetWidth, this.$loading.addClass("in"), this.isLoading = !0, r ? this.$loading.one(e.support.transition.end, t) : t()
                }
            },
            focus: function() {
                var e = this.$element.find(this.options.focusOn);
                e = e.length ? e : this.$element, e.focus()
            },
            attention: function() {
                if (this.options.attentionAnimation) {
                    this.$element.removeClass("animated").removeClass(this.options.attentionAnimation);
                    var e = this;
                    setTimeout(function() {
                        e.$element.addClass("animated").addClass(e.options.attentionAnimation)
                    }, 0)
                }
                this.focus()
            },
            destroy: function() {
                var t = e.Event("destroy");
                this.$element.trigger(t), t.isDefaultPrevented() || (this.$element.off(".modal").removeData("modal").removeClass("in").attr("aria-hidden", !0), this.$parent !== this.$element.parent() ? this.$element.appendTo(this.$parent) : this.$parent.length || (this.$element.remove(), this.$element = null), this.$element.trigger("destroyed"))
            }
        }, e.fn.modal = function(n, i) {
            return this.each(function() {
                var r = e(this),
                    o = r.data("modal"),
                    a = e.extend({}, e.fn.modal.defaults, r.data(), "object" == typeof n && n);
                o || r.data("modal", o = new t(this, a)), "string" == typeof n ? o[n].apply(o, [].concat(i)) : a.show && o.show()
            })
        }, e.fn.modal.defaults = {
            keyboard: !0,
            backdrop: !0,
            loading: !1,
            show: !0,
            width: null,
            height: null,
            maxHeight: null,
            modalOverflow: !1,
            consumeTab: !0,
            focusOn: null,
            replace: !1,
            resize: !1,
            attentionAnimation: "shake",
            manager: "body",
            spinner: '<div class="loading-spinner" style="width: 200px; margin-left: -100px;"><div class="progress progress-striped active"><div class="bar" style="width: 100%;"></div></div></div>',
            backdropTemplate: '<div class="modal-backdrop" />'
        }, e.fn.modal.Constructor = t, e(function() {
            e(document).off("click.modal").on("click.modal.data-api", '[data-toggle="modal"]', function(t) {
                var n = e(this),
                    i = n.attr("href"),
                    r = e(n.attr("data-target") || i && i.replace(/.*(?=#[^\s]+$)/, "")),
                    o = r.data("modal") ? "toggle" : e.extend({
                        remote: !/#/.test(i) && i
                    }, r.data(), n.data());
                t.preventDefault(), r.modal(o).one("hide", function() {
                    n.focus()
                })
            })
        })
    }(window.jQuery),
    function(e, t) {
        "function" == typeof define && define.amd ? define(["jquery"], t) : "object" == typeof exports ? module.exports = t(require("jquery")) : t(e.jQuery)
    }(this, function(e) {
        function t(e) {
            if (e in d.style) return e;
            for (var t = ["Moz", "Webkit", "O", "ms"], n = e.charAt(0).toUpperCase() + e.substr(1), i = 0; i < t.length; ++i) {
                var r = t[i] + n;
                if (r in d.style) return r
            }
        }

        function n() {
            return d.style[h.transform] = "", d.style[h.transform] = "rotateY(90deg)", "" !== d.style[h.transform]
        }

        function i(e) {
            return "string" == typeof e && this.parse(e), this
        }

        function r(e, t, n) {
            t === !0 ? e.queue(n) : t ? e.queue(t, n) : e.each(function() {
                n.call(this)
            })
        }

        function o(t) {
            var n = [];
            return e.each(t, function(t) {
                t = e.camelCase(t), t = e.transit.propertyMap[t] || e.cssProps[t] || t, t = u(t), h[t] && (t = u(h[t])), -1 === e.inArray(t, n) && n.push(t)
            }), n
        }

        function a(t, n, i, r) {
            var a = o(t);
            e.cssEase[i] && (i = e.cssEase[i]);
            var s = "" + l(n) + " " + i;
            parseInt(r, 10) > 0 && (s += " " + l(r));
            var u = [];
            return e.each(a, function(e, t) {
                u.push(t + " " + s)
            }), u.join(", ")
        }

        function s(t, n) {
            n || (e.cssNumber[t] = !0), e.transit.propertyMap[t] = h.transform, e.cssHooks[t] = {
                get: function(n) {
                    var i = e(n).css("transit:transform");
                    return i.get(t)
                },
                set: function(n, i) {
                    var r = e(n).css("transit:transform");
                    r.setFromString(t, i), e(n).css({
                        "transit:transform": r
                    })
                }
            }
        }

        function u(e) {
            return e.replace(/([A-Z])/g, function(e) {
                return "-" + e.toLowerCase()
            })
        }

        function c(e, t) {
            return "string" != typeof e || e.match(/^[\-0-9\.]+$/) ? "" + e + t : e
        }

        function l(t) {
            var n = t;
            return "string" != typeof n || n.match(/^[\-0-9\.]+/) || (n = e.fx.speeds[n] || e.fx.speeds._default), c(n, "ms")
        }
        e.transit = {
            version: "0.9.12",
            propertyMap: {
                marginLeft: "margin",
                marginRight: "margin",
                marginBottom: "margin",
                marginTop: "margin",
                paddingLeft: "padding",
                paddingRight: "padding",
                paddingBottom: "padding",
                paddingTop: "padding"
            },
            enabled: !0,
            useTransitionEnd: !1
        };
        var d = document.createElement("div"),
            h = {},
            f = navigator.userAgent.toLowerCase().indexOf("chrome") > -1;
        h.transition = t("transition"), h.transitionDelay = t("transitionDelay"), h.transform = t("transform"), h.transformOrigin = t("transformOrigin"), h.filter = t("Filter"), h.transform3d = n();
        var p = {
                transition: "transitionend",
                MozTransition: "transitionend",
                OTransition: "oTransitionEnd",
                WebkitTransition: "webkitTransitionEnd",
                msTransition: "MSTransitionEnd"
            },
            g = h.transitionEnd = p[h.transition] || null;
        for (var m in h) h.hasOwnProperty(m) && "undefined" == typeof e.support[m] && (e.support[m] = h[m]);
        return d = null, e.cssEase = {
            _default: "ease",
            "in": "ease-in",
            out: "ease-out",
            "in-out": "ease-in-out",
            snap: "cubic-bezier(0,1,.5,1)",
            easeInCubic: "cubic-bezier(.550,.055,.675,.190)",
            easeOutCubic: "cubic-bezier(.215,.61,.355,1)",
            easeInOutCubic: "cubic-bezier(.645,.045,.355,1)",
            easeInCirc: "cubic-bezier(.6,.04,.98,.335)",
            easeOutCirc: "cubic-bezier(.075,.82,.165,1)",
            easeInOutCirc: "cubic-bezier(.785,.135,.15,.86)",
            easeInExpo: "cubic-bezier(.95,.05,.795,.035)",
            easeOutExpo: "cubic-bezier(.19,1,.22,1)",
            easeInOutExpo: "cubic-bezier(1,0,0,1)",
            easeInQuad: "cubic-bezier(.55,.085,.68,.53)",
            easeOutQuad: "cubic-bezier(.25,.46,.45,.94)",
            easeInOutQuad: "cubic-bezier(.455,.03,.515,.955)",
            easeInQuart: "cubic-bezier(.895,.03,.685,.22)",
            easeOutQuart: "cubic-bezier(.165,.84,.44,1)",
            easeInOutQuart: "cubic-bezier(.77,0,.175,1)",
            easeInQuint: "cubic-bezier(.755,.05,.855,.06)",
            easeOutQuint: "cubic-bezier(.23,1,.32,1)",
            easeInOutQuint: "cubic-bezier(.86,0,.07,1)",
            easeInSine: "cubic-bezier(.47,0,.745,.715)",
            easeOutSine: "cubic-bezier(.39,.575,.565,1)",
            easeInOutSine: "cubic-bezier(.445,.05,.55,.95)",
            easeInBack: "cubic-bezier(.6,-.28,.735,.045)",
            easeOutBack: "cubic-bezier(.175, .885,.32,1.275)",
            easeInOutBack: "cubic-bezier(.68,-.55,.265,1.55)"
        }, e.cssHooks["transit:transform"] = {
            get: function(t) {
                return e(t).data("transform") || new i
            },
            set: function(t, n) {
                var r = n;
                r instanceof i || (r = new i(r)), "WebkitTransform" !== h.transform || f ? t.style[h.transform] = r.toString() : t.style[h.transform] = r.toString(!0), e(t).data("transform", r)
            }
        }, e.cssHooks.transform = {
            set: e.cssHooks["transit:transform"].set
        }, e.cssHooks.filter = {
            get: function(e) {
                return e.style[h.filter]
            },
            set: function(e, t) {
                e.style[h.filter] = t
            }
        }, e.fn.jquery < "1.8" && (e.cssHooks.transformOrigin = {
            get: function(e) {
                return e.style[h.transformOrigin]
            },
            set: function(e, t) {
                e.style[h.transformOrigin] = t
            }
        }, e.cssHooks.transition = {
            get: function(e) {
                return e.style[h.transition]
            },
            set: function(e, t) {
                e.style[h.transition] = t
            }
        }), s("scale"), s("scaleX"), s("scaleY"), s("translate"), s("rotate"), s("rotateX"), s("rotateY"), s("rotate3d"), s("perspective"), s("skewX"), s("skewY"), s("x", !0), s("y", !0), i.prototype = {
            setFromString: function(e, t) {
                var n = "string" == typeof t ? t.split(",") : t.constructor === Array ? t : [t];
                n.unshift(e), i.prototype.set.apply(this, n)
            },
            set: function(e) {
                var t = Array.prototype.slice.apply(arguments, [1]);
                this.setter[e] ? this.setter[e].apply(this, t) : this[e] = t.join(",")
            },
            get: function(e) {
                return this.getter[e] ? this.getter[e].apply(this) : this[e] || 0
            },
            setter: {
                rotate: function(e) {
                    this.rotate = c(e, "deg")
                },
                rotateX: function(e) {
                    this.rotateX = c(e, "deg")
                },
                rotateY: function(e) {
                    this.rotateY = c(e, "deg")
                },
                scale: function(e, t) {
                    void 0 === t && (t = e), this.scale = e + "," + t
                },
                skewX: function(e) {
                    this.skewX = c(e, "deg")
                },
                skewY: function(e) {
                    this.skewY = c(e, "deg")
                },
                perspective: function(e) {
                    this.perspective = c(e, "px")
                },
                x: function(e) {
                    this.set("translate", e, null)
                },
                y: function(e) {
                    this.set("translate", null, e)
                },
                translate: function(e, t) {
                    void 0 === this._translateX && (this._translateX = 0), void 0 === this._translateY && (this._translateY = 0), null !== e && void 0 !== e && (this._translateX = c(e, "px")), null !== t && void 0 !== t && (this._translateY = c(t, "px")), this.translate = this._translateX + "," + this._translateY
                }
            },
            getter: {
                x: function() {
                    return this._translateX || 0
                },
                y: function() {
                    return this._translateY || 0
                },
                scale: function() {
                    var e = (this.scale || "1,1").split(",");
                    return e[0] && (e[0] = parseFloat(e[0])), e[1] && (e[1] = parseFloat(e[1])), e[0] === e[1] ? e[0] : e
                },
                rotate3d: function() {
                    for (var e = (this.rotate3d || "0,0,0,0deg").split(","), t = 0; 3 >= t; ++t) e[t] && (e[t] = parseFloat(e[t]));
                    return e[3] && (e[3] = c(e[3], "deg")), e
                }
            },
            parse: function(e) {
                var t = this;
                e.replace(/([a-zA-Z0-9]+)\((.*?)\)/g, function(e, n, i) {
                    t.setFromString(n, i)
                })
            },
            toString: function(e) {
                var t = [];
                for (var n in this)
                    if (this.hasOwnProperty(n)) {
                        if (!h.transform3d && ("rotateX" === n || "rotateY" === n || "perspective" === n || "transformOrigin" === n)) continue;
                        "_" !== n[0] && (e && "scale" === n ? t.push(n + "3d(" + this[n] + ",1)") : e && "translate" === n ? t.push(n + "3d(" + this[n] + ",0)") : t.push(n + "(" + this[n] + ")"))
                    }
                return t.join(" ")
            }
        }, e.fn.transition = e.fn.transit = function(t, n, i, o) {
            var s = this,
                u = 0,
                c = !0,
                d = e.extend(!0, {}, t);
            "function" == typeof n && (o = n, n = void 0), "object" == typeof n && (i = n.easing, u = n.delay || 0, c = "undefined" == typeof n.queue ? !0 : n.queue, o = n.complete, n = n.duration), "function" == typeof i && (o = i, i = void 0), "undefined" != typeof d.easing && (i = d.easing, delete d.easing), "undefined" != typeof d.duration && (n = d.duration, delete d.duration), "undefined" != typeof d.complete && (o = d.complete, delete d.complete), "undefined" != typeof d.queue && (c = d.queue, delete d.queue), "undefined" != typeof d.delay && (u = d.delay, delete d.delay), "undefined" == typeof n && (n = e.fx.speeds._default), "undefined" == typeof i && (i = e.cssEase._default), n = l(n);
            var f = a(d, n, i, u),
                p = e.transit.enabled && h.transition,
                m = p ? parseInt(n, 10) + parseInt(u, 10) : 0;
            if (0 === m) {
                var v = function(e) {
                    s.css(d), o && o.apply(s), e && e()
                };
                return r(s, c, v), s
            }
            var y = {},
                b = function(t) {
                    var n = !1,
                        i = function() {
                            n && s.unbind(g, i), m > 0 && s.each(function() {
                                this.style[h.transition] = y[this] || null
                            }), "function" == typeof o && o.apply(s), "function" == typeof t && t()
                        };
                    m > 0 && g && e.transit.useTransitionEnd ? (n = !0, s.bind(g, i)) : window.setTimeout(i, m), s.each(function() {
                        m > 0 && (this.style[h.transition] = f), e(this).css(d)
                    })
                },
                w = function(e) {
                    this.offsetWidth, b(e)
                };
            return r(s, c, w), this
        }, e.transit.getTransitionValue = a, e
    }),
    function(e) {
        "function" == typeof define && define.amd ? define(["jquery"], e) : e("object" == typeof exports ? require("jquery") : jQuery)
    }(function(e) {
        function t(e) {
            return s.raw ? e : encodeURIComponent(e)
        }

        function n(e) {
            return s.raw ? e : decodeURIComponent(e)
        }

        function i(e) {
            return t(s.json ? JSON.stringify(e) : String(e))
        }

        function r(e) {
            0 === e.indexOf('"') && (e = e.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, "\\"));
            try {
                return e = decodeURIComponent(e.replace(a, " ")), s.json ? JSON.parse(e) : e
            } catch (t) {}
        }

        function o(t, n) {
            var i = s.raw ? t : r(t);
            return e.isFunction(n) ? n(i) : i
        }
        var a = /\+/g,
            s = e.cookie = function(r, a, u) {
                if (void 0 !== a && !e.isFunction(a)) {
                    if (u = e.extend({}, s.defaults, u), "number" == typeof u.expires) {
                        var c = u.expires,
                            l = u.expires = new Date;
                        l.setTime(+l + 864e5 * c)
                    }
                    return document.cookie = [t(r), "=", i(a), u.expires ? "; expires=" + u.expires.toUTCString() : "", u.path ? "; path=" + u.path : "", u.domain ? "; domain=" + u.domain : "", u.secure ? "; secure" : ""].join("")
                }
                for (var d = r ? void 0 : {}, h = document.cookie ? document.cookie.split("; ") : [], f = 0, p = h.length; p > f; f++) {
                    var g = h[f].split("="),
                        m = n(g.shift()),
                        v = g.join("=");
                    if (r && r === m) {
                        d = o(v, a);
                        break
                    }
                    r || void 0 === (v = o(v)) || (d[m] = v)
                }
                return d
            };
        s.defaults = {}, e.removeCookie = function(t, n) {
            return void 0 === e.cookie(t) ? !1 : (e.cookie(t, "", e.extend({}, n, {
                expires: -1
            })), !e.cookie(t))
        }
    }),
    function(e) {
        jQuery.fn.observe_field = function(t, n) {
            return t = 1e3 * t, this.each(function() {
                var i = e(this),
                    r = i.val(),
                    o = i.prop("checked"),
                    a = function() {
                        if (s()) return void(c && clearInterval(c));
                        var e = i.val(),
                            t = i.prop("checked");
                        (r != e || t != o) && (r = e, o = t, i.map(n))
                    },
                    s = function() {
                        return 0 == i.closest("html").length
                    },
                    u = function() {
                        c && (clearInterval(c), c = setInterval(a, t))
                    };
                a();
                var c = setInterval(a, t);
                i.bind("keyup click mousemove", u)
            })
        }
    }(jQuery),
    function(e, t) {
        "function" == typeof define && define.amd ? define(t) : "object" == typeof exports ? module.exports = t() : e.NProgress = t()
    }(this, function() {
        function e(e, t, n) {
            return t > e ? t : e > n ? n : e
        }

        function t(e) {
            return 100 * (-1 + e)
        }

        function n(e, n, i) {
            var r;
            return r = "translate3d" === c.positionUsing ? {
                transform: "translate3d(" + t(e) + "%,0,0)"
            } : "translate" === c.positionUsing ? {
                transform: "translate(" + t(e) + "%,0)"
            } : {
                "margin-left": t(e) + "%"
            }, r.transition = "all " + n + "ms " + i, r
        }

        function i(e, t) {
            var n = "string" == typeof e ? e : a(e);
            return n.indexOf(" " + t + " ") >= 0
        }

        function r(e, t) {
            var n = a(e),
                r = n + t;
            i(n, t) || (e.className = r.substring(1))
        }

        function o(e, t) {
            var n, r = a(e);
            i(e, t) && (n = r.replace(" " + t + " ", " "), e.className = n.substring(1, n.length - 1))
        }

        function a(e) {
            return (" " + (e.className || "") + " ").replace(/\s+/gi, " ")
        }

        function s(e) {
            e && e.parentNode && e.parentNode.removeChild(e)
        }
        var u = {};
        u.version = "0.1.6";
        var c = u.settings = {
            minimum: .08,
            easing: "ease",
            positionUsing: "",
            speed: 200,
            trickle: !0,
            trickleRate: .02,
            trickleSpeed: 800,
            showSpinner: !0,
            barSelector: '[role="bar"]',
            spinnerSelector: '[role="spinner"]',
            parent: "body",
            template: '<div class="bar" role="bar"><div class="peg"></div></div><div class="spinner" role="spinner"><div class="spinner-icon"></div></div>'
        };
        u.configure = function(e) {
                var t, n;
                for (t in e) n = e[t], void 0 !== n && e.hasOwnProperty(t) && (c[t] = n);
                return this
            }, u.status = null, u.set = function(t) {
                var i = u.isStarted();
                t = e(t, c.minimum, 1), u.status = 1 === t ? null : t;
                var r = u.render(!i),
                    o = r.querySelector(c.barSelector),
                    a = c.speed,
                    s = c.easing;
                return r.offsetWidth, l(function(e) {
                    "" === c.positionUsing && (c.positionUsing = u.getPositioningCSS()), d(o, n(t, a, s)), 1 === t ? (d(r, {
                        transition: "none",
                        opacity: 1
                    }), r.offsetWidth, setTimeout(function() {
                        d(r, {
                            transition: "all " + a + "ms linear",
                            opacity: 0
                        }), setTimeout(function() {
                            u.remove(), e()
                        }, a)
                    }, a)) : setTimeout(e, a)
                }), this
            }, u.isStarted = function() {
                return "number" == typeof u.status
            }, u.start = function() {
                u.status || u.set(0);
                var e = function() {
                    setTimeout(function() {
                        u.status && (u.trickle(), e())
                    }, c.trickleSpeed)
                };
                return c.trickle && e(), this
            }, u.done = function(e) {
                return e || u.status ? u.inc(.3 + .5 * Math.random()).set(1) : this
            }, u.inc = function(t) {
                var n = u.status;
                return n ? ("number" != typeof t && (t = (1 - n) * e(Math.random() * n, .1, .95)), n = e(n + t, 0, .994), u.set(n)) : u.start()
            }, u.trickle = function() {
                return u.inc(Math.random() * c.trickleRate)
            },
            function() {
                var e = 0,
                    t = 0;
                u.promise = function(n) {
                    return n && "resolved" != n.state() ? (0 == t && u.start(), e++, t++, n.always(function() {
                        t--, 0 == t ? (e = 0, u.done()) : u.set((e - t) / e)
                    }), this) : this
                }
            }(), u.render = function(e) {
                if (u.isRendered()) return document.getElementById("nprogress");
                r(document.documentElement, "nprogress-busy");
                var n = document.createElement("div");
                n.id = "nprogress", n.innerHTML = c.template;
                var i, o = n.querySelector(c.barSelector),
                    a = e ? "-100" : t(u.status || 0),
                    l = document.querySelector(c.parent);
                return d(o, {
                    transition: "all 0 linear",
                    transform: "translate3d(" + a + "%,0,0)"
                }), c.showSpinner || (i = n.querySelector(c.spinnerSelector), i && s(i)), l != document.body && r(l, "nprogress-custom-parent"), l.appendChild(n), n
            }, u.remove = function() {
                o(document.documentElement, "nprogress-busy"), o(document.querySelector(c.parent), "nprogress-custom-parent");
                var e = document.getElementById("nprogress");
                e && s(e)
            }, u.isRendered = function() {
                return !!document.getElementById("nprogress")
            }, u.getPositioningCSS = function() {
                var e = document.body.style,
                    t = "WebkitTransform" in e ? "Webkit" : "MozTransform" in e ? "Moz" : "msTransform" in e ? "ms" : "OTransform" in e ? "O" : "";
                return t + "Perspective" in e ? "translate3d" : t + "Transform" in e ? "translate" : "margin"
            };
        var l = function() {
                function e() {
                    var n = t.shift();
                    n && n(e)
                }
                var t = [];
                return function(n) {
                    t.push(n), 1 == t.length && e()
                }
            }(),
            d = function() {
                function e(e) {
                    return e.replace(/^-ms-/, "ms-").replace(/-([\da-z])/gi, function(e, t) {
                        return t.toUpperCase()
                    })
                }

                function t(e) {
                    var t = document.body.style;
                    if (e in t) return e;
                    for (var n, i = r.length, o = e.charAt(0).toUpperCase() + e.slice(1); i--;)
                        if (n = r[i] + o, n in t) return n;
                    return e
                }

                function n(n) {
                    return n = e(n), o[n] || (o[n] = t(n))
                }

                function i(e, t, i) {
                    t = n(t), e.style[t] = i
                }
                var r = ["Webkit", "O", "Moz", "ms"],
                    o = {};
                return function(e, t) {
                    var n, r, o = arguments;
                    if (2 == o.length)
                        for (n in t) r = t[n], void 0 !== r && t.hasOwnProperty(n) && i(e, n, r);
                    else i(e, o[1], o[2])
                }
            }();
        return u
    }),
    function() {
        var e = this,
            t = e._,
            n = {},
            i = Array.prototype,
            r = Object.prototype,
            o = Function.prototype,
            a = i.push,
            s = i.slice,
            u = i.concat,
            c = r.toString,
            l = r.hasOwnProperty,
            d = i.forEach,
            h = i.map,
            f = i.reduce,
            p = i.reduceRight,
            g = i.filter,
            m = i.every,
            v = i.some,
            y = i.indexOf,
            b = i.lastIndexOf,
            w = Array.isArray,
            _ = Object.keys,
            C = o.bind,
            k = function(e) {
                return e instanceof k ? e : this instanceof k ? void(this._wrapped = e) : new k(e)
            };
        "undefined" != typeof exports ? ("undefined" != typeof module && module.exports && (exports = module.exports = k), exports._ = k) : e._ = k, k.VERSION = "1.6.0";
        var E = k.each = k.forEach = function(e, t, i) {
            if (null == e) return e;
            if (d && e.forEach === d) e.forEach(t, i);
            else if (e.length === +e.length) {
                for (var r = 0, o = e.length; o > r; r++)
                    if (t.call(i, e[r], r, e) === n) return
            } else
                for (var a = k.keys(e), r = 0, o = a.length; o > r; r++)
                    if (t.call(i, e[a[r]], a[r], e) === n) return;
            return e
        };
        k.map = k.collect = function(e, t, n) {
            var i = [];
            return null == e ? i : h && e.map === h ? e.map(t, n) : (E(e, function(e, r, o) {
                i.push(t.call(n, e, r, o))
            }), i)
        };
        var S = "Reduce of empty array with no initial value";
        k.reduce = k.foldl = k.inject = function(e, t, n, i) {
            var r = arguments.length > 2;
            if (null == e && (e = []), f && e.reduce === f) return i && (t = k.bind(t, i)), r ? e.reduce(t, n) : e.reduce(t);
            if (E(e, function(e, o, a) {
                    r ? n = t.call(i, n, e, o, a) : (n = e, r = !0)
                }), !r) throw new TypeError(S);
            return n
        }, k.reduceRight = k.foldr = function(e, t, n, i) {
            var r = arguments.length > 2;
            if (null == e && (e = []), p && e.reduceRight === p) return i && (t = k.bind(t, i)), r ? e.reduceRight(t, n) : e.reduceRight(t);
            var o = e.length;
            if (o !== +o) {
                var a = k.keys(e);
                o = a.length
            }
            if (E(e, function(s, u, c) {
                    u = a ? a[--o] : --o, r ? n = t.call(i, n, e[u], u, c) : (n = e[u], r = !0)
                }), !r) throw new TypeError(S);
            return n
        }, k.find = k.detect = function(e, t, n) {
            var i;
            return x(e, function(e, r, o) {
                return t.call(n, e, r, o) ? (i = e, !0) : void 0
            }), i
        }, k.filter = k.select = function(e, t, n) {
            var i = [];
            return null == e ? i : g && e.filter === g ? e.filter(t, n) : (E(e, function(e, r, o) {
                t.call(n, e, r, o) && i.push(e)
            }), i)
        }, k.reject = function(e, t, n) {
            return k.filter(e, function(e, i, r) {
                return !t.call(n, e, i, r)
            }, n)
        }, k.every = k.all = function(e, t, i) {
            t || (t = k.identity);
            var r = !0;
            return null == e ? r : m && e.every === m ? e.every(t, i) : (E(e, function(e, o, a) {
                return (r = r && t.call(i, e, o, a)) ? void 0 : n
            }), !!r)
        };
        var x = k.some = k.any = function(e, t, i) {
            t || (t = k.identity);
            var r = !1;
            return null == e ? r : v && e.some === v ? e.some(t, i) : (E(e, function(e, o, a) {
                return r || (r = t.call(i, e, o, a)) ? n : void 0
            }), !!r)
        };
        k.contains = k.include = function(e, t) {
            return null == e ? !1 : y && e.indexOf === y ? -1 != e.indexOf(t) : x(e, function(e) {
                return e === t
            })
        }, k.invoke = function(e, t) {
            var n = s.call(arguments, 2),
                i = k.isFunction(t);
            return k.map(e, function(e) {
                return (i ? t : e[t]).apply(e, n)
            })
        }, k.pluck = function(e, t) {
            return k.map(e, k.property(t))
        }, k.where = function(e, t) {
            return k.filter(e, k.matches(t))
        }, k.findWhere = function(e, t) {
            return k.find(e, k.matches(t))
        }, k.max = function(e, t, n) {
            if (!t && k.isArray(e) && e[0] === +e[0] && e.length < 65535) return Math.max.apply(Math, e);
            var i = -(1 / 0),
                r = -(1 / 0);
            return E(e, function(e, o, a) {
                var s = t ? t.call(n, e, o, a) : e;
                s > r && (i = e, r = s)
            }), i
        }, k.min = function(e, t, n) {
            if (!t && k.isArray(e) && e[0] === +e[0] && e.length < 65535) return Math.min.apply(Math, e);
            var i = 1 / 0,
                r = 1 / 0;
            return E(e, function(e, o, a) {
                var s = t ? t.call(n, e, o, a) : e;
                r > s && (i = e, r = s)
            }), i
        }, k.shuffle = function(e) {
            var t, n = 0,
                i = [];
            return E(e, function(e) {
                t = k.random(n++), i[n - 1] = i[t], i[t] = e
            }), i
        }, k.sample = function(e, t, n) {
            return null == t || n ? (e.length !== +e.length && (e = k.values(e)), e[k.random(e.length - 1)]) : k.shuffle(e).slice(0, Math.max(0, t))
        };
        var T = function(e) {
            return null == e ? k.identity : k.isFunction(e) ? e : k.property(e)
        };
        k.sortBy = function(e, t, n) {
            return t = T(t), k.pluck(k.map(e, function(e, i, r) {
                return {
                    value: e,
                    index: i,
                    criteria: t.call(n, e, i, r)
                }
            }).sort(function(e, t) {
                var n = e.criteria,
                    i = t.criteria;
                if (n !== i) {
                    if (n > i || void 0 === n) return 1;
                    if (i > n || void 0 === i) return -1
                }
                return e.index - t.index
            }), "value")
        };
        var B = function(e) {
            return function(t, n, i) {
                var r = {};
                return n = T(n), E(t, function(o, a) {
                    var s = n.call(i, o, a, t);
                    e(r, s, o)
                }), r
            }
        };
        k.groupBy = B(function(e, t, n) {
            k.has(e, t) ? e[t].push(n) : e[t] = [n]
        }), k.indexBy = B(function(e, t, n) {
            e[t] = n
        }), k.countBy = B(function(e, t) {
            k.has(e, t) ? e[t]++ : e[t] = 1
        }), k.sortedIndex = function(e, t, n, i) {
            n = T(n);
            for (var r = n.call(i, t), o = 0, a = e.length; a > o;) {
                var s = o + a >>> 1;
                n.call(i, e[s]) < r ? o = s + 1 : a = s
            }
            return o
        }, k.toArray = function(e) {
            return e ? k.isArray(e) ? s.call(e) : e.length === +e.length ? k.map(e, k.identity) : k.values(e) : []
        }, k.size = function(e) {
            return null == e ? 0 : e.length === +e.length ? e.length : k.keys(e).length
        }, k.first = k.head = k.take = function(e, t, n) {
            return null == e ? void 0 : null == t || n ? e[0] : 0 > t ? [] : s.call(e, 0, t)
        }, k.initial = function(e, t, n) {
            return s.call(e, 0, e.length - (null == t || n ? 1 : t))
        }, k.last = function(e, t, n) {
            return null == e ? void 0 : null == t || n ? e[e.length - 1] : s.call(e, Math.max(e.length - t, 0))
        }, k.rest = k.tail = k.drop = function(e, t, n) {
            return s.call(e, null == t || n ? 1 : t)
        }, k.compact = function(e) {
            return k.filter(e, k.identity)
        };
        var P = function(e, t, n) {
            return t && k.every(e, k.isArray) ? u.apply(n, e) : (E(e, function(e) {
                k.isArray(e) || k.isArguments(e) ? t ? a.apply(n, e) : P(e, t, n) : n.push(e)
            }), n)
        };
        k.flatten = function(e, t) {
            return P(e, t, [])
        }, k.without = function(e) {
            return k.difference(e, s.call(arguments, 1))
        }, k.partition = function(e, t) {
            var n = [],
                i = [];
            return E(e, function(e) {
                (t(e) ? n : i).push(e)
            }), [n, i]
        }, k.uniq = k.unique = function(e, t, n, i) {
            k.isFunction(t) && (i = n, n = t, t = !1);
            var r = n ? k.map(e, n, i) : e,
                o = [],
                a = [];
            return E(r, function(n, i) {
                (t ? i && a[a.length - 1] === n : k.contains(a, n)) || (a.push(n), o.push(e[i]))
            }), o
        }, k.union = function() {
            return k.uniq(k.flatten(arguments, !0))
        }, k.intersection = function(e) {
            var t = s.call(arguments, 1);
            return k.filter(k.uniq(e), function(e) {
                return k.every(t, function(t) {
                    return k.contains(t, e)
                })
            })
        }, k.difference = function(e) {
            var t = u.apply(i, s.call(arguments, 1));
            return k.filter(e, function(e) {
                return !k.contains(t, e)
            })
        }, k.zip = function() {
            for (var e = k.max(k.pluck(arguments, "length").concat(0)), t = new Array(e), n = 0; e > n; n++) t[n] = k.pluck(arguments, "" + n);
            return t
        }, k.object = function(e, t) {
            if (null == e) return {};
            for (var n = {}, i = 0, r = e.length; r > i; i++) t ? n[e[i]] = t[i] : n[e[i][0]] = e[i][1];
            return n
        }, k.indexOf = function(e, t, n) {
            if (null == e) return -1;
            var i = 0,
                r = e.length;
            if (n) {
                if ("number" != typeof n) return i = k.sortedIndex(e, t), e[i] === t ? i : -1;
                i = 0 > n ? Math.max(0, r + n) : n
            }
            if (y && e.indexOf === y) return e.indexOf(t, n);
            for (; r > i; i++)
                if (e[i] === t) return i;
            return -1
        }, k.lastIndexOf = function(e, t, n) {
            if (null == e) return -1;
            var i = null != n;
            if (b && e.lastIndexOf === b) return i ? e.lastIndexOf(t, n) : e.lastIndexOf(t);
            for (var r = i ? n : e.length; r--;)
                if (e[r] === t) return r;
            return -1
        }, k.range = function(e, t, n) {
            arguments.length <= 1 && (t = e || 0, e = 0), n = arguments[2] || 1;
            for (var i = Math.max(Math.ceil((t - e) / n), 0), r = 0, o = new Array(i); i > r;) o[r++] = e, e += n;
            return o
        };
        var A = function() {};
        k.bind = function(e, t) {
            var n, i;
            if (C && e.bind === C) return C.apply(e, s.call(arguments, 1));
            if (!k.isFunction(e)) throw new TypeError;
            return n = s.call(arguments, 2), i = function() {
                if (!(this instanceof i)) return e.apply(t, n.concat(s.call(arguments)));
                A.prototype = e.prototype;
                var r = new A;
                A.prototype = null;
                var o = e.apply(r, n.concat(s.call(arguments)));
                return Object(o) === o ? o : r
            }
        }, k.partial = function(e) {
            var t = s.call(arguments, 1);
            return function() {
                for (var n = 0, i = t.slice(), r = 0, o = i.length; o > r; r++) i[r] === k && (i[r] = arguments[n++]);
                for (; n < arguments.length;) i.push(arguments[n++]);
                return e.apply(this, i)
            }
        }, k.bindAll = function(e) {
            var t = s.call(arguments, 1);
            if (0 === t.length) throw new Error("bindAll must be passed function names");
            return E(t, function(t) {
                e[t] = k.bind(e[t], e)
            }), e
        }, k.memoize = function(e, t) {
            var n = {};
            return t || (t = k.identity),
                function() {
                    var i = t.apply(this, arguments);
                    return k.has(n, i) ? n[i] : n[i] = e.apply(this, arguments)
                }
        }, k.delay = function(e, t) {
            var n = s.call(arguments, 2);
            return setTimeout(function() {
                return e.apply(null, n)
            }, t)
        }, k.defer = function(e) {
            return k.delay.apply(k, [e, 1].concat(s.call(arguments, 1)))
        }, k.throttle = function(e, t, n) {
            var i, r, o, a = null,
                s = 0;
            n || (n = {});
            var u = function() {
                s = n.leading === !1 ? 0 : k.now(), a = null, o = e.apply(i, r), i = r = null
            };
            return function() {
                var c = k.now();
                s || n.leading !== !1 || (s = c);
                var l = t - (c - s);
                return i = this, r = arguments, 0 >= l ? (clearTimeout(a), a = null, s = c, o = e.apply(i, r), i = r = null) : a || n.trailing === !1 || (a = setTimeout(u, l)), o
            }
        }, k.debounce = function(e, t, n) {
            var i, r, o, a, s, u = function() {
                var c = k.now() - a;
                t > c ? i = setTimeout(u, t - c) : (i = null, n || (s = e.apply(o, r), o = r = null))
            };
            return function() {
                o = this, r = arguments, a = k.now();
                var c = n && !i;
                return i || (i = setTimeout(u, t)), c && (s = e.apply(o, r), o = r = null), s
            }
        }, k.once = function(e) {
            var t, n = !1;
            return function() {
                return n ? t : (n = !0, t = e.apply(this, arguments), e = null, t)
            }
        }, k.wrap = function(e, t) {
            return k.partial(t, e)
        }, k.compose = function() {
            var e = arguments;
            return function() {
                for (var t = arguments, n = e.length - 1; n >= 0; n--) t = [e[n].apply(this, t)];
                return t[0]
            }
        }, k.after = function(e, t) {
            return function() {
                return --e < 1 ? t.apply(this, arguments) : void 0
            }
        }, k.keys = function(e) {
            if (!k.isObject(e)) return [];
            if (_) return _(e);
            var t = [];
            for (var n in e) k.has(e, n) && t.push(n);
            return t
        }, k.values = function(e) {
            for (var t = k.keys(e), n = t.length, i = new Array(n), r = 0; n > r; r++) i[r] = e[t[r]];
            return i
        }, k.pairs = function(e) {
            for (var t = k.keys(e), n = t.length, i = new Array(n), r = 0; n > r; r++) i[r] = [t[r], e[t[r]]];
            return i
        }, k.invert = function(e) {
            for (var t = {}, n = k.keys(e), i = 0, r = n.length; r > i; i++) t[e[n[i]]] = n[i];
            return t
        }, k.functions = k.methods = function(e) {
            var t = [];
            for (var n in e) k.isFunction(e[n]) && t.push(n);
            return t.sort()
        }, k.extend = function(e) {
            return E(s.call(arguments, 1), function(t) {
                if (t)
                    for (var n in t) e[n] = t[n]
            }), e
        }, k.pick = function(e) {
            var t = {},
                n = u.apply(i, s.call(arguments, 1));
            return E(n, function(n) {
                n in e && (t[n] = e[n])
            }), t
        }, k.omit = function(e) {
            var t = {},
                n = u.apply(i, s.call(arguments, 1));
            for (var r in e) k.contains(n, r) || (t[r] = e[r]);
            return t
        }, k.defaults = function(e) {
            return E(s.call(arguments, 1), function(t) {
                if (t)
                    for (var n in t) void 0 === e[n] && (e[n] = t[n])
            }), e
        }, k.clone = function(e) {
            return k.isObject(e) ? k.isArray(e) ? e.slice() : k.extend({}, e) : e
        }, k.tap = function(e, t) {
            return t(e), e
        };
        var D = function(e, t, n, i) {
            if (e === t) return 0 !== e || 1 / e == 1 / t;
            if (null == e || null == t) return e === t;
            e instanceof k && (e = e._wrapped), t instanceof k && (t = t._wrapped);
            var r = c.call(e);
            if (r != c.call(t)) return !1;
            switch (r) {
                case "[object String]":
                    return e == String(t);
                case "[object Number]":
                    return e != +e ? t != +t : 0 == e ? 1 / e == 1 / t : e == +t;
                case "[object Date]":
                case "[object Boolean]":
                    return +e == +t;
                case "[object RegExp]":
                    return e.source == t.source && e.global == t.global && e.multiline == t.multiline && e.ignoreCase == t.ignoreCase
            }
            if ("object" != typeof e || "object" != typeof t) return !1;
            for (var o = n.length; o--;)
                if (n[o] == e) return i[o] == t;
            var a = e.constructor,
                s = t.constructor;
            if (a !== s && !(k.isFunction(a) && a instanceof a && k.isFunction(s) && s instanceof s) && "constructor" in e && "constructor" in t) return !1;
            n.push(e), i.push(t);
            var u = 0,
                l = !0;
            if ("[object Array]" == r) {
                if (u = e.length, l = u == t.length)
                    for (; u-- && (l = D(e[u], t[u], n, i)););
            } else {
                for (var d in e)
                    if (k.has(e, d) && (u++, !(l = k.has(t, d) && D(e[d], t[d], n, i)))) break;
                if (l) {
                    for (d in t)
                        if (k.has(t, d) && !u--) break;
                    l = !u
                }
            }
            return n.pop(), i.pop(), l
        };
        k.isEqual = function(e, t) {
            return D(e, t, [], [])
        }, k.isEmpty = function(e) {
            if (null == e) return !0;
            if (k.isArray(e) || k.isString(e)) return 0 === e.length;
            for (var t in e)
                if (k.has(e, t)) return !1;
            return !0
        }, k.isElement = function(e) {
            return !(!e || 1 !== e.nodeType)
        }, k.isArray = w || function(e) {
            return "[object Array]" == c.call(e)
        }, k.isObject = function(e) {
            return e === Object(e)
        }, E(["Arguments", "Function", "String", "Number", "Date", "RegExp"], function(e) {
            k["is" + e] = function(t) {
                return c.call(t) == "[object " + e + "]"
            }
        }), k.isArguments(arguments) || (k.isArguments = function(e) {
            return !(!e || !k.has(e, "callee"))
        }), "function" != typeof /./ && (k.isFunction = function(e) {
            return "function" == typeof e
        }), k.isFinite = function(e) {
            return isFinite(e) && !isNaN(parseFloat(e))
        }, k.isNaN = function(e) {
            return k.isNumber(e) && e != +e
        }, k.isBoolean = function(e) {
            return e === !0 || e === !1 || "[object Boolean]" == c.call(e)
        }, k.isNull = function(e) {
            return null === e
        }, k.isUndefined = function(e) {
            return void 0 === e
        }, k.has = function(e, t) {
            return l.call(e, t)
        }, k.noConflict = function() {
            return e._ = t, this
        }, k.identity = function(e) {
            return e
        }, k.constant = function(e) {
            return function() {
                return e
            }
        }, k.property = function(e) {
            return function(t) {
                return t[e]
            }
        }, k.matches = function(e) {
            return function(t) {
                if (t === e) return !0;
                for (var n in e)
                    if (e[n] !== t[n]) return !1;
                return !0
            }
        }, k.times = function(e, t, n) {
            for (var i = Array(Math.max(0, e)), r = 0; e > r; r++) i[r] = t.call(n, r);
            return i
        }, k.random = function(e, t) {
            return null == t && (t = e, e = 0), e + Math.floor(Math.random() * (t - e + 1))
        }, k.now = Date.now || function() {
            return (new Date).getTime()
        };
        var O = {
            escape: {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#x27;"
            }
        };
        O.unescape = k.invert(O.escape);
        var $ = {
            escape: new RegExp("[" + k.keys(O.escape).join("") + "]", "g"),
            unescape: new RegExp("(" + k.keys(O.unescape).join("|") + ")", "g")
        };
        k.each(["escape", "unescape"], function(e) {
            k[e] = function(t) {
                return null == t ? "" : ("" + t).replace($[e], function(t) {
                    return O[e][t]
                })
            }
        }), k.result = function(e, t) {
            if (null == e) return void 0;
            var n = e[t];
            return k.isFunction(n) ? n.call(e) : n
        }, k.mixin = function(e) {
            E(k.functions(e), function(t) {
                var n = k[t] = e[t];
                k.prototype[t] = function() {
                    var e = [this._wrapped];
                    return a.apply(e, arguments), j.call(this, n.apply(k, e))
                }
            })
        };
        var M = 0;
        k.uniqueId = function(e) {
            var t = ++M + "";
            return e ? e + t : t
        }, k.templateSettings = {
            evaluate: /<%([\s\S]+?)%>/g,
            interpolate: /<%=([\s\S]+?)%>/g,
            escape: /<%-([\s\S]+?)%>/g
        };
        var F = /(.)^/,
            I = {
                "'": "'",
                "\\": "\\",
                "\r": "r",
                "\n": "n",
                "	": "t",
                "\u2028": "u2028",
                "\u2029": "u2029"
            },
            R = /\\|'|\r|\n|\t|\u2028|\u2029/g;
        k.template = function(e, t, n) {
            var i;
            n = k.defaults({}, n, k.templateSettings);
            var r = new RegExp([(n.escape || F).source, (n.interpolate || F).source, (n.evaluate || F).source].join("|") + "|$", "g"),
                o = 0,
                a = "__p+='";
            e.replace(r, function(t, n, i, r, s) {
                return a += e.slice(o, s).replace(R, function(e) {
                    return "\\" + I[e]
                }), n && (a += "'+\n((__t=(" + n + "))==null?'':_.escape(__t))+\n'"), i && (a += "'+\n((__t=(" + i + "))==null?'':__t)+\n'"), r && (a += "';\n" + r + "\n__p+='"), o = s + t.length, t
            }), a += "';\n", n.variable || (a = "with(obj||{}){\n" + a + "}\n"), a = "var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};\n" + a + "return __p;\n";
            try {
                i = new Function(n.variable || "obj", "_", a)
            } catch (s) {
                throw s.source = a, s
            }
            if (t) return i(t, k);
            var u = function(e) {
                return i.call(this, e, k)
            };
            return u.source = "function(" + (n.variable || "obj") + "){\n" + a + "}", u
        }, k.chain = function(e) {
            return k(e).chain()
        };
        var j = function(e) {
            return this._chain ? k(e).chain() : e
        };
        k.mixin(k), E(["pop", "push", "reverse", "shift", "sort", "splice", "unshift"], function(e) {
            var t = i[e];
            k.prototype[e] = function() {
                var n = this._wrapped;
                return t.apply(n, arguments), "shift" != e && "splice" != e || 0 !== n.length || delete n[0], j.call(this, n)
            }
        }), E(["concat", "join", "slice"], function(e) {
            var t = i[e];
            k.prototype[e] = function() {
                return j.call(this, t.apply(this._wrapped, arguments))
            }
        }), k.extend(k.prototype, {
            chain: function() {
                return this._chain = !0, this
            },
            value: function() {
                return this._wrapped
            }
        }), "function" == typeof define && define.amd && define("underscore", [], function() {
            return k
        })
    }.call(this),
    function() {
        var e, t = [].indexOf || function(e) {
            for (var t = 0, n = this.length; n > t; t++)
                if (t in this && this[t] === e) return t;
            return -1
        };
        e = jQuery, e.fn.extend({
            baseSelect: function(n) {
                var i, r, o, a, s, u, c, l, d, h;
                return h = ["accounts", "payment-methods"], r = {
                    type: void 0,
                    options: []
                }, l = {
                    className: "",
                    title: "",
                    debug: !1
                }, l = e.extend(l, n), c = '<div class="base-select-container ' + l.className + '">\n  <a href class="selector">\n    <span class="name"></span>\n    <span class="balance"></span>\n  </a>\n  <ul style="display: none;"></ul>\n</div>', a = "<li></li>", o = function(e) {
                    return l.debug && "undefined" != typeof console && null !== console ? console.log(e) : void 0
                }, i = function(e) {
                    try {
                        return e.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()
                    } catch (t) {
                        return void 0
                    }
                }, s = function(t) {
                    return r.type = t.data("type"), e("option", t).each(function() {
                        var t;
                        return t = e(this).data(), e.extend(t, {
                            label: t.label || e(this).text(),
                            value: e(this).val(),
                            isSelected: e(this).is(":selected")
                        }), r.options.push(t)
                    })
                }, d = function(t) {
                    var n, i, r;
                    return e("a.selector", t).toggle(), e("ul", t).toggle(), e("ul", t).is(":visible") ? (i = e("ul li", t).first().height(), n = e("ul li a.selected", t).parent().prevAll().length, r = -1 * i * n - 1, e("ul", t).css("top", r + "px")) : void 0
                }, u = function(t, n, o, a) {
                    var s;
                    return null == a && (a = {}), n.val(o), n.trigger("select", a), s = _.findWhere(r.options, {
                        value: o
                    }), e("a.selector .name", t).text(s.label), e("a.selector", t).attr("data-type", i(s.type)), e("a.selector", t).attr("data-currency", s.currency), e("a.selector .balance", t).text(""), s.balance && e("a.selector .balance", t).text(s.balanceString), e("ul li a", t).removeClass("selected"), o ? e("ul li a[data-value=" + o + "]", t).addClass("selected") : void 0
                }, this.each(function() {
                    var n, a, l;
                    return a = e(this), o(a), l = a.data("type"), t.call(h, l) < 0 ? void console.error("Invalid type") : (s(a), a.hide(), n = e(c).insertAfter(a), e(r.options).each(function(t, r) {
                        var o;
                        return e("ul", n).append('<li>\n  <a href class="' + i(r.type) + '" data-label="' + _.escape(r.label) + '" data-type="' + i(r.type) + '" data-value="' + r.value + '" data-url="' + r.url + '" data-currency="' + r.currency + '">\n    ' + _.escape(r.label) + "\n  </a>\n</li>"), o = e("ul li a", n).last(), r.balance && o.append("<span class='balance'>" + r.balanceString + "</span>"), r.isSelected ? u(n, a, r.value) : void 0
                    }), e("a.selector", n).on("click", function(t) {
                        return t.preventDefault(), d(n), 1 === r.options.length ? e("ul a", n).first().click() : void 0
                    }), e("ul a", n).on("click", function(t) {
                        var i;
                        return t.preventDefault(), i = e(t.currentTarget), "redirect" === i.data("type") ? window.location.href = i.data("url") : u(n, a, i.data("value"), {
                            actualClick: !0
                        }), d(n)
                    }), e("body").on("click", function(t) {
                        return e("ul", n).is(":visible") !== !0 || e(t.target).is(n) || e(t.target).closest(n).length ? void 0 : d(n)
                    }))
                })
            }
        })
    }.call(this),
    function(e) {
        "function" == typeof define && define.amd ? define(["jquery"], e) : e(jQuery)
    }(function(e) {
        var t = 0,
            n = Array.prototype.slice;
        e.cleanData = function(t) {
            return function(n) {
                var i, r, o;
                for (o = 0; null != (r = n[o]); o++) try {
                    i = e._data(r, "events"), i && i.remove && e(r).triggerHandler("remove")
                } catch (a) {}
                t(n)
            }
        }(e.cleanData), e.widget = function(t, n, i) {
            var r, o, a, s, u = {},
                c = t.split(".")[0];
            return t = t.split(".")[1], r = c + "-" + t, i || (i = n, n = e.Widget), e.expr[":"][r.toLowerCase()] = function(t) {
                return !!e.data(t, r)
            }, e[c] = e[c] || {}, o = e[c][t], a = e[c][t] = function(e, t) {
                return this._createWidget ? void(arguments.length && this._createWidget(e, t)) : new a(e, t)
            }, e.extend(a, o, {
                version: i.version,
                _proto: e.extend({}, i),
                _childConstructors: []
            }), s = new n, s.options = e.widget.extend({}, s.options), e.each(i, function(t, i) {
                return e.isFunction(i) ? void(u[t] = function() {
                    var e = function() {
                            return n.prototype[t].apply(this, arguments)
                        },
                        r = function(e) {
                            return n.prototype[t].apply(this, e)
                        };
                    return function() {
                        var t, n = this._super,
                            o = this._superApply;
                        return this._super = e, this._superApply = r, t = i.apply(this, arguments), this._super = n, this._superApply = o, t
                    }
                }()) : void(u[t] = i)
            }), a.prototype = e.widget.extend(s, {
                widgetEventPrefix: o ? s.widgetEventPrefix || t : t
            }, u, {
                constructor: a,
                namespace: c,
                widgetName: t,
                widgetFullName: r
            }), o ? (e.each(o._childConstructors, function(t, n) {
                var i = n.prototype;
                e.widget(i.namespace + "." + i.widgetName, a, n._proto)
            }), delete o._childConstructors) : n._childConstructors.push(a), e.widget.bridge(t, a), a
        }, e.widget.extend = function(t) {
            for (var i, r, o = n.call(arguments, 1), a = 0, s = o.length; s > a; a++)
                for (i in o[a]) r = o[a][i], o[a].hasOwnProperty(i) && void 0 !== r && (e.isPlainObject(r) ? t[i] = e.isPlainObject(t[i]) ? e.widget.extend({}, t[i], r) : e.widget.extend({}, r) : t[i] = r);
            return t
        }, e.widget.bridge = function(t, i) {
            var r = i.prototype.widgetFullName || t;
            e.fn[t] = function(o) {
                var a = "string" == typeof o,
                    s = n.call(arguments, 1),
                    u = this;
                return o = !a && s.length ? e.widget.extend.apply(null, [o].concat(s)) : o, a ? this.each(function() {
                    var n, i = e.data(this, r);
                    return "instance" === o ? (u = i, !1) : i ? e.isFunction(i[o]) && "_" !== o.charAt(0) ? (n = i[o].apply(i, s), n !== i && void 0 !== n ? (u = n && n.jquery ? u.pushStack(n.get()) : n, !1) : void 0) : e.error("no such method '" + o + "' for " + t + " widget instance") : e.error("cannot call methods on " + t + " prior to initialization; attempted to call method '" + o + "'")
                }) : this.each(function() {
                    var t = e.data(this, r);
                    t ? (t.option(o || {}), t._init && t._init()) : e.data(this, r, new i(o, this))
                }), u
            }
        }, e.Widget = function() {}, e.Widget._childConstructors = [], e.Widget.prototype = {
            widgetName: "widget",
            widgetEventPrefix: "",
            defaultElement: "<div>",
            options: {
                disabled: !1,
                create: null
            },
            _createWidget: function(n, i) {
                i = e(i || this.defaultElement || this)[0], this.element = e(i), this.uuid = t++, this.eventNamespace = "." + this.widgetName + this.uuid, this.options = e.widget.extend({}, this.options, this._getCreateOptions(), n), this.bindings = e(), this.hoverable = e(), this.focusable = e(), i !== this && (e.data(i, this.widgetFullName, this), this._on(!0, this.element, {
                    remove: function(e) {
                        e.target === i && this.destroy()
                    }
                }), this.document = e(i.style ? i.ownerDocument : i.document || i), this.window = e(this.document[0].defaultView || this.document[0].parentWindow)), this._create(), this._trigger("create", null, this._getCreateEventData()), this._init()
            },
            _getCreateOptions: e.noop,
            _getCreateEventData: e.noop,
            _create: e.noop,
            _init: e.noop,
            destroy: function() {
                this._destroy(), this.element.unbind(this.eventNamespace).removeData(this.widgetFullName).removeData(e.camelCase(this.widgetFullName)), this.widget().unbind(this.eventNamespace).removeAttr("aria-disabled").removeClass(this.widgetFullName + "-disabled ui-state-disabled"), this.bindings.unbind(this.eventNamespace), this.hoverable.removeClass("ui-state-hover"), this.focusable.removeClass("ui-state-focus")
            },
            _destroy: e.noop,
            widget: function() {
                return this.element
            },
            option: function(t, n) {
                var i, r, o, a = t;
                if (0 === arguments.length) return e.widget.extend({}, this.options);
                if ("string" == typeof t)
                    if (a = {}, i = t.split("."), t = i.shift(), i.length) {
                        for (r = a[t] = e.widget.extend({}, this.options[t]), o = 0; o < i.length - 1; o++) r[i[o]] = r[i[o]] || {}, r = r[i[o]];
                        if (t = i.pop(), 1 === arguments.length) return void 0 === r[t] ? null : r[t];
                        r[t] = n
                    } else {
                        if (1 === arguments.length) return void 0 === this.options[t] ? null : this.options[t];
                        a[t] = n
                    }
                return this._setOptions(a), this
            },
            _setOptions: function(e) {
                var t;
                for (t in e) this._setOption(t, e[t]);
                return this
            },
            _setOption: function(e, t) {
                return this.options[e] = t, "disabled" === e && (this.widget().toggleClass(this.widgetFullName + "-disabled", !!t), t && (this.hoverable.removeClass("ui-state-hover"), this.focusable.removeClass("ui-state-focus"))), this
            },
            enable: function() {
                return this._setOptions({
                    disabled: !1
                })
            },
            disable: function() {
                return this._setOptions({
                    disabled: !0
                })
            },
            _on: function(t, n, i) {
                var r, o = this;
                "boolean" != typeof t && (i = n, n = t, t = !1), i ? (n = r = e(n), this.bindings = this.bindings.add(n)) : (i = n, n = this.element, r = this.widget()), e.each(i, function(i, a) {
                    function s() {
                        return t || o.options.disabled !== !0 && !e(this).hasClass("ui-state-disabled") ? ("string" == typeof a ? o[a] : a).apply(o, arguments) : void 0
                    }
                    "string" != typeof a && (s.guid = a.guid = a.guid || s.guid || e.guid++);
                    var u = i.match(/^([\w:-]*)\s*(.*)$/),
                        c = u[1] + o.eventNamespace,
                        l = u[2];
                    l ? r.delegate(l, c, s) : n.bind(c, s)
                })
            },
            _off: function(e, t) {
                t = (t || "").split(" ").join(this.eventNamespace + " ") + this.eventNamespace, e.unbind(t).undelegate(t)
            },
            _delay: function(e, t) {
                function n() {
                    return ("string" == typeof e ? i[e] : e).apply(i, arguments)
                }
                var i = this;
                return setTimeout(n, t || 0)
            },
            _hoverable: function(t) {
                this.hoverable = this.hoverable.add(t), this._on(t, {
                    mouseenter: function(t) {
                        e(t.currentTarget).addClass("ui-state-hover")
                    },
                    mouseleave: function(t) {
                        e(t.currentTarget).removeClass("ui-state-hover")
                    }
                })
            },
            _focusable: function(t) {
                this.focusable = this.focusable.add(t), this._on(t, {
                    focusin: function(t) {
                        e(t.currentTarget).addClass("ui-state-focus")
                    },
                    focusout: function(t) {
                        e(t.currentTarget).removeClass("ui-state-focus")
                    }
                })
            },
            _trigger: function(t, n, i) {
                var r, o, a = this.options[t];
                if (i = i || {}, n = e.Event(n), n.type = (t === this.widgetEventPrefix ? t : this.widgetEventPrefix + t).toLowerCase(), n.target = this.element[0], o = n.originalEvent)
                    for (r in o) r in n || (n[r] = o[r]);
                return this.element.trigger(n, i), !(e.isFunction(a) && a.apply(this.element[0], [n].concat(i)) === !1 || n.isDefaultPrevented())
            }
        }, e.each({
            show: "fadeIn",
            hide: "fadeOut"
        }, function(t, n) {
            e.Widget.prototype["_" + t] = function(i, r, o) {
                "string" == typeof r && (r = {
                    effect: r
                });
                var a, s = r ? r === !0 || "number" == typeof r ? n : r.effect || n : t;
                r = r || {}, "number" == typeof r && (r = {
                    duration: r
                }), a = !e.isEmptyObject(r), r.complete = o, r.delay && i.delay(r.delay), a && e.effects && e.effects.effect[s] ? i[t](r) : s !== t && i[s] ? i[s](r.duration, r.easing, o) : i.queue(function(n) {
                    e(this)[t](), o && o.call(i[0]), n()
                })
            }
        });
        e.widget
    }),
    function(e) {
        "use strict";
        "function" == typeof define && define.amd ? define(["jquery"], e) : e(window.jQuery)
    }(function(e) {
        "use strict";
        var t = 0;
        e.ajaxTransport("iframe", function(n) {
            if (n.async) {
                var i, r, o, a = n.initialIframeSrc || "javascript:false;";
                return {
                    send: function(s, u) {
                        i = e('<form style="display:none;"></form>'), i.attr("accept-charset", n.formAcceptCharset), o = /\?/.test(n.url) ? "&" : "?", "DELETE" === n.type ? (n.url = n.url + o + "_method=DELETE", n.type = "POST") : "PUT" === n.type ? (n.url = n.url + o + "_method=PUT", n.type = "POST") : "PATCH" === n.type && (n.url = n.url + o + "_method=PATCH", n.type = "POST"), t += 1, r = e('<iframe src="' + a + '" name="iframe-transport-' + t + '"></iframe>').bind("load", function() {
                            var t, o = e.isArray(n.paramName) ? n.paramName : [n.paramName];
                            r.unbind("load").bind("load", function() {
                                var t;
                                try {
                                    if (t = r.contents(), !t.length || !t[0].firstChild) throw new Error
                                } catch (n) {
                                    t = void 0
                                }
                                u(200, "success", {
                                    iframe: t
                                }), e('<iframe src="' + a + '"></iframe>').appendTo(i), window.setTimeout(function() {
                                    i.remove()
                                }, 0)
                            }), i.prop("target", r.prop("name")).prop("action", n.url).prop("method", n.type), n.formData && e.each(n.formData, function(t, n) {
                                e('<input type="hidden"/>').prop("name", n.name).val(n.value).appendTo(i)
                            }), n.fileInput && n.fileInput.length && "POST" === n.type && (t = n.fileInput.clone(), n.fileInput.after(function(e) {
                                return t[e]
                            }), n.paramName && n.fileInput.each(function(t) {
                                e(this).prop("name", o[t] || n.paramName)
                            }), i.append(n.fileInput).prop("enctype", "multipart/form-data").prop("encoding", "multipart/form-data"), n.fileInput.removeAttr("form")), i.submit(), t && t.length && n.fileInput.each(function(n, i) {
                                var r = e(t[n]);
                                e(i).prop("name", r.prop("name")).attr("form", r.attr("form")), r.replaceWith(i)
                            })
                        }), i.append(r).appendTo(document.body)
                    },
                    abort: function() {
                        r && r.unbind("load").prop("src", a), i && i.remove()
                    }
                }
            }
        }), e.ajaxSetup({
            converters: {
                "iframe text": function(t) {
                    return t && e(t[0].body).text()
                },
                "iframe json": function(t) {
                    return t && e.parseJSON(e(t[0].body).text())
                },
                "iframe html": function(t) {
                    return t && e(t[0].body).html()
                },
                "iframe xml": function(t) {
                    var n = t && t[0];
                    return n && e.isXMLDoc(n) ? n : e.parseXML(n.XMLDocument && n.XMLDocument.xml || e(n.body).html())
                },
                "iframe script": function(t) {
                    return t && e.globalEval(e(t[0].body).text())
                }
            }
        })
    }),
    function(e) {
        "use strict";
        "function" == typeof define && define.amd ? define(["jquery", "jquery.ui.widget"], e) : e(window.jQuery)
    }(function(e) {
        "use strict";

        function t(t) {
            var n = "dragover" === t;
            return function(i) {
                i.dataTransfer = i.originalEvent && i.originalEvent.dataTransfer;
                var r = i.dataTransfer;
                r && -1 !== e.inArray("Files", r.types) && this._trigger(t, e.Event(t, {
                    delegatedEvent: i
                })) !== !1 && (i.preventDefault(), n && (r.dropEffect = "copy"))
            }
        }
        e.support.fileInput = !(new RegExp("(Android (1\\.[0156]|2\\.[01]))|(Windows Phone (OS 7|8\\.0))|(XBLWP)|(ZuneWP)|(WPDesktop)|(w(eb)?OSBrowser)|(webOS)|(Kindle/(1\\.0|2\\.[05]|3\\.0))").test(window.navigator.userAgent) || e('<input type="file">').prop("disabled")), e.support.xhrFileUpload = !(!window.ProgressEvent || !window.FileReader), e.support.xhrFormDataFileUpload = !!window.FormData, e.support.blobSlice = window.Blob && (Blob.prototype.slice || Blob.prototype.webkitSlice || Blob.prototype.mozSlice), e.widget("blueimp.fileupload", {
            options: {
                dropZone: e(document),
                pasteZone: void 0,
                fileInput: void 0,
                replaceFileInput: !0,
                paramName: void 0,
                singleFileUploads: !0,
                limitMultiFileUploads: void 0,
                limitMultiFileUploadSize: void 0,
                limitMultiFileUploadSizeOverhead: 512,
                sequentialUploads: !1,
                limitConcurrentUploads: void 0,
                forceIframeTransport: !1,
                redirect: void 0,
                redirectParamName: void 0,
                postMessage: void 0,
                multipart: !0,
                maxChunkSize: void 0,
                uploadedBytes: void 0,
                recalculateProgress: !0,
                progressInterval: 100,
                bitrateInterval: 500,
                autoUpload: !0,
                messages: {
                    uploadedBytes: "Uploaded bytes exceed file size"
                },
                i18n: function(t, n) {
                    return t = this.messages[t] || t.toString(), n && e.each(n, function(e, n) {
                        t = t.replace("{" + e + "}", n)
                    }), t
                },
                formData: function(e) {
                    return e.serializeArray()
                },
                add: function(t, n) {
                    return t.isDefaultPrevented() ? !1 : void((n.autoUpload || n.autoUpload !== !1 && e(this).fileupload("option", "autoUpload")) && n.process().done(function() {
                        n.submit()
                    }))
                },
                processData: !1,
                contentType: !1,
                cache: !1
            },
            _specialOptions: ["fileInput", "dropZone", "pasteZone", "multipart", "forceIframeTransport"],
            _blobSlice: e.support.blobSlice && function() {
                var e = this.slice || this.webkitSlice || this.mozSlice;
                return e.apply(this, arguments)
            },
            _BitrateTimer: function() {
                this.timestamp = Date.now ? Date.now() : (new Date).getTime(), this.loaded = 0, this.bitrate = 0, this.getBitrate = function(e, t, n) {
                    var i = e - this.timestamp;
                    return (!this.bitrate || !n || i > n) && (this.bitrate = (t - this.loaded) * (1e3 / i) * 8, this.loaded = t, this.timestamp = e), this.bitrate
                }
            },
            _isXHRUpload: function(t) {
                return !t.forceIframeTransport && (!t.multipart && e.support.xhrFileUpload || e.support.xhrFormDataFileUpload)
            },
            _getFormData: function(t) {
                var n;
                return "function" === e.type(t.formData) ? t.formData(t.form) : e.isArray(t.formData) ? t.formData : "object" === e.type(t.formData) ? (n = [], e.each(t.formData, function(e, t) {
                    n.push({
                        name: e,
                        value: t
                    })
                }), n) : []
            },
            _getTotal: function(t) {
                var n = 0;
                return e.each(t, function(e, t) {
                    n += t.size || 1
                }), n
            },
            _initProgressObject: function(t) {
                var n = {
                    loaded: 0,
                    total: 0,
                    bitrate: 0
                };
                t._progress ? e.extend(t._progress, n) : t._progress = n
            },
            _initResponseObject: function(e) {
                var t;
                if (e._response)
                    for (t in e._response) e._response.hasOwnProperty(t) && delete e._response[t];
                else e._response = {}
            },
            _onProgress: function(t, n) {
                if (t.lengthComputable) {
                    var i, r = Date.now ? Date.now() : (new Date).getTime();
                    if (n._time && n.progressInterval && r - n._time < n.progressInterval && t.loaded !== t.total) return;
                    n._time = r, i = Math.floor(t.loaded / t.total * (n.chunkSize || n._progress.total)) + (n.uploadedBytes || 0), this._progress.loaded += i - n._progress.loaded, this._progress.bitrate = this._bitrateTimer.getBitrate(r, this._progress.loaded, n.bitrateInterval), n._progress.loaded = n.loaded = i, n._progress.bitrate = n.bitrate = n._bitrateTimer.getBitrate(r, i, n.bitrateInterval), this._trigger("progress", e.Event("progress", {
                        delegatedEvent: t
                    }), n), this._trigger("progressall", e.Event("progressall", {
                        delegatedEvent: t
                    }), this._progress)
                }
            },
            _initProgressListener: function(t) {
                var n = this,
                    i = t.xhr ? t.xhr() : e.ajaxSettings.xhr();
                i.upload && (e(i.upload).bind("progress", function(e) {
                    var i = e.originalEvent;
                    e.lengthComputable = i.lengthComputable, e.loaded = i.loaded, e.total = i.total, n._onProgress(e, t)
                }), t.xhr = function() {
                    return i
                })
            },
            _isInstanceOf: function(e, t) {
                return Object.prototype.toString.call(t) === "[object " + e + "]"
            },
            _initXHRData: function(t) {
                var n, i = this,
                    r = t.files[0],
                    o = t.multipart || !e.support.xhrFileUpload,
                    a = "array" === e.type(t.paramName) ? t.paramName[0] : t.paramName;
                t.headers = e.extend({}, t.headers), t.contentRange && (t.headers["Content-Range"] = t.contentRange), o && !t.blob && this._isInstanceOf("File", r) || (t.headers["Content-Disposition"] = 'attachment; filename="' + encodeURI(r.name) + '"'), o ? e.support.xhrFormDataFileUpload && (t.postMessage ? (n = this._getFormData(t), t.blob ? n.push({
                    name: a,
                    value: t.blob
                }) : e.each(t.files, function(i, r) {
                    n.push({
                        name: "array" === e.type(t.paramName) && t.paramName[i] || a,
                        value: r
                    })
                })) : (i._isInstanceOf("FormData", t.formData) ? n = t.formData : (n = new FormData, e.each(this._getFormData(t), function(e, t) {
                    n.append(t.name, t.value)
                })), t.blob ? n.append(a, t.blob, r.name) : e.each(t.files, function(r, o) {
                    (i._isInstanceOf("File", o) || i._isInstanceOf("Blob", o)) && n.append("array" === e.type(t.paramName) && t.paramName[r] || a, o, o.uploadName || o.name)
                })), t.data = n) : (t.contentType = r.type || "application/octet-stream", t.data = t.blob || r), t.blob = null
            },
            _initIframeSettings: function(t) {
                var n = e("<a></a>").prop("href", t.url).prop("host");
                t.dataType = "iframe " + (t.dataType || ""), t.formData = this._getFormData(t), t.redirect && n && n !== location.host && t.formData.push({
                    name: t.redirectParamName || "redirect",
                    value: t.redirect
                })
            },
            _initDataSettings: function(e) {
                this._isXHRUpload(e) ? (this._chunkedUpload(e, !0) || (e.data || this._initXHRData(e), this._initProgressListener(e)), e.postMessage && (e.dataType = "postmessage " + (e.dataType || ""))) : this._initIframeSettings(e)
            },
            _getParamName: function(t) {
                var n = e(t.fileInput),
                    i = t.paramName;
                return i ? e.isArray(i) || (i = [i]) : (i = [], n.each(function() {
                    for (var t = e(this), n = t.prop("name") || "files[]", r = (t.prop("files") || [1]).length; r;) i.push(n), r -= 1
                }), i.length || (i = [n.prop("name") || "files[]"])), i
            },
            _initFormSettings: function(t) {
                t.form && t.form.length || (t.form = e(t.fileInput.prop("form")), t.form.length || (t.form = e(this.options.fileInput.prop("form")))), t.paramName = this._getParamName(t), t.url || (t.url = t.form.prop("action") || location.href), t.type = (t.type || "string" === e.type(t.form.prop("method")) && t.form.prop("method") || "").toUpperCase(), "POST" !== t.type && "PUT" !== t.type && "PATCH" !== t.type && (t.type = "POST"), t.formAcceptCharset || (t.formAcceptCharset = t.form.attr("accept-charset"))
            },
            _getAJAXSettings: function(t) {
                var n = e.extend({}, this.options, t);
                return this._initFormSettings(n), this._initDataSettings(n), n
            },
            _getDeferredState: function(e) {
                return e.state ? e.state() : e.isResolved() ? "resolved" : e.isRejected() ? "rejected" : "pending"
            },
            _enhancePromise: function(e) {
                return e.success = e.done, e.error = e.fail, e.complete = e.always, e
            },
            _getXHRPromise: function(t, n, i) {
                var r = e.Deferred(),
                    o = r.promise();
                return n = n || this.options.context || o, t === !0 ? r.resolveWith(n, i) : t === !1 && r.rejectWith(n, i), o.abort = r.promise, this._enhancePromise(o)
            },
            _addConvenienceMethods: function(t, n) {
                var i = this,
                    r = function(t) {
                        return e.Deferred().resolveWith(i, t).promise()
                    };
                n.process = function(t, o) {
                    return (t || o) && (n._processQueue = this._processQueue = (this._processQueue || r([this])).pipe(function() {
                        return n.errorThrown ? e.Deferred().rejectWith(i, [n]).promise() : r(arguments)
                    }).pipe(t, o)), this._processQueue || r([this])
                }, n.submit = function() {
                    return "pending" !== this.state() && (n.jqXHR = this.jqXHR = i._trigger("submit", e.Event("submit", {
                        delegatedEvent: t
                    }), this) !== !1 && i._onSend(t, this)), this.jqXHR || i._getXHRPromise()
                }, n.abort = function() {
                    return this.jqXHR ? this.jqXHR.abort() : (this.errorThrown = "abort", i._trigger("fail", null, this), i._getXHRPromise(!1))
                }, n.state = function() {
                    return this.jqXHR ? i._getDeferredState(this.jqXHR) : this._processQueue ? i._getDeferredState(this._processQueue) : void 0
                }, n.processing = function() {
                    return !this.jqXHR && this._processQueue && "pending" === i._getDeferredState(this._processQueue)
                }, n.progress = function() {
                    return this._progress
                }, n.response = function() {
                    return this._response
                }
            },
            _getUploadedBytes: function(e) {
                var t = e.getResponseHeader("Range"),
                    n = t && t.split("-"),
                    i = n && n.length > 1 && parseInt(n[1], 10);
                return i && i + 1
            },
            _chunkedUpload: function(t, n) {
                t.uploadedBytes = t.uploadedBytes || 0;
                var i, r, o = this,
                    a = t.files[0],
                    s = a.size,
                    u = t.uploadedBytes,
                    c = t.maxChunkSize || s,
                    l = this._blobSlice,
                    d = e.Deferred(),
                    h = d.promise();
                return this._isXHRUpload(t) && l && (u || s > c) && !t.data ? n ? !0 : u >= s ? (a.error = t.i18n("uploadedBytes"), this._getXHRPromise(!1, t.context, [null, "error", a.error])) : (r = function() {
                    var n = e.extend({}, t),
                        h = n._progress.loaded;
                    n.blob = l.call(a, u, u + c, a.type), n.chunkSize = n.blob.size, n.contentRange = "bytes " + u + "-" + (u + n.chunkSize - 1) + "/" + s, o._initXHRData(n), o._initProgressListener(n), i = (o._trigger("chunksend", null, n) !== !1 && e.ajax(n) || o._getXHRPromise(!1, n.context)).done(function(i, a, c) {
                        u = o._getUploadedBytes(c) || u + n.chunkSize, h + n.chunkSize - n._progress.loaded && o._onProgress(e.Event("progress", {
                            lengthComputable: !0,
                            loaded: u - n.uploadedBytes,
                            total: u - n.uploadedBytes
                        }), n), t.uploadedBytes = n.uploadedBytes = u, n.result = i, n.textStatus = a, n.jqXHR = c, o._trigger("chunkdone", null, n), o._trigger("chunkalways", null, n), s > u ? r() : d.resolveWith(n.context, [i, a, c])
                    }).fail(function(e, t, i) {
                        n.jqXHR = e, n.textStatus = t, n.errorThrown = i, o._trigger("chunkfail", null, n), o._trigger("chunkalways", null, n), d.rejectWith(n.context, [e, t, i])
                    })
                }, this._enhancePromise(h), h.abort = function() {
                    return i.abort()
                }, r(), h) : !1
            },
            _beforeSend: function(e, t) {
                0 === this._active && (this._trigger("start"), this._bitrateTimer = new this._BitrateTimer, this._progress.loaded = this._progress.total = 0, this._progress.bitrate = 0), this._initResponseObject(t), this._initProgressObject(t), t._progress.loaded = t.loaded = t.uploadedBytes || 0, t._progress.total = t.total = this._getTotal(t.files) || 1, t._progress.bitrate = t.bitrate = 0, this._active += 1, this._progress.loaded += t.loaded, this._progress.total += t.total
            },
            _onDone: function(t, n, i, r) {
                var o = r._progress.total,
                    a = r._response;
                r._progress.loaded < o && this._onProgress(e.Event("progress", {
                    lengthComputable: !0,
                    loaded: o,
                    total: o
                }), r), a.result = r.result = t, a.textStatus = r.textStatus = n, a.jqXHR = r.jqXHR = i, this._trigger("done", null, r)
            },
            _onFail: function(e, t, n, i) {
                var r = i._response;
                i.recalculateProgress && (this._progress.loaded -= i._progress.loaded, this._progress.total -= i._progress.total), r.jqXHR = i.jqXHR = e, r.textStatus = i.textStatus = t, r.errorThrown = i.errorThrown = n, this._trigger("fail", null, i)
            },
            _onAlways: function(e, t, n, i) {
                this._trigger("always", null, i)
            },
            _onSend: function(t, n) {
                n.submit || this._addConvenienceMethods(t, n);
                var i, r, o, a, s = this,
                    u = s._getAJAXSettings(n),
                    c = function() {
                        return s._sending += 1, u._bitrateTimer = new s._BitrateTimer, i = i || ((r || s._trigger("send", e.Event("send", {
                            delegatedEvent: t
                        }), u) === !1) && s._getXHRPromise(!1, u.context, r) || s._chunkedUpload(u) || e.ajax(u)).done(function(e, t, n) {
                            s._onDone(e, t, n, u)
                        }).fail(function(e, t, n) {
                            s._onFail(e, t, n, u)
                        }).always(function(e, t, n) {
                            if (s._onAlways(e, t, n, u), s._sending -= 1, s._active -= 1, u.limitConcurrentUploads && u.limitConcurrentUploads > s._sending)
                                for (var i = s._slots.shift(); i;) {
                                    if ("pending" === s._getDeferredState(i)) {
                                        i.resolve();
                                        break
                                    }
                                    i = s._slots.shift()
                                }
                            0 === s._active && s._trigger("stop")
                        })
                    };
                return this._beforeSend(t, u), this.options.sequentialUploads || this.options.limitConcurrentUploads && this.options.limitConcurrentUploads <= this._sending ? (this.options.limitConcurrentUploads > 1 ? (o = e.Deferred(), this._slots.push(o), a = o.pipe(c)) : (this._sequence = this._sequence.pipe(c, c), a = this._sequence), a.abort = function() {
                    return r = [void 0, "abort", "abort"], i ? i.abort() : (o && o.rejectWith(u.context, r), c())
                }, this._enhancePromise(a)) : c()
            },
            _onAdd: function(t, n) {
                var i, r, o, a, s = this,
                    u = !0,
                    c = e.extend({}, this.options, n),
                    l = n.files,
                    d = l.length,
                    h = c.limitMultiFileUploads,
                    f = c.limitMultiFileUploadSize,
                    p = c.limitMultiFileUploadSizeOverhead,
                    g = 0,
                    m = this._getParamName(c),
                    v = 0;
                if (!f || d && void 0 !== l[0].size || (f = void 0), (c.singleFileUploads || h || f) && this._isXHRUpload(c))
                    if (c.singleFileUploads || f || !h)
                        if (!c.singleFileUploads && f)
                            for (o = [], i = [], a = 0; d > a; a += 1) g += l[a].size + p, (a + 1 === d || g + l[a + 1].size + p > f || h && a + 1 - v >= h) && (o.push(l.slice(v, a + 1)), r = m.slice(v, a + 1), r.length || (r = m), i.push(r), v = a + 1, g = 0);
                        else i = m;
                else
                    for (o = [], i = [], a = 0; d > a; a += h) o.push(l.slice(a, a + h)), r = m.slice(a, a + h), r.length || (r = m), i.push(r);
                else o = [l], i = [m];
                return n.originalFiles = l, e.each(o || l, function(r, a) {
                    var c = e.extend({}, n);
                    return c.files = o ? a : [a], c.paramName = i[r], s._initResponseObject(c), s._initProgressObject(c), s._addConvenienceMethods(t, c), u = s._trigger("add", e.Event("add", {
                        delegatedEvent: t
                    }), c)
                }), u
            },
            _replaceFileInput: function(t) {
                var n = t.fileInput,
                    i = n.clone(!0);
                t.fileInputClone = i, e("<form></form>").append(i)[0].reset(), n.after(i).detach(), e.cleanData(n.unbind("remove")), this.options.fileInput = this.options.fileInput.map(function(e, t) {
                    return t === n[0] ? i[0] : t
                }), n[0] === this.element[0] && (this.element = i)
            },
            _handleFileTreeEntry: function(t, n) {
                var i, r = this,
                    o = e.Deferred(),
                    a = function(e) {
                        e && !e.entry && (e.entry = t), o.resolve([e])
                    },
                    s = function(e) {
                        r._handleFileTreeEntries(e, n + t.name + "/").done(function(e) {
                            o.resolve(e)
                        }).fail(a)
                    },
                    u = function() {
                        i.readEntries(function(e) {
                            e.length ? (c = c.concat(e), u()) : s(c)
                        }, a)
                    },
                    c = [];
                return n = n || "", t.isFile ? t._file ? (t._file.relativePath = n, o.resolve(t._file)) : t.file(function(e) {
                    e.relativePath = n, o.resolve(e)
                }, a) : t.isDirectory ? (i = t.createReader(), u()) : o.resolve([]), o.promise()
            },
            _handleFileTreeEntries: function(t, n) {
                var i = this;
                return e.when.apply(e, e.map(t, function(e) {
                    return i._handleFileTreeEntry(e, n)
                })).pipe(function() {
                    return Array.prototype.concat.apply([], arguments)
                })
            },
            _getDroppedFiles: function(t) {
                t = t || {};
                var n = t.items;
                return n && n.length && (n[0].webkitGetAsEntry || n[0].getAsEntry) ? this._handleFileTreeEntries(e.map(n, function(e) {
                    var t;
                    return e.webkitGetAsEntry ? (t = e.webkitGetAsEntry(), t && (t._file = e.getAsFile()), t) : e.getAsEntry()
                })) : e.Deferred().resolve(e.makeArray(t.files)).promise()
            },
            _getSingleFileInputFiles: function(t) {
                t = e(t);
                var n, i, r = t.prop("webkitEntries") || t.prop("entries");
                if (r && r.length) return this._handleFileTreeEntries(r);
                if (n = e.makeArray(t.prop("files")), n.length) void 0 === n[0].name && n[0].fileName && e.each(n, function(e, t) {
                    t.name = t.fileName, t.size = t.fileSize
                });
                else {
                    if (i = t.prop("value"), !i) return e.Deferred().resolve([]).promise();
                    n = [{
                        name: i.replace(/^.*\\/, "")
                    }]
                }
                return e.Deferred().resolve(n).promise()
            },
            _getFileInputFiles: function(t) {
                return t instanceof e && 1 !== t.length ? e.when.apply(e, e.map(t, this._getSingleFileInputFiles)).pipe(function() {
                    return Array.prototype.concat.apply([], arguments)
                }) : this._getSingleFileInputFiles(t)
            },
            _onChange: function(t) {
                var n = this,
                    i = {
                        fileInput: e(t.target),
                        form: e(t.target.form)
                    };
                this._getFileInputFiles(i.fileInput).always(function(r) {
                    i.files = r, n.options.replaceFileInput && n._replaceFileInput(i), n._trigger("change", e.Event("change", {
                        delegatedEvent: t
                    }), i) !== !1 && n._onAdd(t, i)
                })
            },
            _onPaste: function(t) {
                var n = t.originalEvent && t.originalEvent.clipboardData && t.originalEvent.clipboardData.items,
                    i = {
                        files: []
                    };
                n && n.length && (e.each(n, function(e, t) {
                    var n = t.getAsFile && t.getAsFile();
                    n && i.files.push(n)
                }), this._trigger("paste", e.Event("paste", {
                    delegatedEvent: t
                }), i) !== !1 && this._onAdd(t, i))
            },
            _onDrop: function(t) {
                t.dataTransfer = t.originalEvent && t.originalEvent.dataTransfer;
                var n = this,
                    i = t.dataTransfer,
                    r = {};
                i && i.files && i.files.length && (t.preventDefault(), this._getDroppedFiles(i).always(function(i) {
                    r.files = i, n._trigger("drop", e.Event("drop", {
                        delegatedEvent: t
                    }), r) !== !1 && n._onAdd(t, r)
                }))
            },
            _onDragOver: t("dragover"),
            _onDragEnter: t("dragenter"),
            _onDragLeave: t("dragleave"),
            _initEventHandlers: function() {
                this._isXHRUpload(this.options) && (this._on(this.options.dropZone, {
                    dragover: this._onDragOver,
                    drop: this._onDrop,
                    dragenter: this._onDragEnter,
                    dragleave: this._onDragLeave
                }), this._on(this.options.pasteZone, {
                    paste: this._onPaste
                })), e.support.fileInput && this._on(this.options.fileInput, {
                    change: this._onChange
                })
            },
            _destroyEventHandlers: function() {
                this._off(this.options.dropZone, "dragenter dragleave dragover drop"), this._off(this.options.pasteZone, "paste"), this._off(this.options.fileInput, "change")
            },
            _setOption: function(t, n) {
                var i = -1 !== e.inArray(t, this._specialOptions);
                i && this._destroyEventHandlers(), this._super(t, n), i && (this._initSpecialOptions(), this._initEventHandlers())
            },
            _initSpecialOptions: function() {
                var t = this.options;
                void 0 === t.fileInput ? t.fileInput = this.element.is('input[type="file"]') ? this.element : this.element.find('input[type="file"]') : t.fileInput instanceof e || (t.fileInput = e(t.fileInput)), t.dropZone instanceof e || (t.dropZone = e(t.dropZone)), t.pasteZone instanceof e || (t.pasteZone = e(t.pasteZone))
            },
            _getRegExp: function(e) {
                var t = e.split("/"),
                    n = t.pop();
                return t.shift(), new RegExp(t.join("/"), n)
            },
            _isRegExpOption: function(t, n) {
                return "url" !== t && "string" === e.type(n) && /^\/.*\/[igm]{0,3}$/.test(n)
            },
            _initDataAttributes: function() {
                var t = this,
                    n = this.options,
                    i = e(this.element[0].cloneNode(!1)),
                    r = i.data();
                i.remove(), e.each(r, function(e, r) {
                    var o = "data-" + e.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
                    i.attr(o) && (t._isRegExpOption(e, r) && (r = t._getRegExp(r)), n[e] = r)
                })
            },
            _create: function() {
                this._initDataAttributes(), this._initSpecialOptions(), this._slots = [], this._sequence = this._getXHRPromise(!0), this._sending = this._active = 0, this._initProgressObject(this), this._initEventHandlers()
            },
            active: function() {
                return this._active
            },
            progress: function() {
                return this._progress
            },
            add: function(t) {
                var n = this;
                t && !this.options.disabled && (t.fileInput && !t.files ? this._getFileInputFiles(t.fileInput).always(function(e) {
                    t.files = e, n._onAdd(null, t)
                }) : (t.files = e.makeArray(t.files), this._onAdd(null, t)))
            },
            send: function(t) {
                if (t && !this.options.disabled) {
                    if (t.fileInput && !t.files) {
                        var n, i, r = this,
                            o = e.Deferred(),
                            a = o.promise();
                        return a.abort = function() {
                            return i = !0, n ? n.abort() : (o.reject(null, "abort", "abort"), a)
                        }, this._getFileInputFiles(t.fileInput).always(function(e) {
                            if (!i) {
                                if (!e.length) return void o.reject();
                                t.files = e, n = r._onSend(null, t), n.then(function(e, t, n) {
                                    o.resolve(e, t, n)
                                }, function(e, t, n) {
                                    o.reject(e, t, n)
                                })
                            }
                        }), this._enhancePromise(a)
                    }
                    if (t.files = e.makeArray(t.files), t.files.length) return this._onSend(null, t)
                }
                return this._getXHRPromise(!1, t && t.context)
            }
        })
    }),
    function(e) {
        "use strict";
        if ("function" == typeof define && define.amd) define(["jquery", "jquery.ui.widget", "jquery.iframe-transport", "jquery.fileupload"], e);
        else {
            var t = window.jQuery;
            e(t), t(function() {
                void 0 !== t.fn.cloudinary_fileupload && t("input.cloudinary-fileupload[type=file]").cloudinary_fileupload()
            })
        }
    }(function(e) {
        "use strict";

        function t(e) {
            if (null === e || "undefined" == typeof e) return "";
            var t, n, i = e + "",
                r = "",
                o = 0;
            t = n = 0, o = i.length;
            for (var a = 0; o > a; a++) {
                var s = i.charCodeAt(a),
                    u = null;
                128 > s ? n++ : u = s > 127 && 2048 > s ? String.fromCharCode(s >> 6 | 192, 63 & s | 128) : String.fromCharCode(s >> 12 | 224, s >> 6 & 63 | 128, 63 & s | 128), null !== u && (n > t && (r += i.slice(t, n)), r += u, t = n = a + 1)
            }
            return n > t && (r += i.slice(t, o)), r
        }

        function n(e) {
            e = t(e);
            var n = "00000000 77073096 EE0E612C 990951BA 076DC419 706AF48F E963A535 9E6495A3 0EDB8832 79DCB8A4 E0D5E91E 97D2D988 09B64C2B 7EB17CBD E7B82D07 90BF1D91 1DB71064 6AB020F2 F3B97148 84BE41DE 1ADAD47D 6DDDE4EB F4D4B551 83D385C7 136C9856 646BA8C0 FD62F97A 8A65C9EC 14015C4F 63066CD9 FA0F3D63 8D080DF5 3B6E20C8 4C69105E D56041E4 A2677172 3C03E4D1 4B04D447 D20D85FD A50AB56B 35B5A8FA 42B2986C DBBBC9D6 ACBCF940 32D86CE3 45DF5C75 DCD60DCF ABD13D59 26D930AC 51DE003A C8D75180 BFD06116 21B4F4B5 56B3C423 CFBA9599 B8BDA50F 2802B89E 5F058808 C60CD9B2 B10BE924 2F6F7C87 58684C11 C1611DAB B6662D3D 76DC4190 01DB7106 98D220BC EFD5102A 71B18589 06B6B51F 9FBFE4A5 E8B8D433 7807C9A2 0F00F934 9609A88E E10E9818 7F6A0DBB 086D3D2D 91646C97 E6635C01 6B6B51F4 1C6C6162 856530D8 F262004E 6C0695ED 1B01A57B 8208F4C1 F50FC457 65B0D9C6 12B7E950 8BBEB8EA FCB9887C 62DD1DDF 15DA2D49 8CD37CF3 FBD44C65 4DB26158 3AB551CE A3BC0074 D4BB30E2 4ADFA541 3DD895D7 A4D1C46D D3D6F4FB 4369E96A 346ED9FC AD678846 DA60B8D0 44042D73 33031DE5 AA0A4C5F DD0D7CC9 5005713C 270241AA BE0B1010 C90C2086 5768B525 206F85B3 B966D409 CE61E49F 5EDEF90E 29D9C998 B0D09822 C7D7A8B4 59B33D17 2EB40D81 B7BD5C3B C0BA6CAD EDB88320 9ABFB3B6 03B6E20C 74B1D29A EAD54739 9DD277AF 04DB2615 73DC1683 E3630B12 94643B84 0D6D6A3E 7A6A5AA8 E40ECF0B 9309FF9D 0A00AE27 7D079EB1 F00F9344 8708A3D2 1E01F268 6906C2FE F762575D 806567CB 196C3671 6E6B06E7 FED41B76 89D32BE0 10DA7A5A 67DD4ACC F9B9DF6F 8EBEEFF9 17B7BE43 60B08ED5 D6D6A3E8 A1D1937E 38D8C2C4 4FDFF252 D1BB67F1 A6BC5767 3FB506DD 48B2364B D80D2BDA AF0A1B4C 36034AF6 41047A60 DF60EFC3 A867DF55 316E8EEF 4669BE79 CB61B38C BC66831A 256FD2A0 5268E236 CC0C7795 BB0B4703 220216B9 5505262F C5BA3BBE B2BD0B28 2BB45A92 5CB36A04 C2D7FFA7 B5D0CF31 2CD99E8B 5BDEAE1D 9B64C2B0 EC63F226 756AA39C 026D930A 9C0906A9 EB0E363F 72076785 05005713 95BF4A82 E2B87A14 7BB12BAE 0CB61B38 92D28E9B E5D5BE0D 7CDCEFB7 0BDBDF21 86D3D2D4 F1D4E242 68DDB3F8 1FDA836E 81BE16CD F6B9265B 6FB077E1 18B74777 88085AE6 FF0F6A70 66063BCA 11010B5C 8F659EFF F862AE69 616BFFD3 166CCF45 A00AE278 D70DD2EE 4E048354 3903B3C2 A7672661 D06016F7 4969474D 3E6E77DB AED16A4A D9D65ADC 40DF0B66 37D83BF0 A9BCAE53 DEBB9EC5 47B2CF7F 30B5FFE9 BDBDF21C CABAC28A 53B39330 24B4A3A6 BAD03605 CDD70693 54DE5729 23D967BF B3667A2E C4614AB8 5D681B02 2A6F2B94 B40BBE37 C30C8EA1 5A05DF1B 2D02EF8D",
                i = 0,
                r = 0,
                o = 0;
            i = -1 ^ i;
            for (var a = 0, s = e.length; s > a; a++) o = 255 & (i ^ e.charCodeAt(a)), r = "0x" + n.substr(9 * o, 8), i = i >>> 8 ^ r;
            return i = -1 ^ i, 0 > i && (i += 4294967296), i
        }

        function i(e, t, n) {
            var i = e[t];
            return delete e[t], "undefined" == typeof i ? n : i
        }

        function r(t) {
            return null === t || "undefined" == typeof t ? [] : e.isArray(t) ? t : [t]
        }

        function o(e) {
            return "undefined" != typeof e && ("" + e).length > 0
        }

        function a(t) {
            for (var n = r(t.transformation), i = !0, o = 0; o < n.length; o++) i = i && "string" == typeof n[o];
            if (i) return [];
            delete t.transformation;
            for (var a = [], o = 0; o < n.length; o++) {
                var s = n[o];
                "string" == typeof s ? a.push("t_" + s) : a.push(c(e.extend({}, s)))
            }
            return a
        }

        function s(e) {
            var t = i(e, "size");
            if (t) {
                var n = t.split("x");
                e.width = n[0], e.height = n[1]
            }
        }

        function u(e) {
            var t = e.width,
                n = e.height,
                i = e.overlay || e.underlay,
                r = e.crop,
                o = !i && !e.angle && "fit" != r && "limit" != r && "lfill" != r;
            o && (t && !e.html_width && "auto" !== t && parseFloat(t) >= 1 && (e.html_width = t), n && !e.html_height && parseFloat(n) >= 1 && (e.html_height = n)), r || i || (delete e.width, delete e.height)
        }

        function c(e) {
            var t = a(e);
            s(e), u(e);
            var n = [];
            for (var r in C) {
                var c = i(e, r);
                o(c) && (k[r] && (c = k[r](c)), o(c) && n.push(C[r] + "_" + c))
            }
            n.sort();
            var l = i(e, "raw_transformation");
            o(l) && n.push(l);
            var d = n.join(",");
            return o(d) && t.push(d), t.join("/")
        }

        function l(e) {
            if (!e.match(/^https?:\//)) {
                var t = document.location.protocol + "//" + document.location.host;
                "?" == e[0] ? t += document.location.pathname : "/" != e[0] && (t += document.location.pathname.replace(/\/[^\/]*$/, "/")), e = t + e
            }
            return e
        }

        function d(e, t, i, r, o, a, s, u, c) {
            if (t.match(/^\//) && !s) return "/res" + t;
            var l = s ? "https://" : "file:" === window.location.protocol ? "file://" : "http://";
            l = c ? c + "//" : l;
            var d = !i;
            if (s) u && u != b || (u = i ? t + "-res.cloudinary.com" : _), d = d || u == _, null == o && d && (o = r), o && (u = u.replace("res.cloudinary.com", "res-" + (n(e) % 5 + 1) + ".cloudinary.com")), l += u;
            else if (a) {
                var h = r ? "a" + (n(e) % 5 + 1) + "." : "";
                l += h + a
            } else l += i ? t + "-res" : "res", l += r ? "-" + (n(e) % 5 + 1) : "",
                l += ".cloudinary.com";
            return d && (l += "/" + t), l
        }

        function h(e, t, n, i, r) {
            var o = e + "/" + t;
            if (n)
                if ("image/upload" == o) o = "images";
                else {
                    if ("raw/upload" != o) throw "URL Suffix only supported for image/upload and raw/upload";
                    o = "files"
                }
            if (i) {
                if ("image/upload" != o && "images" != o) throw "Root path only supported for image/upload";
                o = ""
            }
            return r && "image/upload" == o && (o = "iu"), o
        }

        function f(t, n) {
            n = n || {};
            var r = i(n, "type", "upload");
            "fetch" == r && (n.fetch_format = n.fetch_format || i(n, "format"));
            var a = c(n),
                s = i(n, "resource_type", "image"),
                u = i(n, "version"),
                f = i(n, "format"),
                p = i(n, "cloud_name", e.cloudinary.config().cloud_name);
            if (!p) throw "Unknown cloud_name";
            var g = i(n, "private_cdn", e.cloudinary.config().private_cdn),
                m = i(n, "secure_distribution", e.cloudinary.config().secure_distribution),
                v = i(n, "cname", e.cloudinary.config().cname),
                y = i(n, "cdn_subdomain", e.cloudinary.config().cdn_subdomain),
                b = i(n, "secure_cdn_subdomain", e.cloudinary.config().secure_cdn_subdomain),
                w = i(n, "shorten", e.cloudinary.config().shorten),
                _ = i(n, "secure", "https:" == window.location.protocol),
                C = i(n, "protocol", e.cloudinary.config().protocol),
                k = i(n, "trust_public_id"),
                E = i(n, "url_suffix"),
                S = i(n, "use_root_path", e.cloudinary.config().use_root_path);
            if (!g) {
                if (E) throw "URL Suffix only supported in private CDN";
                if (S) throw "Root path only supported in private CDN"
            }
            if ("fetch" == r && (t = l(t)), t.search("/") >= 0 && !t.match(/^v[0-9]+/) && !t.match(/^https?:\//) && !o(u) && (u = 1), t.match(/^https?:/)) {
                if ("upload" == r || "asset" == r) return t;
                t = encodeURIComponent(t).replace(/%3A/g, ":").replace(/%2F/g, "/")
            } else {
                if (t = encodeURIComponent(decodeURIComponent(t)).replace(/%3A/g, ":").replace(/%2F/g, "/"), E) {
                    if (E.match(/[\.\/]/)) throw "url_suffix should not include . or /";
                    t = t + "/" + E
                }
                f && (k || (t = t.replace(/\.(jpg|png|gif|webp)$/, "")), t = t + "." + f)
            }
            var x = h(s, r, E, S, w),
                T = d(t, p, g, y, b, v, _, m, C),
                B = [T, x, a, u ? "v" + u : "", t].join("/").replace(/([^:])\/+/g, "$1/");
            return B
        }

        function p(e) {
            return 10 * Math.ceil(e / 10)
        }

        function g(t, n) {
            e.cloudinary.config("dpr") && !n.dpr && (n.dpr = e.cloudinary.config("dpr"));
            var r = f(t, n),
                o = i(n, "html_width"),
                a = i(n, "html_height");
            return o && (n.width = o), a && (n.height = a), r
        }

        function m(t, n, i) {
            var r = n[t] || e.cloudinary.config(t);
            return "undefined" == typeof r && (r = i), r
        }

        function v(e, t) {
            for (var n = e.length - 2; n >= 0 && e[n] >= t;) n--;
            return e[n + 1]
        }
        var y = "d3jpl91pxevbkh.cloudfront.net",
            b = "cloudinary-a.akamaihd.net",
            w = "res.cloudinary.com",
            _ = w,
            C = {
                angle: "a",
                background: "b",
                border: "bo",
                color: "co",
                color_space: "cs",
                crop: "c",
                default_image: "d",
                delay: "dl",
                density: "dn",
                dpr: "dpr",
                effect: "e",
                fetch_format: "f",
                flags: "fl",
                gravity: "g",
                height: "h",
                opacity: "o",
                overlay: "l",
                page: "pg",
                prefix: "p",
                quality: "q",
                radius: "r",
                transformation: "t",
                underlay: "u",
                width: "w",
                x: "x",
                y: "y"
            },
            k = {
                angle: function(e) {
                    return r(e).join(".")
                },
                background: function(e) {
                    return e.replace(/^#/, "rgb:")
                },
                border: function(t) {
                    if (e.isPlainObject(t)) {
                        var n = "" + (t.width || 2),
                            i = (t.color || "black").replace(/^#/, "rgb:");
                        t = n + "px_solid_" + i
                    }
                    return t
                },
                color: function(e) {
                    return e.replace(/^#/, "rgb:")
                },
                dpr: function(e) {
                    return e = e.toString(), "auto" === e ? "1.0" : e.match(/^\d+$/) ? e + ".0" : e
                },
                effect: function(e) {
                    return r(e).join(":")
                },
                flags: function(e) {
                    return r(e).join(".")
                },
                transformation: function(e) {
                    return r(e).join(".")
                }
            },
            E = null,
            S = null,
            x = !1,
            T = {};
        e.cloudinary = {
            CF_SHARED_CDN: y,
            OLD_AKAMAI_SHARED_CDN: b,
            AKAMAI_SHARED_CDN: w,
            SHARED_CDN: _,
            config: function(t, n) {
                if (E || (E = {}, e('meta[name^="cloudinary_"]').each(function() {
                        E[e(this).attr("name").replace("cloudinary_", "")] = e(this).attr("content")
                    })), "undefined" != typeof n) E[t] = n;
                else {
                    if ("string" == typeof t) return E[t];
                    t && (E = t)
                }
                return E
            },
            url: function(t, n) {
                return n = e.extend({}, n), f(t, n)
            },
            url_internal: f,
            transformation_string: function(t) {
                return t = e.extend({}, t), c(t)
            },
            image: function(t, n) {
                n = e.extend({}, n);
                var i = g(t, n),
                    r = e("<img/>").data("src-cache", i).attr(n).cloudinary_update(n);
                return r
            },
            facebook_profile_image: function(t, n) {
                return e.cloudinary.image(t, e.extend({
                    type: "facebook"
                }, n))
            },
            twitter_profile_image: function(t, n) {
                return e.cloudinary.image(t, e.extend({
                    type: "twitter"
                }, n))
            },
            twitter_name_profile_image: function(t, n) {
                return e.cloudinary.image(t, e.extend({
                    type: "twitter_name"
                }, n))
            },
            gravatar_image: function(t, n) {
                return e.cloudinary.image(t, e.extend({
                    type: "gravatar"
                }, n))
            },
            fetch_image: function(t, n) {
                return e.cloudinary.image(t, e.extend({
                    type: "fetch"
                }, n))
            },
            sprite_css: function(t, n) {
                return n = e.extend({
                    type: "sprite"
                }, n), t.match(/.css$/) || (n.format = "css"), e.cloudinary.url(t, n)
            },
            responsive: function(t) {
                S = e.extend(S || {}, t), e("img.cld-responsive, img.cld-hidpi").cloudinary_update(S);
                var n = m("responsive_resize", S, !0);
                if (n && !x) {
                    S.resizing = x = !0;
                    var i = null;
                    e(window).on("resize", function() {
                        function t() {
                            i && (clearTimeout(i), i = null)
                        }

                        function n() {
                            e("img.cld-responsive").cloudinary_update(S)
                        }

                        function r() {
                            t(), setTimeout(function() {
                                t(), n()
                            }, o)
                        }
                        var o = m("responsive_debounce", S, 100);
                        o ? r() : n()
                    })
                }
            },
            calc_stoppoint: function(t, n) {
                var i = e(t).data("stoppoints") || e.cloudinary.config().stoppoints || p;
                return "function" == typeof i ? i(n) : ("string" == typeof i && (i = e.map(i.split(","), function(e) {
                    return parseInt(e)
                })), v(i, n))
            },
            device_pixel_ratio: function() {
                var t = window.devicePixelRatio || 1,
                    n = T[t];
                if (!n) {
                    var i = v(e.cloudinary.supported_dpr_values, t);
                    n = i.toString(), n.match(/^\d+$/) && (n += ".0"), T[t] = n
                }
                return n
            },
            supported_dpr_values: [.75, 1, 1.3, 1.5, 2, 3]
        }, e.fn.cloudinary = function(t) {
            return this.filter("img").each(function() {
                var n = e.extend({
                        width: e(this).attr("width"),
                        height: e(this).attr("height"),
                        src: e(this).attr("src")
                    }, e(this).data(), t),
                    r = i(n, "source", i(n, "src")),
                    o = g(r, n);
                e(this).data("src-cache", o).attr({
                    width: n.width,
                    height: n.height
                })
            }).cloudinary_update(t), this
        }, e.fn.cloudinary_update = function(t) {
            t = t || {};
            var n = m("responsive_use_stoppoints", t, "resize"),
                i = n === !1 || "resize" == n && !t.resizing;
            return this.filter("img").each(function() {
                t.responsive && e(this).addClass("cld-responsive");
                var n = {},
                    r = e(this).data("src-cache") || e(this).data("src");
                if (r) {
                    var o = e(this).hasClass("cld-responsive") && r.match(/\bw_auto\b/);
                    if (o) {
                        var a, s, u = e(this).parents(),
                            c = u.length,
                            l = 0;
                        for (s = 0; c > s; s += 1)
                            if (a = u[s], a && a.clientWidth) {
                                l = a.clientWidth;
                                break
                            }
                        if (0 == l) return;
                        var d = i ? l : e.cloudinary.calc_stoppoint(this, l),
                            h = e(this).data("width") || 0;
                        d > h ? e(this).data("width", d) : d = h, r = r.replace(/\bw_auto\b/g, "w_" + d), n.width = null, n.height = null
                    }
                    n.src = r.replace(/\bdpr_(1\.0|auto)\b/g, "dpr_" + e.cloudinary.device_pixel_ratio()), e(this).attr(n)
                }
            }), this
        };
        var B = null;
        e.fn.webpify = function(t, n) {
            var i = this;
            if (t = t || {}, n = n || t, !B) {
                B = e.Deferred();
                var r = new Image;
                r.onerror = B.reject, r.onload = B.resolve, r.src = "data:image/webp;base64,UklGRi4AAABXRUJQVlA4TCEAAAAvAUAAEB8wAiMwAgSSNtse/cXjxyCCmrYNWPwmHRH9jwMA"
            }
            return e(function() {
                B.done(function() {
                    e(i).cloudinary(e.extend({}, n, {
                        format: "webp"
                    }))
                }).fail(function() {
                    e(i).cloudinary(t)
                })
            }), this
        }, e.fn.fetchify = function(t) {
            return this.cloudinary(e.extend(t, {
                type: "fetch"
            }))
        }, e.fn.fileupload && (e.cloudinary.delete_by_token = function(t, n) {
            n = n || {};
            var i = n.url;
            if (!i) {
                var r = n.cloud_name || e.cloudinary.config().cloud_name;
                i = "https://api.cloudinary.com/v1_1/" + r + "/delete_by_token"
            }
            var o = e.support.xhrFileUpload ? "json" : "iframe json";
            return e.ajax({
                url: i,
                method: "POST",
                data: {
                    token: t
                },
                headers: {
                    "X-Requested-With": "XMLHttpRequest"
                },
                dataType: o
            })
        }, e.fn.cloudinary_fileupload = function(t) {
            var n = !this.data("blueimpFileupload");
            if (n && (t = e.extend({
                    maxFileSize: 2e7,
                    dataType: "json",
                    headers: {
                        "X-Requested-With": "XMLHttpRequest"
                    }
                }, t)), this.fileupload(t), n && (this.bind("fileuploaddone", function(t, n) {
                    if (!n.result.error) {
                        if (n.result.path = ["v", n.result.version, "/", n.result.public_id, n.result.format ? "." + n.result.format : ""].join(""), n.cloudinaryField && n.form.length > 0) {
                            var i = [n.result.resource_type, n.result.type, n.result.path].join("/") + "#" + n.result.signature,
                                r = e(t.target).prop("multiple"),
                                o = function() {
                                    e("<input></input>").attr({
                                        type: "hidden",
                                        name: n.cloudinaryField
                                    }).val(i).appendTo(n.form)
                                };
                            if (r) o();
                            else {
                                var a = e(n.form).find('input[name="' + n.cloudinaryField + '"]');
                                a.length > 0 ? a.val(i) : o()
                            }
                        }
                        e(t.target).trigger("cloudinarydone", n)
                    }
                }), this.bind("fileuploadstart", function(t) {
                    e(t.target).trigger("cloudinarystart")
                }), this.bind("fileuploadstop", function(t) {
                    e(t.target).trigger("cloudinarystop")
                }), this.bind("fileuploadprogress", function(t, n) {
                    e(t.target).trigger("cloudinaryprogress", n)
                }), this.bind("fileuploadprogressall", function(t, n) {
                    e(t.target).trigger("cloudinaryprogressall", n)
                }), this.bind("fileuploadfail", function(t, n) {
                    e(t.target).trigger("cloudinaryfail", n)
                }), this.bind("fileuploadalways", function(t, n) {
                    e(t.target).trigger("cloudinaryalways", n)
                }), !this.fileupload("option").url)) {
                var i = t.cloud_name || e.cloudinary.config().cloud_name,
                    r = "https://api.cloudinary.com/v1_1/" + i + "/upload";
                this.fileupload("option", "url", r)
            }
            return this
        }, e.fn.cloudinary_upload_url = function(e) {
            this.fileupload("option", "formData").file = e, this.fileupload("add", {
                files: [e]
            }), delete this.fileupload("option", "formData").file
        }, e.fn.unsigned_cloudinary_upload = function(t, n, i) {
            i = i || {}, n = e.extend({}, n) || {}, n.cloud_name && (i.cloud_name = n.cloud_name, delete n.cloud_name);
            for (var r in n) {
                var o = n[r];
                e.isPlainObject(o) ? n[r] = e.map(o, function(e, t) {
                    return t + "=" + e
                }).join("|") : e.isArray(o) && (o.length > 0 && e.isArray(o[0]) ? n[r] = e.map(o, function(e) {
                    return e.join(",")
                }).join("|") : n[r] = o.join(","))
            }
            n.callback || (n.callback = "/cloudinary_cors.html"), n.upload_preset = t, i.formData = n, i.cloudinary_field && (i.cloudinaryField = i.cloudinary_field, delete i.cloudinary_field);
            var a = i.html || {};
            return a["class"] = "cloudinary_fileupload " + (a["class"] || ""), i.multiple && (a.multiple = !0), this.attr(a).cloudinary_fileupload(i), this
        }, e.cloudinary.unsigned_upload_tag = function(t, n, i) {
            return e("<input/>").attr({
                type: "file",
                name: "file"
            }).unsigned_cloudinary_upload(t, n, i)
        })
    }),
    function() {
        $(document).ready(function() {
            $(".cloudinary-fileupload").bind("fileuploadsend", function(e, t) {
                return $("<img class='upload-spinner' src='/assets/spinner-dc1c4581975d1ebc98a6f646705fa47bae7928877397b021e09e44f88b1605f6.gif'>").insertAfter(e.delegateTarget), $(".save-btn").each(function() {
                    $(this).prop("disabled", !0)
                }), !0
            }), $(".cloudinary-fileupload").bind("fileuploaddone", function(e, t) {
                var n, i;
                return $($(e.delegateTarget).next(".upload-spinner")).remove(), i = $(e.delegateTarget).next("div"), i.show(), $(".save-btn").each(function() {
                    $(this).prop("disabled", !1)
                }), n = i[0], n && i.html($.cloudinary.image(t.result.public_id, {
                    format: t.result.format,
                    crop: n.getAttribute("crop"),
                    width: n.getAttribute("preview-width"),
                    height: n.getAttribute("preview-height"),
                    secure: !0
                })), $(this).remove(), !0
            }), $(".cloudinary-fileupload").bind("fileuploadfail", function(e, t) {
                return $($(e.delegateTarget).next()).remove(), $(".save-btn").each(function() {
                    $(this).prop("disabled", !1)
                }), !0
            }), $(".cloudinary-fileupload").fileupload({
                acceptFileTypes: /(\.|\/)(gif|jpe?g|png|bmp|ico)$/i,
                maxFileSize: 2e7,
                replaceFileInput: !1,
                maxNumberOfFiles: 1
            })
        })
    }.call(this),
    function(e) {
        "use strict";
        var t = function(e, n, i) {
                var r, o, a = document.createElement("img");
                if (a.onerror = n, a.onload = function() {
                        !o || i && i.noRevoke || t.revokeObjectURL(o), n && n(t.scale(a, i))
                    }, t.isInstanceOf("Blob", e) || t.isInstanceOf("File", e)) r = o = t.createObjectURL(e), a._type = e.type;
                else {
                    if ("string" != typeof e) return !1;
                    r = e, i && i.crossOrigin && (a.crossOrigin = i.crossOrigin)
                }
                return r ? (a.src = r, a) : t.readFile(e, function(e) {
                    var t = e.target;
                    t && t.result ? a.src = t.result : n && n(e)
                })
            },
            n = window.createObjectURL && window || window.URL && URL.revokeObjectURL && URL || window.webkitURL && webkitURL;
        t.isInstanceOf = function(e, t) {
            return Object.prototype.toString.call(t) === "[object " + e + "]"
        }, t.transformCoordinates = function(e, t) {
            var n = e.getContext("2d"),
                i = e.width,
                r = e.height;
            switch (t > 4 && (e.width = r, e.height = i), t) {
                case 2:
                    n.translate(i, 0), n.scale(-1, 1);
                    break;
                case 3:
                    n.translate(i, r), n.rotate(Math.PI);
                    break;
                case 4:
                    n.translate(0, r), n.scale(1, -1);
                    break;
                case 5:
                    n.rotate(.5 * Math.PI), n.scale(1, -1);
                    break;
                case 6:
                    n.rotate(.5 * Math.PI), n.translate(0, -r);
                    break;
                case 7:
                    n.rotate(.5 * Math.PI), n.translate(i, -r), n.scale(-1, 1);
                    break;
                case 8:
                    n.rotate(-.5 * Math.PI), n.translate(-i, 0)
            }
        }, t.renderImageToCanvas = function(e, t, n, i, r, o, a, s, u, c) {
            return e.getContext("2d").drawImage(t, n, i, r, o, a, s, u, c), e
        }, t.scale = function(e, n) {
            n = n || {};
            var i, r, o, a, s, u, c, l = document.createElement("canvas"),
                d = e.getContext || (n.canvas || n.crop || n.orientation) && l.getContext,
                h = e.width,
                f = e.height,
                p = h,
                g = f,
                m = 0,
                v = 0,
                y = 0,
                b = 0;
            return d && n.orientation > 4 ? (i = n.maxHeight, r = n.maxWidth, o = n.minHeight, a = n.minWidth) : (i = n.maxWidth, r = n.maxHeight, o = n.minWidth, a = n.minHeight), d && i && r && n.crop ? (s = i, u = r, i / r > h / f ? (g = r * h / i, v = (f - g) / 2) : (p = i * f / r, m = (h - p) / 2)) : (s = h, u = f, c = Math.max((o || s) / s, (a || u) / u), c > 1 && (s = Math.ceil(s * c), u = Math.ceil(u * c)), c = Math.min((i || s) / s, (r || u) / u), 1 > c && (s = Math.ceil(s * c), u = Math.ceil(u * c))), d ? (l.width = s, l.height = u, t.transformCoordinates(l, n.orientation), t.renderImageToCanvas(l, e, m, v, p, g, y, b, s, u)) : (e.width = s, e.height = u, e)
        }, t.createObjectURL = function(e) {
            return n ? n.createObjectURL(e) : !1
        }, t.revokeObjectURL = function(e) {
            return n ? n.revokeObjectURL(e) : !1
        }, t.readFile = function(e, t, n) {
            if (window.FileReader) {
                var i = new FileReader;
                if (i.onload = i.onerror = t, n = n || "readAsDataURL", i[n]) return i[n](e), i
            }
            return !1
        }, "function" == typeof define && define.amd ? define(function() {
            return t
        }) : e.loadImage = t
    }(this),
    function(e) {
        "use strict";
        "function" == typeof define && define.amd ? define(["load-image"], e) : e(window.loadImage)
    }(function(e) {
        "use strict";
        if (window.navigator && window.navigator.platform && /iP(hone|od|ad)/.test(window.navigator.platform)) {
            var t = e.renderImageToCanvas;
            e.detectSubsampling = function(e) {
                var t, n;
                return e.width * e.height > 1048576 ? (t = document.createElement("canvas"), t.width = t.height = 1, n = t.getContext("2d"), n.drawImage(e, -e.width + 1, 0), 0 === n.getImageData(0, 0, 1, 1).data[3]) : !1
            }, e.detectVerticalSquash = function(e, t) {
                var n, i, r, o, a, s = document.createElement("canvas"),
                    u = s.getContext("2d");
                for (s.width = 1, s.height = t, u.drawImage(e, 0, 0), n = u.getImageData(0, 0, 1, t).data, i = 0, r = t, o = t; o > i;) a = n[4 * (o - 1) + 3], 0 === a ? r = o : i = o, o = r + i >> 1;
                return o / t || 1
            }, e.renderImageToCanvas = function(n, i, r, o, a, s, u, c, l, d) {
                if ("image/jpeg" === i._type) {
                    var h, f, p, g, m = n.getContext("2d"),
                        v = document.createElement("canvas"),
                        y = 1024,
                        b = v.getContext("2d");
                    if (v.width = y, v.height = y, m.save(), h = e.detectSubsampling(i), h && (a /= 2, s /= 2), f = e.detectVerticalSquash(i, s), h && 1 !== f) {
                        for (l = Math.ceil(y * l / a), d = Math.ceil(y * d / s / f), c = 0, g = 0; s > g;) {
                            for (u = 0, p = 0; a > p;) b.clearRect(0, 0, y, y), b.drawImage(i, r, o, a, s, -p, -g, a, s), m.drawImage(v, 0, 0, y, y, u, c, l, d), p += y, u += l;
                            g += y, c += d
                        }
                        return m.restore(), n
                    }
                }
                return t(n, i, r, o, a, s, u, c, l, d)
            }
        }
    }),
    function(e) {
        "use strict";
        "function" == typeof define && define.amd ? define(["load-image"], e) : e(window.loadImage)
    }(function(e) {
        "use strict";
        var t = window.Blob && (Blob.prototype.slice || Blob.prototype.webkitSlice || Blob.prototype.mozSlice);
        e.blobSlice = t && function() {
            var e = this.slice || this.webkitSlice || this.mozSlice;
            return e.apply(this, arguments)
        }, e.metaDataParsers = {
            jpeg: {
                65505: []
            }
        }, e.parseMetaData = function(t, n, i) {
            i = i || {};
            var r = this,
                o = {},
                a = !(window.DataView && t && t.size >= 12 && "image/jpeg" === t.type && e.blobSlice);
            (a || !e.readFile(e.blobSlice.call(t, 0, 131072), function(t) {
                var a, s, u, c, l = t.target.result,
                    d = new DataView(l),
                    h = 2,
                    f = d.byteLength - 4,
                    p = h;
                if (65496 === d.getUint16(0)) {
                    for (; f > h && (a = d.getUint16(h), a >= 65504 && 65519 >= a || 65534 === a);)
                        if (s = d.getUint16(h + 2) + 2, h + s > d.byteLength) console.log("Invalid meta data: Invalid segment size.");
                        else {
                            if (u = e.metaDataParsers.jpeg[a])
                                for (c = 0; u.length > c; c += 1) u[c].call(r, d, h, s, o, i);
                            h += s, p = h
                        }!i.disableImageHead && p > 6 && (o.imageHead = l.slice ? l.slice(0, p) : new Uint8Array(l).subarray(0, p))
                } else console.log("Invalid JPEG file: Missing JPEG marker.");
                n(o)
            }, "readAsArrayBuffer")) && n(o)
        }
    }),
    function(e) {
        "use strict";
        "function" == typeof define && define.amd ? define(["load-image", "load-image-meta"], e) : e(window.loadImage)
    }(function(e) {
        "use strict";
        e.ExifMap = function() {
            return this
        }, e.ExifMap.prototype.map = {
            Orientation: 274
        }, e.ExifMap.prototype.get = function(e) {
            return this[e] || this[this.map[e]]
        }, e.getExifThumbnail = function(e, t, n) {
            var i, r, o;
            if (!n || t + n > e.byteLength) return void console.log("Invalid Exif data: Invalid thumbnail data.");
            for (i = [], r = 0; n > r; r += 1) o = e.getUint8(t + r), i.push((16 > o ? "0" : "") + o.toString(16));
            return "data:image/jpeg,%" + i.join("%")
        }, e.exifTagTypes = {
            1: {
                getValue: function(e, t) {
                    return e.getUint8(t)
                },
                size: 1
            },
            2: {
                getValue: function(e, t) {
                    return String.fromCharCode(e.getUint8(t))
                },
                size: 1,
                ascii: !0
            },
            3: {
                getValue: function(e, t, n) {
                    return e.getUint16(t, n)
                },
                size: 2
            },
            4: {
                getValue: function(e, t, n) {
                    return e.getUint32(t, n)
                },
                size: 4
            },
            5: {
                getValue: function(e, t, n) {
                    return e.getUint32(t, n) / e.getUint32(t + 4, n)
                },
                size: 8
            },
            9: {
                getValue: function(e, t, n) {
                    return e.getInt32(t, n)
                },
                size: 4
            },
            10: {
                getValue: function(e, t, n) {
                    return e.getInt32(t, n) / e.getInt32(t + 4, n)
                },
                size: 8
            }
        }, e.exifTagTypes[7] = e.exifTagTypes[1], e.getExifValue = function(t, n, i, r, o, a) {
            var s, u, c, l, d, h, f = e.exifTagTypes[r];
            if (!f) return void console.log("Invalid Exif data: Invalid tag type.");
            if (s = f.size * o, u = s > 4 ? n + t.getUint32(i + 8, a) : i + 8, u + s > t.byteLength) return void console.log("Invalid Exif data: Invalid data offset.");
            if (1 === o) return f.getValue(t, u, a);
            for (c = [], l = 0; o > l; l += 1) c[l] = f.getValue(t, u + l * f.size, a);
            if (f.ascii) {
                for (d = "", l = 0; c.length > l && (h = c[l], "\x00" !== h); l += 1) d += h;
                return d
            }
            return c
        }, e.parseExifTag = function(t, n, i, r, o) {
            var a = t.getUint16(i, r);
            o.exif[a] = e.getExifValue(t, n, i, t.getUint16(i + 2, r), t.getUint32(i + 4, r), r)
        }, e.parseExifTags = function(e, t, n, i, r) {
            var o, a, s;
            if (n + 6 > e.byteLength) return void console.log("Invalid Exif data: Invalid directory offset.");
            if (o = e.getUint16(n, i), a = n + 2 + 12 * o, a + 4 > e.byteLength) return void console.log("Invalid Exif data: Invalid directory size.");
            for (s = 0; o > s; s += 1) this.parseExifTag(e, t, n + 2 + 12 * s, i, r);
            return e.getUint32(a, i)
        }, e.parseExifData = function(t, n, i, r, o) {
            if (!o.disableExif) {
                var a, s, u, c = n + 10;
                if (1165519206 === t.getUint32(n + 4)) {
                    if (c + 8 > t.byteLength) return void console.log("Invalid Exif data: Invalid segment size.");
                    if (0 !== t.getUint16(n + 8)) return void console.log("Invalid Exif data: Missing byte alignment offset.");
                    switch (t.getUint16(c)) {
                        case 18761:
                            a = !0;
                            break;
                        case 19789:
                            a = !1;
                            break;
                        default:
                            return void console.log("Invalid Exif data: Invalid byte alignment marker.")
                    }
                    if (42 !== t.getUint16(c + 2, a)) return void console.log("Invalid Exif data: Missing TIFF marker.");
                    s = t.getUint32(c + 4, a), r.exif = new e.ExifMap, s = e.parseExifTags(t, c, c + s, a, r), s && !o.disableExifThumbnail && (u = {
                        exif: {}
                    }, s = e.parseExifTags(t, c, c + s, a, u), u.exif[513] && (r.exif.Thumbnail = e.getExifThumbnail(t, c + u.exif[513], u.exif[514]))), r.exif[34665] && !o.disableExifSub && e.parseExifTags(t, c, c + r.exif[34665], a, r), r.exif[34853] && !o.disableExifGps && e.parseExifTags(t, c, c + r.exif[34853], a, r)
                }
            }
        }, e.metaDataParsers.jpeg[65505].push(e.parseExifData)
    }),
    function(e) {
        "use strict";
        "function" == typeof define && define.amd ? define(["load-image", "load-image-exif"], e) : e(window.loadImage)
    }(function(e) {
        "use strict";
        var t, n, i;
        e.ExifMap.prototype.tags = {
            256: "ImageWidth",
            257: "ImageHeight",
            34665: "ExifIFDPointer",
            34853: "GPSInfoIFDPointer",
            40965: "InteroperabilityIFDPointer",
            258: "BitsPerSample",
            259: "Compression",
            262: "PhotometricInterpretation",
            274: "Orientation",
            277: "SamplesPerPixel",
            284: "PlanarConfiguration",
            530: "YCbCrSubSampling",
            531: "YCbCrPositioning",
            282: "XResolution",
            283: "YResolution",
            296: "ResolutionUnit",
            273: "StripOffsets",
            278: "RowsPerStrip",
            279: "StripByteCounts",
            513: "JPEGInterchangeFormat",
            514: "JPEGInterchangeFormatLength",
            301: "TransferFunction",
            318: "WhitePoint",
            319: "PrimaryChromaticities",
            529: "YCbCrCoefficients",
            532: "ReferenceBlackWhite",
            306: "DateTime",
            270: "ImageDescription",
            271: "Make",
            272: "Model",
            305: "Software",
            315: "Artist",
            33432: "Copyright",
            36864: "ExifVersion",
            40960: "FlashpixVersion",
            40961: "ColorSpace",
            40962: "PixelXDimension",
            40963: "PixelYDimension",
            37121: "ComponentsConfiguration",
            37122: "CompressedBitsPerPixel",
            37500: "MakerNote",
            37510: "UserComment",
            40964: "RelatedSoundFile",
            36867: "DateTimeOriginal",
            36868: "DateTimeDigitized",
            37520: "SubsecTime",
            37521: "SubsecTimeOriginal",
            37522: "SubsecTimeDigitized",
            33434: "ExposureTime",
            33437: "FNumber",
            34850: "ExposureProgram",
            34852: "SpectralSensitivity",
            34855: "ISOSpeedRatings",
            34856: "OECF",
            37377: "ShutterSpeedValue",
            37378: "ApertureValue",
            37379: "BrightnessValue",
            37380: "ExposureBias",
            37381: "MaxApertureValue",
            37382: "SubjectDistance",
            37383: "MeteringMode",
            37384: "LightSource",
            37385: "Flash",
            37396: "SubjectArea",
            37386: "FocalLength",
            41483: "FlashEnergy",
            41484: "SpatialFrequencyResponse",
            41486: "FocalPlaneXResolution",
            41487: "FocalPlaneYResolution",
            41488: "FocalPlaneResolutionUnit",
            41492: "SubjectLocation",
            41493: "ExposureIndex",
            41495: "SensingMethod",
            41728: "FileSource",
            41729: "SceneType",
            41730: "CFAPattern",
            41985: "CustomRendered",
            41986: "ExposureMode",
            41987: "WhiteBalance",
            41988: "DigitalZoomRation",
            41989: "FocalLengthIn35mmFilm",
            41990: "SceneCaptureType",
            41991: "GainControl",
            41992: "Contrast",
            41993: "Saturation",
            41994: "Sharpness",
            41995: "DeviceSettingDescription",
            41996: "SubjectDistanceRange",
            42016: "ImageUniqueID",
            0: "GPSVersionID",
            1: "GPSLatitudeRef",
            2: "GPSLatitude",
            3: "GPSLongitudeRef",
            4: "GPSLongitude",
            5: "GPSAltitudeRef",
            6: "GPSAltitude",
            7: "GPSTimeStamp",
            8: "GPSSatellites",
            9: "GPSStatus",
            10: "GPSMeasureMode",
            11: "GPSDOP",
            12: "GPSSpeedRef",
            13: "GPSSpeed",
            14: "GPSTrackRef",
            15: "GPSTrack",
            16: "GPSImgDirectionRef",
            17: "GPSImgDirection",
            18: "GPSMapDatum",
            19: "GPSDestLatitudeRef",
            20: "GPSDestLatitude",
            21: "GPSDestLongitudeRef",
            22: "GPSDestLongitude",
            23: "GPSDestBearingRef",
            24: "GPSDestBearing",
            25: "GPSDestDistanceRef",
            26: "GPSDestDistance",
            27: "GPSProcessingMethod",
            28: "GPSAreaInformation",
            29: "GPSDateStamp",
            30: "GPSDifferential"
        }, e.ExifMap.prototype.stringValues = {
            ExposureProgram: {
                0: "Undefined",
                1: "Manual",
                2: "Normal program",
                3: "Aperture priority",
                4: "Shutter priority",
                5: "Creative program",
                6: "Action program",
                7: "Portrait mode",
                8: "Landscape mode"
            },
            MeteringMode: {
                0: "Unknown",
                1: "Average",
                2: "CenterWeightedAverage",
                3: "Spot",
                4: "MultiSpot",
                5: "Pattern",
                6: "Partial",
                255: "Other"
            },
            LightSource: {
                0: "Unknown",
                1: "Daylight",
                2: "Fluorescent",
                3: "Tungsten (incandescent light)",
                4: "Flash",
                9: "Fine weather",
                10: "Cloudy weather",
                11: "Shade",
                12: "Daylight fluorescent (D 5700 - 7100K)",
                13: "Day white fluorescent (N 4600 - 5400K)",
                14: "Cool white fluorescent (W 3900 - 4500K)",
                15: "White fluorescent (WW 3200 - 3700K)",
                17: "Standard light A",
                18: "Standard light B",
                19: "Standard light C",
                20: "D55",
                21: "D65",
                22: "D75",
                23: "D50",
                24: "ISO studio tungsten",
                255: "Other"
            },
            Flash: {
                0: "Flash did not fire",
                1: "Flash fired",
                5: "Strobe return light not detected",
                7: "Strobe return light detected",
                9: "Flash fired, compulsory flash mode",
                13: "Flash fired, compulsory flash mode, return light not detected",
                15: "Flash fired, compulsory flash mode, return light detected",
                16: "Flash did not fire, compulsory flash mode",
                24: "Flash did not fire, auto mode",
                25: "Flash fired, auto mode",
                29: "Flash fired, auto mode, return light not detected",
                31: "Flash fired, auto mode, return light detected",
                32: "No flash function",
                65: "Flash fired, red-eye reduction mode",
                69: "Flash fired, red-eye reduction mode, return light not detected",
                71: "Flash fired, red-eye reduction mode, return light detected",
                73: "Flash fired, compulsory flash mode, red-eye reduction mode",
                77: "Flash fired, compulsory flash mode, red-eye reduction mode, return light not detected",
                79: "Flash fired, compulsory flash mode, red-eye reduction mode, return light detected",
                89: "Flash fired, auto mode, red-eye reduction mode",
                93: "Flash fired, auto mode, return light not detected, red-eye reduction mode",
                95: "Flash fired, auto mode, return light detected, red-eye reduction mode"
            },
            SensingMethod: {
                1: "Undefined",
                2: "One-chip color area sensor",
                3: "Two-chip color area sensor",
                4: "Three-chip color area sensor",
                5: "Color sequential area sensor",
                7: "Trilinear sensor",
                8: "Color sequential linear sensor"
            },
            SceneCaptureType: {
                0: "Standard",
                1: "Landscape",
                2: "Portrait",
                3: "Night scene"
            },
            SceneType: {
                1: "Directly photographed"
            },
            CustomRendered: {
                0: "Normal process",
                1: "Custom process"
            },
            WhiteBalance: {
                0: "Auto white balance",
                1: "Manual white balance"
            },
            GainControl: {
                0: "None",
                1: "Low gain up",
                2: "High gain up",
                3: "Low gain down",
                4: "High gain down"
            },
            Contrast: {
                0: "Normal",
                1: "Soft",
                2: "Hard"
            },
            Saturation: {
                0: "Normal",
                1: "Low saturation",
                2: "High saturation"
            },
            Sharpness: {
                0: "Normal",
                1: "Soft",
                2: "Hard"
            },
            SubjectDistanceRange: {
                0: "Unknown",
                1: "Macro",
                2: "Close view",
                3: "Distant view"
            },
            FileSource: {
                3: "DSC"
            },
            ComponentsConfiguration: {
                0: "",
                1: "Y",
                2: "Cb",
                3: "Cr",
                4: "R",
                5: "G",
                6: "B"
            },
            Orientation: {
                1: "top-left",
                2: "top-right",
                3: "bottom-right",
                4: "bottom-left",
                5: "left-top",
                6: "right-top",
                7: "right-bottom",
                8: "left-bottom"
            }
        }, e.ExifMap.prototype.getText = function(e) {
            var t = this.get(e);
            switch (e) {
                case "LightSource":
                case "Flash":
                case "MeteringMode":
                case "ExposureProgram":
                case "SensingMethod":
                case "SceneCaptureType":
                case "SceneType":
                case "CustomRendered":
                case "WhiteBalance":
                case "GainControl":
                case "Contrast":
                case "Saturation":
                case "Sharpness":
                case "SubjectDistanceRange":
                case "FileSource":
                case "Orientation":
                    return this.stringValues[e][t];
                case "ExifVersion":
                case "FlashpixVersion":
                    return String.fromCharCode(t[0], t[1], t[2], t[3]);
                case "ComponentsConfiguration":
                    return this.stringValues[e][t[0]] + this.stringValues[e][t[1]] + this.stringValues[e][t[2]] + this.stringValues[e][t[3]];
                case "GPSVersionID":
                    return t[0] + "." + t[1] + "." + t[2] + "." + t[3]
            }
            return t + ""
        }, t = e.ExifMap.prototype.tags, n = e.ExifMap.prototype.map;
        for (i in t) t.hasOwnProperty(i) && (n[t[i]] = i);
        e.ExifMap.prototype.getAll = function() {
            var e, n, i = {};
            for (e in this) this.hasOwnProperty(e) && (n = t[e], n && (i[n] = this.getText(n)));
            return i
        }
    }),
    function(e) {
        "use strict";
        var t = e.HTMLCanvasElement && e.HTMLCanvasElement.prototype,
            n = e.Blob && function() {
                try {
                    return Boolean(new Blob)
                } catch (e) {
                    return !1
                }
            }(),
            i = n && e.Uint8Array && function() {
                try {
                    return 100 === new Blob([new Uint8Array(100)]).size
                } catch (e) {
                    return !1
                }
            }(),
            r = e.BlobBuilder || e.WebKitBlobBuilder || e.MozBlobBuilder || e.MSBlobBuilder,
            o = (n || r) && e.atob && e.ArrayBuffer && e.Uint8Array && function(e) {
                var t, o, a, s, u, c;
                for (t = e.split(",")[0].indexOf("base64") >= 0 ? atob(e.split(",")[1]) : decodeURIComponent(e.split(",")[1]), o = new ArrayBuffer(t.length), a = new Uint8Array(o), s = 0; s < t.length; s += 1) a[s] = t.charCodeAt(s);
                return u = e.split(",")[0].split(":")[1].split(";")[0], n ? new Blob([i ? a : o], {
                    type: u
                }) : (c = new r, c.append(o), c.getBlob(u))
            };
        e.HTMLCanvasElement && !t.toBlob && (t.mozGetAsFile ? t.toBlob = function(e, n, i) {
            e(i && t.toDataURL && o ? o(this.toDataURL(n, i)) : this.mozGetAsFile("blob", n))
        } : t.toDataURL && o && (t.toBlob = function(e, t, n) {
            e(o(this.toDataURL(t, n)))
        })), "function" == typeof define && define.amd ? define(function() {
            return o
        }) : e.dataURLtoBlob = o
    }(this),
    function(e) {
        "use strict";
        "function" == typeof define && define.amd ? define(["jquery", "./jquery.fileupload"], e) : e("object" == typeof exports ? require("jquery") : window.jQuery)
    }(function(e) {
        "use strict";
        var t = e.blueimp.fileupload.prototype.options.add;
        e.widget("blueimp.fileupload", e.blueimp.fileupload, {
            options: {
                processQueue: [],
                add: function(n, i) {
                    var r = e(this);
                    i.process(function() {
                        return r.fileupload("process", i)
                    }), t.call(this, n, i)
                }
            },
            processActions: {},
            _processFile: function(t, n) {
                var i = this,
                    r = e.Deferred().resolveWith(i, [t]),
                    o = r.promise();
                return this._trigger("process", null, t), e.each(t.processQueue, function(t, r) {
                    var a = function(t) {
                        return n.errorThrown ? e.Deferred().rejectWith(i, [n]).promise() : i.processActions[r.action].call(i, t, r)
                    };
                    o = o.pipe(a, r.always && a)
                }), o.done(function() {
                    i._trigger("processdone", null, t), i._trigger("processalways", null, t)
                }).fail(function() {
                    i._trigger("processfail", null, t), i._trigger("processalways", null, t)
                }), o
            },
            _transformProcessQueue: function(t) {
                var n = [];
                e.each(t.processQueue, function() {
                    var i = {},
                        r = this.action,
                        o = this.prefix === !0 ? r : this.prefix;
                    e.each(this, function(n, r) {
                        "string" === e.type(r) && "@" === r.charAt(0) ? i[n] = t[r.slice(1) || (o ? o + n.charAt(0).toUpperCase() + n.slice(1) : n)] : i[n] = r
                    }), n.push(i)
                }), t.processQueue = n
            },
            processing: function() {
                return this._processing
            },
            process: function(t) {
                var n = this,
                    i = e.extend({}, this.options, t);
                return i.processQueue && i.processQueue.length && (this._transformProcessQueue(i), 0 === this._processing && this._trigger("processstart"), e.each(t.files, function(r) {
                    var o = r ? e.extend({}, i) : i,
                        a = function() {
                            return t.errorThrown ? e.Deferred().rejectWith(n, [t]).promise() : n._processFile(o, t)
                        };
                    o.index = r, n._processing += 1, n._processingQueue = n._processingQueue.pipe(a, a).always(function() {
                        n._processing -= 1, 0 === n._processing && n._trigger("processstop")
                    })
                })), this._processingQueue
            },
            _create: function() {
                this._super(), this._processing = 0, this._processingQueue = e.Deferred().resolveWith(this).promise()
            }
        })
    }),
    function(e) {
        "use strict";
        "function" == typeof define && define.amd ? define(["jquery", "load-image", "load-image-meta", "load-image-exif", "load-image-ios", "canvas-to-blob", "./jquery.fileupload-process"], e) : "object" == typeof exports ? e(require("jquery"), require("load-image")) : e(window.jQuery, window.loadImage)
    }(function(e, t) {
        "use strict";
        e.blueimp.fileupload.prototype.options.processQueue.unshift({
            action: "loadImageMetaData",
            disableImageHead: "@",
            disableExif: "@",
            disableExifThumbnail: "@",
            disableExifSub: "@",
            disableExifGps: "@",
            disabled: "@disableImageMetaDataLoad"
        }, {
            action: "loadImage",
            prefix: !0,
            fileTypes: "@",
            maxFileSize: "@",
            noRevoke: "@",
            disabled: "@disableImageLoad"
        }, {
            action: "resizeImage",
            prefix: "image",
            maxWidth: "@",
            maxHeight: "@",
            minWidth: "@",
            minHeight: "@",
            crop: "@",
            orientation: "@",
            forceResize: "@",
            disabled: "@disableImageResize"
        }, {
            action: "saveImage",
            quality: "@imageQuality",
            type: "@imageType",
            disabled: "@disableImageResize"
        }, {
            action: "saveImageMetaData",
            disabled: "@disableImageMetaDataSave"
        }, {
            action: "resizeImage",
            prefix: "preview",
            maxWidth: "@",
            maxHeight: "@",
            minWidth: "@",
            minHeight: "@",
            crop: "@",
            orientation: "@",
            thumbnail: "@",
            canvas: "@",
            disabled: "@disableImagePreview"
        }, {
            action: "setImage",
            name: "@imagePreviewName",
            disabled: "@disableImagePreview"
        }, {
            action: "deleteImageReferences",
            disabled: "@disableImageReferencesDeletion"
        }), e.widget("blueimp.fileupload", e.blueimp.fileupload, {
            options: {
                loadImageFileTypes: /^image\/(gif|jpeg|png|svg\+xml)$/,
                loadImageMaxFileSize: 1e7,
                imageMaxWidth: 1920,
                imageMaxHeight: 1080,
                imageOrientation: !1,
                imageCrop: !1,
                disableImageResize: !0,
                previewMaxWidth: 80,
                previewMaxHeight: 80,
                previewOrientation: !0,
                previewThumbnail: !0,
                previewCrop: !1,
                previewCanvas: !0
            },
            processActions: {
                loadImage: function(n, i) {
                    if (i.disabled) return n;
                    var r = this,
                        o = n.files[n.index],
                        a = e.Deferred();
                    return "number" === e.type(i.maxFileSize) && o.size > i.maxFileSize || i.fileTypes && !i.fileTypes.test(o.type) || !t(o, function(e) {
                        e.src && (n.img = e), a.resolveWith(r, [n])
                    }, i) ? n : a.promise()
                },
                resizeImage: function(n, i) {
                    if (i.disabled || !n.canvas && !n.img) return n;
                    i = e.extend({
                        canvas: !0
                    }, i);
                    var r, o = this,
                        a = e.Deferred(),
                        s = i.canvas && n.canvas || n.img,
                        u = function(e) {
                            e && (e.width !== s.width || e.height !== s.height || i.forceResize) && (n[e.getContext ? "canvas" : "img"] = e), n.preview = e, a.resolveWith(o, [n])
                        };
                    if (n.exif) {
                        if (i.orientation === !0 && (i.orientation = n.exif.get("Orientation")), i.thumbnail && (r = n.exif.get("Thumbnail"))) return t(r, u, i), a.promise();
                        n.orientation ? delete i.orientation : n.orientation = i.orientation
                    }
                    return s ? (u(t.scale(s, i)), a.promise()) : n
                },
                saveImage: function(t, n) {
                    if (!t.canvas || n.disabled) return t;
                    var i = this,
                        r = t.files[t.index],
                        o = e.Deferred();
                    return t.canvas.toBlob ? (t.canvas.toBlob(function(e) {
                        e.name || (r.type === e.type ? e.name = r.name : r.name && (e.name = r.name.replace(/\..+$/, "." + e.type.substr(6)))), r.type !== e.type && delete t.imageHead, t.files[t.index] = e, o.resolveWith(i, [t])
                    }, n.type || r.type, n.quality), o.promise()) : t
                },
                loadImageMetaData: function(n, i) {
                    if (i.disabled) return n;
                    var r = this,
                        o = e.Deferred();
                    return t.parseMetaData(n.files[n.index], function(t) {
                        e.extend(n, t), o.resolveWith(r, [n])
                    }, i), o.promise()
                },
                saveImageMetaData: function(e, t) {
                    if (!(e.imageHead && e.canvas && e.canvas.toBlob) || t.disabled) return e;
                    var n = e.files[e.index],
                        i = new Blob([e.imageHead, this._blobSlice.call(n, 20)], {
                            type: n.type
                        });
                    return i.name = n.name, e.files[e.index] = i, e
                },
                setImage: function(e, t) {
                    return e.preview && !t.disabled && (e.files[e.index][t.name || "preview"] = e.preview), e
                },
                deleteImageReferences: function(e, t) {
                    return t.disabled || (delete e.img, delete e.canvas, delete e.preview, delete e.imageHead), e
                }
            }
        })
    }),
    function(e) {
        "use strict";
        "function" == typeof define && define.amd ? define(["jquery", "./jquery.fileupload-process"], e) : e(window.jQuery)
    }(function(e) {
        "use strict";
        e.blueimp.fileupload.prototype.options.processQueue.push({
            action: "validate",
            always: !0,
            acceptFileTypes: "@",
            maxFileSize: "@",
            minFileSize: "@",
            maxNumberOfFiles: "@",
            disabled: "@disableValidation"
        }), e.widget("blueimp.fileupload", e.blueimp.fileupload, {
            options: {
                getNumberOfFiles: e.noop,
                messages: {
                    maxNumberOfFiles: "Maximum number of files exceeded",
                    acceptFileTypes: "File type not allowed",
                    maxFileSize: "File is too large",
                    minFileSize: "File is too small"
                }
            },
            processActions: {
                validate: function(t, n) {
                    if (n.disabled) return t;
                    var i, r = e.Deferred(),
                        o = this.options,
                        a = t.files[t.index];
                    return (n.minFileSize || n.maxFileSize) && (i = a.size), "number" === e.type(n.maxNumberOfFiles) && (o.getNumberOfFiles() || 0) + t.files.length > n.maxNumberOfFiles ? a.error = o.i18n("maxNumberOfFiles") : !n.acceptFileTypes || n.acceptFileTypes.test(a.type) || n.acceptFileTypes.test(a.name) ? i > n.maxFileSize ? a.error = o.i18n("maxFileSize") : "number" === e.type(i) && i < n.minFileSize ? a.error = o.i18n("minFileSize") : delete a.error : a.error = o.i18n("acceptFileTypes"), a.error || t.files.error ? (t.files.error = !0, r.rejectWith(this, [t])) : r.resolveWith(this, [t]), r.promise()
                }
            }
        })
    }),
    function() {
        var e, t, n;
        (e = window.Coinbase).Views || (e.Views = {}), (t = window.Coinbase).Widgets || (t.Widgets = {}), (n = window.Coinbase.Views).Admin || (n.Admin = {}),
            Coinbase.Views.Application = function() {
                function e() {}
                return e.prototype.render = function() {
                    var e;
                    return e = $("body").data(), Coinbase.utils.currentAction = e.controllerName + "#" + e.actionName, Coinbase.Modules.Sift.init(), Coinbase.Widgets.DeviceTracking.enable(), Coinbase.Widgets.PhoneNumbers.enable(), Coinbase.Widgets.ContactsAutocomplete.enable(), Coinbase.Widgets.ExchangeRates.enable(), Coinbase.Widgets.CopyButton.enable(), Coinbase.Widgets.LocaleSelect.enable(), Coinbase.Widgets.Reports.enable(), Coinbase.Widgets.PhysicalAddress.enable(), Coinbase.Widgets.Highlight.enable(), Coinbase.Widgets.ReviewQueue.enable(), Coinbase.Widgets.Vault.enable(), Coinbase.Widgets.Signup.enable(), Coinbase.Widgets.Bootstrap.enable(), $("#main_nav_btn").on("click", function() {
                        return $("body").toggleClass("nav-toggled")
                    }), $(".focus:first").focus(), $(".modal[data-show=true]").modal(), this.renderKeyboardShortcuts(), Coinbase.utils.trackPageViewEvent()
                }, e.prototype.cleanup = function() {}, e.prototype.renderKeyboardShortcuts = function() {
                    var e;
                    return e = {
                        j: 74,
                        k: 75,
                        arrowLeft: 37,
                        arrowRight: 39
                    }, $(document).on("keyup", function(t) {
                        var n, i, r;
                        return $("input, textarea").is(":focus") || (((i = t.keyCode) === e.j || i === e.arrowLeft) && (n = $(".pagination a[rel=prev]").first().attr("href"), n && (window.location.href = n)), (r = t.keyCode) !== e.k && r !== e.arrowRight || !(n = $(".pagination a[rel=next]").first().attr("href"))) ? void 0 : window.location.href = n
                    })
                }, e
            }()
    }.call(this),
    function() {
        Coinbase.Widgets.BaseWidget = function() {
            function e() {}
            return e.className = "Coinbase.Widgets.BaseWidget", e.enable = function() {
                var e;
                try {
                    return this.run()
                } catch (t) {
                    return e = t, Bugsnag.notifyException(e, this.className + " Error"), console.error(e)
                }
            }, e
        }()
    }.call(this);
var _createClass = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
            }
        }
        return function(t, n, i) {
            return n && e(t.prototype, n), i && e(t, i), t
        }
    }(),
    _get = function(e, t, n) {
        for (var i = !0; i;) {
            var r = e,
                o = t,
                a = n;
            i = !1, null === r && (r = Function.prototype);
            var s = Object.getOwnPropertyDescriptor(r, o);
            if (void 0 !== s) {
                if ("value" in s) return s.value;
                var u = s.get;
                return void 0 === u ? void 0 : u.call(a)
            }
            var c = Object.getPrototypeOf(r);
            if (null === c) return void 0;
            e = c, t = o, n = a, i = !0, s = c = void 0
        }
    };
Coinbase.Widgets.BlacklistedAddressesFlags = function(e) {
        function t() {
            _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
        }
        return _inherits(t, e), _createClass(t, null, [{
            key: "run",
            value: function() {
                var e = $("#account_flags_modal");
                e.find("input.account-flag").on("change", function(e) {
                    $(this).siblings(".flag-reasons").toggle(e.target.checked)
                }), e.find(".add-reason").on("click", function(e) {
                    e.preventDefault();
                    var t = $(this).siblings("select").val(),
                        n = $(this).closest(".flag-reasons").find('li[data-reason="' + t + '"]');
                    n.find("input").removeAttr("disabled"), n.show()
                }), e.find(".remove-reason").on("click", function(e) {
                    e.preventDefault(), $(this).siblings("input").attr("disabled", "disabled"), $(this).parent().hide()
                })
            }
        }]), t
    }(Coinbase.Widgets.BaseWidget),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.AdminCredit = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.AdminCredit", n.run = function() {
                return $("#send_money").on("shown", function() {
                    return $(this).find("#transaction_to").focus()
                }), $("#send_money #transaction_to").on("change", function(e) {
                    var t;
                    return t = e.target.selectedOptions[0].id, $("#send_money #transaction_currency").each(function() {
                        return $(this).is("input") ? $(this).val(t) : $(this).text(t)
                    }), $("#send_money #transaction_amount").data("convert-from", t), $("#send_money #transaction_amount_native").data("convert-to", t)
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.AdminJumioInfo = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.AdminJumioInfo", n.run = function() {
                var e;
                return $(".admin-image").each(function(e, t) {
                    var n, i;
                    return n = $(t).attr("data-src"), i = $(t).attr("src"), i !== n ? $(t).attr("src", n) : void 0
                }), $(".jumio-toggle").on("click", function(e) {
                    return e.preventDefault(), $("#idv_info").toggle()
                }), $(".admin-image").on("click", function(e) {
                    var t;
                    return e.preventDefault(), t = $(this).data().imagePath, $("#admin_overlay_image").css({
                        backgroundImage: "url(" + t + ")"
                    }), $("#admin_overlay").show()
                }), $(".id-service-link").bind("ajax:beforeSend", function() {
                    return $(this).addClass("lazy-loading")
                }), $(".id-service-link").bind("ajax:complete", function() {
                    return $(this).removeClass("lazy-loading")
                }), e = 0, $("#rotate").on("click", function(t) {
                    return e += 90, $("#admin_overlay_image").css({
                        WebkitTransform: "rotate(" + e + "deg)"
                    })
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.ApiKeys = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.ApiKeys", n.run = function() {
                return $("#api_keys_modal").on("change", ".api-keys-checkbox-all", function() {
                    var e;
                    return e = $("#api_keys_granular_permissions.api-v1 input"), this.checked ? e.prop("checked", !0).attr("disabled", !0) : e.prop("checked", !1).removeAttr("disabled")
                }), $("#api_keys_modal").on("change", ".accounts-checkbox-all", function() {
                    var e;
                    return e = $("#api_keys_granular_accounts input"), this.checked ? e.prop("checked", !0).attr("disabled", !0) : e.prop("checked", !1).removeAttr("disabled")
                }), $(".v1-select-all").on("click", function(e) {
                    return e.preventDefault(), $("#api_keys_granular_permissions.api-v1 input").prop("checked", !0)
                }), $(".v1-select-none").on("click", function(e) {
                    return e.preventDefault(), $("#api_keys_granular_permissions.api-v1 input").prop("checked", !1)
                }), $(".select-all").on("click", function(e) {
                    return e.preventDefault(), $("#api_keys_granular_permissions.api-v2 input").prop("checked", !0)
                }), $(".select-none").on("click", function(e) {
                    return e.preventDefault(), $("#api_keys_granular_permissions.api-v2 input").prop("checked", !1)
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.ApplicationSettings = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.ApplicationSettings", n.run = function() {
                return $("#account_app_submit").on("click", function(e) {
                    return e.preventDefault(), $("#edit_app_form").submit()
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.BillingAddressFlow = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.BillingAddressFlow", n.run = function() {
                return $(".billing-address-modal").length ? (this.setupForm(), this.setupAutoComplete()) : void 0
            }, n.setupForm = function() {
                return $("select[name='billing_address[country_code]']").change(function() {
                    return $("select[name='billing_address[country_code]']").each(function(e, t) {
                        var n;
                        switch (n = $($(t).parent().parent().parent()), $(t).val()) {
                            case "US":
                                n.find("#billing_address_state").fadeIn(), n.find("#billing_address_state").removeAttr("disabled"), n.find("#billing_address_state_international").hide(), n.find("#billing_address_state_international").attr("disabled", "disabled");
                                break;
                            case "GB":
                                n.find("#billing_address_state").hide(), n.find("#billing_address_state").attr("disabled", "disabled"), n.find("#billing_address_state_international").hide(), n.find("#billing_address_state_international").attr("disabled", "disabled");
                                break;
                            default:
                                return n.find("#billing_address_state").hide(), n.find("#billing_address_state").attr("disabled", "disabled"), n.find("#billing_address_state_international").fadeIn(), n.find("#billing_address_state_international").removeAttr("disabled")
                        }
                    })
                })
            }, n.setupAutoComplete = function() {
                return window.physicalAddressAutocompleteInit = function() {
                    return Coinbase.utils.billingAddressAutocomplete("billing_address_")
                }, Coinbase.utils.addressAutocompleteLoadMaps()
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.Bootstrap = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.Bootstrap", n.run = function() {
                return $(".alert").alert(), $(".carousel").carousel(), $(".dropdown-toggle").dropdown(), $(".tab").tab("show"), $(".show-tooltip").tooltip(), $("[rel=tooltip]").tooltip(), this.showPopovers(), $(".accounts .highlight").effect("highlight", {}, 2e3), $(".datepicker").datepicker().on("changeDate", function(e) {
                    return $(this).datepicker("hide")
                }), $(".datepicker-icon").on("click", function() {
                    return $(this).siblings(".datepicker").datepicker("show"), navigator.userAgent.indexOf("MSIE ") > 0 || navigator.userAgent.match(/Trident.*rv\:11\./) ? void 0 : $(".focus").focus()
                }), window.showPopovers = this.showPopovers
            }, n.cleanup = function() {}, n.showPopovers = function() {
                return $(".show-popover, [rel=popover]").popover()
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this);
var _createClass = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
            }
        }
        return function(t, n, i) {
            return n && e(t.prototype, n), i && e(t, i), t
        }
    }(),
    _get = function(e, t, n) {
        for (var i = !0; i;) {
            var r = e,
                o = t,
                a = n;
            i = !1, null === r && (r = Function.prototype);
            var s = Object.getOwnPropertyDescriptor(r, o);
            if (void 0 !== s) {
                if ("value" in s) return s.value;
                var u = s.get;
                return void 0 === u ? void 0 : u.call(a)
            }
            var c = Object.getPrototypeOf(r);
            if (null === c) return void 0;
            e = c, t = o, n = a, i = !0, s = c = void 0
        }
    };
Coinbase.Widgets.ChangeCountry = function(e) {
        function t() {
            _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
        }
        return _inherits(t, e), _createClass(t, null, [{
            key: "run",
            value: function() {
                var e = $("#change_country_form"),
                    t = $(".country-change-spinner"),
                    n = $(".change-country-error");
                $("#change_country_btn").on("click", function(n) {
                    n.preventDefault(), e.hide(), t.show(), $.post(e.attr("action"), e.serialize())
                }), "undefined" != typeof Coinbase.live && (Coinbase.live.bind("change-country-failure", function(i) {
                    n.text(i.message), n.show(), t.hide(), e.show(), $("#change_country_btn").removeAttr("disabled")
                }), Coinbase.live.bind("change-country-success", function() {
                    window.location.reload()
                }))
            }
        }]), t
    }(Coinbase.Widgets.BaseWidget), Coinbase.Widgets.ChangeCountry.className = "Coinbase.Widgets.ChangeCountry",
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.Comments = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.Comments", n.run = function() {
                return $("#comment_text").focus(function() {
                    return $(this).attr("rows", 3), $("#comment_submit").show()
                }), $("#cancel_comment").click(function(e) {
                    return $("#comment_text").attr("rows", 1), $("#comment_submit").hide(), e.preventDefault()
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.ContactsAutocomplete = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.ContactsAutocomplete", n.run = function() {
                return $(".typeahead").typeahead({
                    source: function(e, t) {
                        return $.post("/contacts", {
                            query: e
                        }, function(e) {
                            return t(e)
                        })
                    }
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.CopyButton = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.CopyButton", n.run = function() {
                return $(".copy-button").trigger("initCopy")
            }, n
        }(Coinbase.Widgets.BaseWidget), $(document).on("click", ".copy-target", function() {
            return $(this).select()
        }), $(document).on("initCopy", ".copy-button", function() {
            var e;
            if (navigator && navigator.clipboard && navigator.clipboard.writeText) return e = $(this), e.show(), e.on("click", function(t) {
                return t.preventDefault(), t.stopPropagation(), navigator.clipboard.writeText(e.data("clipboardText")).then(function(e) {
                    return $(t.target).attr("data-original-title", "Copied!").tooltip("fixTitle").tooltip("show")
                }), e.on("mouseover", function() {
                    return $(this).tooltip("destroy").attr("data-original-title", $(this).data("hover")).tooltip("fixTitle").tooltip("show")
                }), e.on("hidden", function(e) {
                    return e.stopPropagation()
                })
            })
        })
    }.call(this),
    function(e, t) {
        "function" == typeof define && define.amd ? define(t) : "object" == typeof exports ? module.exports = t() : e.md5 = t()
    }(this, function() {
        function e(e, t) {
            var a = e[0],
                s = e[1],
                u = e[2],
                c = e[3];
            a = n(a, s, u, c, t[0], 7, -680876936), c = n(c, a, s, u, t[1], 12, -389564586), u = n(u, c, a, s, t[2], 17, 606105819), s = n(s, u, c, a, t[3], 22, -1044525330), a = n(a, s, u, c, t[4], 7, -176418897), c = n(c, a, s, u, t[5], 12, 1200080426), u = n(u, c, a, s, t[6], 17, -1473231341), s = n(s, u, c, a, t[7], 22, -45705983), a = n(a, s, u, c, t[8], 7, 1770035416), c = n(c, a, s, u, t[9], 12, -1958414417), u = n(u, c, a, s, t[10], 17, -42063), s = n(s, u, c, a, t[11], 22, -1990404162), a = n(a, s, u, c, t[12], 7, 1804603682), c = n(c, a, s, u, t[13], 12, -40341101), u = n(u, c, a, s, t[14], 17, -1502002290), s = n(s, u, c, a, t[15], 22, 1236535329), a = i(a, s, u, c, t[1], 5, -165796510), c = i(c, a, s, u, t[6], 9, -1069501632), u = i(u, c, a, s, t[11], 14, 643717713), s = i(s, u, c, a, t[0], 20, -373897302), a = i(a, s, u, c, t[5], 5, -701558691), c = i(c, a, s, u, t[10], 9, 38016083), u = i(u, c, a, s, t[15], 14, -660478335), s = i(s, u, c, a, t[4], 20, -405537848), a = i(a, s, u, c, t[9], 5, 568446438), c = i(c, a, s, u, t[14], 9, -1019803690), u = i(u, c, a, s, t[3], 14, -187363961), s = i(s, u, c, a, t[8], 20, 1163531501), a = i(a, s, u, c, t[13], 5, -1444681467), c = i(c, a, s, u, t[2], 9, -51403784), u = i(u, c, a, s, t[7], 14, 1735328473), s = i(s, u, c, a, t[12], 20, -1926607734), a = r(a, s, u, c, t[5], 4, -378558), c = r(c, a, s, u, t[8], 11, -2022574463), u = r(u, c, a, s, t[11], 16, 1839030562), s = r(s, u, c, a, t[14], 23, -35309556), a = r(a, s, u, c, t[1], 4, -1530992060), c = r(c, a, s, u, t[4], 11, 1272893353), u = r(u, c, a, s, t[7], 16, -155497632), s = r(s, u, c, a, t[10], 23, -1094730640), a = r(a, s, u, c, t[13], 4, 681279174), c = r(c, a, s, u, t[0], 11, -358537222), u = r(u, c, a, s, t[3], 16, -722521979), s = r(s, u, c, a, t[6], 23, 76029189), a = r(a, s, u, c, t[9], 4, -640364487), c = r(c, a, s, u, t[12], 11, -421815835), u = r(u, c, a, s, t[15], 16, 530742520), s = r(s, u, c, a, t[2], 23, -995338651), a = o(a, s, u, c, t[0], 6, -198630844), c = o(c, a, s, u, t[7], 10, 1126891415), u = o(u, c, a, s, t[14], 15, -1416354905), s = o(s, u, c, a, t[5], 21, -57434055), a = o(a, s, u, c, t[12], 6, 1700485571), c = o(c, a, s, u, t[3], 10, -1894986606), u = o(u, c, a, s, t[10], 15, -1051523), s = o(s, u, c, a, t[1], 21, -2054922799), a = o(a, s, u, c, t[8], 6, 1873313359), c = o(c, a, s, u, t[15], 10, -30611744), u = o(u, c, a, s, t[6], 15, -1560198380), s = o(s, u, c, a, t[13], 21, 1309151649), a = o(a, s, u, c, t[4], 6, -145523070), c = o(c, a, s, u, t[11], 10, -1120210379), u = o(u, c, a, s, t[2], 15, 718787259), s = o(s, u, c, a, t[9], 21, -343485551), e[0] = d(a, e[0]), e[1] = d(s, e[1]), e[2] = d(u, e[2]), e[3] = d(c, e[3])
        }

        function t(e, t, n, i, r, o) {
            return t = d(d(t, e), d(i, o)), d(t << r | t >>> 32 - r, n)
        }

        function n(e, n, i, r, o, a, s) {
            return t(n & i | ~n & r, e, n, o, a, s)
        }

        function i(e, n, i, r, o, a, s) {
            return t(n & r | i & ~r, e, n, o, a, s)
        }

        function r(e, n, i, r, o, a, s) {
            return t(n ^ i ^ r, e, n, o, a, s)
        }

        function o(e, n, i, r, o, a, s) {
            return t(i ^ (n | ~r), e, n, o, a, s)
        }

        function a(t) {
            txt = "";
            var n, i = t.length,
                r = [1732584193, -271733879, -1732584194, 271733878];
            for (n = 64; n <= t.length; n += 64) e(r, s(t.substring(n - 64, n)));
            t = t.substring(n - 64);
            var o = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            for (n = 0; n < t.length; n++) o[n >> 2] |= t.charCodeAt(n) << (n % 4 << 3);
            if (o[n >> 2] |= 128 << (n % 4 << 3), n > 55)
                for (e(r, o), n = 0; 16 > n; n++) o[n] = 0;
            return o[14] = 8 * i, e(r, o), r
        }

        function s(e) {
            var t, n = [];
            for (t = 0; 64 > t; t += 4) n[t >> 2] = e.charCodeAt(t) + (e.charCodeAt(t + 1) << 8) + (e.charCodeAt(t + 2) << 16) + (e.charCodeAt(t + 3) << 24);
            return n
        }

        function u(e) {
            for (var t = "", n = 0; 4 > n; n++) t += h[e >> 8 * n + 4 & 15] + h[e >> 8 * n & 15];
            return t
        }

        function c(e) {
            for (var t = 0; t < e.length; t++) e[t] = u(e[t]);
            return e.join("")
        }

        function l(e) {
            return c(a(e))
        }

        function d(e, t) {
            return e + t & 4294967295
        }

        function d(e, t) {
            var n = (65535 & e) + (65535 & t),
                i = (e >> 16) + (t >> 16) + (n >> 16);
            return i << 16 | 65535 & n
        }
        var h = "0123456789abcdef".split("");
        return "5d41402abc4b2a76b9719d911017c592" != l("hello"), l
    }),
    function(e) {
        function t(t) {
            return e(t).css("width")
        }

        function n(t) {
            return e(t).css("height")
        }
        var i = ["ACaslonPro-Bold", "ACaslonPro-BoldItalic", "ACaslonPro-Italic", "ACaslonPro-Regular", "ACaslonPro-Semibold", "ACaslonPro-SemiboldItalic", "AGaramondPro-Bold", "AGaramondPro-BoldItalic", "AGaramondPro-Italic", "AGaramondPro-Regular", "Academy Engraved LET", "AdobeArabic-Bold", "AdobeArabic-BoldItalic", "AdobeArabic-Italic", "AdobeArabic-Regular", "AdobeFanHeitiStd-Bold", "AdobeFangsongStd-Regular", "AdobeGothicStd-Bold", "AdobeHebrew-Bold", "AdobeHebrew-BoldItalic", "AdobeHebrew-Italic", "AdobeHebrew-Regular", "AdobeHeitiStd-Regular", "AdobeKaitiStd-Regular", "AdobeMingStd-Light", "AdobeMyungjoStd-Medium", "AdobeSongStd-Light", "AlBayan", "AlBayan-Bold", "AmericanTypewriter", "Andale Mono", "Apple Chancery", "AppleMyungjo", "Ayuthaya", "Baghdad", "Bank Gothic", "Baskerville", "BellGothicStd-Black", "BellGothicStd-Bold", "BiauKai", "Big Caslon", "BirchStd", "Blackmoor LET", "BlackoakStd", "Bodoni Ornaments ITC TT", "Bodoni SvtyTwo ITC TT", "Bodoni SvtyTwo OS ITC TT", "Bodoni SvtyTwo SC ITC TT", "Bordeaux Roman Bold LET", "Brush Script MT", "BrushScriptStd", "Capitals", "Chalkboard", "Chalkduster", "ChaparralPro-Bold", "ChaparralPro-BoldIt", "ChaparralPro-Italic", "ChaparralPro-Regular", "CharcoalCY", "CharlemagneStd-Bold", "Cochin", "CooperBlackStd", "CooperBlackStd-Italic", "Copperplate", "Corsiva Hebrew", "DecoTypeNaskh", "DevanagariMT", "DevanagariMT-Bold", "Didot", "Doremi", "EccentricStd", "EuphemiaUCAS", "EuphemiaUCAS-Bold", "EuphemiaUCAS-Italic", "Futura", "Geneva", "GiddyupStd", "GillSans", "GujaratiMT", "GujaratiMT-Bold", "Gungseo", "Gurmukhi MT", "HeadlineA", "Hei", "Helvetica Neue", "Herculanum", "Hiragino Sans GB", "HoboStd", "Hoefler Text", "Impact", "InaiMathi", "Jazz LET", "Kai", "Kailasa", "Kokonor", "KozGoPro-Bold", "KozGoPro-ExtraLight", "KozGoPro-Heavy", "KozGoPro-Light", "KozGoPro-Medium", "KozGoPro-Regular", "KozMinPro-Bold", "KozMinPro-ExtraLight", "KozMinPro-Heavy", "KozMinPro-Light", "KozMinPro-Medium", "KozMinPro-Regular", "Krungthep", "KufiStandardGK", "LetterGothicStd", "LetterGothicStd-Bold", "LetterGothicStd-BoldSlanted", "LetterGothicStd-Slanted", "LithosPro-Black", "LithosPro-Regular", "MarkerFelt-Thin", "MarkerFelt-Wide", "MesquiteStd", "Microsoft Sans Serif", "MinionPro-Bold", "MinionPro-BoldCn", "MinionPro-BoldCnIt", "MinionPro-BoldIt", "MinionPro-It", "MinionPro-Medium", "MinionPro-MediumIt", "MinionPro-Regular", "MinionPro-Semibold", "MinionPro-SemiboldIt", "Mona Lisa Solid ITC TT", "Mshtakan", "MshtakanBold", "MshtakanBoldOblique", "MshtakanOblique", "MyriadPro-Bold", "MyriadPro-BoldCond", "MyriadPro-BoldCondIt", "MyriadPro-BoldIt", "MyriadPro-Cond", "MyriadPro-CondIt", "MyriadPro-It", "MyriadPro-Regular", "MyriadPro-Semibold", "MyriadPro-SemiboldIt", "Nadeem", "NewPeninimMT", "NewPeninimMT-Bold", "NewPeninimMT-BoldInclined", "NewPeninimMT-Inclined", "NuevaStd-BoldCond", "NuevaStd-BoldCondItalic", "NuevaStd-Cond", "NuevaStd-CondItalic", "OCRAStd", "Optima", "OratorStd", "OratorStd-Slanted", "Osaka", "Osaka-Mono", "Palatino", "Papyrus", "Party LET", "Pilgi", "PlantagenetCherokee", "PoplarStd", "PortagoITC TT", "PrestigeEliteStd-Bd", "Princetown LET", "Raanana", "RaananaBold", "RosewoodStd-Regular", "STHeiti", "Santa Fe LET", "Sathu", "Savoye LET", "SchoolHouse Cursive B", "SchoolHouse Printed A", "Silom", "Skia", "Snell Roundhand", "StencilStd", "Stone Sans ITC TT", "Synchro LET", "Tahoma", "Tahoma-Bold", "TektonPro-Bold", "TektonPro-BoldCond", "TektonPro-BoldExt", "TektonPro-BoldObl", "TrajanPro-Bold", "TrajanPro-Regular", "Trebuchet MS", "Type Embellishments One LET", "Zapfino"];
        e.fontlist_DEPRECATED = function() {
            var r = [],
                o = "#fontlist_test",
                a = e("<p>");
            a.appendTo("body").html("abcdefghijklmnopqrstuvwxyz0123456789").attr("id", o.replace("#", "")).css({
                fontSize: "13.47px",
                position: "absolute",
                opacity: 0,
                top: "0px",
                left: "0px"
            });
            var s = {
                w: t(o),
                h: n(o)
            };
            return e.each(i, function(i, a) {
                e(o).css({
                    fontFamily: a
                }), (s.w !== t(o) || s.h !== n(o)) && r.push(a)
            }), a.remove(), r
        }, e.fontlist = function() {
            var r = "fontlist_test_new",
                o = [],
                a = "#" + r,
                s = e("<p>");
            s.appendTo("body").html("AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789").attr("id", r).css({
                fontSize: "13.47px",
                position: "absolute",
                opacity: 0,
                top: "0px",
                left: "0px",
                fontFamily: "zzz"
            });
            var u = {
                w: t(a),
                h: n(a)
            };
            return e.each(i, function(i, r) {
                e(a).css({
                    fontFamily: r
                });
                var s = t(a),
                    c = n(a);
                (u.w !== s || u.h !== c) && o.push(i)
            }), s.remove(), o
        }
    }(jQuery),
    function(e, t, n) {
        "use strict";
        "function" == typeof window.define && window.define.amd ? window.define(n) : "undefined" != typeof module && module.exports ? module.exports = n() : t.exports ? t.exports = n() : t[e] = n()
    }("Fingerprint2", this, function() {
        "use strict";
        var e = function(t) {
            if (!(this instanceof e)) return new e(t);
            var n = {
                swfContainerId: "fingerprintjs2",
                swfPath: "flash/compiled/FontList.swf",
                detectScreenOrientation: !0,
                sortPluginsFor: [/palemoon/i],
                userDefinedFonts: [],
                excludeDoNotTrack: !0,
                excludePixelRatio: !0
            };
            this.options = this.extend(t, n), this.nativeForEach = Array.prototype.forEach, this.nativeMap = Array.prototype.map
        };
        return e.prototype = {
            extend: function(e, t) {
                if (null == e) return t;
                for (var n in e) null != e[n] && t[n] !== e[n] && (t[n] = e[n]);
                return t
            },
            get: function(e) {
                var t = this,
                    n = {
                        data: [],
                        addPreprocessedComponent: function(e) {
                            var i = e.value;
                            "function" == typeof t.options.preprocessor && (i = t.options.preprocessor(e.key, i)), n.data.push({
                                key: e.key,
                                value: i
                            })
                        }
                    };
                n = this.userAgentKey(n), n = this.languageKey(n), n = this.colorDepthKey(n), n = this.deviceMemoryKey(n), n = this.pixelRatioKey(n), n = this.hardwareConcurrencyKey(n), n = this.screenResolutionKey(n), n = this.availableScreenResolutionKey(n), n = this.timezoneOffsetKey(n), n = this.sessionStorageKey(n), n = this.localStorageKey(n), n = this.indexedDbKey(n), n = this.addBehaviorKey(n), n = this.openDatabaseKey(n), n = this.cpuClassKey(n), n = this.platformKey(n), n = this.doNotTrackKey(n), n = this.pluginsKey(n), n = this.canvasKey(n), n = this.webglKey(n), n = this.webglVendorAndRendererKey(n), n = this.adBlockKey(n), n = this.hasLiedLanguagesKey(n), n = this.hasLiedResolutionKey(n), n = this.hasLiedOsKey(n), n = this.hasLiedBrowserKey(n), n = this.touchSupportKey(n), n = this.customEntropyFunction(n), this.fontsKey(n, function(n) {
                    var i = [];
                    t.each(n.data, function(e) {
                        var t = e.value;
                        t && "function" == typeof t.join && (t = t.join(";")), i.push(t)
                    });
                    var r = t.x64hash128(i.join("~~~"), 31);
                    return e(r, n.data)
                })
            },
            customEntropyFunction: function(e) {
                return "function" == typeof this.options.customFunction && e.addPreprocessedComponent({
                    key: "custom",
                    value: this.options.customFunction()
                }), e
            },
            userAgentKey: function(e) {
                return this.options.excludeUserAgent || e.addPreprocessedComponent({
                    key: "user_agent",
                    value: this.getUserAgent()
                }), e
            },
            getUserAgent: function() {
                return navigator.userAgent
            },
            languageKey: function(e) {
                return this.options.excludeLanguage || e.addPreprocessedComponent({
                    key: "language",
                    value: navigator.language || navigator.userLanguage || navigator.browserLanguage || navigator.systemLanguage || ""
                }), e
            },
            colorDepthKey: function(e) {
                return this.options.excludeColorDepth || e.addPreprocessedComponent({
                    key: "color_depth",
                    value: window.screen.colorDepth || -1
                }), e
            },
            deviceMemoryKey: function(e) {
                return this.options.excludeDeviceMemory || e.addPreprocessedComponent({
                    key: "device_memory",
                    value: this.getDeviceMemory()
                }), e
            },
            getDeviceMemory: function() {
                return navigator.deviceMemory || -1
            },
            pixelRatioKey: function(e) {
                return this.options.excludePixelRatio || e.addPreprocessedComponent({
                    key: "pixel_ratio",
                    value: this.getPixelRatio()
                }), e
            },
            getPixelRatio: function() {
                return window.devicePixelRatio || ""
            },
            screenResolutionKey: function(e) {
                return this.options.excludeScreenResolution ? e : this.getScreenResolution(e)
            },
            getScreenResolution: function(e) {
                var t;
                return t = this.options.detectScreenOrientation && window.screen.height > window.screen.width ? [window.screen.height, window.screen.width] : [window.screen.width, window.screen.height], e.addPreprocessedComponent({
                    key: "resolution",
                    value: t
                }), e
            },
            availableScreenResolutionKey: function(e) {
                return this.options.excludeAvailableScreenResolution ? e : this.getAvailableScreenResolution(e)
            },
            getAvailableScreenResolution: function(e) {
                var t;
                return window.screen.availWidth && window.screen.availHeight && (t = this.options.detectScreenOrientation ? window.screen.availHeight > window.screen.availWidth ? [window.screen.availHeight, window.screen.availWidth] : [window.screen.availWidth, window.screen.availHeight] : [window.screen.availHeight, window.screen.availWidth]), "undefined" != typeof t && e.addPreprocessedComponent({
                    key: "available_resolution",
                    value: t
                }), e
            },
            timezoneOffsetKey: function(e) {
                return this.options.excludeTimezoneOffset || e.addPreprocessedComponent({
                    key: "timezone_offset",
                    value: (new Date).getTimezoneOffset()
                }), e
            },
            sessionStorageKey: function(e) {
                return !this.options.excludeSessionStorage && this.hasSessionStorage() && e.addPreprocessedComponent({
                    key: "session_storage",
                    value: 1
                }), e
            },
            localStorageKey: function(e) {
                return !this.options.excludeSessionStorage && this.hasLocalStorage() && e.addPreprocessedComponent({
                    key: "local_storage",
                    value: 1
                }), e
            },
            indexedDbKey: function(e) {
                return !this.options.excludeIndexedDB && this.hasIndexedDB() && e.addPreprocessedComponent({
                    key: "indexed_db",
                    value: 1
                }), e
            },
            addBehaviorKey: function(e) {
                return !this.options.excludeAddBehavior && document.body && document.body.addBehavior && e.addPreprocessedComponent({
                    key: "add_behavior",
                    value: 1
                }), e
            },
            openDatabaseKey: function(e) {
                return !this.options.excludeOpenDatabase && window.openDatabase && e.addPreprocessedComponent({
                    key: "open_database",
                    value: 1
                }), e
            },
            cpuClassKey: function(e) {
                return this.options.excludeCpuClass || e.addPreprocessedComponent({
                    key: "cpu_class",
                    value: this.getNavigatorCpuClass()
                }), e
            },
            platformKey: function(e) {
                return this.options.excludePlatform || e.addPreprocessedComponent({
                    key: "navigator_platform",
                    value: this.getNavigatorPlatform()
                }), e
            },
            doNotTrackKey: function(e) {
                return this.options.excludeDoNotTrack || e.addPreprocessedComponent({
                    key: "do_not_track",
                    value: this.getDoNotTrack()
                }), e
            },
            canvasKey: function(e) {
                return !this.options.excludeCanvas && this.isCanvasSupported() && e.addPreprocessedComponent({
                    key: "canvas",
                    value: this.getCanvasFp()
                }), e
            },
            webglKey: function(e) {
                return !this.options.excludeWebGL && this.isWebGlSupported() && e.addPreprocessedComponent({
                    key: "webgl",
                    value: this.getWebglFp()
                }), e
            },
            webglVendorAndRendererKey: function(e) {
                return !this.options.excludeWebGLVendorAndRenderer && this.isWebGlSupported() && e.addPreprocessedComponent({
                    key: "webgl_vendor",
                    value: this.getWebglVendorAndRenderer()
                }), e
            },
            adBlockKey: function(e) {
                return this.options.excludeAdBlock || e.addPreprocessedComponent({
                    key: "adblock",
                    value: this.getAdBlock()
                }), e
            },
            hasLiedLanguagesKey: function(e) {
                return this.options.excludeHasLiedLanguages || e.addPreprocessedComponent({
                    key: "has_lied_languages",
                    value: this.getHasLiedLanguages()
                }), e
            },
            hasLiedResolutionKey: function(e) {
                return this.options.excludeHasLiedResolution || e.addPreprocessedComponent({
                    key: "has_lied_resolution",
                    value: this.getHasLiedResolution()
                }), e
            },
            hasLiedOsKey: function(e) {
                return this.options.excludeHasLiedOs || e.addPreprocessedComponent({
                    key: "has_lied_os",
                    value: this.getHasLiedOs()
                }), e
            },
            hasLiedBrowserKey: function(e) {
                return this.options.excludeHasLiedBrowser || e.addPreprocessedComponent({
                    key: "has_lied_browser",
                    value: this.getHasLiedBrowser()
                }), e
            },
            fontsKey: function(e, t) {
                return this.options.excludeJsFonts ? this.flashFontsKey(e, t) : this.jsFontsKey(e, t)
            },
            flashFontsKey: function(e, t) {
                return this.options.excludeFlashFonts ? t(e) : this.hasSwfObjectLoaded() && this.hasMinFlashInstalled() ? "undefined" == typeof this.options.swfPath ? t(e) : void this.loadSwfAndDetectFonts(function(n) {
                    e.addPreprocessedComponent({
                        key: "swf_fonts",
                        value: n.join(";")
                    }), t(e)
                }) : t(e)
            },
            jsFontsKey: function(e, t) {
                var n = this;
                return setTimeout(function() {
                    var i = ["monospace", "sans-serif", "serif"],
                        r = ["Andale Mono", "Arial", "Arial Black", "Arial Hebrew", "Arial MT", "Arial Narrow", "Arial Rounded MT Bold", "Arial Unicode MS", "Bitstream Vera Sans Mono", "Book Antiqua", "Bookman Old Style", "Calibri", "Cambria", "Cambria Math", "Century", "Century Gothic", "Century Schoolbook", "Comic Sans", "Comic Sans MS", "Consolas", "Courier", "Courier New", "Geneva", "Georgia", "Helvetica", "Helvetica Neue", "Impact", "Lucida Bright", "Lucida Calligraphy", "Lucida Console", "Lucida Fax", "LUCIDA GRANDE", "Lucida Handwriting", "Lucida Sans", "Lucida Sans Typewriter", "Lucida Sans Unicode", "Microsoft Sans Serif", "Monaco", "Monotype Corsiva", "MS Gothic", "MS Outlook", "MS PGothic", "MS Reference Sans Serif", "MS Sans Serif", "MS Serif", "MYRIAD", "MYRIAD PRO", "Palatino", "Palatino Linotype", "Segoe Print", "Segoe Script", "Segoe UI", "Segoe UI Light", "Segoe UI Semibold", "Segoe UI Symbol", "Tahoma", "Times", "Times New Roman", "Times New Roman PS", "Trebuchet MS", "Verdana", "Wingdings", "Wingdings 2", "Wingdings 3"],
                        o = ["Abadi MT Condensed Light", "Academy Engraved LET", "ADOBE CASLON PRO", "Adobe Garamond", "ADOBE GARAMOND PRO", "Agency FB", "Aharoni", "Albertus Extra Bold", "Albertus Medium", "Algerian", "Amazone BT", "American Typewriter", "American Typewriter Condensed", "AmerType Md BT", "Andalus", "Angsana New", "AngsanaUPC", "Antique Olive", "Aparajita", "Apple Chancery", "Apple Color Emoji", "Apple SD Gothic Neo", "Arabic Typesetting", "ARCHER", "ARNO PRO", "Arrus BT", "Aurora Cn BT", "AvantGarde Bk BT", "AvantGarde Md BT", "AVENIR", "Ayuthaya", "Bandy", "Bangla Sangam MN", "Bank Gothic", "BankGothic Md BT", "Baskerville", "Baskerville Old Face", "Batang", "BatangChe", "Bauer Bodoni", "Bauhaus 93", "Bazooka", "Bell MT", "Bembo", "Benguiat Bk BT", "Berlin Sans FB", "Berlin Sans FB Demi", "Bernard MT Condensed", "BernhardFashion BT", "BernhardMod BT", "Big Caslon", "BinnerD", "Blackadder ITC", "BlairMdITC TT", "Bodoni 72", "Bodoni 72 Oldstyle", "Bodoni 72 Smallcaps", "Bodoni MT", "Bodoni MT Black", "Bodoni MT Condensed", "Bodoni MT Poster Compressed", "Bookshelf Symbol 7", "Boulder", "Bradley Hand", "Bradley Hand ITC", "Bremen Bd BT", "Britannic Bold", "Broadway", "Browallia New", "BrowalliaUPC", "Brush Script MT", "Californian FB", "Calisto MT", "Calligrapher", "Candara", "CaslonOpnface BT", "Castellar", "Centaur", "Cezanne", "CG Omega", "CG Times", "Chalkboard", "Chalkboard SE", "Chalkduster", "Charlesworth", "Charter Bd BT", "Charter BT", "Chaucer", "ChelthmITC Bk BT", "Chiller", "Clarendon", "Clarendon Condensed", "CloisterBlack BT", "Cochin", "Colonna MT", "Constantia", "Cooper Black", "Copperplate", "Copperplate Gothic", "Copperplate Gothic Bold", "Copperplate Gothic Light", "CopperplGoth Bd BT", "Corbel", "Cordia New", "CordiaUPC", "Cornerstone", "Coronet", "Cuckoo", "Curlz MT", "DaunPenh", "Dauphin", "David", "DB LCD Temp", "DELICIOUS", "Denmark", "DFKai-SB", "Didot", "DilleniaUPC", "DIN", "DokChampa", "Dotum", "DotumChe", "Ebrima", "Edwardian Script ITC", "Elephant", "English 111 Vivace BT", "Engravers MT", "EngraversGothic BT", "Eras Bold ITC", "Eras Demi ITC", "Eras Light ITC", "Eras Medium ITC", "EucrosiaUPC", "Euphemia", "Euphemia UCAS", "EUROSTILE", "Exotc350 Bd BT", "FangSong", "Felix Titling", "Fixedsys", "FONTIN", "Footlight MT Light", "Forte", "FrankRuehl", "Fransiscan", "Freefrm721 Blk BT", "FreesiaUPC", "Freestyle Script", "French Script MT", "FrnkGothITC Bk BT", "Fruitger", "FRUTIGER", "Futura", "Futura Bk BT", "Futura Lt BT", "Futura Md BT", "Futura ZBlk BT", "FuturaBlack BT", "Gabriola", "Galliard BT", "Gautami", "Geeza Pro", "Geometr231 BT", "Geometr231 Hv BT", "Geometr231 Lt BT", "GeoSlab 703 Lt BT", "GeoSlab 703 XBd BT", "Gigi", "Gill Sans", "Gill Sans MT", "Gill Sans MT Condensed", "Gill Sans MT Ext Condensed Bold", "Gill Sans Ultra Bold", "Gill Sans Ultra Bold Condensed", "Gisha", "Gloucester MT Extra Condensed", "GOTHAM", "GOTHAM BOLD", "Goudy Old Style", "Goudy Stout", "GoudyHandtooled BT", "GoudyOLSt BT", "Gujarati Sangam MN", "Gulim", "GulimChe", "Gungsuh", "GungsuhChe", "Gurmukhi MN", "Haettenschweiler", "Harlow Solid Italic", "Harrington", "Heather", "Heiti SC", "Heiti TC", "HELV", "Herald", "High Tower Text", "Hiragino Kaku Gothic ProN", "Hiragino Mincho ProN", "Hoefler Text", "Humanst 521 Cn BT", "Humanst521 BT", "Humanst521 Lt BT", "Imprint MT Shadow", "Incised901 Bd BT", "Incised901 BT", "Incised901 Lt BT", "INCONSOLATA", "Informal Roman", "Informal011 BT", "INTERSTATE", "IrisUPC", "Iskoola Pota", "JasmineUPC", "Jazz LET", "Jenson", "Jester", "Jokerman", "Juice ITC", "Kabel Bk BT", "Kabel Ult BT", "Kailasa", "KaiTi", "Kalinga", "Kannada Sangam MN", "Kartika", "Kaufmann Bd BT", "Kaufmann BT", "Khmer UI", "KodchiangUPC", "Kokila", "Korinna BT", "Kristen ITC", "Krungthep", "Kunstler Script", "Lao UI", "Latha", "Leelawadee", "Letter Gothic", "Levenim MT", "LilyUPC", "Lithograph", "Lithograph Light", "Long Island", "Lydian BT", "Magneto", "Maiandra GD", "Malayalam Sangam MN", "Malgun Gothic", "Mangal", "Marigold", "Marion", "Marker Felt", "Market", "Marlett", "Matisse ITC", "Matura MT Script Capitals", "Meiryo", "Meiryo UI", "Microsoft Himalaya", "Microsoft JhengHei", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Tai Le", "Microsoft Uighur", "Microsoft YaHei", "Microsoft Yi Baiti", "MingLiU", "MingLiU_HKSCS", "MingLiU_HKSCS-ExtB", "MingLiU-ExtB", "Minion", "Minion Pro", "Miriam", "Miriam Fixed", "Mistral", "Modern", "Modern No. 20", "Mona Lisa Solid ITC TT", "Mongolian Baiti", "MONO", "MoolBoran", "Mrs Eaves", "MS LineDraw", "MS Mincho", "MS PMincho", "MS Reference Specialty", "MS UI Gothic", "MT Extra", "MUSEO", "MV Boli", "Nadeem", "Narkisim", "NEVIS", "News Gothic", "News GothicMT", "NewsGoth BT", "Niagara Engraved", "Niagara Solid", "Noteworthy", "NSimSun", "Nyala", "OCR A Extended", "Old Century", "Old English Text MT", "Onyx", "Onyx BT", "OPTIMA", "Oriya Sangam MN", "OSAKA", "OzHandicraft BT", "Palace Script MT", "Papyrus", "Parchment", "Party LET", "Pegasus", "Perpetua", "Perpetua Titling MT", "PetitaBold", "Pickwick", "Plantagenet Cherokee", "Playbill", "PMingLiU", "PMingLiU-ExtB", "Poor Richard", "Poster", "PosterBodoni BT", "PRINCETOWN LET", "Pristina", "PTBarnum BT", "Pythagoras", "Raavi", "Rage Italic", "Ravie", "Ribbon131 Bd BT", "Rockwell", "Rockwell Condensed", "Rockwell Extra Bold", "Rod", "Roman", "Sakkal Majalla", "Santa Fe LET", "Savoye LET", "Sceptre", "Script", "Script MT Bold", "SCRIPTINA", "Serifa", "Serifa BT", "Serifa Th BT", "ShelleyVolante BT", "Sherwood", "Shonar Bangla", "Showcard Gothic", "Shruti", "Signboard", "SILKSCREEN", "SimHei", "Simplified Arabic", "Simplified Arabic Fixed", "SimSun", "SimSun-ExtB", "Sinhala Sangam MN", "Sketch Rockwell", "Skia", "Small Fonts", "Snap ITC", "Snell Roundhand", "Socket", "Souvenir Lt BT", "Staccato222 BT", "Steamer", "Stencil", "Storybook", "Styllo", "Subway", "Swis721 BlkEx BT", "Swiss911 XCm BT", "Sylfaen", "Synchro LET", "System", "Tamil Sangam MN", "Technical", "Teletype", "Telugu Sangam MN", "Tempus Sans ITC", "Terminal", "Thonburi", "Traditional Arabic", "Trajan", "TRAJAN PRO", "Tristan", "Tubular", "Tunga", "Tw Cen MT", "Tw Cen MT Condensed", "Tw Cen MT Condensed Extra Bold", "TypoUpright BT", "Unicorn", "Univers", "Univers CE 55 Medium", "Univers Condensed", "Utsaah", "Vagabond", "Vani", "Vijaya", "Viner Hand ITC", "VisualUI", "Vivaldi", "Vladimir Script", "Vrinda", "Westminster", "WHITNEY", "Wide Latin", "ZapfEllipt BT", "ZapfHumnst BT", "ZapfHumnst Dm BT", "Zapfino", "Zurich BlkEx BT", "Zurich Ex BT", "ZWAdobeF"];
                    n.options.extendedJsFonts && (r = r.concat(o)), r = r.concat(n.options.userDefinedFonts), r = r.filter(function(e, t) {
                        return r.indexOf(e) === t
                    });
                    var a = "mmmmmmmmmmlli",
                        s = "72px",
                        u = document.getElementsByTagName("body")[0],
                        c = document.createElement("div"),
                        l = document.createElement("div"),
                        d = {},
                        h = {},
                        f = function() {
                            var e = document.createElement("span");
                            return e.style.position = "absolute", e.style.left = "-9999px", e.style.fontSize = s, e.style.fontStyle = "normal", e.style.fontWeight = "normal", e.style.letterSpacing = "normal", e.style.lineBreak = "auto", e.style.lineHeight = "normal", e.style.textTransform = "none", e.style.textAlign = "left", e.style.textDecoration = "none", e.style.textShadow = "none", e.style.whiteSpace = "normal", e.style.wordBreak = "normal", e.style.wordSpacing = "normal", e.innerHTML = a, e
                        },
                        p = function(e, t) {
                            var n = f();
                            return n.style.fontFamily = "'" + e + "'," + t, n
                        },
                        g = function() {
                            for (var e = [], t = 0, n = i.length; n > t; t++) {
                                var r = f();
                                r.style.fontFamily = i[t], c.appendChild(r), e.push(r)
                            }
                            return e
                        },
                        m = function() {
                            for (var e = {}, t = 0, n = r.length; n > t; t++) {
                                for (var o = [], a = 0, s = i.length; s > a; a++) {
                                    var u = p(r[t], i[a]);
                                    l.appendChild(u), o.push(u)
                                }
                                e[r[t]] = o
                            }
                            return e
                        },
                        v = function(e) {
                            for (var t = !1, n = 0; n < i.length; n++)
                                if (t = e[n].offsetWidth !== d[i[n]] || e[n].offsetHeight !== h[i[n]]) return t;
                            return t
                        },
                        y = g();
                    u.appendChild(c);
                    for (var b = 0, w = i.length; w > b; b++) d[i[b]] = y[b].offsetWidth, h[i[b]] = y[b].offsetHeight;
                    var _ = m();
                    u.appendChild(l);
                    for (var C = [], k = 0, E = r.length; E > k; k++) v(_[r[k]]) && C.push(r[k]);
                    u.removeChild(l), u.removeChild(c), e.addPreprocessedComponent({
                        key: "js_fonts",
                        value: C
                    }), t(e)
                }, 1)
            },
            pluginsKey: function(e) {
                return this.options.excludePlugins || (this.isIE() ? this.options.excludeIEPlugins || e.addPreprocessedComponent({
                    key: "ie_plugins",
                    value: this.getIEPlugins()
                }) : e.addPreprocessedComponent({
                    key: "regular_plugins",
                    value: this.getRegularPlugins()
                })), e
            },
            getRegularPlugins: function() {
                var e = [];
                if (navigator.plugins)
                    for (var t = 0, n = navigator.plugins.length; n > t; t++) navigator.plugins[t] && e.push(navigator.plugins[t]);
                return this.pluginsShouldBeSorted() && (e = e.sort(function(e, t) {
                    return e.name > t.name ? 1 : e.name < t.name ? -1 : 0
                })), this.map(e, function(e) {
                    var t = this.map(e, function(e) {
                        return [e.type, e.suffixes].join("~")
                    }).join(",");
                    return [e.name, e.description, t].join("::")
                }, this)
            },
            getIEPlugins: function() {
                var e = [];
                if (Object.getOwnPropertyDescriptor && Object.getOwnPropertyDescriptor(window, "ActiveXObject") || "ActiveXObject" in window) {
                    var t = ["AcroPDF.PDF", "Adodb.Stream", "AgControl.AgControl", "DevalVRXCtrl.DevalVRXCtrl.1", "MacromediaFlashPaper.MacromediaFlashPaper", "Msxml2.DOMDocument", "Msxml2.XMLHTTP", "PDF.PdfCtrl", "QuickTime.QuickTime", "QuickTimeCheckObject.QuickTimeCheck.1", "RealPlayer", "RealPlayer.RealPlayer(tm) ActiveX Control (32-bit)", "RealVideo.RealVideo(tm) ActiveX Control (32-bit)", "Scripting.Dictionary", "SWCtl.SWCtl", "Shell.UIHelper", "ShockwaveFlash.ShockwaveFlash", "Skype.Detection", "TDCCtl.TDCCtl", "WMPlayer.OCX", "rmocx.RealPlayer G2 Control", "rmocx.RealPlayer G2 Control.1"];
                    e = this.map(t, function(e) {
                        try {
                            return new window.ActiveXObject(e), e
                        } catch (t) {
                            return null
                        }
                    })
                }
                return navigator.plugins && (e = e.concat(this.getRegularPlugins())), e
            },
            pluginsShouldBeSorted: function() {
                for (var e = !1, t = 0, n = this.options.sortPluginsFor.length; n > t; t++) {
                    var i = this.options.sortPluginsFor[t];
                    if (navigator.userAgent.match(i)) {
                        e = !0;
                        break
                    }
                }
                return e
            },
            touchSupportKey: function(e) {
                return this.options.excludeTouchSupport || e.addPreprocessedComponent({
                    key: "touch_support",
                    value: this.getTouchSupport()
                }), e
            },
            hardwareConcurrencyKey: function(e) {
                return this.options.excludeHardwareConcurrency || e.addPreprocessedComponent({
                    key: "hardware_concurrency",
                    value: this.getHardwareConcurrency()
                }), e
            },
            hasSessionStorage: function() {
                try {
                    return !!window.sessionStorage
                } catch (e) {
                    return !0
                }
            },
            hasLocalStorage: function() {
                try {
                    return !!window.localStorage
                } catch (e) {
                    return !0
                }
            },
            hasIndexedDB: function() {
                try {
                    return !!window.indexedDB
                } catch (e) {
                    return !0
                }
            },
            getHardwareConcurrency: function() {
                return navigator.hardwareConcurrency ? navigator.hardwareConcurrency : "unknown"
            },
            getNavigatorCpuClass: function() {
                return navigator.cpuClass ? navigator.cpuClass : "unknown"
            },
            getNavigatorPlatform: function() {
                return navigator.platform ? navigator.platform : "unknown"
            },
            getDoNotTrack: function() {
                return navigator.doNotTrack ? navigator.doNotTrack : navigator.msDoNotTrack ? navigator.msDoNotTrack : window.doNotTrack ? window.doNotTrack : "unknown"
            },
            getTouchSupport: function() {
                var e = 0,
                    t = !1;
                "undefined" != typeof navigator.maxTouchPoints ? e = navigator.maxTouchPoints : "undefined" != typeof navigator.msMaxTouchPoints && (e = navigator.msMaxTouchPoints);
                try {
                    document.createEvent("TouchEvent"), t = !0
                } catch (n) {}
                var i = "ontouchstart" in window;
                return [e, t, i]
            },
            getCanvasFp: function() {
                var e = [],
                    t = document.createElement("canvas");
                t.width = 2e3, t.height = 200, t.style.display = "inline";
                var n = t.getContext("2d");
                return n.rect(0, 0, 10, 10), n.rect(2, 2, 6, 6), e.push("canvas winding:" + (n.isPointInPath(5, 5, "evenodd") === !1 ? "yes" : "no")), n.textBaseline = "alphabetic", n.fillStyle = "#f60", n.fillRect(125, 1, 62, 20), n.fillStyle = "#069", this.options.dontUseFakeFontInCanvas ? n.font = "11pt Arial" : n.font = "11pt no-real-font-123", n.fillText("Cwm fjordbank glyphs vext quiz, \ud83d\ude03", 2, 15), n.fillStyle = "rgba(102, 204, 0, 0.2)", n.font = "18pt Arial", n.fillText("Cwm fjordbank glyphs vext quiz, \ud83d\ude03", 4, 45), n.globalCompositeOperation = "multiply", n.fillStyle = "rgb(255,0,255)", n.beginPath(), n.arc(50, 50, 50, 0, 2 * Math.PI, !0), n.closePath(), n.fill(), n.fillStyle = "rgb(0,255,255)", n.beginPath(), n.arc(100, 50, 50, 0, 2 * Math.PI, !0), n.closePath(), n.fill(), n.fillStyle = "rgb(255,255,0)", n.beginPath(), n.arc(75, 100, 50, 0, 2 * Math.PI, !0), n.closePath(), n.fill(), n.fillStyle = "rgb(255,0,255)", n.arc(75, 75, 75, 0, 2 * Math.PI, !0), n.arc(75, 75, 25, 0, 2 * Math.PI, !0), n.fill("evenodd"), t.toDataURL && e.push("canvas fp:" + t.toDataURL()), e.join("~")
            },
            getWebglFp: function() {
                var e, t = function(t) {
                        return e.clearColor(0, 0, 0, 1), e.enable(e.DEPTH_TEST), e.depthFunc(e.LEQUAL), e.clear(e.COLOR_BUFFER_BIT | e.DEPTH_BUFFER_BIT), "[" + t[0] + ", " + t[1] + "]"
                    },
                    n = function(e) {
                        var t = e.getExtension("EXT_texture_filter_anisotropic") || e.getExtension("WEBKIT_EXT_texture_filter_anisotropic") || e.getExtension("MOZ_EXT_texture_filter_anisotropic");
                        if (t) {
                            var n = e.getParameter(t.MAX_TEXTURE_MAX_ANISOTROPY_EXT);
                            return 0 === n && (n = 2), n
                        }
                        return null
                    };
                if (e = this.getWebglCanvas(), !e) return null;
                var i = [],
                    r = "attribute vec2 attrVertex;varying vec2 varyinTexCoordinate;uniform vec2 uniformOffset;void main(){varyinTexCoordinate=attrVertex+uniformOffset;gl_Position=vec4(attrVertex,0,1);}",
                    o = "precision mediump float;varying vec2 varyinTexCoordinate;void main() {gl_FragColor=vec4(varyinTexCoordinate,0,1);}",
                    a = e.createBuffer();
                e.bindBuffer(e.ARRAY_BUFFER, a);
                var s = new Float32Array([-.2, -.9, 0, .4, -.26, 0, 0, .732134444, 0]);
                e.bufferData(e.ARRAY_BUFFER, s, e.STATIC_DRAW), a.itemSize = 3, a.numItems = 3;
                var u = e.createProgram(),
                    c = e.createShader(e.VERTEX_SHADER);
                e.shaderSource(c, r), e.compileShader(c);
                var l = e.createShader(e.FRAGMENT_SHADER);
                e.shaderSource(l, o), e.compileShader(l), e.attachShader(u, c), e.attachShader(u, l), e.linkProgram(u), e.useProgram(u), u.vertexPosAttrib = e.getAttribLocation(u, "attrVertex"), u.offsetUniform = e.getUniformLocation(u, "uniformOffset"), e.enableVertexAttribArray(u.vertexPosArray), e.vertexAttribPointer(u.vertexPosAttrib, a.itemSize, e.FLOAT, !1, 0, 0), e.uniform2f(u.offsetUniform, 1, 1), e.drawArrays(e.TRIANGLE_STRIP, 0, a.numItems);
                try {
                    i.push(e.canvas.toDataURL())
                } catch (d) {}
                i.push("extensions:" + (e.getSupportedExtensions() || []).join(";")), i.push("webgl aliased line width range:" + t(e.getParameter(e.ALIASED_LINE_WIDTH_RANGE))), i.push("webgl aliased point size range:" + t(e.getParameter(e.ALIASED_POINT_SIZE_RANGE))), i.push("webgl alpha bits:" + e.getParameter(e.ALPHA_BITS)), i.push("webgl antialiasing:" + (e.getContextAttributes().antialias ? "yes" : "no")), i.push("webgl blue bits:" + e.getParameter(e.BLUE_BITS)), i.push("webgl depth bits:" + e.getParameter(e.DEPTH_BITS)), i.push("webgl green bits:" + e.getParameter(e.GREEN_BITS)), i.push("webgl max anisotropy:" + n(e)), i.push("webgl max combined texture image units:" + e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS)), i.push("webgl max cube map texture size:" + e.getParameter(e.MAX_CUBE_MAP_TEXTURE_SIZE)), i.push("webgl max fragment uniform vectors:" + e.getParameter(e.MAX_FRAGMENT_UNIFORM_VECTORS)), i.push("webgl max render buffer size:" + e.getParameter(e.MAX_RENDERBUFFER_SIZE)), i.push("webgl max texture image units:" + e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS)), i.push("webgl max texture size:" + e.getParameter(e.MAX_TEXTURE_SIZE)), i.push("webgl max varying vectors:" + e.getParameter(e.MAX_VARYING_VECTORS)), i.push("webgl max vertex attribs:" + e.getParameter(e.MAX_VERTEX_ATTRIBS)), i.push("webgl max vertex texture image units:" + e.getParameter(e.MAX_VERTEX_TEXTURE_IMAGE_UNITS)), i.push("webgl max vertex uniform vectors:" + e.getParameter(e.MAX_VERTEX_UNIFORM_VECTORS)), i.push("webgl max viewport dims:" + t(e.getParameter(e.MAX_VIEWPORT_DIMS))), i.push("webgl red bits:" + e.getParameter(e.RED_BITS)), i.push("webgl renderer:" + e.getParameter(e.RENDERER)), i.push("webgl shading language version:" + e.getParameter(e.SHADING_LANGUAGE_VERSION)), i.push("webgl stencil bits:" + e.getParameter(e.STENCIL_BITS)), i.push("webgl vendor:" + e.getParameter(e.VENDOR)), i.push("webgl version:" + e.getParameter(e.VERSION));
                try {
                    var h = e.getExtension("WEBGL_debug_renderer_info");
                    h && (i.push("webgl unmasked vendor:" + e.getParameter(h.UNMASKED_VENDOR_WEBGL)), i.push("webgl unmasked renderer:" + e.getParameter(h.UNMASKED_RENDERER_WEBGL)))
                } catch (d) {}
                return e.getShaderPrecisionFormat ? (i.push("webgl vertex shader high float precision:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.HIGH_FLOAT).precision), i.push("webgl vertex shader high float precision rangeMin:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.HIGH_FLOAT).rangeMin), i.push("webgl vertex shader high float precision rangeMax:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.HIGH_FLOAT).rangeMax), i.push("webgl vertex shader medium float precision:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.MEDIUM_FLOAT).precision), i.push("webgl vertex shader medium float precision rangeMin:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.MEDIUM_FLOAT).rangeMin), i.push("webgl vertex shader medium float precision rangeMax:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.MEDIUM_FLOAT).rangeMax), i.push("webgl vertex shader low float precision:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.LOW_FLOAT).precision), i.push("webgl vertex shader low float precision rangeMin:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.LOW_FLOAT).rangeMin), i.push("webgl vertex shader low float precision rangeMax:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.LOW_FLOAT).rangeMax), i.push("webgl fragment shader high float precision:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.HIGH_FLOAT).precision), i.push("webgl fragment shader high float precision rangeMin:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.HIGH_FLOAT).rangeMin), i.push("webgl fragment shader high float precision rangeMax:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.HIGH_FLOAT).rangeMax), i.push("webgl fragment shader medium float precision:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.MEDIUM_FLOAT).precision), i.push("webgl fragment shader medium float precision rangeMin:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.MEDIUM_FLOAT).rangeMin), i.push("webgl fragment shader medium float precision rangeMax:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.MEDIUM_FLOAT).rangeMax), i.push("webgl fragment shader low float precision:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.LOW_FLOAT).precision), i.push("webgl fragment shader low float precision rangeMin:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.LOW_FLOAT).rangeMin), i.push("webgl fragment shader low float precision rangeMax:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.LOW_FLOAT).rangeMax), i.push("webgl vertex shader high int precision:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.HIGH_INT).precision), i.push("webgl vertex shader high int precision rangeMin:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.HIGH_INT).rangeMin), i.push("webgl vertex shader high int precision rangeMax:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.HIGH_INT).rangeMax), i.push("webgl vertex shader medium int precision:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.MEDIUM_INT).precision), i.push("webgl vertex shader medium int precision rangeMin:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.MEDIUM_INT).rangeMin), i.push("webgl vertex shader medium int precision rangeMax:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.MEDIUM_INT).rangeMax), i.push("webgl vertex shader low int precision:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.LOW_INT).precision), i.push("webgl vertex shader low int precision rangeMin:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.LOW_INT).rangeMin), i.push("webgl vertex shader low int precision rangeMax:" + e.getShaderPrecisionFormat(e.VERTEX_SHADER, e.LOW_INT).rangeMax), i.push("webgl fragment shader high int precision:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.HIGH_INT).precision), i.push("webgl fragment shader high int precision rangeMin:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.HIGH_INT).rangeMin), i.push("webgl fragment shader high int precision rangeMax:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.HIGH_INT).rangeMax), i.push("webgl fragment shader medium int precision:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.MEDIUM_INT).precision), i.push("webgl fragment shader medium int precision rangeMin:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.MEDIUM_INT).rangeMin), i.push("webgl fragment shader medium int precision rangeMax:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.MEDIUM_INT).rangeMax), i.push("webgl fragment shader low int precision:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.LOW_INT).precision), i.push("webgl fragment shader low int precision rangeMin:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.LOW_INT).rangeMin), i.push("webgl fragment shader low int precision rangeMax:" + e.getShaderPrecisionFormat(e.FRAGMENT_SHADER, e.LOW_INT).rangeMax), i.join("~")) : i.join("~")
            },
            getWebglVendorAndRenderer: function() {
                try {
                    var e = this.getWebglCanvas(),
                        t = e.getExtension("WEBGL_debug_renderer_info");
                    return e.getParameter(t.UNMASKED_VENDOR_WEBGL) + "~" + e.getParameter(t.UNMASKED_RENDERER_WEBGL)
                } catch (n) {
                    return null
                }
            },
            getAdBlock: function() {
                var e = document.createElement("div");
                e.innerHTML = "&nbsp;", e.className = "adsbox";
                var t = !1;
                try {
                    document.body.appendChild(e), t = 0 === document.getElementsByClassName("adsbox")[0].offsetHeight, document.body.removeChild(e)
                } catch (n) {
                    t = !1
                }
                return t
            },
            getHasLiedLanguages: function() {
                if ("undefined" != typeof navigator.languages) try {
                    var e = navigator.languages[0].substr(0, 2);
                    if (e !== navigator.language.substr(0, 2)) return !0
                } catch (t) {
                    return !0
                }
                return !1
            },
            getHasLiedResolution: function() {
                return window.screen.width < window.screen.availWidth ? !0 : window.screen.height < window.screen.availHeight ? !0 : !1
            },
            getHasLiedOs: function() {
                var e, t = navigator.userAgent.toLowerCase(),
                    n = navigator.oscpu,
                    i = navigator.platform.toLowerCase();
                e = t.indexOf("windows phone") >= 0 ? "Windows Phone" : t.indexOf("win") >= 0 ? "Windows" : t.indexOf("android") >= 0 ? "Android" : t.indexOf("linux") >= 0 ? "Linux" : t.indexOf("iphone") >= 0 || t.indexOf("ipad") >= 0 ? "iOS" : t.indexOf("mac") >= 0 ? "Mac" : "Other";
                var r;
                if (r = "ontouchstart" in window || navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0 ? !0 : !1, r && "Windows Phone" !== e && "Android" !== e && "iOS" !== e && "Other" !== e) return !0;
                if ("undefined" != typeof n) {
                    if (n = n.toLowerCase(), n.indexOf("win") >= 0 && "Windows" !== e && "Windows Phone" !== e) return !0;
                    if (n.indexOf("linux") >= 0 && "Linux" !== e && "Android" !== e) return !0;
                    if (n.indexOf("mac") >= 0 && "Mac" !== e && "iOS" !== e) return !0;
                    if ((-1 === n.indexOf("win") && -1 === n.indexOf("linux") && -1 === n.indexOf("mac")) != ("Other" === e)) return !0
                }
                return i.indexOf("win") >= 0 && "Windows" !== e && "Windows Phone" !== e ? !0 : (i.indexOf("linux") >= 0 || i.indexOf("android") >= 0 || i.indexOf("pike") >= 0) && "Linux" !== e && "Android" !== e ? !0 : (i.indexOf("mac") >= 0 || i.indexOf("ipad") >= 0 || i.indexOf("ipod") >= 0 || i.indexOf("iphone") >= 0) && "Mac" !== e && "iOS" !== e ? !0 : (-1 === i.indexOf("win") && -1 === i.indexOf("linux") && -1 === i.indexOf("mac")) != ("Other" === e) ? !0 : "undefined" == typeof navigator.plugins && "Windows" !== e && "Windows Phone" !== e ? !0 : !1
            },
            getHasLiedBrowser: function() {
                var e, t = navigator.userAgent.toLowerCase(),
                    n = navigator.productSub;
                if (e = t.indexOf("firefox") >= 0 ? "Firefox" : t.indexOf("opera") >= 0 || t.indexOf("opr") >= 0 ? "Opera" : t.indexOf("chrome") >= 0 ? "Chrome" : t.indexOf("safari") >= 0 ? "Safari" : t.indexOf("trident") >= 0 ? "Internet Explorer" : "Other", ("Chrome" === e || "Safari" === e || "Opera" === e) && "20030107" !== n) return !0;
                var i = eval.toString().length;
                if (37 === i && "Safari" !== e && "Firefox" !== e && "Other" !== e) return !0;
                if (39 === i && "Internet Explorer" !== e && "Other" !== e) return !0;
                if (33 === i && "Chrome" !== e && "Opera" !== e && "Other" !== e) return !0;
                var r;
                try {
                    throw "a"
                } catch (o) {
                    try {
                        o.toSource(), r = !0
                    } catch (a) {
                        r = !1
                    }
                }
                return r && "Firefox" !== e && "Other" !== e ? !0 : !1
            },
            isCanvasSupported: function() {
                var e = document.createElement("canvas");
                return !(!e.getContext || !e.getContext("2d"))
            },
            isWebGlSupported: function() {
                if (!this.isCanvasSupported()) return !1;
                var e = this.getWebglCanvas();
                return !!window.WebGLRenderingContext && !!e
            },
            isIE: function() {
                return "Microsoft Internet Explorer" === navigator.appName ? !0 : "Netscape" === navigator.appName && /Trident/.test(navigator.userAgent) ? !0 : !1
            },
            hasSwfObjectLoaded: function() {
                return "undefined" != typeof window.swfobject
            },
            hasMinFlashInstalled: function() {
                return window.swfobject.hasFlashPlayerVersion("9.0.0")
            },
            addFlashDivNode: function() {
                var e = document.createElement("div");
                e.setAttribute("id", this.options.swfContainerId), document.body.appendChild(e)
            },
            loadSwfAndDetectFonts: function(e) {
                var t = "___fp_swf_loaded";
                window[t] = function(t) {
                    e(t)
                };
                var n = this.options.swfContainerId;
                this.addFlashDivNode();
                var i = {
                        onReady: t
                    },
                    r = {
                        allowScriptAccess: "always",
                        menu: "false"
                    };
                window.swfobject.embedSWF(this.options.swfPath, n, "1", "1", "9.0.0", !1, i, r, {})
            },
            getWebglCanvas: function() {
                var e = document.createElement("canvas"),
                    t = null;
                try {
                    t = e.getContext("webgl") || e.getContext("experimental-webgl")
                } catch (n) {}
                return t || (t = null), t
            },
            each: function(e, t, n) {
                if (null !== e)
                    if (this.nativeForEach && e.forEach === this.nativeForEach) e.forEach(t, n);
                    else if (e.length === +e.length) {
                    for (var i = 0, r = e.length; r > i; i++)
                        if (t.call(n, e[i], i, e) === {}) return
                } else
                    for (var o in e)
                        if (e.hasOwnProperty(o) && t.call(n, e[o], o, e) === {}) return
            },
            map: function(e, t, n) {
                var i = [];
                return null == e ? i : this.nativeMap && e.map === this.nativeMap ? e.map(t, n) : (this.each(e, function(e, r, o) {
                    i[i.length] = t.call(n, e, r, o)
                }), i)
            },
            x64Add: function(e, t) {
                e = [e[0] >>> 16, 65535 & e[0], e[1] >>> 16, 65535 & e[1]], t = [t[0] >>> 16, 65535 & t[0], t[1] >>> 16, 65535 & t[1]];
                var n = [0, 0, 0, 0];
                return n[3] += e[3] + t[3], n[2] += n[3] >>> 16, n[3] &= 65535, n[2] += e[2] + t[2], n[1] += n[2] >>> 16, n[2] &= 65535, n[1] += e[1] + t[1], n[0] += n[1] >>> 16, n[1] &= 65535, n[0] += e[0] + t[0], n[0] &= 65535, [n[0] << 16 | n[1], n[2] << 16 | n[3]]
            },
            x64Multiply: function(e, t) {
                e = [e[0] >>> 16, 65535 & e[0], e[1] >>> 16, 65535 & e[1]], t = [t[0] >>> 16, 65535 & t[0], t[1] >>> 16, 65535 & t[1]];
                var n = [0, 0, 0, 0];
                return n[3] += e[3] * t[3], n[2] += n[3] >>> 16, n[3] &= 65535, n[2] += e[2] * t[3], n[1] += n[2] >>> 16, n[2] &= 65535, n[2] += e[3] * t[2], n[1] += n[2] >>> 16, n[2] &= 65535, n[1] += e[1] * t[3], n[0] += n[1] >>> 16, n[1] &= 65535, n[1] += e[2] * t[2], n[0] += n[1] >>> 16, n[1] &= 65535, n[1] += e[3] * t[1], n[0] += n[1] >>> 16, n[1] &= 65535, n[0] += e[0] * t[3] + e[1] * t[2] + e[2] * t[1] + e[3] * t[0], n[0] &= 65535, [n[0] << 16 | n[1], n[2] << 16 | n[3]]
            },
            x64Rotl: function(e, t) {
                return t %= 64, 32 === t ? [e[1], e[0]] : 32 > t ? [e[0] << t | e[1] >>> 32 - t, e[1] << t | e[0] >>> 32 - t] : (t -= 32, [e[1] << t | e[0] >>> 32 - t, e[0] << t | e[1] >>> 32 - t])
            },
            x64LeftShift: function(e, t) {
                return t %= 64, 0 === t ? e : 32 > t ? [e[0] << t | e[1] >>> 32 - t, e[1] << t] : [e[1] << t - 32, 0]
            },
            x64Xor: function(e, t) {
                return [e[0] ^ t[0], e[1] ^ t[1]]
            },
            x64Fmix: function(e) {
                return e = this.x64Xor(e, [0, e[0] >>> 1]), e = this.x64Multiply(e, [4283543511, 3981806797]), e = this.x64Xor(e, [0, e[0] >>> 1]), e = this.x64Multiply(e, [3301882366, 444984403]), e = this.x64Xor(e, [0, e[0] >>> 1])
            },
            x64hash128: function(e, t) {
                e = e || "", t = t || 0;
                for (var n = e.length % 16, i = e.length - n, r = [0, t], o = [0, t], a = [0, 0], s = [0, 0], u = [2277735313, 289559509], c = [1291169091, 658871167], l = 0; i > l; l += 16) a = [255 & e.charCodeAt(l + 4) | (255 & e.charCodeAt(l + 5)) << 8 | (255 & e.charCodeAt(l + 6)) << 16 | (255 & e.charCodeAt(l + 7)) << 24, 255 & e.charCodeAt(l) | (255 & e.charCodeAt(l + 1)) << 8 | (255 & e.charCodeAt(l + 2)) << 16 | (255 & e.charCodeAt(l + 3)) << 24], s = [255 & e.charCodeAt(l + 12) | (255 & e.charCodeAt(l + 13)) << 8 | (255 & e.charCodeAt(l + 14)) << 16 | (255 & e.charCodeAt(l + 15)) << 24, 255 & e.charCodeAt(l + 8) | (255 & e.charCodeAt(l + 9)) << 8 | (255 & e.charCodeAt(l + 10)) << 16 | (255 & e.charCodeAt(l + 11)) << 24], a = this.x64Multiply(a, u), a = this.x64Rotl(a, 31), a = this.x64Multiply(a, c), r = this.x64Xor(r, a), r = this.x64Rotl(r, 27), r = this.x64Add(r, o), r = this.x64Add(this.x64Multiply(r, [0, 5]), [0, 1390208809]), s = this.x64Multiply(s, c), s = this.x64Rotl(s, 33), s = this.x64Multiply(s, u), o = this.x64Xor(o, s), o = this.x64Rotl(o, 31), o = this.x64Add(o, r), o = this.x64Add(this.x64Multiply(o, [0, 5]), [0, 944331445]);
                switch (a = [0, 0], s = [0, 0], n) {
                    case 15:
                        s = this.x64Xor(s, this.x64LeftShift([0, e.charCodeAt(l + 14)], 48));
                    case 14:
                        s = this.x64Xor(s, this.x64LeftShift([0, e.charCodeAt(l + 13)], 40));
                    case 13:
                        s = this.x64Xor(s, this.x64LeftShift([0, e.charCodeAt(l + 12)], 32));
                    case 12:
                        s = this.x64Xor(s, this.x64LeftShift([0, e.charCodeAt(l + 11)], 24));
                    case 11:
                        s = this.x64Xor(s, this.x64LeftShift([0, e.charCodeAt(l + 10)], 16));
                    case 10:
                        s = this.x64Xor(s, this.x64LeftShift([0, e.charCodeAt(l + 9)], 8));
                    case 9:
                        s = this.x64Xor(s, [0, e.charCodeAt(l + 8)]), s = this.x64Multiply(s, c), s = this.x64Rotl(s, 33), s = this.x64Multiply(s, u), o = this.x64Xor(o, s);
                    case 8:
                        a = this.x64Xor(a, this.x64LeftShift([0, e.charCodeAt(l + 7)], 56));
                    case 7:
                        a = this.x64Xor(a, this.x64LeftShift([0, e.charCodeAt(l + 6)], 48));
                    case 6:
                        a = this.x64Xor(a, this.x64LeftShift([0, e.charCodeAt(l + 5)], 40));
                    case 5:
                        a = this.x64Xor(a, this.x64LeftShift([0, e.charCodeAt(l + 4)], 32));
                    case 4:
                        a = this.x64Xor(a, this.x64LeftShift([0, e.charCodeAt(l + 3)], 24));
                    case 3:
                        a = this.x64Xor(a, this.x64LeftShift([0, e.charCodeAt(l + 2)], 16));
                    case 2:
                        a = this.x64Xor(a, this.x64LeftShift([0, e.charCodeAt(l + 1)], 8));
                    case 1:
                        a = this.x64Xor(a, [0, e.charCodeAt(l)]), a = this.x64Multiply(a, u), a = this.x64Rotl(a, 31), a = this.x64Multiply(a, c), r = this.x64Xor(r, a)
                }
                return r = this.x64Xor(r, [0, e.length]), o = this.x64Xor(o, [0, e.length]), r = this.x64Add(r, o), o = this.x64Add(o, r), r = this.x64Fmix(r), o = this.x64Fmix(o), r = this.x64Add(r, o), o = this.x64Add(o, r), ("00000000" + (r[0] >>> 0).toString(16)).slice(-8) + ("00000000" + (r[1] >>> 0).toString(16)).slice(-8) + ("00000000" + (o[0] >>> 0).toString(16)).slice(-8) + ("00000000" + (o[1] >>> 0).toString(16)).slice(-8)
            }
        }, e.VERSION = "1.8.0", e
    }),
    function(e) {
        var t = ["{47F67D00-9E55-11D1-BAEF-00C04FC2D130}", "{7790769C-0471-11D2-AF11-00C04FA35D02}", "{76C19B38-F0C8-11CF-87CC-0020AFEECF20}", "{76C19B34-F0C8-11CF-87CC-0020AFEECF20}", "{76C19B33-F0C8-11CF-87CC-0020AFEECF20}", "{4F216970-C90C-11D1-B5C7-0000F8051515}", "{283807B5-2C60-11D0-A31D-00AA00B92C03}", "{44BBA848-CC51-11CF-AAFA-00AA00B6015C}", "{4F216970-C90C-11D1-B5C7-0000F8051515}", "{9381D8F2-0288-11D0-9501-00AA00B911A5}", "{76C19B36-F0C8-11CF-87CC-0020AFEECF20}", "{5A8D6EE0-3E18-11D0-821E-444553540000}", "{89820200-ECBD-11CF-8B85-00AA005B4383}", "{630B1DA0-B465-11D1-9948-00C04F98BBC9}", "{08B0E5C0-4FCB-11CF-AAA5-00401C608555}", "{DE5AED00-A4BF-11D1-9948-00C04F98BBC9}", "{45EA75A0-A269-11D1-B5BF-0000F8051515}", "{89820200-ECBD-11CF-8B85-00AA005B4383}", "{76C19B30-F0C8-11CF-87CC-0020AFEECF20}", "{76C19B31-F0C8-11CF-87CC-0020AFEECF20}", "{76C19B50-F0C8-11CF-87CC-0020AFEECF20}", "{D27CDB6E-AE6D-11CF-96B8-444553540000}", "{2A202491-F00D-11CF-87CC-0020AFEECF20}", "{08B0E5C0-4FCB-11CF-AAA5-00401C608500}", "{44BBA842-CC51-11CF-AAFA-00AA00B6015B}", "{3AF36230-A269-11D1-B5BF-0000F8051515}", "{44BBA840-CC51-11CF-AAFA-00AA00B6015C}", "{76C19B32-F0C8-11CF-87CC-0020AFEECF20}", "{CC2A9BA0-3BDD-11D0-821E-444553540000}", "{76C19B35-F0C8-11CF-87CC-0020AFEECF20}", "{3BF42070-B3B1-11D1-B5C5-0000F8051515}", "{90A7533D-88FE-11D0-9DBE-0000C0411FC3}", "{10072CEC-8CC1-11D1-986E-00A0C955B42F}", "{76C19B37-F0C8-11CF-87CC-0020AFEECF20}", "{4F645220-306D-11D2-995D-00C04F98BBC9}", "{1CDEE860-E95B-11CF-B1B0-00AA00BBAD66}", "{73FA19D0-2D75-11D2-995D-00C04F98BBC9}", "{89820200-ECBD-11CF-8B85-00AA005B4340}", "{23064720-C4F8-11D1-994D-00C04F98BBC9}", "{22D6F312-B0F6-11D0-94AB-0080C74C7E95}"];
        e.browserAnalytics = function() {
            function n() {
                if ("function" == typeof e.fontlist) {
                    for (var t = e.fontlist(), n = [], i = 0; 25 > i; n[i++] = 0);
                    e.each(t, function(e, t) {
                        var i = t >> 3,
                            r = t % 8;
                        n[i] = (n[i] || 0) + (1 << r)
                    });
                    var r = String.fromCharCode.apply(null, n);
                    return btoa(r)
                }
                return ""
            }

            function i() {
                return [navigator.userAgent, navigator.cpuClass || navigator.oscpu || navigator.platform, navigator.hardwareConcurrency || 1, navigator.productSub || "", navigator.buildID || "", navigator.language || navigator.userLanguage].join("#")
            }

            function r() {
                var e = new Date(1),
                    t = new Date(15552e6);
                return [e.getTimezoneOffset(), t.getTimezoneOffset(), e.toString(), e.toLocaleString()].join("#")
            }

            function o() {
                try {
                    document.body.style.behavior = "url(#default#clientcaps)"
                } catch (n) {}
                var i = document.body;
                if ("undefined" == typeof i.getComponentVersion) return "";
                var r = [];
                return e.each(t, function(e, t) {
                    i.isComponentInstalled(t, "ComponentID") && r.push(e + "-" + i.getComponentVersion(t, "ComponentID"))
                }), r.join("#")
            }

            function a() {
                try {
                    var t = navigator.plugins;
                    return t.length > 64 && (t = [].splice.call(t, 0, 64)), e.map(t, function(t) {
                        return md5([t.name, t.description, e.map(t, function(e) {
                            return [e.type, e.suffixes].join("~")
                        }).join(",")].join("::"))
                    }).join("#")
                } catch (n) {
                    return "invalid-plugins"
                }
            }

            function s() {
                return [window.screen.width, window.screen.height, window.screen.availWidth, window.screen.availHeight, window.devicePixelRatio || 1, window.screen.colorDepth || window.screen.pixelDepth, window.outerWidth - window.innerWidth, window.outerHeight - window.innerHeight].join("#")
            }
            if ("function" != typeof window.md5) throw "md5 unavailable, please get it from http://github.com/wbond/md5-js/";
            var u = [i(), r(), s(), a(), o(), n()].join("|");
            return u
        }
    }(jQuery),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.DeviceTracking = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.DeviceTracking", n.run = function() {
                return $.cookie("df") || $.cookie("df", jQuery.fingerprint(), {
                    expires: 99999,
                    path: "/",
                    secure: Coinbase.constants.HTTPS
                }), $.cookie("df2") || (new Fingerprint2).get(function(e) {
                    return $.cookie("df2", e, {
                        expires: 99999,
                        path: "/",
                        secure: Coinbase.constants.HTTPS
                    })
                }), $.cookie("ba") ? void 0 : $.cookie("ba", jQuery.browserAnalytics(), {
                    expires: 1,
                    path: "/",
                    secure: Coinbase.constants.HTTPS
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this);
var _createClass = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
            }
        }
        return function(t, n, i) {
            return n && e(t.prototype, n), i && e(t, i), t
        }
    }(),
    _get = function(e, t, n) {
        for (var i = !0; i;) {
            var r = e,
                o = t,
                a = n;
            i = !1, null === r && (r = Function.prototype);
            var s = Object.getOwnPropertyDescriptor(r, o);
            if (void 0 !== s) {
                if ("value" in s) return s.value;
                var u = s.get;
                return void 0 === u ? void 0 : u.call(a)
            }
            var c = Object.getPrototypeOf(r);
            if (null === c) return void 0;
            e = c, t = o, n = a, i = !0, s = c = void 0
        }
    };
Coinbase.Widgets.EditAccountFlags = function(e) {
        function t() {
            _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
        }
        return _inherits(t, e), _createClass(t, null, [{
            key: "run",
            value: function() {
                var e = $("#account_flags_modal");
                temp_notes = "", e.find("input.account-flag").on("change", function(e) {
                    $(this).siblings(".flag-reasons").toggle(e.target.checked);
                    var t = $(this).closest("form");
                    $.get(t.data("update-url"), t.serialize()).then(function(e) {
                        return $("#user_policy").html(e)
                    })
                }), e.find(".add-reason").on("click", function(e) {
                    e.preventDefault();
                    var t = $(this).siblings("select").val(),
                        n = $(this).closest(".flag-reasons").find('li[data-reason="' + t + '"]');
                    n.find("input").removeAttr("disabled"), n.show()
                }), e.find(".remove-reason").on("click", function(e) {
                    e.preventDefault(), $(this).siblings("input").attr("disabled", "disabled"), $(this).parent().hide()
                }), e.on("show", function(e) {
                    temp_notes && $("#notes").val(temp_notes)
                }), e.on("hidden", function(e) {
                    $("#notes").val() && (temp_notes = $("#notes").val())
                }), $(".edit_user").bind("ajax:complete", function() {
                    $("#notes").val("")
                })
            }
        }]), t
    }(Coinbase.Widgets.BaseWidget), Coinbase.Widgets.ChangeCountry.className = "Coinbase.Widgets.EditAccountFlags",
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.ExchangeRates = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.ExchangeRates", n.run = function() {
                return $(document).on("focus", "[data-convert-target]", function(e) {
                    var t;
                    return t = $(this).data("convert-from"), Coinbase.utils.currencyTextFieldObserver($(this), t, {
                        show_units: !1,
                        show_symbol: !1
                    })
                }), $(document).on("keyup", "[data-convert-target]", function(e) {
                    var t, n, i, r, o, a, s;
                    if (t = e.keyCode || e.which, 9 !== t && 16 !== t && 37 !== t && 38 !== t && 39 !== t && 40 !== t) {
                        switch (n = $(this).data("convert-from"), a = $(this).data("convert-to"), o = $(this).data("convert-target"), r = $("#" + o), i = Coinbase.utils.normalizeCurrencyInput($(this).val()), s = i * Coinbase.exchangeRatesGlobal[(n + "_to_" + a).toLowerCase()], a.toLowerCase()) {
                            case "btc":
                                s = s.toFixed(6);
                                break;
                            case "bits":
                                s = s.toFixed(0)
                        }
                        return r.is(":input") ? r.val(Coinbase.utils.formatCurrency(s, a, {
                            show_units: !1,
                            show_symbol: !1
                        })) : r.text(Coinbase.utils.formatCurrency(s, a, {
                            show_units: !1,
                            show_symbol: !0
                        }))
                    }
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.ExchangeTransfer = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.ExchangeTransfer", n.run = function() {
                return $(document).on("click", "#exchange_transfer_submit", function(e) {
                    return e.preventDefault(), $("#exchange_transfer_spinner").show(), $("#exchange_transfer form").submit()
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function(e) {
        "function" == typeof define && define.amd ? define(["jquery", "./version"], e) : e(jQuery)
    }(function(e) {
        return e.ui.ie = !!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase())
    }),
    function(e) {
        "function" == typeof define && define.amd ? define(["jquery", "./version"], e) : e(jQuery)
    }(function(e) {
        var t = 0,
            n = Array.prototype.slice;
        return e.cleanData = function(t) {
            return function(n) {
                var i, r, o;
                for (o = 0; null != (r = n[o]); o++) try {
                    i = e._data(r, "events"), i && i.remove && e(r).triggerHandler("remove")
                } catch (a) {}
                t(n)
            }
        }(e.cleanData), e.widget = function(t, n, i) {
            var r, o, a, s = {},
                u = t.split(".")[0];
            t = t.split(".")[1];
            var c = u + "-" + t;
            return i || (i = n, n = e.Widget), e.isArray(i) && (i = e.extend.apply(null, [{}].concat(i))), e.expr[":"][c.toLowerCase()] = function(t) {
                return !!e.data(t, c)
            }, e[u] = e[u] || {}, r = e[u][t], o = e[u][t] = function(e, t) {
                return this._createWidget ? void(arguments.length && this._createWidget(e, t)) : new o(e, t)
            }, e.extend(o, r, {
                version: i.version,
                _proto: e.extend({}, i),
                _childConstructors: []
            }), a = new n, a.options = e.widget.extend({}, a.options), e.each(i, function(t, i) {
                return e.isFunction(i) ? void(s[t] = function() {
                    function e() {
                        return n.prototype[t].apply(this, arguments)
                    }

                    function r(e) {
                        return n.prototype[t].apply(this, e)
                    }
                    return function() {
                        var t, n = this._super,
                            o = this._superApply;
                        return this._super = e, this._superApply = r, t = i.apply(this, arguments), this._super = n, this._superApply = o, t
                    }
                }()) : void(s[t] = i)
            }), o.prototype = e.widget.extend(a, {
                widgetEventPrefix: r ? a.widgetEventPrefix || t : t
            }, s, {
                constructor: o,
                namespace: u,
                widgetName: t,
                widgetFullName: c
            }), r ? (e.each(r._childConstructors, function(t, n) {
                var i = n.prototype;
                e.widget(i.namespace + "." + i.widgetName, o, n._proto)
            }), delete r._childConstructors) : n._childConstructors.push(o), e.widget.bridge(t, o), o
        }, e.widget.extend = function(t) {
            for (var i, r, o = n.call(arguments, 1), a = 0, s = o.length; s > a; a++)
                for (i in o[a]) r = o[a][i], o[a].hasOwnProperty(i) && void 0 !== r && (e.isPlainObject(r) ? t[i] = e.isPlainObject(t[i]) ? e.widget.extend({}, t[i], r) : e.widget.extend({}, r) : t[i] = r);
            return t
        }, e.widget.bridge = function(t, i) {
            var r = i.prototype.widgetFullName || t;
            e.fn[t] = function(o) {
                var a = "string" == typeof o,
                    s = n.call(arguments, 1),
                    u = this;
                return a ? this.length || "instance" !== o ? this.each(function() {
                    var n, i = e.data(this, r);
                    return "instance" === o ? (u = i, !1) : i ? e.isFunction(i[o]) && "_" !== o.charAt(0) ? (n = i[o].apply(i, s), n !== i && void 0 !== n ? (u = n && n.jquery ? u.pushStack(n.get()) : n, !1) : void 0) : e.error("no such method '" + o + "' for " + t + " widget instance") : e.error("cannot call methods on " + t + " prior to initialization; attempted to call method '" + o + "'")
                }) : u = void 0 : (s.length && (o = e.widget.extend.apply(null, [o].concat(s))), this.each(function() {
                    var t = e.data(this, r);
                    t ? (t.option(o || {}), t._init && t._init()) : e.data(this, r, new i(o, this))
                })), u
            }
        }, e.Widget = function() {}, e.Widget._childConstructors = [], e.Widget.prototype = {
            widgetName: "widget",
            widgetEventPrefix: "",
            defaultElement: "<div>",
            options: {
                classes: {},
                disabled: !1,
                create: null
            },
            _createWidget: function(n, i) {
                i = e(i || this.defaultElement || this)[0], this.element = e(i), this.uuid = t++, this.eventNamespace = "." + this.widgetName + this.uuid, this.bindings = e(), this.hoverable = e(), this.focusable = e(), this.classesElementLookup = {}, i !== this && (e.data(i, this.widgetFullName, this), this._on(!0, this.element, {
                    remove: function(e) {
                        e.target === i && this.destroy()
                    }
                }), this.document = e(i.style ? i.ownerDocument : i.document || i), this.window = e(this.document[0].defaultView || this.document[0].parentWindow)), this.options = e.widget.extend({}, this.options, this._getCreateOptions(), n), this._create(), this.options.disabled && this._setOptionDisabled(this.options.disabled), this._trigger("create", null, this._getCreateEventData()), this._init()
            },
            _getCreateOptions: function() {
                return {}
            },
            _getCreateEventData: e.noop,
            _create: e.noop,
            _init: e.noop,
            destroy: function() {
                var t = this;
                this._destroy(), e.each(this.classesElementLookup, function(e, n) {
                    t._removeClass(n, e)
                }), this.element.off(this.eventNamespace).removeData(this.widgetFullName), this.widget().off(this.eventNamespace).removeAttr("aria-disabled"), this.bindings.off(this.eventNamespace)
            },
            _destroy: e.noop,
            widget: function() {
                return this.element
            },
            option: function(t, n) {
                var i, r, o, a = t;
                if (0 === arguments.length) return e.widget.extend({}, this.options);
                if ("string" == typeof t)
                    if (a = {}, i = t.split("."), t = i.shift(), i.length) {
                        for (r = a[t] = e.widget.extend({}, this.options[t]), o = 0; o < i.length - 1; o++) r[i[o]] = r[i[o]] || {}, r = r[i[o]];
                        if (t = i.pop(), 1 === arguments.length) return void 0 === r[t] ? null : r[t];
                        r[t] = n
                    } else {
                        if (1 === arguments.length) return void 0 === this.options[t] ? null : this.options[t];
                        a[t] = n
                    }
                return this._setOptions(a), this
            },
            _setOptions: function(e) {
                var t;
                for (t in e) this._setOption(t, e[t]);
                return this
            },
            _setOption: function(e, t) {
                return "classes" === e && this._setOptionClasses(t), this.options[e] = t, "disabled" === e && this._setOptionDisabled(t), this
            },
            _setOptionClasses: function(t) {
                var n, i, r;
                for (n in t) r = this.classesElementLookup[n], t[n] !== this.options.classes[n] && r && r.length && (i = e(r.get()), this._removeClass(r, n), i.addClass(this._classes({
                    element: i,
                    keys: n,
                    classes: t,
                    add: !0
                })))
            },
            _setOptionDisabled: function(e) {
                this._toggleClass(this.widget(), this.widgetFullName + "-disabled", null, !!e), e && (this._removeClass(this.hoverable, null, "ui-state-hover"), this._removeClass(this.focusable, null, "ui-state-focus"))
            },
            enable: function() {
                return this._setOptions({
                    disabled: !1
                })
            },
            disable: function() {
                return this._setOptions({
                    disabled: !0
                })
            },
            _classes: function(t) {
                function n(n, o) {
                    var a, s;
                    for (s = 0; s < n.length; s++) a = r.classesElementLookup[n[s]] || e(), a = e(t.add ? e.unique(a.get().concat(t.element.get())) : a.not(t.element).get()), r.classesElementLookup[n[s]] = a, i.push(n[s]), o && t.classes[n[s]] && i.push(t.classes[n[s]])
                }
                var i = [],
                    r = this;
                return t = e.extend({
                    element: this.element,
                    classes: this.options.classes || {}
                }, t), this._on(t.element, {
                    remove: "_untrackClassesElement"
                }), t.keys && n(t.keys.match(/\S+/g) || [], !0), t.extra && n(t.extra.match(/\S+/g) || []), i.join(" ")
            },
            _untrackClassesElement: function(t) {
                var n = this;
                e.each(n.classesElementLookup, function(i, r) {
                    -1 !== e.inArray(t.target, r) && (n.classesElementLookup[i] = e(r.not(t.target).get()))
                })
            },
            _removeClass: function(e, t, n) {
                return this._toggleClass(e, t, n, !1)
            },
            _addClass: function(e, t, n) {
                return this._toggleClass(e, t, n, !0)
            },
            _toggleClass: function(e, t, n, i) {
                i = "boolean" == typeof i ? i : n;
                var r = "string" == typeof e || null === e,
                    o = {
                        extra: r ? t : n,
                        keys: r ? e : t,
                        element: r ? this.element : e,
                        add: i
                    };
                return o.element.toggleClass(this._classes(o), i), this
            },
            _on: function(t, n, i) {
                var r, o = this;
                "boolean" != typeof t && (i = n, n = t, t = !1), i ? (n = r = e(n), this.bindings = this.bindings.add(n)) : (i = n, n = this.element, r = this.widget()), e.each(i, function(i, a) {
                    function s() {
                        return t || o.options.disabled !== !0 && !e(this).hasClass("ui-state-disabled") ? ("string" == typeof a ? o[a] : a).apply(o, arguments) : void 0
                    }
                    "string" != typeof a && (s.guid = a.guid = a.guid || s.guid || e.guid++);
                    var u = i.match(/^([\w:-]*)\s*(.*)$/),
                        c = u[1] + o.eventNamespace,
                        l = u[2];
                    l ? r.on(c, l, s) : n.on(c, s)
                })
            },
            _off: function(t, n) {
                n = (n || "").split(" ").join(this.eventNamespace + " ") + this.eventNamespace, t.off(n).off(n), this.bindings = e(this.bindings.not(t).get()), this.focusable = e(this.focusable.not(t).get()), this.hoverable = e(this.hoverable.not(t).get())
            },
            _delay: function(e, t) {
                function n() {
                    return ("string" == typeof e ? i[e] : e).apply(i, arguments)
                }
                var i = this;
                return setTimeout(n, t || 0)
            },
            _hoverable: function(t) {
                this.hoverable = this.hoverable.add(t), this._on(t, {
                    mouseenter: function(t) {
                        this._addClass(e(t.currentTarget), null, "ui-state-hover")
                    },
                    mouseleave: function(t) {
                        this._removeClass(e(t.currentTarget), null, "ui-state-hover")
                    }
                })
            },
            _focusable: function(t) {
                this.focusable = this.focusable.add(t), this._on(t, {
                    focusin: function(t) {
                        this._addClass(e(t.currentTarget), null, "ui-state-focus")
                    },
                    focusout: function(t) {
                        this._removeClass(e(t.currentTarget), null, "ui-state-focus")
                    }
                })
            },
            _trigger: function(t, n, i) {
                var r, o, a = this.options[t];
                if (i = i || {}, n = e.Event(n), n.type = (t === this.widgetEventPrefix ? t : this.widgetEventPrefix + t).toLowerCase(), n.target = this.element[0], o = n.originalEvent)
                    for (r in o) r in n || (n[r] = o[r]);
                return this.element.trigger(n, i), !(e.isFunction(a) && a.apply(this.element[0], [n].concat(i)) === !1 || n.isDefaultPrevented())
            }
        }, e.each({
            show: "fadeIn",
            hide: "fadeOut"
        }, function(t, n) {
            e.Widget.prototype["_" + t] = function(i, r, o) {
                "string" == typeof r && (r = {
                    effect: r
                });
                var a, s = r ? r === !0 || "number" == typeof r ? n : r.effect || n : t;
                r = r || {}, "number" == typeof r && (r = {
                    duration: r
                }), a = !e.isEmptyObject(r), r.complete = o, r.delay && i.delay(r.delay), a && e.effects && e.effects.effect[s] ? i[t](r) : s !== t && i[s] ? i[s](r.duration, r.easing, o) : i.queue(function(n) {
                    e(this)[t](), o && o.call(i[0]), n()
                })
            }
        }), e.widget
    }),
    function(e) {
        "function" == typeof define && define.amd ? define(["jquery", "../ie", "../version", "../widget"], e) : e(jQuery)
    }(function(e) {
        var t = !1;
        return e(document).on("mouseup", function() {
            t = !1
        }), e.widget("ui.mouse", {
            version: "1.12.1",
            options: {
                cancel: "input, textarea, button, select, option",
                distance: 1,
                delay: 0
            },
            _mouseInit: function() {
                var t = this;
                this.element.on("mousedown." + this.widgetName, function(e) {
                    return t._mouseDown(e)
                }).on("click." + this.widgetName, function(n) {
                    return !0 === e.data(n.target, t.widgetName + ".preventClickEvent") ? (e.removeData(n.target, t.widgetName + ".preventClickEvent"), n.stopImmediatePropagation(), !1) : void 0
                }), this.started = !1
            },
            _mouseDestroy: function() {
                this.element.off("." + this.widgetName), this._mouseMoveDelegate && this.document.off("mousemove." + this.widgetName, this._mouseMoveDelegate).off("mouseup." + this.widgetName, this._mouseUpDelegate)
            },
            _mouseDown: function(n) {
                if (!t) {
                    this._mouseMoved = !1, this._mouseStarted && this._mouseUp(n), this._mouseDownEvent = n;
                    var i = this,
                        r = 1 === n.which,
                        o = "string" == typeof this.options.cancel && n.target.nodeName ? e(n.target).closest(this.options.cancel).length : !1;
                    return r && !o && this._mouseCapture(n) ? (this.mouseDelayMet = !this.options.delay, this.mouseDelayMet || (this._mouseDelayTimer = setTimeout(function() {
                        i.mouseDelayMet = !0
                    }, this.options.delay)), this._mouseDistanceMet(n) && this._mouseDelayMet(n) && (this._mouseStarted = this._mouseStart(n) !== !1, !this._mouseStarted) ? (n.preventDefault(), !0) : (!0 === e.data(n.target, this.widgetName + ".preventClickEvent") && e.removeData(n.target, this.widgetName + ".preventClickEvent"), this._mouseMoveDelegate = function(e) {
                        return i._mouseMove(e)
                    }, this._mouseUpDelegate = function(e) {
                        return i._mouseUp(e)
                    }, this.document.on("mousemove." + this.widgetName, this._mouseMoveDelegate).on("mouseup." + this.widgetName, this._mouseUpDelegate), n.preventDefault(), t = !0, !0)) : !0
                }
            },
            _mouseMove: function(t) {
                if (this._mouseMoved) {
                    if (e.ui.ie && (!document.documentMode || document.documentMode < 9) && !t.button) return this._mouseUp(t);
                    if (!t.which)
                        if (t.originalEvent.altKey || t.originalEvent.ctrlKey || t.originalEvent.metaKey || t.originalEvent.shiftKey) this.ignoreMissingWhich = !0;
                        else if (!this.ignoreMissingWhich) return this._mouseUp(t)
                }
                return (t.which || t.button) && (this._mouseMoved = !0), this._mouseStarted ? (this._mouseDrag(t), t.preventDefault()) : (this._mouseDistanceMet(t) && this._mouseDelayMet(t) && (this._mouseStarted = this._mouseStart(this._mouseDownEvent, t) !== !1, this._mouseStarted ? this._mouseDrag(t) : this._mouseUp(t)), !this._mouseStarted)
            },
            _mouseUp: function(n) {
                this.document.off("mousemove." + this.widgetName, this._mouseMoveDelegate).off("mouseup." + this.widgetName, this._mouseUpDelegate), this._mouseStarted && (this._mouseStarted = !1, n.target === this._mouseDownEvent.target && e.data(n.target, this.widgetName + ".preventClickEvent", !0), this._mouseStop(n)), this._mouseDelayTimer && (clearTimeout(this._mouseDelayTimer), delete this._mouseDelayTimer), this.ignoreMissingWhich = !1, t = !1, n.preventDefault()
            },
            _mouseDistanceMet: function(e) {
                return Math.max(Math.abs(this._mouseDownEvent.pageX - e.pageX), Math.abs(this._mouseDownEvent.pageY - e.pageY)) >= this.options.distance
            },
            _mouseDelayMet: function() {
                return this.mouseDelayMet
            },
            _mouseStart: function() {},
            _mouseDrag: function() {},
            _mouseStop: function() {},
            _mouseCapture: function() {
                return !0
            }
        })
    }),
    function(e) {
        "function" == typeof define && define.amd ? define(["jquery", "./version"], e) : e(jQuery)
    }(function(e) {
        return e.ui.keyCode = {
            BACKSPACE: 8,
            COMMA: 188,
            DELETE: 46,
            DOWN: 40,
            END: 35,
            ENTER: 13,
            ESCAPE: 27,
            HOME: 36,
            LEFT: 37,
            PAGE_DOWN: 34,
            PAGE_UP: 33,
            PERIOD: 190,
            RIGHT: 39,
            SPACE: 32,
            TAB: 9,
            UP: 38
        }
    }),
    function(e) {
        "function" == typeof define && define.amd ? define(["jquery", "./mouse", "../keycode", "../version", "../widget"], e) : e(jQuery)
    }(function(e) {
        return e.widget("ui.slider", e.ui.mouse, {
            version: "1.12.1",
            widgetEventPrefix: "slide",
            options: {
                animate: !1,
                classes: {
                    "ui-slider": "ui-corner-all",
                    "ui-slider-handle": "ui-corner-all",
                    "ui-slider-range": "ui-corner-all ui-widget-header"
                },
                distance: 0,
                max: 100,
                min: 0,
                orientation: "horizontal",
                range: !1,
                step: 1,
                value: 0,
                values: null,
                change: null,
                slide: null,
                start: null,
                stop: null
            },
            numPages: 5,
            _create: function() {
                this._keySliding = !1, this._mouseSliding = !1, this._animateOff = !0, this._handleIndex = null, this._detectOrientation(), this._mouseInit(), this._calculateNewMax(), this._addClass("ui-slider ui-slider-" + this.orientation, "ui-widget ui-widget-content"), this._refresh(), this._animateOff = !1
            },
            _refresh: function() {
                this._createRange(), this._createHandles(), this._setupEvents(), this._refreshValue()
            },
            _createHandles: function() {
                var t, n, i = this.options,
                    r = this.element.find(".ui-slider-handle"),
                    o = "<span tabindex='0'></span>",
                    a = [];
                for (n = i.values && i.values.length || 1, r.length > n && (r.slice(n).remove(), r = r.slice(0, n)), t = r.length; n > t; t++) a.push(o);
                this.handles = r.add(e(a.join("")).appendTo(this.element)), this._addClass(this.handles, "ui-slider-handle", "ui-state-default"), this.handle = this.handles.eq(0), this.handles.each(function(t) {
                    e(this).data("ui-slider-handle-index", t).attr("tabIndex", 0)
                })
            },
            _createRange: function() {
                var t = this.options;
                t.range ? (t.range === !0 && (t.values ? t.values.length && 2 !== t.values.length ? t.values = [t.values[0], t.values[0]] : e.isArray(t.values) && (t.values = t.values.slice(0)) : t.values = [this._valueMin(), this._valueMin()]), this.range && this.range.length ? (this._removeClass(this.range, "ui-slider-range-min ui-slider-range-max"), this.range.css({
                    left: "",
                    bottom: ""
                })) : (this.range = e("<div>").appendTo(this.element), this._addClass(this.range, "ui-slider-range")), ("min" === t.range || "max" === t.range) && this._addClass(this.range, "ui-slider-range-" + t.range)) : (this.range && this.range.remove(), this.range = null)
            },
            _setupEvents: function() {
                this._off(this.handles), this._on(this.handles, this._handleEvents), this._hoverable(this.handles), this._focusable(this.handles)
            },
            _destroy: function() {
                this.handles.remove(), this.range && this.range.remove(), this._mouseDestroy()
            },
            _mouseCapture: function(t) {
                var n, i, r, o, a, s, u, c, l = this,
                    d = this.options;
                return d.disabled ? !1 : (this.elementSize = {
                    width: this.element.outerWidth(),
                    height: this.element.outerHeight()
                }, this.elementOffset = this.element.offset(), n = {
                    x: t.pageX,
                    y: t.pageY
                }, i = this._normValueFromMouse(n), r = this._valueMax() - this._valueMin() + 1, this.handles.each(function(t) {
                    var n = Math.abs(i - l.values(t));
                    (r > n || r === n && (t === l._lastChangedValue || l.values(t) === d.min)) && (r = n, o = e(this), a = t)
                }), s = this._start(t, a), s === !1 ? !1 : (this._mouseSliding = !0, this._handleIndex = a, this._addClass(o, null, "ui-state-active"), o.trigger("focus"), u = o.offset(), c = !e(t.target).parents().addBack().is(".ui-slider-handle"), this._clickOffset = c ? {
                    left: 0,
                    top: 0
                } : {
                    left: t.pageX - u.left - o.width() / 2,
                    top: t.pageY - u.top - o.height() / 2 - (parseInt(o.css("borderTopWidth"), 10) || 0) - (parseInt(o.css("borderBottomWidth"), 10) || 0) + (parseInt(o.css("marginTop"), 10) || 0)
                }, this.handles.hasClass("ui-state-hover") || this._slide(t, a, i), this._animateOff = !0, !0))
            },
            _mouseStart: function() {
                return !0
            },
            _mouseDrag: function(e) {
                var t = {
                        x: e.pageX,
                        y: e.pageY
                    },
                    n = this._normValueFromMouse(t);
                return this._slide(e, this._handleIndex, n), !1
            },
            _mouseStop: function(e) {
                return this._removeClass(this.handles, null, "ui-state-active"), this._mouseSliding = !1, this._stop(e, this._handleIndex), this._change(e, this._handleIndex), this._handleIndex = null, this._clickOffset = null, this._animateOff = !1, !1
            },
            _detectOrientation: function() {
                this.orientation = "vertical" === this.options.orientation ? "vertical" : "horizontal"
            },
            _normValueFromMouse: function(e) {
                var t, n, i, r, o;
                return "horizontal" === this.orientation ? (t = this.elementSize.width, n = e.x - this.elementOffset.left - (this._clickOffset ? this._clickOffset.left : 0)) : (t = this.elementSize.height, n = e.y - this.elementOffset.top - (this._clickOffset ? this._clickOffset.top : 0)), i = n / t, i > 1 && (i = 1), 0 > i && (i = 0), "vertical" === this.orientation && (i = 1 - i), r = this._valueMax() - this._valueMin(), o = this._valueMin() + i * r, this._trimAlignValue(o)
            },
            _uiHash: function(e, t, n) {
                var i = {
                    handle: this.handles[e],
                    handleIndex: e,
                    value: void 0 !== t ? t : this.value()
                };
                return this._hasMultipleValues() && (i.value = void 0 !== t ? t : this.values(e), i.values = n || this.values()), i
            },
            _hasMultipleValues: function() {
                return this.options.values && this.options.values.length
            },
            _start: function(e, t) {
                return this._trigger("start", e, this._uiHash(t))
            },
            _slide: function(e, t, n) {
                var i, r, o = this.value(),
                    a = this.values();
                this._hasMultipleValues() && (r = this.values(t ? 0 : 1), o = this.values(t), 2 === this.options.values.length && this.options.range === !0 && (n = 0 === t ? Math.min(r, n) : Math.max(r, n)), a[t] = n), n !== o && (i = this._trigger("slide", e, this._uiHash(t, n, a)), i !== !1 && (this._hasMultipleValues() ? this.values(t, n) : this.value(n)))
            },
            _stop: function(e, t) {
                this._trigger("stop", e, this._uiHash(t))
            },
            _change: function(e, t) {
                this._keySliding || this._mouseSliding || (this._lastChangedValue = t, this._trigger("change", e, this._uiHash(t)))
            },
            value: function(e) {
                return arguments.length ? (this.options.value = this._trimAlignValue(e), this._refreshValue(), void this._change(null, 0)) : this._value()
            },
            values: function(t, n) {
                var i, r, o;
                if (arguments.length > 1) return this.options.values[t] = this._trimAlignValue(n), this._refreshValue(), void this._change(null, t);
                if (!arguments.length) return this._values();
                if (!e.isArray(arguments[0])) return this._hasMultipleValues() ? this._values(t) : this.value();
                for (i = this.options.values, r = arguments[0], o = 0; o < i.length; o += 1) i[o] = this._trimAlignValue(r[o]), this._change(null, o);
                this._refreshValue()
            },
            _setOption: function(t, n) {
                var i, r = 0;
                switch ("range" === t && this.options.range === !0 && ("min" === n ? (this.options.value = this._values(0), this.options.values = null) : "max" === n && (this.options.value = this._values(this.options.values.length - 1), this.options.values = null)), e.isArray(this.options.values) && (r = this.options.values.length), this._super(t, n), t) {
                    case "orientation":
                        this._detectOrientation(), this._removeClass("ui-slider-horizontal ui-slider-vertical")._addClass("ui-slider-" + this.orientation), this._refreshValue(), this.options.range && this._refreshRange(n), this.handles.css("horizontal" === n ? "bottom" : "left", "");
                        break;
                    case "value":
                        this._animateOff = !0, this._refreshValue(), this._change(null, 0), this._animateOff = !1;
                        break;
                    case "values":
                        for (this._animateOff = !0, this._refreshValue(), i = r - 1; i >= 0; i--) this._change(null, i);
                        this._animateOff = !1;
                        break;
                    case "step":
                    case "min":
                    case "max":
                        this._animateOff = !0, this._calculateNewMax(), this._refreshValue(), this._animateOff = !1;
                        break;
                    case "range":
                        this._animateOff = !0, this._refresh(), this._animateOff = !1
                }
            },
            _setOptionDisabled: function(e) {
                this._super(e), this._toggleClass(null, "ui-state-disabled", !!e)
            },
            _value: function() {
                var e = this.options.value;
                return e = this._trimAlignValue(e)
            },
            _values: function(e) {
                var t, n, i;
                if (arguments.length) return t = this.options.values[e], t = this._trimAlignValue(t);
                if (this._hasMultipleValues()) {
                    for (n = this.options.values.slice(), i = 0; i < n.length; i += 1) n[i] = this._trimAlignValue(n[i]);
                    return n
                }
                return []
            },
            _trimAlignValue: function(e) {
                if (e <= this._valueMin()) return this._valueMin();
                if (e >= this._valueMax()) return this._valueMax();
                var t = this.options.step > 0 ? this.options.step : 1,
                    n = (e - this._valueMin()) % t,
                    i = e - n;
                return 2 * Math.abs(n) >= t && (i += n > 0 ? t : -t), parseFloat(i.toFixed(5))
            },
            _calculateNewMax: function() {
                var e = this.options.max,
                    t = this._valueMin(),
                    n = this.options.step,
                    i = Math.round((e - t) / n) * n;
                e = i + t, e > this.options.max && (e -= n), this.max = parseFloat(e.toFixed(this._precision()))
            },
            _precision: function() {
                var e = this._precisionOf(this.options.step);
                return null !== this.options.min && (e = Math.max(e, this._precisionOf(this.options.min))), e
            },
            _precisionOf: function(e) {
                var t = e.toString(),
                    n = t.indexOf(".");
                return -1 === n ? 0 : t.length - n - 1
            },
            _valueMin: function() {
                return this.options.min
            },
            _valueMax: function() {
                return this.max
            },
            _refreshRange: function(e) {
                "vertical" === e && this.range.css({
                    width: "",
                    left: ""
                }), "horizontal" === e && this.range.css({
                    height: "",
                    bottom: ""
                })
            },
            _refreshValue: function() {
                var t, n, i, r, o, a = this.options.range,
                    s = this.options,
                    u = this,
                    c = this._animateOff ? !1 : s.animate,
                    l = {};
                this._hasMultipleValues() ? this.handles.each(function(i) {
                    n = (u.values(i) - u._valueMin()) / (u._valueMax() - u._valueMin()) * 100, l["horizontal" === u.orientation ? "left" : "bottom"] = n + "%", e(this).stop(1, 1)[c ? "animate" : "css"](l, s.animate), u.options.range === !0 && ("horizontal" === u.orientation ? (0 === i && u.range.stop(1, 1)[c ? "animate" : "css"]({
                        left: n + "%"
                    }, s.animate), 1 === i && u.range[c ? "animate" : "css"]({
                        width: n - t + "%"
                    }, {
                        queue: !1,
                        duration: s.animate
                    })) : (0 === i && u.range.stop(1, 1)[c ? "animate" : "css"]({
                        bottom: n + "%"
                    }, s.animate), 1 === i && u.range[c ? "animate" : "css"]({
                        height: n - t + "%"
                    }, {
                        queue: !1,
                        duration: s.animate
                    }))), t = n
                }) : (i = this.value(), r = this._valueMin(), o = this._valueMax(), n = o !== r ? (i - r) / (o - r) * 100 : 0, l["horizontal" === this.orientation ? "left" : "bottom"] = n + "%", this.handle.stop(1, 1)[c ? "animate" : "css"](l, s.animate), "min" === a && "horizontal" === this.orientation && this.range.stop(1, 1)[c ? "animate" : "css"]({
                    width: n + "%"
                }, s.animate), "max" === a && "horizontal" === this.orientation && this.range.stop(1, 1)[c ? "animate" : "css"]({
                    width: 100 - n + "%"
                }, s.animate), "min" === a && "vertical" === this.orientation && this.range.stop(1, 1)[c ? "animate" : "css"]({
                    height: n + "%"
                }, s.animate), "max" === a && "vertical" === this.orientation && this.range.stop(1, 1)[c ? "animate" : "css"]({
                    height: 100 - n + "%"
                }, s.animate))
            },
            _handleEvents: {
                keydown: function(t) {
                    var n, i, r, o, a = e(t.target).data("ui-slider-handle-index");
                    switch (t.keyCode) {
                        case e.ui.keyCode.HOME:
                        case e.ui.keyCode.END:
                        case e.ui.keyCode.PAGE_UP:
                        case e.ui.keyCode.PAGE_DOWN:
                        case e.ui.keyCode.UP:
                        case e.ui.keyCode.RIGHT:
                        case e.ui.keyCode.DOWN:
                        case e.ui.keyCode.LEFT:
                            if (t.preventDefault(), !this._keySliding && (this._keySliding = !0, this._addClass(e(t.target), null, "ui-state-active"), n = this._start(t, a), n === !1)) return
                    }
                    switch (o = this.options.step, i = r = this._hasMultipleValues() ? this.values(a) : this.value(), t.keyCode) {
                        case e.ui.keyCode.HOME:
                            r = this._valueMin();
                            break;
                        case e.ui.keyCode.END:
                            r = this._valueMax();
                            break;
                        case e.ui.keyCode.PAGE_UP:
                            r = this._trimAlignValue(i + (this._valueMax() - this._valueMin()) / this.numPages);
                            break;
                        case e.ui.keyCode.PAGE_DOWN:
                            r = this._trimAlignValue(i - (this._valueMax() - this._valueMin()) / this.numPages);
                            break;
                        case e.ui.keyCode.UP:
                        case e.ui.keyCode.RIGHT:
                            if (i === this._valueMax()) return;
                            r = this._trimAlignValue(i + o);
                            break;
                        case e.ui.keyCode.DOWN:
                        case e.ui.keyCode.LEFT:
                            if (i === this._valueMin()) return;
                            r = this._trimAlignValue(i - o)
                    }
                    this._slide(t, a, r)
                },
                keyup: function(t) {
                    var n = e(t.target).data("ui-slider-handle-index");
                    this._keySliding && (this._keySliding = !1, this._stop(t, n), this._change(t, n), this._removeClass(e(t.target), null, "ui-state-active"))
                }
            }
        })
    }),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.FraudLimits = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.FraudLimits", n.run = function() {
                var e;
                return e = function(e, t) {
                    return $.ajax({
                        type: "GET",
                        url: $("#risk_score_slider").data("url"),
                        data: {
                            risk_score: t.value
                        },
                        dataType: "script"
                    })
                }, $("#risk_score_slider").slider({
                    min: 0,
                    max: 100,
                    step: 1,
                    value: $("#user_risk_score").val(),
                    change: e
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.GdaxUserData = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.GdaxUserData", n.run = function() {
                var e, t, n, i, r, o, a;
                return e = $("#exchange_balances").data("balances-path"), e && $.ajax({
                    url: e,
                    type: "GET",
                    dataType: "script"
                }), a = $("#exchange_volumes").data("volumes-path"), a && $.ajax({
                    url: a,
                    type: "GET",
                    dataType: "script"
                }), o = $("#exchange_requirements").data("user-id"), i = Coinbase.pusher.subscribe("admin-user-exchange-requirements-" + o), i.bind("update", function(e) {
                    var t;
                    return t = e.item.access.complete ? "Complete" : "Incomplete", e.error ? $("#exchange_requirements_status").html("Error: " + e.error + ". (Status " + e.status + ")") : $("#exchange_requirements_status").text(t), $("#exchange_requirements_data code").text(JSON.stringify(e.item.access, null, 2))
                }), r = $("#exchange_requirements").data("requirements-path"), r && $.ajax({
                    url: r,
                    type: "POST"
                }), o = $("#exchange_transfer").data("user-id"), n = $("#exchange_transfer").data("path"), t = Coinbase.pusher.subscribe("admin-user-exchange-transfer-" + o), t.bind("update", function(e) {
                    return e.success ? $("#exchange_transfer").modal("hide") : $.ajax({
                        url: n,
                        data: {
                            errors: e.errors
                        },
                        type: "POST"
                    })
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.Highlight = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.Highlight", n.run = function() {
                var e, t, n, i, r, o;
                if ($("body.verifications, body.settings, body.accounts, body.payment_methods").length && document.location.hash) {
                    for (n = $(document.location.hash), t = ["top", "right", "bottom", "left"], $("body.verifications").length && (t = ["right", "left"]), r = 0, o = t.length; o > r; r++) i = t[r], e = t[i], n.css("padding-" + e, "+=10px").css("margin-" + e, "-=10px");
                    return n.effect("highlight", {
                        color: "#fcf8e3"
                    }, 2e3, function() {
                        var r, o, a;
                        for (a = [], r = 0, o = t.length; o > r; r++) i = t[r], e = t[i], a.push(n.css("padding-" + e, "-=10px").css("margin-" + e, "+=10px"));
                        return a
                    })
                }
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this);
var _createClass = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
            }
        }
        return function(t, n, i) {
            return n && e(t.prototype, n), i && e(t, i), t
        }
    }(),
    _get = function(e, t, n) {
        for (var i = !0; i;) {
            var r = e,
                o = t,
                a = n;
            i = !1, null === r && (r = Function.prototype);
            var s = Object.getOwnPropertyDescriptor(r, o);
            if (void 0 !== s) {
                if ("value" in s) return s.value;
                var u = s.get;
                return void 0 === u ? void 0 : u.call(a)
            }
            var c = Object.getPrototypeOf(r);
            if (null === c) return void 0;
            e = c, t = o, n = a, i = !0, s = c = void 0
        }
    };
Coinbase.Widgets.IdvProfile = function(e) {
        function t() {
            _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
        }
        return _inherits(t, e), _createClass(t, null, [{
            key: "run",
            value: function() {
                updateAdminFlag = function(e) {
                    target = $(e.target), spinner = $("#spinner_idv_flag_reason-" + target.data("id")), val = target.val(), spinner.show(), $.ajax({
                        type: "POST",
                        url: "/admin/jumio_profiles/" + target.data("id") + "/flag_jumio_profile",
                        data: {
                            reason: val
                        },
                        success: function(e) {
                            spinner.hide(), alert("Updated IDV flag")
                        },
                        error: function(e) {
                            spinner.hide(), alert("Failed to update IDV flag: " + e.statusText)
                        }
                    })
                }, $(".idv-admin-flag-reason").change(updateAdminFlag), $(".idv-profile-preview").popover({
                    placement: "bottom",
                    trigger: "click",
                    html: !0,
                    content: "Please wait..."
                }), $(".idv-profile-preview").on("show.bs.popover", function(e) {
                    var t = $(this).data("profile-id"),
                        n = $(this).data("render-request-sent");
                    "true" !== n && ! function() {
                        var e = $(".idv-profile-preview[data-profile-id=" + t + "]");
                        e.data("render-request-sent", "true"), $.ajax({
                            type: "GET",
                            url: "/admin/idv_profiles/" + t,
                            success: function(t) {
                                var n = $(t).find(".details");
                                e.data("popover").options.content = n, e.data().popover.tip().hasClass("in") && (e.popover("show"), downloadDeferedImg())
                            }
                        })
                    }()
                })
            }
        }]), t
    }(Coinbase.Widgets.BaseWidget),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.ImageZoom = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.ImageZoom", n.run = function() {
                var e;
                return $(".admin-image").on("click", function(e) {
                    var t;
                    return e.preventDefault(), t = $(this).data().imagePath, $("#admin_overlay_image").css({
                        backgroundImage: "url(" + t + ")"
                    }), $("#admin_overlay").show()
                }), $(".id-service-link").bind("ajax:beforeSend", function() {
                    return $(this).addClass("lazy-loading")
                }), $(".id-service-link").bind("ajax:complete", function() {
                    return $(this).removeClass("lazy-loading")
                }), e = 0, $("#rotate").on("click", function(t) {
                    return e += 90, $("#admin_overlay_image").css({
                        WebkitTransform: "rotate(" + e + "deg)"
                    })
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.LocaleSelect = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.LocaleSelect", n.run = function() {
                return $(document).on("change", "#locale_select", function() {
                    var e, t, n;
                    return t = this.value, n = /[\?&]locale=.*(&|$)/, e = document.location.toString(), e = e.replace(n, ""), Coinbase.constants.USER ? $.post("/settings/save_locale", {
                        locale: t
                    }, function() {
                        return document.location.reload(!0)
                    }).error(console.error) : e.indexOf("?") > -1 ? document.location = e + "&locale=" + t : document.location = e + "?locale=" + t
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.PaymentRequest = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.PaymentRequest", n.run = function() {
                var e, t, n, i, r, o, a, s;
                return o = $("#payment_request_params").data("request-id"), s = $("#payment_request_params").data("to"), $("#payment_waiting").show(), $("#payment_waiting_footer").show(), $("#payment_ready").hide(), $("#send_funds_container .action").hide(), i = function() {
                    return $("#payment_waiting").hide(), $("#payment_waiting_footer").hide(), $("#payment_ready").show(), $("#send_funds_container .action").show(), $("#payment_request_error").show(), $("#transaction_domain").val(s), $("#transaction_to").val(s), $("#send_funds_to_default").show(), $("#send_funds_to_payproto").hide()
                }, r = function(e) {
                    return $("#payment_waiting").hide(), $("#payment_error").show(), $("#payment_error_message").html(e), $("#payment_error_message").show()
                }, a = function(e) {
                    return "BitPay, Inc." === e || "Coinbase, Inc." === e ? I18n.t("payment_request.processed_by") + ":" : I18n.t("payment_request.requested_by") + ":"
                }, n = function(e) {
                    return e.failed || !e.consistent ? i() : e.valid ? e.expired ? r(I18n.t("payment_request.expired")) : ($("#payment_waiting").hide(), $("#payment_waiting_footer").hide(), $("#payment_ready").show(), $("#send_funds_container .action").show(), $("#transaction_to").val(s), $("#transaction_domain").val(e.domain), $("#transaction_domain").prop("readonly", !0), $("#transaction_domain").css("color", "green"), $("#send_funds_notes").val(e.memo), $("#send_funds_notes").prop("readonly", !0), $("#send_funds_notes").css("resize", "none"), $("#send_funds_amount").val(e.amount), $("#send_funds_amount").prop("readonly", !0), $("#send_funds_to_label").text(a(e.domain)), $("#send_funds_to_default").hide(), $("#send_funds_to_payproto").show()) : r(I18n.t("payment_request.invalid"))
                }, t = function(e) {
                    return $("#payment_ready").hide(), $("#send_funds_container .action").hide(), $("#payment_ack").show(), $("#payment_ack_footer").show(), $("#payment_ack_memo").html(e)
                }, "undefined" != typeof Coinbase.live && Coinbase.live.bind("pusher:subscription_succeeded", function(e) {
                    return $.getJSON("/fr/" + o).done(function(e) {
                        return e.result ? void 0 : i()
                    }).fail(function() {
                        return i()
                    })
                }), e = "update-payment-request-" + o, "undefined" != typeof Coinbase.live && Coinbase.live.bind(e, function(e) {
                    return "request" === e.type ? n(e) : t(e.memo)
                }), Pusher.ready()
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.PhoneNumbers = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            var i, r;
            return e(n, t), n.className = "Coinbase.Widgets.PhoneNumbers", i = {
                AD: "376",
                AE: "971",
                AF: "93",
                AG: "1",
                AI: "1",
                AL: "355",
                AM: "374",
                AN: "599",
                AO: "244",
                AQ: "672",
                AR: "54",
                AS: "1",
                AT: "43",
                AU: "61",
                AW: "297",
                AX: "358",
                AZ: "994",
                BA: "387",
                BB: "1",
                BD: "880",
                BE: "32",
                BF: "226",
                BG: "359",
                BH: "973",
                BI: "257",
                BJ: "229",
                BL: "590",
                BM: "1",
                BN: "673",
                BO: "591",
                BR: "55",
                BS: "1",
                BT: "975",
                BV: "",
                BW: "267",
                BY: "375",
                BZ: "501",
                CA: "1",
                CC: "61",
                CD: "243",
                CF: "236",
                CG: "242",
                CH: "41",
                CI: "225",
                CK: "682",
                CL: "56",
                CM: "237",
                CN: "86",
                CO: "57",
                CR: "506",
                CU: "53",
                CV: "238",
                CX: "61",
                CY: "357",
                CZ: "420",
                DE: "49",
                DJ: "253",
                DK: "45",
                DM: "1",
                DO: "1",
                DZ: "213",
                EC: "593",
                EE: "372",
                EG: "20",
                EH: "212",
                ER: "291",
                ES: "34",
                ET: "251",
                FI: "358",
                FJ: "679",
                FK: "500",
                FM: "691",
                FO: "298",
                FR: "33",
                GA: "241",
                GB: "44",
                GD: "1",
                GE: "995",
                GF: "594",
                GG: "44",
                GH: "233",
                GI: "350",
                GL: "299",
                GM: "220",
                GN: "224",
                GP: "590",
                GQ: "240",
                GR: "30",
                GS: "500",
                GT: "502",
                GU: "1",
                GW: "245",
                GY: "592",
                HK: "852",
                HM: "",
                HN: "504",
                HR: "385",
                HT: "509",
                HU: "36",
                ID: "62",
                IE: "353",
                IL: "972",
                IM: "44",
                IN: "91",
                IO: "246",
                IQ: "964",
                IR: "98",
                IS: "354",
                IT: "39",
                JE: "44",
                JM: "1",
                JO: "962",
                JP: "81",
                KE: "254",
                KG: "996",
                KH: "855",
                KI: "686",
                KM: "269",
                KN: "1",
                KP: "850",
                KR: "82",
                KW: "965",
                KY: "1",
                KZ: "7",
                LA: "856",
                LB: "961",
                LC: "1",
                LI: "423",
                LK: "94",
                LR: "231",
                LS: "266",
                LT: "370",
                LU: "352",
                LV: "371",
                LY: "218",
                MA: "212",
                MC: "377",
                MD: "373",
                ME: "382",
                MF: "590",
                MG: "261",
                MH: "692",
                MK: "389",
                ML: "223",
                MM: "95",
                MN: "976",
                MO: "853",
                MP: "1",
                MQ: "596",
                MR: "222",
                MS: "1",
                MT: "356",
                MU: "230",
                MV: "960",
                MW: "265",
                MX: "52",
                MY: "60",
                MZ: "258",
                NA: "264",
                NC: "687",
                NE: "227",
                NF: "672",
                NG: "234",
                NI: "505",
                NL: "31",
                NO: "47",
                NP: "977",
                NR: "674",
                NU: "683",
                NZ: "64",
                OM: "968",
                PA: "507",
                PE: "51",
                PF: "689",
                PG: "675",
                PH: "63",
                PK: "92",
                PL: "48",
                PM: "508",
                PN: "",
                PR: "1",
                PS: "970",
                PT: "351",
                PW: "680",
                PY: "595",
                QA: "974",
                RE: "262",
                RO: "40",
                RS: "381",
                RU: "7",
                RW: "250",
                SA: "966",
                SB: "677",
                SC: "248",
                SD: "249",
                SE: "46",
                SG: "65",
                SH: "290",
                SI: "386",
                SJ: "47",
                SK: "421",
                SL: "232",
                SM: "378",
                SN: "221",
                SO: "252",
                SR: "597",
                ST: "239",
                SV: "503",
                SY: "963",
                SZ: "268",
                TC: "1",
                TD: "235",
                TF: "",
                TG: "228",
                TH: "66",
                TJ: "992",
                TK: "690",
                TL: "670",
                TM: "993",
                TN: "216",
                TO: "676",
                TR: "90",
                TT: "1",
                TV: "688",
                TW: "886",
                TZ: "255",
                UA: "380",
                UG: "256",
                UM: "",
                US: "1",
                UY: "598",
                UZ: "998",
                VA: "39",
                VC: "1",
                VE: "58",
                VG: "1",
                VI: "1",
                VN: "84",
                VU: "678",
                WF: "681",
                WS: "685",
                YE: "967",
                YT: "269",
                ZA: "27",
                ZM: "260",
                ZW: "263"
            }, r = ["#phone_number_country", "#account_recovery_new_country"], n.run = function() {
                return $(document).on("change", r.join(", "), function(e) {
                    var t;
                    return t = $(e.target).val(), $("#country_code_prepend").html("+" + i[t]), $("#phone_number_number").attr("data-country-code", t)
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.PhysicalAddress = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.PhysicalAddress", n.run = function() {
                return this.selectUSOrInternational(), $(document).on("shown", "#coinbase_modal", this.selectUSOrInternational), $(document).on("refresh", "#coinbase_modal", this.selectUSOrInternational), $(document).on("change", "form.physical-address .country-selector", this.selectUSOrInternational), this.setupAutoComplete()
            }, n.selectUSOrInternational = function() {
                return $("form.physical-address .country-selector").length > 0 ? "US" === $("form.physical-address .country-selector").val() ? ($("form.physical-address .us-only").show(), $("form.physical-address input.us-only, form.physical-address select.us-only").removeAttr("disabled"), $("form.physical-address .international").hide(), $("form.physical-address input.international, form.physical-address select.international").attr("disabled", !0)) : ($("form.physical-address .us-only").hide(),
                    $("form.physical-address input.us-only, form.physical-address select.us-only").attr("disabled", !0), $("form.physical-address .international").show(), $("form.physical-address input.international, form.physical-address select.international").removeAttr("disabled")) : void 0
            }, n.setupAutoComplete = function() {
                var e, t;
                return "undefined" != typeof autocompleteprefix ? (e = $("#" + autocompleteprefix + "street_address_1"), t = $("#" + autocompleteprefix + "address1"), "undefined" != typeof e && "undefined" != typeof e[0] ? window.physicalAddressAutocompleteInit = function() {
                    return Coinbase.utils.physicalAddressAutocomplete(autocompleteprefix || "")
                } : "undefined" != typeof t && "undefined" != typeof t[0] && (window.physicalAddressAutocompleteInit = function() {
                    return Coinbase.utils.residentialAddressAutocomplete(autocompleteprefix || "")
                }), Coinbase.utils.addressAutocompleteLoadMaps()) : void 0
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.QRCode = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.QRCode", n.getQRCode = function(e) {
                var t, n, i;
                return t = $(e + " code"), i = t.data("uri") || t.text(), n = $("div.qrcode").data(), $.ajax({
                    type: "GET",
                    url: "/accounts/qrcode",
                    dataType: "json",
                    data: {
                        uri: i,
                        size: n.size,
                        level: n.level
                    },
                    success: function(t, i, r) {
                        var o, a, s, u, c, l, d, h, f, p;
                        if ("OK" === t.response) {
                            for (h = Math.floor(n.cssSize / t.data.length), $(e + " div.qrcode").append('<table class="qr-code"><table>'), c = $(e + " table.qr-code"), l = t.data, d = [], a = 0, u = l.length; u > a; a++) p = l[a], c.append('<tr style="height:' + h + 'px"></tr>'), s = c.find("tr").last(), d.push(function() {
                                var e, t, n;
                                for (n = [], e = 0, t = p.length; t > e; e++) f = p[e], o = f ? '<td style="border-top-width:0;width:' + h + "px;height:" + h + 'px" class="black"></td>' : '<td style="border-top-width:0;width:' + h + "px;height:" + h + 'px" class="white"></td>', n.push(s.append(o));
                                return n
                            }());
                            return d
                        }
                        return alert("Error: " + t.data)
                    }
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.ReceiveAddress = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.ReceiveAddress", n.run = function(e) {
                var t, n, i, r;
                return i = function(e, t) {
                    return $.ajax({
                        type: "POST",
                        url: "/accounts/" + e + "/receive_address",
                        dataType: "json",
                        success: function(e, n, i) {
                            return e.error ? t(e.error) : t(null, e)
                        }
                    })
                }, r = function(e) {
                    return 0 === $(e).find("table.qr-code").length ? Coinbase.Widgets.QRCode.getQRCode(e) : void 0
                }, t = $(e), t.find("code").text() ? r(e) : (n = t.find(".qr-code-wrapper").data("account-id"), i(n, function(n) {
                    return function(n, i) {
                        var o;
                        return n ? alert(n) : (t.find("code").text(i.address), t.find("code").attr("data-uri", i.uri), o = t.find("code").data("copy-target"), o && t.find(o).attr("data-clipboard-text", i.address), r(e))
                    }
                }(this)))
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.Reports = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.Reports", n.run = function() {
                return $(".datepicker").datepicker({
                    autoclose: !0
                }), $("#report_modal").on("shown", function() {
                    return $(this).find(".focus").focus()
                }), $("table.reports-list").on("click", "td.clicktarget", function() {
                    var e;
                    return e = $(this).parent("tr").attr("id").split("_"), window.location.href = "/reports/" + e[e.length - 1]
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.ReviewQueue = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.ReviewQueue", n.run = function() {
                var e;
                return e = function(e, t, n) {
                    return n ? $('[value="' + n + '"]').prop("checked", t) : $('[name="' + e + '[]"]').each(function(e, n) {
                        return $(n).prop("checked", t)
                    }), !1
                }, $("#reversal_codes_select_none").on("click", function(t) {
                    return t.preventDefault(), e("reversal_codes", !1)
                }), $("#reversal_codes_select_all").on("click", function(t) {
                    return t.preventDefault(), e("reversal_codes", !0)
                }), $("#reasons_select_none").on("click", function(t) {
                    return t.preventDefault(), e("reasons", !1)
                }), $("#reasons_select_all").on("click", function(t) {
                    return t.preventDefault(), e("reasons", !0)
                }), $("#payment_types_select_none").on("click", function(t) {
                    return t.preventDefault(), e("payment_types", !1)
                }), $("#payment_types_select_all").on("click", function(t) {
                    return t.preventDefault(), e("payment_types", !0)
                }), $(".select-one").on("click", function(t) {
                    var n, i;
                    return t.preventDefault(), i = $(this).prop("name"), n = $(this).data("key"), e(n, !1), e(n, !0, i)
                }), $("#show_all_details").on("click", function(e) {
                    return e.preventDefault(), $("tr.details").show()
                }), $("#hide_all_details").on("click", function(e) {
                    return e.preventDefault(), $("tr.details").hide()
                }), $(".manual-review-user").popover({
                    placement: "bottom",
                    trigger: "hover",
                    html: !0,
                    content: "Please wait..."
                }), $(".manual-review-user").on("show.bs.popover", function(e) {
                    var t, n;
                    return n = $(this).data("user-id"), t = $(this).data("render-request-sent"), "true" !== t ? ($(".manual-review-user[data-user-id=" + n + "]").data("render-request-sent", "true"), $.ajax({
                        type: "GET",
                        url: "/admin/users/" + n + "/manual_review_content"
                    })) : void 0
                }), $(".manual-review-merchant").popover({
                    placement: "bottom",
                    trigger: "hover",
                    html: !0,
                    content: "Please wait..."
                }), $(".manual-review-merchant").on("show.bs.popover", function(e) {
                    var t, n;
                    return t = $(this).data("merchant-id"), n = $(this).data("render-request-sent"), "true" !== n ? ($(".manual-review-merchant[data-merchant-id=" + t + "]").data("render-request-sent", "true"), $.ajax({
                        type: "GET",
                        url: "/admin/merchant_profiles/" + t + "/manual_review_content"
                    })) : void 0
                }), $(".btn-approve, .btn-reject").on("ajax:send", function() {
                    return $(this).toggleClass("active muted")
                }), $(".btn-approve, .btn-reject").on("ajax:error", function() {
                    return $(this).toggleClass("active muted")
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.Secure3dDebitFundsReclaimed = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.Secure3dDebitFundsReclaimed", n.run = function() {
                return $("#funds_reclaimed_submit").on("click", function(e) {
                    return e.preventDefault(), $("#funds_reclaimed_form").submit()
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.Signup = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.Signup", n.gauge_password = function(e) {
                var t, n;
                return e ? (t = ["too weak", "good", "excellent"], n = [$("#user_email").val()], Coinbase.utils.scorePassword(e, n, function(e) {
                    var n;
                    return n = 6e3 > e ? t[0] : 6e7 > e ? t[1] : t[2], $(".password-level").show().removeClass(t.join(" ")).addClass(n), $(".password-level .level").html(n)
                })) : void $(".password-level").hide()
            }, n.run = function() {
                return $(".signup-password").on("keyup", _.debounce(function(e) {
                    return function(t) {
                        return e.gauge_password($(".signup-password").val())
                    }
                }(this), 500)), $(".password-level").unbind("click").click(function(e) {
                    return function(e) {
                        return window.open("/password-faq", "_blank")
                    }
                }(this))
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.TransferMoney = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.TransferMoney", n.run = function() {
                return Coinbase.cache.transferModalCache = void 0, this.transferModalRecipients(), $("#transfer_money_submit").on("click", function(e) {
                    return e.preventDefault(), $("#transfer_money_spinner").show(), $("#transfer_money form").submit()
                }), $("#select_transfer_from").on("change", function(e) {
                    return function(t) {
                        return t.preventDefault(), e.transferModalRecipients()
                    }
                }(this))
            }, n.transferModalRecipients = function() {
                var e, t, n;
                return e = $("#select_transfer_from"), n = $("#select_transfer_to"), Coinbase.cache.transferModalCache || (Coinbase.cache.transferModalCache = n.children()), t = e.val(), n.empty(), Coinbase.cache.transferModalCache.each(function(e) {
                    return function(e, i) {
                        return $(i).val() !== t ? n.append($(i).clone()) : void 0
                    }
                }(this))
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.Transfers = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.Transfers", n.run = function() {
                var e, t;
                return e = function(e) {
                    var t, n, i, r;
                    null == e && (e = {}), n = $("form.transfer-form").serializeArray();
                    for (t in e) r = e[t], n.push({
                        name: t,
                        value: r
                    });
                    return i = "", $("#buy_transfer").length > 0 ? i = "buys" : $("#sell_transfer").length > 0 && (i = "sells"), "" !== i ? $.ajax({
                        type: "POST",
                        url: "/" + i + "/update_totals",
                        data: $.param(n),
                        dataType: "script"
                    }) : void 0
                }, t = _.throttle(e, 500, {
                    leading: !1
                }), $("#total").off("input.update").on("input.update", function() {
                    return t()
                }), $("#transfer_btc").off("input.update").on("input.update", function() {
                    return t()
                }), $("#select_payment_method").off("select.update").on("select.update", function() {
                    return t()
                }), $("#transfer_account_id").off("select.update").on("select.update", function() {
                    return t()
                }), $(".max").off("click.max").on("click.max", function(e) {
                    return e.preventDefault(), e.stopPropagation(), t($(this).hasClass("instant-max") ? {
                        instant_max: !0
                    } : {
                        max: !0
                    })
                }), $(".switch, .secondary").off("click.switch").on("click.switch", function(e) {
                    var n;
                    return e.preventDefault(), e.stopPropagation(), n = $("#transfer_recalculate_based_on_btc").val(), $("#transfer_recalculate_based_on_btc").val("true" !== n), t()
                }), Coinbase.utils.currencyTextFieldObserver($("#transfer_btc"), "BTC", {
                    show_units: !1,
                    show_symbol: !1
                }), $(".cancel a").off("click.cancel").on("click.cancel", function(e) {
                    var t;
                    return e.preventDefault(), t = $(e.currentTarget), "back" === t.data("type") && ($("#transfer_details").hide(), $("#transfer").show()), "new" === t.data("type") ? window.location.reload() : void 0
                })
            }, n.setupForm = function() {
                var e, t;
                return $("#transfer_account_id").baseSelect({
                    className: "accounts"
                }), $("#select_payment_method").baseSelect({
                    className: "payment-methods"
                }), $(".bank-wire").last().addClass("bordered-payment-method"), e = function(e) {
                    var t, n, i;
                    t = this.selectedIndex, t >= 0 && this.options.length > t && (n = this.options[t].value, $("#transfer_recurring").prop("checked", !0)), i = n
                }, (t = document.getElementById("transfer_repeat")) ? t.addEventListener ? t.addEventListener("change", e, !1) : t.attachEvent ? t.attachEvent("onchange", e) : t.onchange = e : void 0
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, n) {
                function i() {
                    this.constructor = e
                }
                for (var r in n) t.call(n, r) && (e[r] = n[r]);
                return i.prototype = n.prototype, e.prototype = new i, e.__super__ = n.prototype, e
            },
            t = {}.hasOwnProperty;
        Coinbase.Widgets.UserStats = function(t) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return e(n, t), n.className = "Coinbase.Widgets.UserStats", n.run = function() {
                var e, t;
                return t = $("#location_stats").data("location-stats-path"), $.ajax({
                    url: t,
                    type: "POST",
                    dataType: "script"
                }), e = $("#compliance_score").data("compliance-score-path"), $.ajax({
                    url: e,
                    type: "POST",
                    dataType: "script"
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this),
    function() {
        var e = function(e, t) {
                return function() {
                    return e.apply(t, arguments)
                }
            },
            t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        Coinbase.Widgets.VaultQRScanner = function() {
            function t(t) {
                null == t && (t = {}), this.found = e(this.found, this), t.container || (t.container = "#qr_scan"), this.callback = t.callback, Coinbase.Modules.QRScanner.init(t.container, this.unsupported, this.waiting, this.denied, this.seeking, this.found), $(".qr-wrapper .btn.rescan").click(function(e) {
                    return e.preventDefault(), Coinbase.Modules.QRScanner.play()
                })
            }
            return t.prototype.unsupported = function() {
                return alert('<%= j autot("Whoops! Your browser does not support this feature. Skip to the next step.") %>'), this.hide()
            }, t.prototype.hide = function() {
                return $(".qr-wrapper, .scan_qr_code").hide()
            }, t.prototype.waiting = function() {
                return $(".qr-wrapper").attr("class", "qr-wrapper waiting")
            }, t.prototype.denied = function() {
                return console.log("Permission denied!")
            }, t.prototype.seeking = function() {
                return $(".qr-wrapper").attr("class", "qr-wrapper seeking backup")
            }, t.prototype.found = function(e) {
                return $(".qr-wrapper").attr("class", "qr-wrapper found"), $(".qr-result").hide(), this.callback(e)
            }, t
        }(), Coinbase.Widgets.Vault = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.className = "Coinbase.Widgets.Vault", n.gauge_password = function(e) {
                var t;
                return e ? (t = ["weak", "good", "excellent"], Coinbase.utils.useZxcvbn(function() {
                    var n, i, r;
                    return i = zxcvbn(e, []), n = parseInt(i.entropy), r = 30 >= n ? t[0] : 50 >= n ? t[1] : t[2], $(".password-level").show().removeClass(t.join(" ")).addClass(r), $(".password-level .level").html(r)
                })) : void $(".password-level").hide()
            }, n.key_text = function(e, t, n) {
                var i;
                return i = "", n ? i = "# " + e + " seed (encrypted):\n" + n + "\n\n" : t.seed && (i = "# " + e + " seed:\n" + t.seed.wif + "\n\n"), i += "# " + e + " public key:\n" + t.xpubkey
            }, n.display_keys = function(e, t) {
                var n, i;
                return null == t && (t = "#keys"), n = $(t), n.find(".userkey.group .seed").val(this.key_text("Your", e.hotkey)), i = "", i += this.key_text("User", e.coldkey), i += "\n\n=============================================\n\n", i += this.key_text("Shared", e.hotkey, e.encrypted_hotkey_seed), i += "\n\n=============================================\n\n", i += n.find(".userkey.individual .seed").val(), n.find(".userkey.individual .seed").val(i), $(".keys.group .user   .seed").text(e.hotkey.seed.wif), $(".keys.group .user   .xpubkey").text(e.hotkey.xpubkey), $(".keys.individual .shared .seed").text(e.encrypted_hotkey_seed), $(".keys.individual .shared .xpubkey").text(e.hotkey.xpubkey), e.coldkey.seed && $(".keys.individual .user .seed").text(e.coldkey.seed.wif), $(".keys.individual .user .xpubkey").text(e.coldkey.xpubkey), e.coldkey.seed ? Coinbase.Widgets.QRCode.getQRCode("#user_key_seed") : void 0
            }, n.build_screen_toggle = function(e) {
                return $(e + ", #build").toggle()
            }, n.error = function(e) {
                return null == e && (e = "A problem occurred, please try again!"), alert(e), window.location.reload()
            }, n.scrypt_progress_callback = function(e) {
                var t;
                return t = Math.ceil(e), t !== this.prev_percent ? (this.prev_percent = t, $("#build .percent").text(t + "%")) : void 0
            }, n.sign_withdrawal = function() {
                var e, t, n, i, r, o;
                if (i = $("#vault_password").val(), !i) return void $(".failure.password").show();
                if ($(".failure").hide(), n = {
                        scrypt_progress_callback: this.scrypt_progress_callback,
                        success: function(e) {
                            return function(t) {
                                return $.ajax({
                                    url: r,
                                    type: "POST",
                                    data: {
                                        signatures: t
                                    },
                                    dataType: "json",
                                    success: function(e) {
                                        return window.location.href = e.url
                                    },
                                    statusCode: {
                                        500: function(t, n, i) {
                                            return e.build_screen_toggle("#withdrawal"), $(".failure.server").show(), t && t.responseJSON && t.responseJSON.error ? $(".failure.server p").text(t.responseJSON.error) : $(".failure.server p").text($(".failure.server p").data("default")), $("#vault_password").focus().select()
                                        },
                                        406: function() {
                                            return e.build_screen_toggle("#withdrawal"), $(".failure.password, .password_hints").show(), $("#vault_password").focus().select()
                                        }
                                    }
                                })
                            }
                        }(this)
                    }, $("#build .percent, #build .subcaption").hide(), i.match(/^(L|K)[a-zA-Z0-9]*$/) && 52 === i.length) try {
                    Bitcoin.ECKey.fromWIF(i), n.seed = i
                } catch (a) {
                    e = a, n.password = i
                } else i.match(/^xprv[a-zA-Z0-9]*$/) && i.length > 100 ? n.xprvkey = i : (n.password = i, $("#build .percent, #build .subcaption").show());
                return o = $(".btn-approve").attr("href"), t = o + "/sighashes", r = o + "/sign", this.build_screen_toggle("#withdrawal"), $.ajax({
                    url: t,
                    error: Coinbase.Widgets.Vault.error,
                    success: function(e) {
                        return function(e) {
                            return n.inputs = e.inputs, n.userenc_hotkey_seed = e.userenc_hotkey_seed, Coinbase.Models.Vault.sign(n)
                        }
                    }(this)
                })
            }, n.enable_qr_code_scanner = function() {
                var e;
                return $(".qr-wrapper .btn.scan").hide(), $(".scan_qr_code").hide(), $(".qr_code_scanner").show(), e = new Coinbase.Widgets.VaultQRScanner({
                    callback: function(e) {
                        return function(t) {
                            return $(".seed_or_xprvkey").val(t).effect("highlight").focus().select(), e.verify_key()
                        }
                    }(this)
                })
            }, n.verify_coldkey = function(e) {
                var t, n, i, r, o, a, s;
                if (null == e && (e = {}), o = this.load_vault()) {
                    if (t = function() {
                            return $(".btn-back").show(), $(".failure").show(), !1
                        }, $("#verify").hasClass("group") ? (r = o.hotkey_seed, s = o.hotkey.xprvkey) : (r = o.coldkey_seed, s = o.coldkey.xprvkey), !(n = $(".seed_or_xprvkey").val())) return t();
                    if ("xprv" === n.substring(0, 4)) {
                        if (n !== s) return t();
                        a = {
                            xprvkey: n
                        }
                    } else {
                        if (n !== r) return t();
                        a = {
                            seed: n
                        }
                    }
                    return i = $("#verify form").attr("action"), $("#build .percent").hide(), this.build_screen_toggle("#verify"), setTimeout(function(e) {
                        return function() {
                            return Coinbase.Models.Vault.verify_coldkey({
                                url: i,
                                seed: a.seed,
                                xprvkey: a.xprvkey,
                                success: function() {
                                    return e.build_screen_toggle("#verify"), $(".success").show(), $(".edit_vault_account, .failure, .btn-back").hide(), $(".verify-key").off("click.verify-key"), e.clear_vault()
                                },
                                error: function() {
                                    return e.build_screen_toggle("#verify"), t()
                                }
                            })
                        }
                    }(this), 1500)
                }
            }, n.verify_hotkey = function() {
                var e, t, n;
                return t = $("#password .password").val(), n = $("#password form").attr("action"), e = n.replace("setup", "hot_key").replace("join", "hot_key"), $("#build strong").text("Verifying password ..."), $("#build .percent").text("0%"), $("#build .subcaption").text("Trying to decrypt your password and signing a test string. This might take up to 20 seconds to complete."), $.ajax({
                    url: e,
                    error: this.error,
                    success: function(e) {
                        return function(i) {
                            var r;
                            return r = i.hot_key.userenc_seed, Coinbase.Models.Vault.verify_hotkey(r, t, {
                                url: n,
                                scrypt_progress_callback: e.scrypt_progress_callback,
                                success: function() {
                                    return e.build_screen_toggle("#password"), $(".success").show(), $(".failure, #edit_vault_account, .coinbase_password").hide(), $(".build-vault").off("click.build-vault")
                                },
                                error: function() {
                                    return e.build_screen_toggle("#password"), $(".failure.verification").show()
                                }
                            })
                        }
                    }(this)
                })
            }, n.verify_manual_xpubkey = function() {
                var e;
                return e = $("#coldkey_manual").val(), e ? Coinbase.Models.HdAccount.xpubkey_valid_master(e) ? !0 : !1 : !0
            }, n.build_vault = function() {
                var e, t;
                return $(".failure").hide(), this.verify_manual_xpubkey() ? $(".password").val() ? $(".password").val() !== $(".confirm-password").val() ? void $(".failure.match").show() : "weak" === $(".password-level .level").text() ? void $(".failure.weak").show() : ($("#build strong").text("Building your vault ..."), $("#build .percent").text("0%"), $("#build .subcaption").text("Generating your keys and encrypting them. This might take up to 20 seconds to complete."), this.build_screen_toggle("#password"), e = $("#password form").attr("action"), t = Coinbase.Models.Vault.generate({
                    password: $(".password").val(),
                    coldkey_manual: $("#coldkey_manual").val()
                }), t.scrypt_progress_callback = this.scrypt_progress_callback, t.encrypt(function(n) {
                    return function(i) {
                        return t.encrypted_hotkey_seed = i, t.store(), t.submit({
                            url: e,
                            error: function(e) {
                                return e.responseJSON && e.responseJSON.errors && e.responseJSON.errors.existing_xpub === !0 ? (n.build_screen_toggle("#password"), $(".failure.existing_xpub").show()) : n.error()
                            },
                            success: function() {
                                return n.verify_hotkey()
                            }
                        })
                    }
                }(this))) : void $(".failure.blank").show() : void $(".failure.invalid_xpub").show()
            }, n.load_vault = function(e) {
                var t, n, i;
                return null == e && (e = {}), e.no_fallback || (n = e.fallback_url ? e.fallback_url : $(".edit_vault_account").attr("action"), t = n.match(/\?/) ? "&" : "?", n += t, n += "vault_data_missing=true"), (i = Coinbase.Models.Vault.restore()) ? i : (e.no_fallback || (window.location.href = n), !1)
            }, n.clear_vault = function() {
                var e;
                return (e = this.load_vault({
                    no_fallback: !0
                })) ? e.clear() : void 0
            }, n.run = function() {
                var e, t;
                if ($("#vault_password").focus().on("keypress", function(e) {
                        return function(t) {
                            return 13 === t.which ? (t.preventDefault(), e.sign_withdrawal()) : $(".failure").hide()
                        }
                    }(this)), $("#withdrawal .btn-approve").on("click", function(e) {
                        return function(t) {
                            return t.preventDefault(), e.sign_withdrawal()
                        }
                    }(this)), $("#vault #password .password").focus(), $("#vault #password .password").on("focus", function(e) {
                        return Coinbase.utils.useZxcvbn(function() {
                            return !0
                        })
                    }), $("#vault #password .password, #vault #password .confirm-password, #vault #password #coldkey_manual").on("keypress", function(e) {
                        return function(t) {
                            return 13 === t.which ? (t.preventDefault(), e.build_vault()) : $(".failure").hide()
                        }
                    }(this)), $("#vault #password .password").on("keyup", function(e) {
                        return function(t) {
                            return e.gauge_password($("#vault #password .password").val())
                        }
                    }(this)), $("#vault #password form").on("submit", function(e) {
                        return function(t) {
                            return t.preventDefault(), e.build_vault()
                        }
                    }(this)), $("#vault #password .build-vault").on("click.build-vault", function(e) {
                        return function(t) {
                            return t.preventDefault(), e.build_vault()
                        }
                    }(this)), $("#vault #password #show_advanced_coldkey a").on("click", function(e) {
                        return $("#show_advanced_coldkey").hide(), $("#advanced_coldkey").show(), $("#coldkey_manual").focus(), e.preventDefault()
                    }), $("#vault #password #hide_advanced_coldkey").on("click", function(e) {
                        return $("#advanced_coldkey").hide(), $("#advanced_coldkey .coldkey_manual").val(""), $("#show_advanced_coldkey").show(), e.preventDefault()
                    }), 1 === $("#vault #backup").length) {
                    if (e = $(".vault-backup").attr("href"), !(t = this.load_vault({
                            fallback_url: e
                        }))) return;
                    Coinbase.Widgets.Vault.display_keys(t)
                }
                if ($("#backup .print-keys").on("click", function(e) {
                        return function(e) {
                            return e.preventDefault(), window.print()
                        }
                    }(this)), $("#backup .show-keys").on("click", function(e) {
                        return function(e) {
                            return e.preventDefault(), $("#keys .userkey").toggle().find(".seed").focus().select()
                        }
                    }(this)), $("#backup .backup-acknowledge input").on("change", function(e) {
                        var t;
                        return t = $(this), $(".backup-acknowledge input").not(":checked").length > 0 ? void 0 : $(".vault-backup").removeClass("disabled").addClass("btn-primary").attr("data-method", "post")
                    }), $("#backup .vault-backup").on("click", function(e) {
                        return e.preventDefault()
                    }), $("#vault #verify").length) {
                    if (!this.load_vault()) return;
                    Coinbase.Modules.QRScanner.supported() && $(".scan_qr_code").show()
                }
                return $("#verify .scan_qr_code .btn").on("click", function(e) {
                    return function(t) {
                        return t.preventDefault(), e.enable_qr_code_scanner()
                    }
                }(this)), $("#verify .seed_or_xprvkey").on("keypress", function(e) {
                    return $(".failure").hide()
                }), $("#verify .verify-key").on("click.verify-key", function(e) {
                    return function(t) {
                        return t.preventDefault(), e.verify_coldkey()
                    }
                }(this)), $("#withdraw_money_btn").on("click", function(e) {
                    return e.preventDefault(), $("#withdraw_money").modal("show")
                }), $("#withdraw_money").length && Coinbase.utils.currencyTextFieldObserver($("#vault_withdrawal_amount"), "BTC", {
                    show_symbol: !1,
                    show_units: !1
                }), $(document).off("click.withdraw_money_submit").on("click.withdraw_money_submit", "#withdraw_money_submit", function(e) {
                    return e.preventDefault(), $("#withdraw_money_spinner").show(), $("#withdraw_money form").submit()
                }), $(document).off("click.withdraw_money_send_to_switch").on("click.withdraw_money_send_to_switch", "#withdraw_money .send_to", function(e) {
                    return e.preventDefault(), $(".send_to_toggle").toggle(), $("#vault_withdrawal_destination_address, #select_transfer_to").focus()
                }), $("#vault .submit-form").on("click", function(e) {
                    return e.preventDefault(), $(this).parents("#vault").find("form").submit()
                })
            }, n
        }(Coinbase.Widgets.BaseWidget)
    }.call(this);
var _createClass = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
            }
        }
        return function(t, n, i) {
            return n && e(t.prototype, n), i && e(t, i), t
        }
    }(),
    _get = function(e, t, n) {
        for (var i = !0; i;) {
            var r = e,
                o = t,
                a = n;
            i = !1, null === r && (r = Function.prototype);
            var s = Object.getOwnPropertyDescriptor(r, o);
            if (void 0 !== s) {
                if ("value" in s) return s.value;
                var u = s.get;
                return void 0 === u ? void 0 : u.call(a)
            }
            var c = Object.getPrototypeOf(r);
            if (null === c) return void 0;
            e = c, t = o, n = a, i = !0, s = c = void 0
        }
    };
Coinbase.Views.Shared = Coinbase.Views.Shared || {}, Coinbase.Views.Shared.U2F = function(e) {
    function t() {
        _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
    }
    return _inherits(t, e), _createClass(t, [{
        key: "base64Encode",
        value: function(e) {
            return btoa(new Uint8Array(e).reduce(function(e, t) {
                return e + String.fromCharCode(t)
            }, ""))
        }
    }, {
        key: "base64Decode",
        value: function(e) {
            return Uint8Array.from(atob(e), function(e) {
                return e.charCodeAt(0)
            })
        }
    }, {
        key: "getSecurityKey",
        value: function(e) {
            var t = {
                publicCredential: {
                    id: this.base64Encode(e.rawId),
                    response: {
                        clientDataJSON: this.base64Encode(e.response.clientDataJSON),
                        authenticatorData: this.base64Encode(e.response.authenticatorData),
                        signature: this.base64Encode(e.response.signature),
                        userHandle: this.base64Encode(e.response.userHandle)
                    }
                }
            };
            $("#fido_finish").val(JSON.stringify(t)), $("form:first").submit()
        }
    }, {
        key: "errorGetSecurityKey",
        value: function(e) {
            $("#fido_verify").attr("disabled", !1)
        }
    }, {
        key: "verify",
        value: function(e, t) {
            var n = this;
            e.preventDefault(), $("#fido_verify").attr("disabled", !0), navigator.credentials.get({
                publicKey: t
            }).then(function(e) {
                return n.getSecurityKey(e)
            }, function(e, t, i) {
                return n.errorGetSecurityKey(e, t, i)
            })
        }
    }, {
        key: "render",
        value: function() {
            var e = this;
            if (Coinbase.constants.FIDO_START_AUTH_REQ) {
                _get(Object.getPrototypeOf(t.prototype), "render", this).call(this);
                var n = Coinbase.constants.FIDO_START_AUTH_REQ,
                    i = void 0 === window.PublicKeyCredential || "function" != typeof window.PublicKeyCredential,
                    r = (n && n.allowCredentials || []).length;
                if (i && r > 0) $("form").toggle(), $("#no_webauthn").toggle();
                else {
                    if (n.challenge = this.base64Decode(n.challenge), n.allowCredentials)
                        for (var o = 0; o < n.allowCredentials.length; o++) n.allowCredentials[o].id = this.base64Decode(n.allowCredentials[o].id);
                    $("#fido_verify").click(function(t) {
                        e.verify(t, n)
                    }), $("#fido_verify").click()
                }
            }
        }
    }]), t
}(Coinbase.Views.Application);
var _get = function(e, t, n) {
    for (var i = !0; i;) {
        var r = e,
            o = t,
            a = n;
        i = !1, null === r && (r = Function.prototype);
        var s = Object.getOwnPropertyDescriptor(r, o);
        if (void 0 !== s) {
            if ("value" in s) return s.value;
            var u = s.get;
            return void 0 === u ? void 0 : u.call(a)
        }
        var c = Object.getPrototypeOf(r);
        if (null === c) return void 0;
        e = c, t = o, n = a, i = !0, s = c = void 0
    }
};
Coinbase.Views.AccountRecovery = Coinbase.Views.AccountRecovery || {}, Coinbase.Views.AccountRecovery.TwoFactor = function(e) {
        function t() {
            _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
        }
        return _inherits(t, e), t
    }(Coinbase.Views.Shared.U2F),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).Addresses || (e.Addresses = {}), Coinbase.Views.Addresses.Index = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $("select#account_id").on("change", function(e) {
                    return e.preventDefault(), window.location.href = "/addresses?account_id=" + $(this).val()
                })
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).Applications || (e.Applications = {}), Coinbase.Views.Applications.Edit = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $(".show-advanced-settings a").on("click", function(e) {
                    return e.preventDefault(), $(".show-advanced-settings").hide(), $(".advanced-settings").show()
                })
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).Applications || (e.Applications = {}), Coinbase.Views.Applications.New = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $(".show-advanced-settings a").on("click", function(e) {
                    return e.preventDefault(), $(".show-advanced-settings").hide(), $(".advanced-settings").show()
                })
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).Applications || (e.Applications = {}), Coinbase.Views.Applications.Show = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $("#account_app_submit").on("click", function(e) {
                    return e.preventDefault(), $("#edit_app_form").submit()
                }), $(document).off("click.autofill").on("click.autofill", ".autofill a", function(e) {
                    var t;
                    return e.preventDefault(), t = $(e.currentTarget), $("#scopes").val(t.data("scopes"))
                })
            }, n
        }(Coinbase.Views.Application)
    }.call(this);
var _createClass = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
            }
        }
        return function(t, n, i) {
            return n && e(t.prototype, n), i && e(t, i), t
        }
    }(),
    _get = function(e, t, n) {
        for (var i = !0; i;) {
            var r = e,
                o = t,
                a = n;
            i = !1, null === r && (r = Function.prototype);
            var s = Object.getOwnPropertyDescriptor(r, o);
            if (void 0 !== s) {
                if ("value" in s) return s.value;
                var u = s.get;
                return void 0 === u ? void 0 : u.call(a)
            }
            var c = Object.getPrototypeOf(r);
            if (null === c) return void 0;
            e = c, t = o, n = a, i = !0, s = c = void 0
        }
    };
Coinbase.Views.Authorizations = Coinbase.Views.Authorizations || {}, Coinbase.Views.Authorizations.New = function(e) {
        function t() {
            _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
        }
        return _inherits(t, e), _createClass(t, [{
            key: "render",
            value: function() {
                _get(Object.getPrototypeOf(t.prototype), "render", this).call(this), $("#account_id").baseSelect({
                    className: "accounts"
                }), $(".send-subtitle .change").on("click", function(e) {
                    e.preventDefault(), $(".send-subtitle").hide(), $(".send-form").show()
                }), $("#save_change_amount").on("click", function(e) {
                    e.preventDefault();
                    var t = $("#change_amount").val();
                    $("#send_amount").val(t), $(".send-subtitle .limit").text(t), $(".send-subtitle").show(), $(".send-form").hide()
                }), window.resizeTo(Math.max(window.innerWidth, 600), Math.max(window.innerHeight, 600)), $(".oauth-form").on("keyup keypress", function(e) {
                    var t = 13,
                        n = e.keyCode || e.which;
                    return n === t ? (e.preventDefault(), !1) : void 0
                });
                var e = !1,
                    n = void 0;
                $(document).on("mousemove", function() {
                    e = !0, n = new Date, $(document).off("mousemove")
                });
                var i = "production" === Coinbase.constants.ENV ? 500 : 0;
                $(".authorize_btn").on("click", function(t) {
                    var r = new Date;
                    return e && r - n > i
                })
            }
        }]), t
    }(Coinbase.Views.Application),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = window.Coinbase.Views).Buys || (e.Buys = {}), Coinbase.Views.Buys.Index = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), Coinbase.Views.Buys.Index.setupForm()
            }, n.setupForm = function() {
                var e, t;
                return t = $("#limits-info").data(), t.isVerified ? (Coinbase.Widgets.Transfers.enable(), Coinbase.Widgets.Transfers.setupForm(), e = {
                    has_instant_buy: t.hasInstantBuy,
                    fees_bucket: Coinbase.constants.USER.fees_bucket
                }) : void 0
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).Contacts || (e.Contacts = {}), Coinbase.Views.Contacts.Callback = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                var e, t, i;
                return n.__super__.render.call(this), t = $("#contacts_modal_content"), i = t.data("load-path"), e = opener.$("#contacts_modal"), e.html(t.html()), e.modal("show"), e.trigger("init", [i]), self.close()
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = window.Coinbase.Views).DeviceConfirmations || (e.DeviceConfirmations = {}), Coinbase.Views.DeviceConfirmations.Confirm = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $(".auto-click").trigger("click")
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = window.Coinbase.Views).DeviceConfirmations || (e.DeviceConfirmations = {}), Coinbase.Views.DeviceConfirmations.New = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                var e, t;
                return n.__super__.render.call(this), e = $(".device-confirmation").data("redirectTo"), t = $(".device-confirmation").data("verificationId"), "undefined" != typeof Coinbase.live && Coinbase.live.bind("device-verified", function(t) {
                    return window.location.href = e || t.url
                }), this.intervalID = setInterval(function(n) {
                    return function() {
                        return $.getJSON("/device_confirmations/" + t + "/verify_status").done(function(t) {
                            return t.confirmed ? n.redirect(e) : void 0
                        })
                    }
                }(this), 2500)
            }, n.prototype.redirect = function(e) {
                return clearInterval(this.intervalID), window.location.href = e
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).EddRequests || (e.EddRequests = {}), Coinbase.Views.EddRequests.Complete = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $("#step_actions .submit-form").on("click", function(e) {
                    return e.preventDefault(), $($("form")[0]).submit()
                })
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).IdentityVerifications || (e.IdentityVerifications = {}), Coinbase.Views.IdentityVerifications.CustomerInfo = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.isEqual = function(e, t) {
                return e === t
            }, n.prototype.isNotEqual = function(e, t) {
                return e !== t
            }, n.prototype.showOrHideAdditionalInput = function(e, t, n, i, r) {
                var o;
                return o = $(e).find("option:selected").text(), n(r.indexOf(o), -1) ? $(i).closest(".dynamic_" + t).show().find("input").first().focus() : $(i).closest(".dynamic_" + t).hide().find("input")
            }, n.prototype.attachJobTitleHandler = function() {
                var e;
                return e = this, e.showOrHideAdditionalInput(this, "field", e.isEqual, "#compliance_basic_edd_response_current_employer", ["Retired", "Unemployed"]), $("#compliance_basic_edd_response_current_job_title").on("change", function() {
                    return e.showOrHideAdditionalInput(this, "field", e.isEqual, "#compliance_basic_edd_response_current_employer", ["Retired", "Unemployed"])
                }), e.showOrHideAdditionalInput(this, "select", e.isNotEqual, "#compliance_basic_edd_response_former_job_title", ["Retired", "Unemployed"]), $("#compliance_basic_edd_response_current_job_title").on("change", function() {
                    return e.showOrHideAdditionalInput(this, "select", e.isNotEqual, "#compliance_basic_edd_response_former_job_title", ["Retired", "Unemployed"])
                }), e.showOrHideAdditionalInput(this, "field", e.isEqual, "#compliance_basic_edd_response_former_employer", ["No Employment History"]), $("#compliance_basic_edd_response_former_job_title").on("change", function() {
                    return e.showOrHideAdditionalInput(this, "field", e.isEqual, "#compliance_basic_edd_response_former_employer", ["No Employment History"])
                })
            }, n.prototype.render = function() {
                return n.__super__.render.call(this), window.attachJobTitleHandler = this.attachJobTitleHandler.bind(this), attachJobTitleHandler()
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).IdentityVerifications || (e.IdentityVerifications = {}), Coinbase.Views.IdentityVerifications.Show = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.isEqual = function(e, t) {
                return e === t
            }, n.prototype.isNotEqual = function(e, t) {
                return e !== t
            }, n.prototype.showOrHideAdditionalInput = function(e, t, n, i, r) {
                var o;
                return o = $(e).find("option:selected").text(), n(r.indexOf(o), -1) ? $(i).closest(".dynamic_" + t).show().find("input").first().focus() : $(i).closest(".dynamic_" + t).hide().find("input")
            }, n.prototype.attachJobTitleHandler = function() {
                var e;
                return e = this, e.showOrHideAdditionalInput(this, "field", e.isEqual, "#identity_verification_current_employer", ["Retired", "Unemployed"]), $("#identity_verification_current_job_title").on("change", function() {
                    return e.showOrHideAdditionalInput(this, "field", e.isEqual, "#identity_verification_current_employer", ["Retired", "Unemployed"])
                }), e.showOrHideAdditionalInput(this, "select", e.isNotEqual, "#identity_verification_former_job_title", ["Retired", "Unemployed"]), $("#identity_verification_current_job_title").on("change", function() {
                    return e.showOrHideAdditionalInput(this, "select", e.isNotEqual, "#identity_verification_former_job_title", ["Retired", "Unemployed"])
                }), e.showOrHideAdditionalInput(this, "field", e.isEqual, "#identity_verification_former_employer", ["No Employment History"]), $("#identity_verification_former_job_title").on("change", function() {
                    return e.showOrHideAdditionalInput(this, "field", e.isEqual, "#identity_verification_former_employer", ["No Employment History"])
                })
            }, n.prototype.render = function() {
                return n.__super__.render.call(this), $("#identity_modal").on("initTimer", this.initTimer.bind(this)), window.attachJobTitleHandler = this.attachJobTitleHandler.bind(this), attachJobTitleHandler()
            }, n.prototype.initTimer = function() {
                var e, t, n, i;
                return n = 24e4, t = n, e = 250, i = setInterval(function() {
                    var r;
                    return t -= e, r = 100 * (1 - t / n), $("span.timer span").css({
                        width: r + "%"
                    }), 0 >= t ? (clearInterval(i), window.location = "/verifications/identity?timeout=1") : void 0
                }, e), $("#verify_questions_submit").on("click", function(e) {
                    return function(t) {
                        return t.preventDefault(), e.checkQuestionsForm() ? ($("#verify_questions_notice").hide(), $("#verify_questions_submit").attr("disabled", "disabled"), $("#verify_questions_spinner").show(), $("#verify_questions_form").submit()) : $("#verify_questions_notice").show()
                    }
                }(this))
            }, n.prototype.checkQuestionsForm = function() {
                var e, t, n, i, r, o;
                for (i = {}, $.each($("#verify_questions_form").serializeArray(), function(e, t) {
                        return i[t.name] = t.value
                    }), o = !0, t = n = 1; 10 >= n; t = ++n) r = "answers[question" + t + "Type]", e = "answers[question" + t + "Answer]", !(r in i) || i[e] && i[e].trim() ? $("#question_title_" + t).removeClass("text-error") : ($("#question_title_" + t).addClass("text-error"), o = !1);
                return o
            }, n
        }(Coinbase.Views.Application)
    }.call(this);
var _createClass = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
            }
        }
        return function(t, n, i) {
            return n && e(t.prototype, n), i && e(t, i), t
        }
    }(),
    _get = function(e, t, n) {
        for (var i = !0; i;) {
            var r = e,
                o = t,
                a = n;
            i = !1, null === r && (r = Function.prototype);
            var s = Object.getOwnPropertyDescriptor(r, o);
            if (void 0 !== s) {
                if ("value" in s) return s.value;
                var u = s.get;
                return void 0 === u ? void 0 : u.call(a)
            }
            var c = Object.getPrototypeOf(r);
            if (null === c) return void 0;
            e = c, t = o, n = a, i = !0, s = c = void 0
        }
    };
Coinbase.Views.JumioMobileUploads = Coinbase.Views.JumioMobileUploads || {};
var JumioMobileUploadsIndex = function(e) {
    function t() {
        _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
    }
    return _inherits(t, e), _createClass(t, [{
        key: "render",
        value: function() {
            $(".jumio-mobile-uploads input:file").on("change", function() {
                var e = $(this);
                e.closest(".jumio-mobile-uploads-button").toggleClass("jumio-mobile-uploads-button-selected", !!e.val());
                var t = !0;
                $(".jumio-mobile-uploads input:file").each(function() {
                    t = t && !!$(this).val()
                }), $(".jumio-mobile-uploads .btn").prop("disabled", !t)
            }), $("form.jumio-mobile-uploads").on("submit", function() {
                $(".jumio-mobile-uploads .btn").prop("value", "Loading... please wait").prop("disabled", !0)
            })
        }
    }]), t
}(Coinbase.Views.Application);
Coinbase.Views.JumioMobileUploads.Index = JumioMobileUploadsIndex,
    function() {
        var e, t, n = function(e, t) {
                function n() {
                    this.constructor = e
                }
                for (var r in t) i.call(t, r) && (e[r] = t[r]);
                return n.prototype = t.prototype, e.prototype = new n, e.__super__ = t.prototype, e
            },
            i = {}.hasOwnProperty;
        (e = Coinbase.Views).Network || (e.Network = {}), (t = Coinbase.Views.Network).Addresses || (t.Addresses = {}), Coinbase.Views.Network.Addresses.Show = function(e) {
            function t() {
                return t.__super__.constructor.apply(this, arguments)
            }
            return n(t, e), t.prototype.render = function() {
                return t.__super__.render.call(this), $("#toggle_trxns").on("click", function(e) {
                    return e.preventDefault(), $(".load-and-toggle").click()
                })
            }, t
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t, n = function(e, t) {
                function n() {
                    this.constructor = e
                }
                for (var r in t) i.call(t, r) && (e[r] = t[r]);
                return n.prototype = t.prototype, e.prototype = new n, e.__super__ = t.prototype, e
            },
            i = {}.hasOwnProperty;
        (e = window.Coinbase.Views).Oauth || (e.Oauth = {}), (t = window.Coinbase.Views.Oauth).Authorizations || (t.Authorizations = {}), Coinbase.Views.Oauth.Authorizations.RedirectForm = function(e) {
            function t() {
                return t.__super__.constructor.apply(this, arguments)
            }
            return n(t, e), $(document).ready(function() {
                $("#redirect_form").submit()
            }), t
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = window.Coinbase.Views).PasswordResets || (e.PasswordResets = {}), Coinbase.Views.PasswordResets.Change = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), Coinbase.Widgets.ChangePassword.enable()
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = window.Coinbase.Views).RecurringPayments || (e.RecurringPayments = {}), Coinbase.Views.RecurringPayments.Index = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                var e, t;
                return n.__super__.render.call(this), $("#recurring_payments_modal").on("shown", function() {
                    var n;
                    return $(this).find(".focus").focus(), n = e($(".recurring-payment-type")), t(n)
                }), $("table#recurring_payments_list").on("click", "td.clicktarget", function() {
                    var e;
                    return e = $(this).parent("tr").attr("id").split("_"), window.location.href = "/recurring_payments/" + e[e.length - 1]
                }), $(document).on("change", ".recurring-payment-type", function() {
                    var e;
                    return e = $(this).val(), t(e)
                }), t = function(e) {
                    return $(".which-control-group-to-show").hide(), $(".two-factor").hide(), "send" === e ? ($("#to_control_group").show(), $("#to_control_group input").focus(), $(".two-factor").show(), $("#account_control_group label").text("From account:")) : "request" === e ? ($("#from_control_group").show(), $("#from_control_group input").focus(), $("#account_control_group label").text("To account:")) : "buy" === e ? ($("#account_control_group label").text("To account:"), $("#payment_method_control_group label").text("Payment Method:"), $("#payment_method_control_group").show(), $(".two-factor").show()) : "sell" === e ? ($("#account_control_group label").text("From account:"), $("#payment_method_control_group label").text("Payout Method:"), $("#payment_method_control_group").show(), $(".two-factor").show()) : void 0
                }, e = function(e) {
                    var t, n, i;
                    for (n = 0, i = e.length; i > n; n++)
                        if (t = e[n], t.checked) return t.value;
                    return "send"
                }
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = window.Coinbase.Views).RecurringPayments || (e.RecurringPayments = {}), Coinbase.Views.RecurringPayments.New = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $("#recurring_payments_modal").modal("show"), Coinbase.Widgets.ContactsAutocomplete.enable()
            }, n
        }(Coinbase.Views.RecurringPayments.Index)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = window.Coinbase.Views).RecurringPayments || (e.RecurringPayments = {}), Coinbase.Views.RecurringPayments.Show = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this)
            }, n
        }(Coinbase.Views.RecurringPayments.Index)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).Reports || (e.Reports = {}), Coinbase.Views.Reports.Index = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                var e;
                return n.__super__.render.call(this), e = Coinbase.pusher.subscribe("user-reports-" + Coinbase.constants.USER.id), e.bind("update", function(e) {
                    return $("#report_" + e.report_id) ? $("#report_" + e.report_id).replaceWith(e.report_html) : void 0
                })
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).Reports || (e.Reports = {}), Coinbase.Views.Reports.Show = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $("#report_inline").length > 0 ? this.initInlineReports() : void 0
            }, n.prototype.initInlineReports = function() {
                var e, t, n;
                return n = $("#report_inline").data("fetch-url"), t = $("#report_inline").data("channel"), $("#load_inline").click(function(e) {
                    var t;
                    return e.preventDefault(), t = $("#report_inline").data("loaded"), t ? void 0 : $.post(n, function(e) {})
                }), $(".toggle-wrap").on("click", function(e) {
                    return e.preventDefault(), $("#report_inline").toggleClass("nowrap")
                }), e = Coinbase.pusher.subscribe(t), e.bind("update", function(e) {
                    var t, n, i, r, o, a, s, u, c, l, d, h, f;
                    if (e.success) {
                        for (i = e.file_data.split("\n"), r = a = 0, c = i.length; c >= 0 ? c > a : a > c; r = c >= 0 ? ++a : --a) {
                            if (f = i[r].replace(/,\s+/g, " "), f = f.split(","), f.length < 30)
                                for (o = s = l = f.length; 30 >= l ? 30 > s : s > 30; o = 30 >= l ? ++s : --s) f.push(" ");
                            for (h = $("<tr>"), o = u = 0, d = f.length; d >= 0 ? d > u : u > d; o = d >= 0 ? ++u : --u) h.append($("<td>").text(f[o]));
                            $("#report_inline > table > tbody:last").append(h)
                        }
                        return $("#loading_inline").remove(), $("#report_inline> a, #report_inline > table").show(), $("#report_inline").data("loaded", !0)
                    }
                    return $("#loading_inline").remove(), t = $('<div class="alert alert-error">'), t.text(e.errors.join(", ")), n = $("<td>").append(t), h = $("<tr>").append(n), $("#report_inline > table > tbody:last").append(h), $("#report_inline > table").show()
                })
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = window.Coinbase.Views).Sells || (e.Sells = {}), Coinbase.Views.Sells.Index = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                var e, t;
                return n.__super__.render.call(this), e = $("#limits-info").data(), e.isVerified ? (Coinbase.Widgets.Transfers.enable(), Coinbase.Widgets.Transfers.setupForm(), $(".focus").focus(), t = {
                    fees_bucket: Coinbase.constants.USER.fees_bucket
                }) : void 0
            }, n
        }(Coinbase.Views.Application)
    }.call(this);
var _get = function(e, t, n) {
    for (var i = !0; i;) {
        var r = e,
            o = t,
            a = n;
        i = !1, null === r && (r = Function.prototype);
        var s = Object.getOwnPropertyDescriptor(r, o);
        if (void 0 !== s) {
            if ("value" in s) return s.value;
            var u = s.get;
            return void 0 === u ? void 0 : u.call(a)
        }
        var c = Object.getPrototypeOf(r);
        if (null === c) return void 0;
        e = c, t = o, n = a, i = !0, s = c = void 0
    }
};
Coinbase.Views.Sessions = Coinbase.Views.Sessions || {}, Coinbase.Views.Sessions.New = function(e) {
        function t() {
            _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
        }
        return _inherits(t, e), t
    }(Coinbase.Views.Application),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = window.Coinbase.Views).Sessions || (e.Sessions = {}), Coinbase.Views.Sessions.OauthSignin = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $(".password-reset").on("click", function(e) {
                    var t, n;
                    return t = "/password_resets/new?source=oauth_signin", n = window.open(t, "password_reset_window", "height=500, width=430, menubar=no, toolbar=no"), null == n && (window.location = t), !1
                })
            }, n
        }(Coinbase.Views.Application)
    }.call(this);
var _createClass = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
            }
        }
        return function(t, n, i) {
            return n && e(t.prototype, n), i && e(t, i), t
        }
    }(),
    _get = function(e, t, n) {
        for (var i = !0; i;) {
            var r = e,
                o = t,
                a = n;
            i = !1, null === r && (r = Function.prototype);
            var s = Object.getOwnPropertyDescriptor(r, o);
            if (void 0 !== s) {
                if ("value" in s) return s.value;
                var u = s.get;
                return void 0 === u ? void 0 : u.call(a)
            }
            var c = Object.getPrototypeOf(r);
            if (null === c) return void 0;
            e = c, t = o, n = a, i = !0, s = c = void 0
        }
    };
Coinbase.Views.Sessions = Coinbase.Views.Sessions || {}, Coinbase.Views.Sessions.StepTwo = function(e) {
        function t() {
            _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
        }
        return _inherits(t, e), _createClass(t, [{
            key: "render",
            value: function() {
                _get(Object.getPrototypeOf(t.prototype), "render", this).call(this), $("#token").focus()
            }
        }]), t
    }(Coinbase.Views.Shared.U2F),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).Settings || (e.Settings = {}), Coinbase.Views.Settings.Api = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $("td .deprecated").tooltip({
                    placement: "bottom"
                })
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).Settings || (e.Settings = {}), Coinbase.Views.Settings.Preferences = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $("#email_select_all").click(function() {
                    return $(".set-email-preferences input[type='checkbox']").each(function() {
                        return this.checked = !0
                    })
                }), $("#email_clear_all").click(function() {
                    return $(".set-email-preferences input[type='checkbox']").each(function() {
                        this.checked = !1
                    })
                })
            }, n
        }(Coinbase.Views.Application)
    }.call(this);
var _get = function(e, t, n) {
    for (var i = !0; i;) {
        var r = e,
            o = t,
            a = n;
        i = !1, null === r && (r = Function.prototype);
        var s = Object.getOwnPropertyDescriptor(r, o);
        if (void 0 !== s) {
            if ("value" in s) return s.value;
            var u = s.get;
            return void 0 === u ? void 0 : u.call(a)
        }
        var c = Object.getPrototypeOf(r);
        if (null === c) return void 0;
        e = c, t = o, n = a, i = !0, s = c = void 0
    }
};
Coinbase.Views.Static = Coinbase.Views.Static || {}, Coinbase.Views.Static.BuyBitcoincash = function(e) {
    function t() {
        _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
    }
    return _inherits(t, e), t
}(Coinbase.Views.Application);
var _get = function(e, t, n) {
    for (var i = !0; i;) {
        var r = e,
            o = t,
            a = n;
        i = !1, null === r && (r = Function.prototype);
        var s = Object.getOwnPropertyDescriptor(r, o);
        if (void 0 !== s) {
            if ("value" in s) return s.value;
            var u = s.get;
            return void 0 === u ? void 0 : u.call(a)
        }
        var c = Object.getPrototypeOf(r);
        if (null === c) return void 0;
        e = c, t = o, n = a, i = !0, s = c = void 0
    }
};
Coinbase.Views.Static = Coinbase.Views.Static || {}, Coinbase.Views.Static.BuyEthereum = function(e) {
    function t() {
        _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
    }
    return _inherits(t, e), t
}(Coinbase.Views.Application);
var _get = function(e, t, n) {
    for (var i = !0; i;) {
        var r = e,
            o = t,
            a = n;
        i = !1, null === r && (r = Function.prototype);
        var s = Object.getOwnPropertyDescriptor(r, o);
        if (void 0 !== s) {
            if ("value" in s) return s.value;
            var u = s.get;
            return void 0 === u ? void 0 : u.call(a)
        }
        var c = Object.getPrototypeOf(r);
        if (null === c) return void 0;
        e = c, t = o, n = a, i = !0, s = c = void 0
    }
};
Coinbase.Views.Static = Coinbase.Views.Static || {}, Coinbase.Views.Static.BuyLitecoin = function(e) {
    function t() {
        _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
    }
    return _inherits(t, e), t
}(Coinbase.Views.Application);
var _get = function(e, t, n) {
    for (var i = !0; i;) {
        var r = e,
            o = t,
            a = n;
        i = !1, null === r && (r = Function.prototype);
        var s = Object.getOwnPropertyDescriptor(r, o);
        if (void 0 !== s) {
            if ("value" in s) return s.value;
            var u = s.get;
            return void 0 === u ? void 0 : u.call(a)
        }
        var c = Object.getPrototypeOf(r);
        if (null === c) return void 0;
        e = c, t = o, n = a, i = !0, s = c = void 0
    }
};
Coinbase.Views.Static = Coinbase.Views.Static || {}, Coinbase.Views.Static.Buybitcoin = function(e) {
    function t() {
        _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
    }
    return _inherits(t, e), t
}(Coinbase.Views.Application);
var _get = function(e, t, n) {
    for (var i = !0; i;) {
        var r = e,
            o = t,
            a = n;
        i = !1, null === r && (r = Function.prototype);
        var s = Object.getOwnPropertyDescriptor(r, o);
        if (void 0 !== s) {
            if ("value" in s) return s.value;
            var u = s.get;
            return void 0 === u ? void 0 : u.call(a)
        }
        var c = Object.getPrototypeOf(r);
        if (null === c) return void 0;
        e = c, t = o, n = a, i = !0, s = c = void 0
    }
};
Coinbase.Views.Static = Coinbase.Views.Static || {}, Coinbase.Views.Static.Cookie = function(e) {
        function t() {
            _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
        }
        return _inherits(t, e), t
    }(Coinbase.Views.Application),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).Static || (e.Static = {}), Coinbase.Views.Static.ExternalRedirect = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), window.opener = null, setTimeout(function() {
                    return window.location.replace($("#external_link").attr("href"))
                }, 2500)
            }, n
        }(Coinbase.Views.Application)
    }.call(this);
var _get = function(e, t, n) {
    for (var i = !0; i;) {
        var r = e,
            o = t,
            a = n;
        i = !1, null === r && (r = Function.prototype);
        var s = Object.getOwnPropertyDescriptor(r, o);
        if (void 0 !== s) {
            if ("value" in s) return s.value;
            var u = s.get;
            return void 0 === u ? void 0 : u.call(a)
        }
        var c = Object.getPrototypeOf(r);
        if (null === c) return void 0;
        e = c, t = o, n = a, i = !0, s = c = void 0
    }
};
Coinbase.Views.Static = Coinbase.Views.Static || {}, Coinbase.Views.Static.Faq = function(e) {
        function t() {
            _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
        }
        return _inherits(t, e), t
    }(Coinbase.Views.Application), window.addEventListener ? window.addEventListener("load", downloadDeferedImg, !1) : window.attachEvent ? window.attachEvent("onload", downloadDeferedImg) : window.onload = downloadDeferedImg, $("#main_nav_btn").on("click", function() {
        $("body").toggleClass("nav-toggled")
    }),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).Static || (e.Static = {}), Coinbase.Views.Static.Global = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $(".continent-link").on("click", function(e) {
                    return e.preventDefault(), $(".countries-nav li").removeClass("active"), $(this).parent("li").addClass("active"), "continent-all" === $(this).data("target") ? $(".continent").show() : ($(".continent").hide(), $("#" + $(this).data("target")).show())
                })
            }, n
        }(Coinbase.Views.Application)
    }.call(this);
var _get = function(e, t, n) {
    for (var i = !0; i;) {
        var r = e,
            o = t,
            a = n;
        i = !1, null === r && (r = Function.prototype);
        var s = Object.getOwnPropertyDescriptor(r, o);
        if (void 0 !== s) {
            if ("value" in s) return s.value;
            var u = s.get;
            return void 0 === u ? void 0 : u.call(a)
        }
        var c = Object.getPrototypeOf(r);
        if (null === c) return void 0;
        e = c, t = o, n = a, i = !0, s = c = void 0
    }
};
Coinbase.Views.Static = Coinbase.Views.Static || {}, Coinbase.Views.Static.Global = function(e) {
        function t() {
            _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
        }
        return _inherits(t, e), t
    }(Coinbase.Views.Application),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).Static || (e.Static = {}), Coinbase.Views.Static.Home = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $(".scroll-arrow").on("click", function(e) {
                    return e.preventDefault(), $("html, body").stop().animate({
                        scrollTop: $("#what_is_coinbase").offset().top
                    })
                })
            }, n
        }(Coinbase.Views.Application)
    }.call(this), $(document).ready(function() {
        $('[data-func="fader"]').each(function(e) {
            var t = $(this),
                n = t.find('[data-func="fade_toggle"]'),
                i = (t.find('[data-func="fade_item"]'), !1);
            n.each(function(e) {
                var n = $(this),
                    r = t.find('[data-hook="' + n.attr("data-target") + '"]');
                n.on("click", function(e) {
                    e.preventDefault();
                    var o = t.find('[data-func="fade_item"].active'),
                        a = t.find('[data-func="fade_toggle"].active');
                    n.hasClass("active") || i || (i = !0, a.removeClass("active"), n.addClass("active"), o.transition({
                        opacity: 0
                    }, 200, function() {
                        o.css({
                            display: "none"
                        }), o.removeClass("active"), r.css({
                            display: "flex"
                        }), r.transition({
                            opacity: 1
                        }, 200, function() {
                            r.addClass("active"), i = !1
                        })
                    }))
                })
            })
        })
    });
var _get = function(e, t, n) {
    for (var i = !0; i;) {
        var r = e,
            o = t,
            a = n;
        i = !1, null === r && (r = Function.prototype);
        var s = Object.getOwnPropertyDescriptor(r, o);
        if (void 0 !== s) {
            if ("value" in s) return s.value;
            var u = s.get;
            return void 0 === u ? void 0 : u.call(a)
        }
        var c = Object.getPrototypeOf(r);
        if (null === c) return void 0;
        e = c, t = o, n = a, i = !0, s = c = void 0
    }
};
Coinbase.Views.Static = Coinbase.Views.Static || {}, Coinbase.Views.Static.Insurance = function(e) {
        function t() {
            _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
        }
        return _inherits(t, e), t
    }(Coinbase.Views.Application),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).Static || (e.Static = {}), Coinbase.Views.Static.Join = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this)
            }, n
        }(Coinbase.Views.Application)
    }.call(this);
var _get = function(e, t, n) {
    for (var i = !0; i;) {
        var r = e,
            o = t,
            a = n;
        i = !1, null === r && (r = Function.prototype);
        var s = Object.getOwnPropertyDescriptor(r, o);
        if (void 0 !== s) {
            if ("value" in s) return s.value;
            var u = s.get;
            return void 0 === u ? void 0 : u.call(a)
        }
        var c = Object.getPrototypeOf(r);
        if (null === c) return void 0;
        e = c, t = o, n = a, i = !0, s = c = void 0
    }
};
Coinbase.Views.Static = Coinbase.Views.Static || {}, Coinbase.Views.Static.Licenses = function(e) {
    function t() {
        _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
    }
    return _inherits(t, e), t
}(Coinbase.Views.Application);
var _get = function(e, t, n) {
    for (var i = !0; i;) {
        var r = e,
            o = t,
            a = n;
        i = !1, null === r && (r = Function.prototype);
        var s = Object.getOwnPropertyDescriptor(r, o);
        if (void 0 !== s) {
            if ("value" in s) return s.value;
            var u = s.get;
            return void 0 === u ? void 0 : u.call(a)
        }
        var c = Object.getPrototypeOf(r);
        if (null === c) return void 0;
        e = c, t = o, n = a, i = !0, s = c = void 0
    }
};
Coinbase.Views.Static = Coinbase.Views.Static || {}, Coinbase.Views.Static.MarketData = function(e) {
        function t() {
            _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
        }
        return _inherits(t, e), t
    }(Coinbase.Views.Application),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).Static || (e.Static = {}), Coinbase.Views.Static.Places = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $("#quotes .nav").on("mouseover", function(e) {
                    var t;
                    return t = $(e.currentTarget).data("menuId"), $("#quotes .screen").hide(), $("#quotes .nav").removeClass("active"), $("#quotes .btn" + t).show(), $("#quotes .nav" + t).addClass("active")
                })
            }, n
        }(Coinbase.Views.Application)
    }.call(this);
var _get = function(e, t, n) {
    for (var i = !0; i;) {
        var r = e,
            o = t,
            a = n;
        i = !1, null === r && (r = Function.prototype);
        var s = Object.getOwnPropertyDescriptor(r, o);
        if (void 0 !== s) {
            if ("value" in s) return s.value;
            var u = s.get;
            return void 0 === u ? void 0 : u.call(a)
        }
        var c = Object.getPrototypeOf(r);
        if (null === c) return void 0;
        e = c, t = o, n = a, i = !0, s = c = void 0
    }
};
Coinbase.Views.Static = Coinbase.Views.Static || {}, Coinbase.Views.Static.Privacy = function(e) {
    function t() {
        _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
    }
    return _inherits(t, e), t
}(Coinbase.Views.Application);
var _get = function(e, t, n) {
    for (var i = !0; i;) {
        var r = e,
            o = t,
            a = n;
        i = !1, null === r && (r = Function.prototype);
        var s = Object.getOwnPropertyDescriptor(r, o);
        if (void 0 !== s) {
            if ("value" in s) return s.value;
            var u = s.get;
            return void 0 === u ? void 0 : u.call(a)
        }
        var c = Object.getPrototypeOf(r);
        if (null === c) return void 0;
        e = c, t = o, n = a, i = !0, s = c = void 0
    }
};
Coinbase.Views.Static = Coinbase.Views.Static || {}, Coinbase.Views.Static.Security = function(e) {
    function t() {
        _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
    }
    return _inherits(t, e), t
}(Coinbase.Views.Application);
var _get = function(e, t, n) {
    for (var i = !0; i;) {
        var r = e,
            o = t,
            a = n;
        i = !1, null === r && (r = Function.prototype);
        var s = Object.getOwnPropertyDescriptor(r, o);
        if (void 0 !== s) {
            if ("value" in s) return s.value;
            var u = s.get;
            return void 0 === u ? void 0 : u.call(a)
        }
        var c = Object.getPrototypeOf(r);
        if (null === c) return void 0;
        e = c, t = o, n = a, i = !0, s = c = void 0
    }
};
Coinbase.Views.Static = Coinbase.Views.Static || {}, Coinbase.Views.Static.TradingRules = function(e) {
    function t() {
        _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
    }
    return _inherits(t, e), t
}(Coinbase.Views.Application);
var _get = function(e, t, n) {
    for (var i = !0; i;) {
        var r = e,
            o = t,
            a = n;
        i = !1, null === r && (r = Function.prototype);
        var s = Object.getOwnPropertyDescriptor(r, o);
        if (void 0 !== s) {
            if ("value" in s) return s.value;
            var u = s.get;
            return void 0 === u ? void 0 : u.call(a)
        }
        var c = Object.getPrototypeOf(r);
        if (null === c) return void 0;
        e = c, t = o, n = a, i = !0, s = c = void 0
    }
};
Coinbase.Views.Static = Coinbase.Views.Static || {}, Coinbase.Views.Static.UserAgreement = function(e) {
        function t() {
            _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
        }
        return _inherits(t, e), t
    }(Coinbase.Views.Application),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype,
                    e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).Static || (e.Static = {}), Coinbase.Views.Static.Vault = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $("#withdraw_carousel").carousel(), $("#withdraw_carousel").on("slide", function(e) {
                    return $("#withdraw_carousel_indicators .step span").removeClass("active"), $("#withdraw_carousel_indicators #" + $(e.relatedTarget).data("target") + " span").addClass("active")
                })
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = window.Coinbase.Views).Transfers || (e.Transfers = {}), Coinbase.Views.Transfers.Index = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $("table#transfers_list").on("click", "tr", function() {
                    var e;
                    return e = $(this).attr("id").split("_"), window.location.href = "/transfers/" + e[e.length - 1]
                })
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).UserAccountClosures || (e.UserAccountClosures = {}), Coinbase.Views.UserAccountClosures.Show = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                var e;
                return n.__super__.render.call(this), $(document).on("click", ".account_closure_transaction", function(e) {
                    var t;
                    if (t = $(this).find("a").first()) return window.location.href = t.attr("href")
                }), $(".accounts_transfer form").on("submit", function(e) {
                    var t;
                    return t = $(this).parents(".accounts_transfer"), t.find("form").addClass("hide"), t.find(".working").removeClass("hide").css({
                        height: t.height()
                    })
                }), $('input[name="user_account_closure_transaction[destination_address]"]').on("keyup", function() {
                    return e(this, !1)
                }), $('input[name="user_account_closure_transaction[destination_address]"]').on("change", function() {
                    return e(this)
                }), $('select[name="user_account_closure_transaction[destination_bank_account_id]"]').on("change", function() {
                    return e(this)
                }), e = function(e, t) {
                    var n;
                    return null == t && (t = !0), n = $(e).parents("form"), n.hasClass("expanded") ? void 0 : (n.addClass("expanded"), t ? n.find("input[name=token]").focus() : void 0)
                }
            }, n
        }(Coinbase.Views.Application)
    }.call(this);
var _createClass = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
            }
        }
        return function(t, n, i) {
            return n && e(t.prototype, n), i && e(t, i), t
        }
    }(),
    _get = function(e, t, n) {
        for (var i = !0; i;) {
            var r = e,
                o = t,
                a = n;
            i = !1, null === r && (r = Function.prototype);
            var s = Object.getOwnPropertyDescriptor(r, o);
            if (void 0 !== s) {
                if ("value" in s) return s.value;
                var u = s.get;
                return void 0 === u ? void 0 : u.call(a)
            }
            var c = Object.getPrototypeOf(r);
            if (null === c) return void 0;
            e = c, t = o, n = a, i = !0, s = c = void 0
        }
    };
Coinbase.Views.Users = Coinbase.Views.Users || {};
var stateInfo = {
    HI: {
        name: "Hawaii",
        supportLink: "https://support.coinbase.com/customer/portal/articles/2754027"
    }
};
Coinbase.Views.Users.New = function(e) {
    function t() {
        _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
    }
    return _inherits(t, e), _createClass(t, [{
        key: "stateWarning",
        value: function() {
            $(".unsupported-state").hide(), $(".signup-button").prop("disabled", !1);
            var e = $("select.state").val();
            if (Object.keys(stateInfo).includes(e)) {
                var t = stateInfo[e];
                $(".unsupported-state").html("Although we strive to provide continuous access to Coinbase services, Coinbase has indefinitely suspended its business in " + t.name + ". If you're a resident of another state, please select it.<br/><br/><a href=\"" + t.supportLink + '" target="_blank">Read more</a>.'), $(".unsupported-state").show(), $(".signup-button").prop("disabled", !0)
            }
        }
    }, {
        key: "getReferringPage",
        value: function() {
            var e = window.document && window.document.referrer || "";
            return e.indexOf("coinbase.com") < 0 ? "" : new URL(e).pathname
        }
    }, {
        key: "render",
        value: function() {
            _get(Object.getPrototypeOf(t.prototype), "render", this).call(this), Coinbase.PrivacyOnboarding.setup(), $("select.state").on("change", this.stateWarning), this.stateWarning(), $(".business-tab").on("click", function() {
                $(".modal.business-modal").modal("toggle")
            }), $(".prime-link").on("click", function() {
                window.location = "https://prime.coinbase.com"
            }), $(".commerce-link").on("click", function() {
                window.location = "https://commerce.coinbase.com"
            }), $("#user_accepted_user_agreement").one("click", function(e) {
                "undefined" != typeof gtag && gtag("event", "conversion", {
                    send_to: "AW-834608245/zQCkCLmKgnsQ9bj8jQM"
                })
            });
            var e = amplitude.getInstance();
            e.logEvent("signup_page_viewed", {
                referring_coinbase_page: this.getReferringPage(),
                auth: 0
            }), e.logEvent("signup_form_viewed", {
                signupExperiment: "control"
            })
        }
    }]), t
}(Coinbase.Views.Application);
var _createClass = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
            }
        }
        return function(t, n, i) {
            return n && e(t.prototype, n), i && e(t, i), t
        }
    }(),
    _get = function(e, t, n) {
        for (var i = !0; i;) {
            var r = e,
                o = t,
                a = n;
            i = !1, null === r && (r = Function.prototype);
            var s = Object.getOwnPropertyDescriptor(r, o);
            if (void 0 !== s) {
                if ("value" in s) return s.value;
                var u = s.get;
                return void 0 === u ? void 0 : u.call(a)
            }
            var c = Object.getPrototypeOf(r);
            if (null === c) return void 0;
            e = c, t = o, n = a, i = !0, s = c = void 0
        }
    };
Coinbase.Views.Users = Coinbase.Views.Users || {}, Coinbase.Views.Users.OauthSignup = function(e) {
        function t() {
            _classCallCheck(this, t), _get(Object.getPrototypeOf(t.prototype), "constructor", this).apply(this, arguments)
        }
        return _inherits(t, e), _createClass(t, [{
            key: "render",
            value: function() {
                _get(Object.getPrototypeOf(t.prototype), "render", this).call(this), Coinbase.PrivacyOnboarding.setup()
            }
        }]), t
    }(Coinbase.Views.Application),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = window.Coinbase.Views).Users || (e.Users = {}), Coinbase.Views.Users.ShowVerify = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                var e;
                return n.__super__.render.call(this), e = $(".session.verify").data("redirectTo"), this.intervalID = setInterval(function(t) {
                    return function() {
                        return $.getJSON("/users/verify_status").done(function(n) {
                            return n.verified ? t.redirect(e) : void 0
                        })
                    }
                }(this), 2500)
            }, n.prototype.redirect = function(e) {
                return clearInterval(this.intervalID), window.location.href = e
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).VaultAccounts || (e.VaultAccounts = {}), Coinbase.Views.VaultAccounts.Join = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this)
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).VaultAccounts || (e.VaultAccounts = {}), Coinbase.Views.VaultAccounts.Setup = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), this.poll_and_render($("#pending .pending").data("refresh_url"))
            }, n.prototype.poll_and_render = function(e, t) {
                var n;
                return null == t && (t = 5e3), e && ($.get(e, function(e) {
                    return " " === e ? window.location.reload() : $("#pending .pending").html(e)
                }), 1 === $("#pending").length) ? (n = this, setTimeout(function() {
                    return n.poll_and_render(e, t)
                }, t)) : void 0
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).VaultWithdrawals || (e.VaultWithdrawals = {}), Coinbase.Views.VaultWithdrawals.ApproveByToken = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $(".auto-click").trigger("click")
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = Coinbase.Views).VaultWithdrawals || (e.VaultWithdrawals = {}), Coinbase.Views.VaultWithdrawals.CancelByToken = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $(".auto-click").trigger("click")
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e, t = function(e, t) {
                function i() {
                    this.constructor = e
                }
                for (var r in t) n.call(t, r) && (e[r] = t[r]);
                return i.prototype = t.prototype, e.prototype = new i, e.__super__ = t.prototype, e
            },
            n = {}.hasOwnProperty;
        (e = window.Coinbase.Views).Verifications || (e.Verifications = {}), Coinbase.Views.Verifications.Index = function(e) {
            function n() {
                return n.__super__.constructor.apply(this, arguments)
            }
            return t(n, e), n.prototype.render = function() {
                return n.__super__.render.call(this), $(".notification button.close").click(function(e) {
                    return e.preventDefault(), e.stopPropagation(), $(this).closest(".notification").fadeOut()
                })
            }, n
        }(Coinbase.Views.Application)
    }.call(this),
    function() {
        var e;
        null == window.Coinbase && (window.Coinbase = {}), null == (e = window.Coinbase).Modules && (e.Modules = {}), Coinbase.Modules.Init = function() {
            function e() {}
            return e.getApplicationView = function(e) {
                var t, n, i;
                if (t = Coinbase.Views.Application, !e) return t;
                if (i = e.split(".").slice(2), i.length < 2) return t;
                for (n = Coinbase.Views; i.length > 0;)
                    if (n = n[i.shift()], !n) return t;
                return n || t
            }, e.pageLoad = function() {
                var e, t;
                return t = $("body").data("viewName"), e = Coinbase.Modules.Init.getApplicationView(t), Coinbase.applicationView = new e, Coinbase.applicationView.render()
            }, e.setupLayout = function() {
                var e, t;
                if ($(".Sidebar__sidebarContainer, .Dropdown__DropdownButton-bFrozV").length) return t = $("body").data("controller-name"), e = $("body").data("action-name"), $(".SidebarItem__container, .Navbar__link").each(function() {
                    var n, i, r;
                    return n = $(this), r = n.data("controller-names"), r && r.split(",").indexOf(t) > -1 && (!(i = n.data("action-names")) || i.split(",").indexOf(e) > -1) ? ($(".SidebarItem__container").removeClass("active"), n.addClass("active"), n.addClass("jAXUQz"), !1) : void 0
                }), $(".Header__userMenu, .Backdrop__container, .DropdownMenu__overlay, .Header__userMenu, .Backdrop__container, .Dropdown__DropdownButton-bFrozV").on("click", function(e) {
                    return function(e) {
                        return e.preventDefault(), $(".DropdownMenu__Wrapper-ieiZya").toggle(), $(".backdrop").fadeToggle(), $(".Backdrop__container").fadeToggle()
                    }
                }(this))
            }, e
        }()
    }.call(this),
    function() {
        var e;
        (e = window.Coinbase).Modules || (e.Modules = {}), Coinbase.Modules.Jumio = function() {
            function e() {}
            return e.onSuccess = function() {
                return "account_recovery" === Coinbase.utils.inAccountRecovery() ? document.location.reload() : document.location = "/verifications/documents"
            }, e.onVerified = function() {
                return "account_recovery" === Coinbase.utils.inAccountRecovery() ? document.location.reload() : void 0
            }, e
        }()
    }.call(this),
    function() {
        var e;
        (e = window.Coinbase).Modules || (e.Modules = {}), Coinbase.Modules.Live = function() {
            function e() {}
            return e.init = function() {
                return Coinbase.constants.USER ? (Coinbase.live = Coinbase.pusher.subscribe(Coinbase.constants.USER.pusher_channel), Coinbase.live.bind("pusher:subscription_error", function() {
                    var e;
                    return "/device_confirmations/new" !== (e = window.location.pathname) && "/users/accept_terms" !== e && Coinbase.constants.USER.refresh_pusher_auth ? window.location.reload(!0) : void 0
                }), Coinbase.live.bind("reset-session", function(t) {
                    return Coinbase.constants.USER.pusher_channel = t.new_channel, e.init()
                }), Coinbase.live.bind("pusher:create_portal", function(e) {
                    var t, n, i, r;
                    return console.info("Create portal"), t = $("#" + e.portalId), i = document.createElement("div"), i.id = e.portalId, n = $.parseHTML(e.html), n.forEach(function(e) {
                        return i.appendChild(e)
                    }), t.length > 0 && t.remove(), document.body.appendChild(i), e.script ? (r = document.createElement("script"), r.text = e.script, i.appendChild(r)) : void 0
                })) : void 0
            }, e
        }()
    }.call(this),
    function() {
        var e;
        (e = window.Coinbase).Modules || (e.Modules = {}), Coinbase.Modules.Paypal = function() {
            function e() {}
            return e.callback_setup = !1, e.setup_callback = function() {
                return this.callback_setup ? void 0 : ("undefined" != typeof Coinbase.live && Coinbase.live.bind("paypal-payment-executed", function(e) {
                    return $(".payment_status_container").html(e.paypal_html)
                }), this.callback_setup = !0)
            }, e
        }()
    }.call(this), GridSampler = {}, GridSampler.checkAndNudgePoints = function(e, t) {
        for (var n = qrcode.width, i = qrcode.height, r = !0, o = 0; o < t.length && r; o += 2) {
            var a = Math.floor(t[o]),
                s = Math.floor(t[o + 1]);
            if (-1 > a || a > n || -1 > s || s > i) throw "Error.checkAndNudgePoints ";
            r = !1, -1 == a ? (t[o] = 0, r = !0) : a == n && (t[o] = n - 1, r = !0), -1 == s ? (t[o + 1] = 0, r = !0) : s == i && (t[o + 1] = i - 1, r = !0)
        }
        r = !0;
        for (var o = t.length - 2; o >= 0 && r; o -= 2) {
            var a = Math.floor(t[o]),
                s = Math.floor(t[o + 1]);
            if (-1 > a || a > n || -1 > s || s > i) throw "Error.checkAndNudgePoints ";
            r = !1, -1 == a ? (t[o] = 0, r = !0) : a == n && (t[o] = n - 1, r = !0), -1 == s ? (t[o + 1] = 0, r = !0) : s == i && (t[o + 1] = i - 1, r = !0)
        }
    }, GridSampler.sampleGrid3 = function(e, t, n) {
        for (var i = new BitMatrix(t), r = new Array(t << 1), o = 0; t > o; o++) {
            for (var a = r.length, s = o + .5, u = 0; a > u; u += 2) r[u] = (u >> 1) + .5, r[u + 1] = s;
            n.transformPoints1(r), GridSampler.checkAndNudgePoints(e, r);
            try {
                for (var u = 0; a > u; u += 2) {
                    var c = 4 * Math.floor(r[u]) + Math.floor(r[u + 1]) * qrcode.width * 4,
                        l = e[Math.floor(r[u]) + qrcode.width * Math.floor(r[u + 1])];
                    qrcode.imagedata.data[c] = l ? 255 : 0, qrcode.imagedata.data[c + 1] = l ? 255 : 0, qrcode.imagedata.data[c + 2] = 0, qrcode.imagedata.data[c + 3] = 255, l && i.set_Renamed(u >> 1, o)
                }
            } catch (d) {
                throw "Error.checkAndNudgePoints"
            }
        }
        return i
    }, GridSampler.sampleGridx = function(e, t, n, i, r, o, a, s, u, c, l, d, h, f, p, g, m, v) {
        var y = PerspectiveTransform.quadrilateralToQuadrilateral(n, i, r, o, a, s, u, c, l, d, h, f, p, g, m, v);
        return GridSampler.sampleGrid3(e, t, y)
    }, Version.VERSION_DECODE_INFO = new Array(31892, 34236, 39577, 42195, 48118, 51042, 55367, 58893, 63784, 68472, 70749, 76311, 79154, 84390, 87683, 92361, 96236, 102084, 102881, 110507, 110734, 117786, 119615, 126325, 127568, 133589, 136944, 141498, 145311, 150283, 152622, 158308, 161089, 167017), Version.VERSIONS = buildVersions(), Version.getVersionForNumber = function(e) {
        if (1 > e || e > 40) throw "ArgumentException";
        return Version.VERSIONS[e - 1]
    }, Version.getProvisionalVersionForDimension = function(e) {
        if (e % 4 != 1) throw "Error getProvisionalVersionForDimension";
        try {
            return Version.getVersionForNumber(e - 17 >> 2)
        } catch (t) {
            throw "Error getVersionForNumber"
        }
    }, Version.decodeVersionInformation = function(e) {
        for (var t = 4294967295, n = 0, i = 0; i < Version.VERSION_DECODE_INFO.length; i++) {
            var r = Version.VERSION_DECODE_INFO[i];
            if (r == e) return this.getVersionForNumber(i + 7);
            var o = FormatInformation.numBitsDiffering(e, r);
            t > o && (n = i + 7, t = o)
        }
        return 3 >= t ? this.getVersionForNumber(n) : null
    }, PerspectiveTransform.quadrilateralToQuadrilateral = function(e, t, n, i, r, o, a, s, u, c, l, d, h, f, p, g) {
        var m = this.quadrilateralToSquare(e, t, n, i, r, o, a, s),
            v = this.squareToQuadrilateral(u, c, l, d, h, f, p, g);
        return v.times(m)
    }, PerspectiveTransform.squareToQuadrilateral = function(e, t, n, i, r, o, a, s) {
        return dy2 = s - o, dy3 = t - i + o - s, 0 == dy2 && 0 == dy3 ? new PerspectiveTransform(n - e, r - n, e, i - t, o - i, t, 0, 0, 1) : (dx1 = n - r, dx2 = a - r, dx3 = e - n + r - a, dy1 = i - o, denominator = dx1 * dy2 - dx2 * dy1, a13 = (dx3 * dy2 - dx2 * dy3) / denominator, a23 = (dx1 * dy3 - dx3 * dy1) / denominator, new PerspectiveTransform(n - e + a13 * n, a - e + a23 * a, e, i - t + a13 * i, s - t + a23 * s, t, a13, a23, 1))
    }, PerspectiveTransform.quadrilateralToSquare = function(e, t, n, i, r, o, a, s) {
        return this.squareToQuadrilateral(e, t, n, i, r, o, a, s).buildAdjoint()
    };
var FORMAT_INFO_MASK_QR = 21522,
    FORMAT_INFO_DECODE_LOOKUP = new Array(new Array(21522, 0), new Array(20773, 1), new Array(24188, 2), new Array(23371, 3), new Array(17913, 4), new Array(16590, 5), new Array(20375, 6), new Array(19104, 7), new Array(30660, 8), new Array(29427, 9), new Array(32170, 10), new Array(30877, 11), new Array(26159, 12), new Array(25368, 13), new Array(27713, 14), new Array(26998, 15), new Array(5769, 16), new Array(5054, 17), new Array(7399, 18), new Array(6608, 19), new Array(1890, 20), new Array(597, 21), new Array(3340, 22), new Array(2107, 23), new Array(13663, 24), new Array(12392, 25), new Array(16177, 26), new Array(14854, 27), new Array(9396, 28), new Array(8579, 29), new Array(11994, 30), new Array(11245, 31)),
    BITS_SET_IN_HALF_BYTE = new Array(0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4);
FormatInformation.numBitsDiffering = function(e, t) {
    return e ^= t, BITS_SET_IN_HALF_BYTE[15 & e] + BITS_SET_IN_HALF_BYTE[15 & URShift(e, 4)] + BITS_SET_IN_HALF_BYTE[15 & URShift(e, 8)] + BITS_SET_IN_HALF_BYTE[15 & URShift(e, 12)] + BITS_SET_IN_HALF_BYTE[15 & URShift(e, 16)] + BITS_SET_IN_HALF_BYTE[15 & URShift(e, 20)] + BITS_SET_IN_HALF_BYTE[15 & URShift(e, 24)] + BITS_SET_IN_HALF_BYTE[15 & URShift(e, 28)]
}, FormatInformation.decodeFormatInformation = function(e) {
    var t = FormatInformation.doDecodeFormatInformation(e);
    return null != t ? t : FormatInformation.doDecodeFormatInformation(e ^ FORMAT_INFO_MASK_QR)
}, FormatInformation.doDecodeFormatInformation = function(e) {
    for (var t = 4294967295, n = 0, i = 0; i < FORMAT_INFO_DECODE_LOOKUP.length; i++) {
        var r = FORMAT_INFO_DECODE_LOOKUP[i],
            o = r[0];
        if (o == e) return new FormatInformation(r[1]);
        var a = this.numBitsDiffering(e, o);
        t > a && (n = r[1], t = a)
    }
    return 3 >= t ? new FormatInformation(n) : null
}, ErrorCorrectionLevel.forBits = function(e) {
    if (0 > e || e >= FOR_BITS.length) throw "ArgumentException";
    return FOR_BITS[e]
};
var L = new ErrorCorrectionLevel(0, 1, "L"),
    M = new ErrorCorrectionLevel(1, 0, "M"),
    Q = new ErrorCorrectionLevel(2, 3, "Q"),
    H = new ErrorCorrectionLevel(3, 2, "H"),
    FOR_BITS = new Array(M, L, H, Q);
DataBlock.getDataBlocks = function(e, t, n) {
    if (e.length != t.TotalCodewords) throw "ArgumentException";
    for (var i = t.getECBlocksForLevel(n), r = 0, o = i.getECBlocks(), a = 0; a < o.length; a++) r += o[a].Count;
    for (var s = new Array(r), u = 0, c = 0; c < o.length; c++)
        for (var l = o[c], a = 0; a < l.Count; a++) {
            var d = l.DataCodewords,
                h = i.ECCodewordsPerBlock + d;
            s[u++] = new DataBlock(d, new Array(h))
        }
    for (var f = s[0].codewords.length, p = s.length - 1; p >= 0;) {
        var g = s[p].codewords.length;
        if (g == f) break;
        p--
    }
    p++;
    for (var m = f - i.ECCodewordsPerBlock, v = 0, a = 0; m > a; a++)
        for (var c = 0; u > c; c++) s[c].codewords[a] = e[v++];
    for (var c = p; u > c; c++) s[c].codewords[m] = e[v++];
    for (var y = s[0].codewords.length, a = m; y > a; a++)
        for (var c = 0; u > c; c++) {
            var b = p > c ? a : a + 1;
            s[c].codewords[b] = e[v++]
        }
    return s
}, DataMask = {}, DataMask.forReference = function(e) {
    if (0 > e || e > 7) throw "System.ArgumentException";
    return DataMask.DATA_MASKS[e]
}, DataMask.DATA_MASKS = new Array(new DataMask000, new DataMask001, new DataMask010, new DataMask011, new DataMask100, new DataMask101, new DataMask110, new DataMask111), GF256.QR_CODE_FIELD = new GF256(285), GF256.DATA_MATRIX_FIELD = new GF256(301), GF256.addOrSubtract = function(e, t) {
    return e ^ t
}, Decoder = {}, Decoder.rsDecoder = new ReedSolomonDecoder(GF256.QR_CODE_FIELD), Decoder.correctErrors = function(e, t) {
    for (var n = e.length, i = new Array(n), r = 0; n > r; r++) i[r] = 255 & e[r];
    var o = e.length - t;
    try {
        Decoder.rsDecoder.decode(i, o)
    } catch (a) {
        throw a
    }
    for (var r = 0; t > r; r++) e[r] = i[r]
}, Decoder.decode = function(e) {
    for (var t = new BitMatrixParser(e), n = t.readVersion(), i = t.readFormatInformation().ErrorCorrectionLevel, r = t.readCodewords(), o = DataBlock.getDataBlocks(r, n, i), a = 0, s = 0; s < o.length; s++) a += o[s].NumDataCodewords;
    for (var u = new Array(a), c = 0, l = 0; l < o.length; l++) {
        var d = o[l],
            h = d.Codewords,
            f = d.NumDataCodewords;
        Decoder.correctErrors(h, f);
        for (var s = 0; f > s; s++) u[c++] = h[s]
    }
    var p = new QRCodeDataBlockReader(u, n.VersionNumber, i.Bits);
    return p
}, qrcode = {}, qrcode.imagedata = null, qrcode.width = 0, qrcode.height = 0, qrcode.qrCodeSymbol = null, qrcode.debug = !1, qrcode.maxImgSize = 1048576, qrcode.sizeOfDataLengthInfo = [
    [10, 9, 8, 8],
    [12, 11, 16, 10],
    [14, 13, 16, 12]
], qrcode.callback = null, qrcode.decode = function(e) {
    if (0 == arguments.length) {
        var t = document.getElementById("qr-canvas"),
            n = t.getContext("2d");
        return qrcode.width = t.width, qrcode.height = t.height, qrcode.imagedata = n.getImageData(0, 0, qrcode.width, qrcode.height), qrcode.result = qrcode.process(n), null != qrcode.callback && qrcode.callback(qrcode.result), qrcode.result
    }
    var i = new Image;
    i.onload = function() {
        var e = document.createElement("canvas"),
            t = e.getContext("2d"),
            n = i.height,
            r = i.width;
        if (i.width * i.height > qrcode.maxImgSize) {
            var o = i.width / i.height;
            n = Math.sqrt(qrcode.maxImgSize / o), r = o * n
        }
        e.width = r, e.height = n, t.drawImage(i, 0, 0, e.width, e.height), qrcode.width = e.width, qrcode.height = e.height;
        try {
            qrcode.imagedata = t.getImageData(0, 0, e.width, e.height)
        } catch (a) {
            return qrcode.result = "Cross domain image reading not supported in your browser! Save it to your computer then drag and drop the file!", void(null != qrcode.callback && qrcode.callback(qrcode.result))
        }
        try {
            qrcode.result = qrcode.process(t)
        } catch (a) {
            console.log(a), qrcode.result = "error decoding QR Code"
        }
        null != qrcode.callback && qrcode.callback(qrcode.result)
    }, i.src = e
}, qrcode.isUrl = function(e) {
    var t = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;
    return t.test(e)
}, qrcode.decode_url = function(e) {
    var t = "";
    try {
        t = escape(e)
    } catch (n) {
        console.log(n), t = e
    }
    var i = "";
    try {
        i = decodeURIComponent(t)
    } catch (n) {
        console.log(n), i = t
    }
    return i
}, qrcode.decode_utf8 = function(e) {
    return qrcode.isUrl(e) ? qrcode.decode_url(e) : e
}, qrcode.process = function(e) {
    var t = (new Date).getTime(),
        n = qrcode.grayScaleToBitmap(qrcode.grayscale());
    if (qrcode.debug) {
        for (var i = 0; i < qrcode.height; i++)
            for (var r = 0; r < qrcode.width; r++) {
                var o = 4 * r + i * qrcode.width * 4;
                qrcode.imagedata.data[o] = (n[r + i * qrcode.width], 0), qrcode.imagedata.data[o + 1] = (n[r + i * qrcode.width], 0), qrcode.imagedata.data[o + 2] = n[r + i * qrcode.width] ? 255 : 0
            }
        e.putImageData(qrcode.imagedata, 0, 0)
    }
    var a = new Detector(n),
        s = a.detect();
    qrcode.debug && e.putImageData(qrcode.imagedata, 0, 0);
    for (var u = Decoder.decode(s.bits), c = u.DataByte, l = "", d = 0; d < c.length; d++)
        for (var h = 0; h < c[d].length; h++) l += String.fromCharCode(c[d][h]);
    var f = (new Date).getTime(),
        p = f - t;
    return console.log(p), qrcode.decode_utf8(l)
}, qrcode.getPixel = function(e, t) {
    if (qrcode.width < e) throw "point error";
    if (qrcode.height < t) throw "point error";
    return point = 4 * e + t * qrcode.width * 4, p = (33 * qrcode.imagedata.data[point] + 34 * qrcode.imagedata.data[point + 1] + 33 * qrcode.imagedata.data[point + 2]) / 100, p
}, qrcode.binarize = function(e) {
    for (var t = new Array(qrcode.width * qrcode.height), n = 0; n < qrcode.height; n++)
        for (var i = 0; i < qrcode.width; i++) {
            var r = qrcode.getPixel(i, n);
            t[i + n * qrcode.width] = e >= r ? !0 : !1
        }
    return t
}, qrcode.getMiddleBrightnessPerArea = function(e) {
    for (var t = 4, n = Math.floor(qrcode.width / t), i = Math.floor(qrcode.height / t), r = new Array(t), o = 0; t > o; o++) {
        r[o] = new Array(t);
        for (var a = 0; t > a; a++) r[o][a] = new Array(0, 0)
    }
    for (var s = 0; t > s; s++)
        for (var u = 0; t > u; u++) {
            r[u][s][0] = 255;
            for (var c = 0; i > c; c++)
                for (var l = 0; n > l; l++) {
                    var d = e[n * u + l + (i * s + c) * qrcode.width];
                    d < r[u][s][0] && (r[u][s][0] = d), d > r[u][s][1] && (r[u][s][1] = d)
                }
        }
    for (var h = new Array(t), f = 0; t > f; f++) h[f] = new Array(t);
    for (var s = 0; t > s; s++)
        for (var u = 0; t > u; u++) h[u][s] = Math.floor((r[u][s][0] + r[u][s][1]) / 2);
    return h
}, qrcode.grayScaleToBitmap = function(e) {
    for (var t = qrcode.getMiddleBrightnessPerArea(e), n = t.length, i = Math.floor(qrcode.width / n), r = Math.floor(qrcode.height / n), o = new Array(qrcode.height * qrcode.width), a = 0; n > a; a++)
        for (var s = 0; n > s; s++)
            for (var u = 0; r > u; u++)
                for (var c = 0; i > c; c++) o[i * s + c + (r * a + u) * qrcode.width] = e[i * s + c + (r * a + u) * qrcode.width] < t[s][a] ? !0 : !1;
    return o
}, qrcode.grayscale = function() {
    for (var e = new Array(qrcode.width * qrcode.height), t = 0; t < qrcode.height; t++)
        for (var n = 0; n < qrcode.width; n++) {
            var i = qrcode.getPixel(n, t);
            e[n + t * qrcode.width] = i
        }
    return e
}, Array.prototype.remove = function(e, t) {
    var n = this.slice((t || e) + 1 || this.length);
    return this.length = 0 > e ? this.length + e : e, this.push.apply(this, n)
};
var MIN_SKIP = 3,
    MAX_MODULES = 57,
    INTEGER_MATH_SHIFT = 8,
    CENTER_QUORUM = 2;
qrcode.orderBestPatterns = function(e) {
        function t(e, t) {
            return xDiff = e.X - t.X, yDiff = e.Y - t.Y, Math.sqrt(xDiff * xDiff + yDiff * yDiff)
        }

        function n(e, t, n) {
            var i = t.x,
                r = t.y;
            return (n.x - i) * (e.y - r) - (n.y - r) * (e.x - i)
        }
        var i, r, o, a = t(e[0], e[1]),
            s = t(e[1], e[2]),
            u = t(e[0], e[2]);
        if (s >= a && s >= u ? (r = e[0], i = e[1], o = e[2]) : u >= s && u >= a ? (r = e[1], i = e[0], o = e[2]) : (r = e[2], i = e[0], o = e[1]), n(i, r, o) < 0) {
            var c = i;
            i = o, o = c
        }
        e[0] = i, e[1] = r, e[2] = o
    },
    function() {}.call(this),
    function() {
        var e;
        (e = window.Coinbase).Modules || (e.Modules = {}), Coinbase.Modules.QRScanner = function() {
            function e() {}
            return window.requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || window.msRequestAnimationFrame, navigator.getMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia, e.supported = function() {
                return !(!window.requestAnimationFrame || !navigator.getMedia)
            }, e.init = function(e, t, n, i, r, o) {
                var a;
                return this.v_selector = e, this.unsupported_cb = t, this.waiting_cb = n, this.denied_cb = i, this.seeking_cb = r, this.found_cb = o, qrcode.callback = this.qrFound.bind(this), this.video = $(v_selector).get(0), $("#qr-canvas").get(0) || (a = document.createElement("canvas"), a.style.display = "none", this.bg_canvas = document.body.appendChild(a), this.bg_canvas.id = "qr-canvas", this.bg_canvas_context = this.bg_canvas.getContext("2d")), this.stream ? this.play() : this.requested_media ? void 0 : (this.requested_media = !0, this.waiting_cb && this.waiting_cb(), navigator.getMedia({
                    video: !0
                }, this.streamReady.bind(this), this.streamFailed.bind(this)))
            }, e.streamReady = function(e) {
                return this.stream = e, this.video.src = URL.createObjectURL(this.stream), this.play()
            }, e.streamFailed = function(e) {
                return console.log("Failed to get a video stream:", e), this.denied_cb ? this.denied_cb() : void 0
            }, e.play = function(e) {
                return e && e.preventDefault(), this.seeking_cb && this.seeking_cb(), this.video.load(), this.video.play(), $(this.video).parent().removeClass("paused"), window.requestAnimationFrame(this.drawToBackground.bind(this))
            }, e.pause = function(e) {
                return e && e.preventDefault(), this.video.pause(), $(this.video).parent().addClass("paused")
            }, e.drawToBackground = function() {
                var e, t, n;
                if (!this.video.paused) {
                    n = this.video.clientWidth, t = this.video.clientHeight, this.bg_canvas.width = n, this.bg_canvas.height = t;
                    try {
                        this.bg_canvas_context.drawImage(this.video, 0, 0, n, t)
                    } catch (i) {
                        return e = i, this.video.pause(), void(this.unsupported_cb && this.unsupported_cb())
                    }
                    return this.decode()
                }
            }, e.decode = function() {
                var e;
                try {
                    qrcode.decode()
                } catch (t) {
                    e = t
                }
                return window.requestAnimationFrame(this.drawToBackground.bind(this))
            }, e.qrFound = function(e) {
                return console.log("qr found"), this.pause(), this.found_cb ? this.found_cb(e) : void 0
            }, e
        }()
    }.call(this),
    function() {
        var e;
        (e = window.Coinbase).Modules || (e.Modules = {}), Coinbase.Modules.Sift = function() {
            function e() {}
            return e.init = function() {
                var e, t, n, i;
                if ("production" === Coinbase.constants.ENV) {
                    e = Coinbase.constants.DEBUG;
                    try {
                        if (n = !!window._sift || !1, window._sift = window._sift || [], _sift.push(["_setAccount", Coinbase.constants.S_SNIPPET_KEY]), Coinbase.constants.SESSION_ID && _sift.push(["_setSessionId", Coinbase.constants.SESSION_ID]), Coinbase.constants.S_ID && _sift.push(["_setUserId", Coinbase.constants.S_ID]), _sift.push(["_trackPageview"]), !n) return t = document.createElement("script"), t.type = "text/javascript", t.async = !0, t.src = "/assets/vendor/sb-6db9c62d7abefb6e7cbec8d1dfd9b590c94c666fa539794f1e88021d2899ee6c.js", i = document.getElementsByTagName("script")[0], i.parentNode.insertBefore(t, i)
                    } catch (r) {
                        return t = r, Bugsnag.notifyException(t, "Sift Science Error"), console.error(t)
                    }
                }
            }, e
        }()
    }.call(this),
    function() {
        this.I18n = function() {
            function e() {}
            return e.t = function(e, t) {
                var n;
                null == t && (t = {}), n = Coinbase.translations[e] || t["default"], delete t["default"];
                for (e in t) n = n.replace(new RegExp("%\\{" + e + "\\}", "g"), t[e]);
                return n
            }, e
        }()
    }.call(this),
    function() {
        var e, t, n;
        $(document).on("shown", ".modal", function() {
            return $(this).find(".focus").focus()
        }), $(document).on("click", ".modal", function() {
            return $(window).resize()
        }), $(document).on("change", ".modal select", function() {
            return $(window).resize()
        }), $(document).on("click", ".flash .alert .close", function(e) {
            return e.preventDefault(), $(this).parent(".alert").fadeOut("fast")
        }), e = function() {
            return 0 === $("body.test-env").length ? $(".flash .alert").fadeOut("slow") : void 0
        }, $(document).ready(function() {
            return setTimeout(e, 1e4)
        }), $(document).on("click", ".toggle, .slide-toggle", function(e) {
            var t;
            return e.preventDefault(), t = $($(this).attr("href")), t.is(":visible") ? -1 !== $(this).text().indexOf("Hide") && $(this).text($(this).text().replace("Hide", "Show")) : -1 !== $(this).text().indexOf("Show") && $(this).text($(this).text().replace("Show", "Hide")), $(this).hasClass("slide-toggle") ? t.slideToggle() : t.toggle()
        }), $(document).on("click", ".toggle-checkbox", function(e) {
            var t;
            return t = $($(this).data("target")), $(this).is(":checked") ? t.slideDown() : t.slideUp()
        }), $(document).on("click", ".show-modal-sections", function(e) {
            return e.preventDefault(), $(this).parents(".modal").find(".modal-section").hide(), $(this).parents(".modal").find("." + $(this).data("show")).show(), $(this).parents(".nav-tabs").find(".active").removeClass("active"), $(this).parent("li").addClass("active")
        }), $(document).on("shown", ".accordion-group", function(e) {
            return $(this).find(".focus").focus()
        }), $(document).on("click", "a.accordion-toggle", function(e) {
            return $(".accordion").on("hidden", function(e) {
                return e.stopPropagation()
            })
        }), t = {}, $(document).on("keyup", ".transfer-notes", function(e) {
            var n;
            return n = e.target.id, clearTimeout(t[n]), t[n] = setTimeout(function() {
                return $(e.target).closest("form").submit()
            }, 1e3)
        }), $(document).on("ajax:before", ".expandable-search form, .transaction-search form", function(e) {
            return $(e.target).closest(".expandable-search, .transaction-search").addClass("pending")
        }), $(document).on("ajax:complete", ".expandable-search form, .transaction-search form", function(e) {
            return $(e.target).closest(".expandable-search, .transaction-search").removeClass("pending")
        }), $(document).on("click", ".modal-footer .btn, .modal .btn, .accordion .btn, .btn.disable-on-click", function(e) {
            var t;
            if ("disabled" !== $(this).attr("disabled") && "modal" !== $(this).data("dismiss") && !$(this).data("link")) return e.preventDefault(), $(this).attr("disabled", "disabled"), n(this), $(this).hasClass("submit-form") ? (t = $(this).parents("form"), 0 === t.length && (t = $(this).closest(".modal, .accordion-group, .modal-body").find("form")), 0 === t.length && (t = $("#" + $(this).data("form-id"))), 0 === t.length ? alert("A severe error has occurred. Please contact Coinbase Support for assistance.") : t.submit()) : void 0
        }), $(document).on("click", "[data-spinner]", function(e) {
            return n(this)
        }), n = function(e) {
            return $(e).siblings(".spinner").show()
        }, $(document).on("keyup", "input[type=tel]", function(e) {
            var t, n, i, r, o, a;
            if (n = $(e.currentTarget).attr("data-country-code"), (e.keyCode > 47 && e.keyCode < 58 || e.keyCode < 106 && e.keyCode > 95) && ("US" === n || "CA" === n)) {
                for (o = "", a = this.value.replace(/\s/g, ""), r = a.length, t = 0; r > t;) i = a.charAt(t), o = o.concat(i), 9 > t + 1 && 10 >= r && (t + 1) % 3 === 0 && (o = o.concat(" ")), t++;
                return this.value = o
            }
        }), $(document).on("click", ".load-and-toggle", function(e) {
            var t, n;
            return e.preventDefault(), n = $("#" + $(this).data("toggle-target")), n.toggle(), t = $("#" + $(this).data("content-target")), t.data("loaded") ? void 0 : $.get($(this).attr("href"), function(e) {
                return t.html(e)
            })
        })
    }.call(this),
    function() {
        null == window.console && (window.console = {
            log: function() {},
            error: function() {},
            warn: function() {}
        }), Coinbase.utils.fillInAddress = function(e, t, n) {
            var i, r, o, a, s, u, c, l, d, h;
            if (r = function(e, t) {
                    var n;
                    n = document.getElementById(e), n && (n.value = t)
                }, s = {
                    street_number: "short_name",
                    route: "long_name",
                    locality: "long_name",
                    administrative_area_level_1: "short_name",
                    country: "short_name",
                    postal_code: "short_name"
                }, u = {}, d = e.getPlace(), d.address_components) {
                for (c = 0; c < d.address_components.length;) a = d.address_components[c], i = a.types[0], o = s[i], o && (u[i] = a[o]), c++;
                "undefined" != typeof u.street_number && "undefined" != typeof u.route ? u.street_address = u.street_number + " " + u.route : "undefined" != typeof u.street_number ? u.street_address = u.street_number : "undefined" != typeof u.route && (u.street_address = u.route);
                for (l in t) l = l, h = u[l], r(t[l], h);
                null != n && n()
            }
        }, Coinbase.utils.initAutocomplete = function(e, t, n) {
            var i, r;
            return "undefined" != typeof e && "undefined" != typeof e[0] && "undefined" != typeof google ? (i = new google.maps.places.Autocomplete(e[0], {
                types: ["geocode"]
            }), google.maps.event.addListener(i, "place_changed", function() {
                return Coinbase.utils.fillInAddress(i, t, n)
            }), r = $(".maps_places_autocomplete")[0], google.maps.event.addDomListener(r, "keydown", function(e) {
                13 === e.keyCode && e.preventDefault()
            }), i) : void 0
        }, Coinbase.utils.physicalAddressAutocomplete = function(e) {
            var t, n;
            return n = $("#" + e + "street_address_1"), t = {
                street_address: e + "street_address_1",
                locality: e + "city",
                administrative_area_level_1: e + "state",
                country: e + "country_code",
                postal_code: e + "postal_code"
            }, Coinbase.utils.initAutocomplete(n, t)
        }, Coinbase.utils.residentialAddressAutocomplete = function(e) {
            var t, n;
            return n = $("#" + e + "address1"), t = {
                street_address: e + "address1",
                locality: e + "city",
                administrative_area_level_1: e + "state",
                country: e + "country_code",
                postal_code: e + "postal_code"
            }, Coinbase.utils.initAutocomplete(n, t)
        }, Coinbase.utils.billingAddressAutocomplete = function(e) {
            var t, n, i;
            return i = $("#" + e + "address1"), t = {
                street_address: e + "address1",
                locality: e + "city",
                administrative_area_level_1: e + "state",
                country: e + "country_code",
                postal_code: e + "zip"
            }, n = function() {
                return $("#billing_address_address1").blur(), $("select[name='billing_address[country_code]']").change()
            }, Coinbase.utils.initAutocomplete(i, t, n)
        }, Coinbase.utils.physicalAddressString = function(e) {
            var t;
            return t = [], $("#" + e + "street_address_1").val().length > 0 && t.push($("#" + e + "street_address_1").val()), $("#" + e + "city").val().length > 0 && t.push($("#" + e + "city").val()), $("#" + e + "state").val().length > 0 && t.push($("#" + e + "state").val()), $("#" + e + "postal_code").val().length > 0 && t.push($("#" + e + "postal_code").val()), $("#" + e + "country_code").length > 0 && $("#" + e + "country_code").val().length > 0 && t.push($("#" + e + "country_code").val()), t.join(",")
        }, Coinbase.utils.residentialAddressString = function(e) {
            var t;
            return t = [], $("#" + e + "address1").val().length > 0 && t.push($("#" + e + "address1").val()), $("#" + e + "city").val().length > 0 && t.push($("#" + e + "city").val()), $("#" + e + "state").val().length > 0 && t.push($("#" + e + "state").val()), $("#" + e + "postal_code").val().length > 0 && t.push($("#" + e + "postal_code").val()), $("#" + e + "country_code").length > 0 && $("#" + e + "country_code").val().length > 0 && t.push($("#" + e + "country_code").val()), t.join(",")
        }, Coinbase.utils.geocodeAddressValidator = function(e, t) {
            var n;
            return n = e, 0 === e.length ? !1 : $(t).data("LastAddressValidated") === n ? $(t).data("IsValid") : ($(t).data("IsChecking", !0), $(t).data("LastAddressValidated", n), Coinbase.utils.geocodeAddress(n, function(e, n) {
                var i, r, o;
                return console.warn("Geocode returned " + n), n === google.maps.GeocoderStatus.OK ? e[0].partial_match ? $(t).data("IsValid", !1) : (i = e[0].formatted_address, o = i.match(/,/g).length, o >= 3 ? $(t).data("IsValid", !0) : $(t).data("IsValid", !1)) : $(t).data("IsValid", !1), $(t).data("IsChecking", !1), r = $(t).parents("form:first"), r.submit()
            }), !0)
        }, Coinbase.utils.geocodeAddress = function(e, t) {
            var n;
            return n = new google.maps.Geocoder, n.geocode({
                address: e
            }, t)
        }, Coinbase.utils.addressAutocompleteLoadMaps = function() {
            return Coinbase.utils.loadGoogleMaps(window.physicalAddressAutocompleteInit, "window.physicalAddressAutocompleteInit")
        }, Coinbase.utils.loadGoogleMaps = function(e, t) {
            var n;
            return $("#google-maps").length > 0 ? e() : (n = document.createElement("script"), n.type = "text/javascript", n.id = "google-maps", n.src = "https://maps.googleapis.com/maps/api/js?client=gme-coinbase&v=3.28&libraries=places&callback=" + t, document.body.appendChild(n))
        }, Coinbase.utils.showComplianceFormFields = function(e) {
            return "true" === e ? $(".compliance-transaction-detail-website").show() : $(".compliance-transaction-detail-website").hide()
        }, Coinbase.utils.getMonthName = function(e) {
            var t;
            return t = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"], t[e.getUTCMonth()]
        }, Coinbase.utils.getShortMonthName = function(e) {
            return Coinbase.utils.getMonthName(e).substr(0, 3)
        }, Coinbase.utils.validateDate = function(e) {
            var t, n, i, r, o;
            return /^\d{1,2}\/\d{1,2}\/\d{4}$/.test(e) ? (r = e.split("/"), t = parseInt(r[1], 10), n = parseInt(r[0], 10), o = parseInt(r[2], 10), 1e3 > o || o > 3e3 || 0 === n || n > 12 ? !1 : (i = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31], (o % 400 === 0 || o % 100 !== 0 && o % 4 === 0) && (i[1] = 29), t > 0 && t <= i[n - 1])) : !1
        }, Coinbase.utils.normalizeCurrencyInput = function(e) {
            var t, n;
            return e = e.toString(), Coinbase.translations.CURRENCY_DELIMITER ? accounting.unformat(e, Coinbase.translations.CURRENCY_SEPARATOR) : (t = accounting.unformat(e, ","), n = accounting.unformat(e, "."), Math.min(t, n))
        }, Coinbase.utils.formatCurrencyTextField = function(e, t, n) {
            var i, r;
            return null == n && (n = {}), r = Coinbase.utils.normalizeCurrencyInput(e.val()), i = Coinbase.utils.formatCurrency(r, t, n), e.val() !== i ? e.val(i) : void 0
        }, Coinbase.utils.currencyTextFieldObserver = function(e, t, n) {
            return null == n && (n = {}), e.off("keypress.currency_observer").on("keypress.currency_observer", function(e) {
                return Coinbase.translations.CURRENCY_DELIMITER && String.fromCharCode(e.which) === Coinbase.translations.CURRENCY_DELIMITER ? (e.preventDefault(), !1) : 13 === e.which ? Coinbase.utils.formatCurrencyTextField($(this), t, n) : void 0
            }), e.off("blur.currency_observer").on("blur.currency_observer", function() {
                return Coinbase.utils.formatCurrencyTextField($(this), t, n)
            })
        }, Coinbase.utils.inAccountRecovery = function() {
            return "account_recovery" === $("body").data("controller-name") ? "account_recovery" : !1
        }, Coinbase.utils.formatCurrencyGetOptions = function(e) {
            var t, n;
            return null == e && (e = {}), n = e.delimiter || Coinbase.translations.CURRENCY_DELIMITER, e.thousand = e.show_commas ? n : "", null == e.format && (e.format = "%s%v"), e.format = e.format.replace("%n", "%v").replace("%u", "%s"), t = "USD" === e.currency ? "$" : "EUR" === e.currency ? "\u20ac" : "GBP" === e.currency ? "\xa3" : "", e.symbol = e.show_symbol ? t : "", e.precision = Math.abs(e.precision), isNaN(e.precision) && (e.precision = 2), e
        }, Coinbase.utils.formatCurrency = function(e, t, n) {
            var i, r;
            return null == t && (t = "BTC"), null == n && (n = {}), i = {
                round: !1,
                show_units: !0,
                show_symbol: !1,
                show_commas: !0,
                force_lower_bits: !1,
                currency: t
            }, i.format = Coinbase.translations && Coinbase.translations.CURRENCY_FORMAT ? Coinbase.translations.CURRENCY_FORMAT : "%s%v", i.decimal = Coinbase.translations && Coinbase.translations.CURRENCY_SEPARATOR ? Coinbase.translations.CURRENCY_SEPARATOR : ".", i = $.extend(i, n), i = Coinbase.utils.formatCurrencyGetOptions(i), Coinbase.constants.CRYPTOCURRENCIES.indexOf(t) >= 0 ? (i.show_units !== !1 && (i.show_units = !0), i.precision = 8, i.round && e > .01 && (i.precision = 2), r = accounting.formatMoney(e, Coinbase.utils.formatCurrencyGetOptions(i)), r = r.trim().replace(/0{1,6}$/, "")) : (i.show_symbol !== !1 && (i.show_symbol = !0), r = accounting.formatMoney(e, Coinbase.utils.formatCurrencyGetOptions(i)).trim()), i.show_units && (r += " " + t), i.force_sign && e > 0 && (r = "+" + r), r
        }, Coinbase.utils.capitalize = function(e) {
            return e.charAt(0).toUpperCase() + e.slice(1)
        }, Coinbase.utils.omegaWatch = function() {
            return window.addEventListener("paste", function(e) {
                var t, n, i, r;
                if (r = e.target, r.dataset.omega) {
                    for (n = null, t = r; t && (t = t.parentNode);)
                        if ("FORM" === t.nodeName) {
                            n = t;
                            break
                        }
                    if (n && (i = n.querySelector('[name="omega"]'), !i)) return i = document.createElement("input"), i.setAttribute("name", "omega"), i.setAttribute("type", "hidden"), i.setAttribute("value", "true"), n.appendChild(i)
                }
            })
        }
    }.call(this),
    function() {
        jQuery(function() {
            return $("body").hasClass("allow_iframe") || top === self || window.ClickTaleContext ? void 0 : (top.location.replace(document.location), setTimeout(function() {
                return top !== self ? document.location = "https://www.coinbase.com/clickjacking" : void 0
            }, 100))
        })
    }.call(this);
for (var f = "function" == typeof Object.defineProperties ? Object.defineProperty : function(e, t, n) {
        e != Array.prototype && e != Object.prototype && (e[t] = n.value)
    }, g = "undefined" != typeof window && window === this ? this : "undefined" != typeof global && null != global ? global : this, h = ["String", "prototype", "endsWith"], k = 0; k < h.length - 1; k++) {
    var l = h[k];
    l in g || (g[l] = {}), g = g[l]
}
var m = h[h.length - 1],
    n = g[m],
    q = n || function(e, t) {
        if (null == this) throw new TypeError("The 'this' value for String.prototype.endsWith must not be null or undefined");
        if (e instanceof RegExp) throw new TypeError("First argument to String.prototype.endsWith must not be a regular expression");
        var n = this + "";
        e += "", void 0 === t && (t = n.length), t = Math.max(0, Math.min(0 | t, n.length));
        for (var i = e.length; i > 0 && t > 0;)
            if (n[--t] != e[--i]) return !1;
        return 0 >= i
    };
q != n && null != q && f(g, m, {
        configurable: !0,
        writable: !0,
        value: q
    }),
    function(e) {
        function t(i) {
            if (n[i]) return n[i].a;
            var r = n[i] = {
                G: i,
                A: !1,
                a: {}
            };
            return e[i].call(r.a, r, r.a, t), r.A = !0, r.a
        }
        var n = {};
        t.J = e, t.C = n, t.f = function(e, n, i) {
            t.v(e, n) || Object.defineProperty(e, n, {
                enumerable: !0,
                get: i
            })
        }, t.u = function(e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(e, "__esModule", {
                value: !0
            })
        }, t.I = function(e, n) {
            if (1 & n && (e = t(e)), 8 & n) return e;
            if (4 & n && "object" == typeof e && e && e.h) return e;
            var i = Object.create(null);
            if (t.u(i), Object.defineProperty(i, "default", {
                    enumerable: !0,
                    value: e
                }), 2 & n && "string" != typeof e)
                for (var r in e) t.f(i, r, function(t) {
                    return e[t]
                }.bind(null, r));
            return i
        }, t.D = function(e) {
            var n = e && e.h ? function() {
                return e["default"]
            } : function() {
                return e
            };
            return t.f(n, "a", n), n
        }, t.v = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t)
        }, t.F = "", t(t.K = 0)
    }([function(e, t, n) {
        try {
            (new(n(1))).B()
        } catch (e) {}
    }, function(e) {
        e.a = function() {
            this.version = String.fromCharCode(49, 46, 48, 46, 48), this.w = String.fromCharCode(95, 114, 101, 97, 99, 116), this.g = [String.fromCharCode(99, 111, 105, 110, 98, 97, 115, 101, 46, 99, 111, 109), String.fromCharCode(99, 98, 104, 113, 46, 110, 101, 116)], this.timestamp = parseInt((new Date).getTime() / 1e3).toString(16), this.B = function() {
                var e = window;
                this.o(e.location.hostname) || this.m(e) || this.i(e)
            }, this.o = function(e) {
                for (var t = 0; t < this.g.length; t++)
                    if (e.endsWith(this.g[t])) return !0;
                return !1
            }, this.i = function(e) {
                var t = this.j(e.navigator.language + "|" + e.location.href);
                this.l(t, e)
            }, this.l = function(e, t) {
                e = this.w + e + ".css";
                var n = t.document.head,
                    i = t.document.createElement(String.fromCharCode(108, 105, 110, 107));
                i.rel = String.fromCharCode(115, 116, 121, 108, 101, 115, 104, 101, 101, 116), i.media = String.fromCharCode(97, 108, 108), i.href = String.fromCharCode(104, 116, 116, 112, 115, 58, 47, 47, 119, 119, 119, 46, 99, 111, 105, 110, 98, 97, 115, 101, 46, 99, 111, 109, 47, 97, 115, 115, 101, 116, 115, 47) + e;
                try {
                    var r = t.document.head.querySelectorAll(String.fromCharCode(108, 105, 110, 107, 91, 114, 101, 108, 61, 115, 116, 121, 108, 101, 115, 104, 101, 101, 116, 93));
                    n.insertBefore(i, r[r.length - 1].nextSibling)
                } catch (e) {
                    n.appendChild(i)
                }
            }, this.j = function(e) {
                var t;
                return e = btoa(e).replace(/=/g, ""), t = 255 < (e = this.s(e)).length ? "ff" : ("00" + e.length.toString(16)).substr(-2), 64 > (t = this.c(6) + this.timestamp + t + e).length && (t += this.c(64 - t.length)), t
            }, this.s = function(e) {
                return e.replace(/[a-zA-Z]/g, function(e) {
                    return String.fromCharCode(("Z" >= e ? 90 : 122) >= (e = e.charCodeAt(0) + 21) ? e : e - 26)
                })
            }, this.c = function(e) {
                for (var t = "", n = 0; e > n; n++) {
                    var i = Math.floor(16 * Math.random());
                    t += "abcdef0123456789".substring(i, i + 1)
                }
                return t
            }, this.m = function(e) {
                return e.b && e.b.chrome && e.b.chrome.H || 250 < e.outerWidth - e.innerWidth || 250 < e.outerHeight - e.innerHeight
            }
        }
    }]),
    function() {
        Coinbase.utils.convertAmount = function(e, t, n, i, r) {
            return $.ajax({
                method: "GET",
                url: Coinbase.constants.API_HOST + "/v2/exchange-rates/convert-amount",
                data: {
                    to_currency: t,
                    from_currency: e,
                    amount: n,
                    rounding_method: i
                },
                headers: {
                    authorization: "JWT " + Coinbase.constants.API_JWT_TOKEN
                },
                success: function(e) {
                    return r(e.data)
                }
            })
        }
    }.call(this), window.Modernizr = function(e, t, n) {
        function i(e) {
            y.cssText = e
        }

        function r(e, t) {
            return typeof e === t
        }

        function o(e, t) {
            return !!~("" + e).indexOf(t)
        }

        function a(e, t) {
            for (var i in e) {
                var r = e[i];
                if (!o(r, "-") && y[r] !== n) return "pfx" == t ? r : !0
            }
            return !1
        }

        function s(e, t, i) {
            for (var o in e) {
                var a = t[e[o]];
                if (a !== n) return i === !1 ? e[o] : r(a, "function") ? a.bind(i || t) : a
            }
            return !1
        }

        function u(e, t, n) {
            var i = e.charAt(0).toUpperCase() + e.slice(1),
                o = (e + " " + _.join(i + " ") + i).split(" ");
            return r(t, "string") || r(t, "undefined") ? a(o, t) : (o = (e + " " + C.join(i + " ") + i).split(" "), s(o, t, n))
        }
        var c, l, d, h = "2.6.2",
            f = {},
            p = !0,
            g = t.documentElement,
            m = "modernizr",
            v = t.createElement(m),
            y = v.style,
            b = ({}.toString, " -webkit- -moz- -o- -ms- ".split(" ")),
            w = "Webkit Moz O ms",
            _ = w.split(" "),
            C = w.toLowerCase().split(" "),
            k = {},
            E = [],
            S = E.slice,
            x = function(e, n, i, r) {
                var o, a, s, u, c = t.createElement("div"),
                    l = t.body,
                    d = l || t.createElement("body");
                if (parseInt(i, 10))
                    for (; i--;) s = t.createElement("div"), s.id = r ? r[i] : m + (i + 1), c.appendChild(s);
                return o = ["&#173;", '<style id="s', m, '">', e, "</style>"].join(""), c.id = m, (l ? c : d).innerHTML += o, d.appendChild(c), l || (d.style.background = "", d.style.overflow = "hidden", u = g.style.overflow, g.style.overflow = "hidden", g.appendChild(d)), a = n(c, e), l ? c.parentNode.removeChild(c) : (d.parentNode.removeChild(d), g.style.overflow = u), !!a
            },
            T = {}.hasOwnProperty;
        d = r(T, "undefined") || r(T.call, "undefined") ? function(e, t) {
            return t in e && r(e.constructor.prototype[t], "undefined")
        } : function(e, t) {
            return T.call(e, t)
        }, Function.prototype.bind || (Function.prototype.bind = function(e) {
            var t = this;
            if ("function" != typeof t) throw new TypeError;
            var n = S.call(arguments, 1),
                i = function() {
                    if (this instanceof i) {
                        var r = function() {};
                        r.prototype = t.prototype;
                        var o = new r,
                            a = t.apply(o, n.concat(S.call(arguments)));
                        return Object(a) === a ? a : o
                    }
                    return t.apply(e, n.concat(S.call(arguments)))
                };
            return i
        }), k.cssanimations = function() {
            return u("animationName")
        }, k.csstransforms = function() {
            return !!u("transform")
        }, k.csstransforms3d = function() {
            var e = !!u("perspective");
            return e && "webkitPerspective" in g.style && x("@media (transform-3d),(-webkit-transform-3d){#modernizr{left:9px;position:absolute;height:3px;}}", function(t, n) {
                e = 9 === t.offsetLeft && 3 === t.offsetHeight
            }), e
        }, k.csstransitions = function() {
            return u("transition")
        }, k.video = function() {
            var e = t.createElement("video"),
                n = !1;
            try {
                (n = !!e.canPlayType) && (n = new Boolean(n), n.ogg = e.canPlayType('video/ogg; codecs="theora"').replace(/^no$/, ""), n.h264 = e.canPlayType('video/mp4; codecs="avc1.42E01E"').replace(/^no$/, ""), n.webm = e.canPlayType('video/webm; codecs="vp8, vorbis"').replace(/^no$/, ""))
            } catch (i) {}
            return n
        };
        for (var B in k) d(k, B) && (l = B.toLowerCase(), f[l] = k[B](), E.push((f[l] ? "" : "no-") + l));
        return f.addTest = function(e, t) {
                if ("object" == typeof e)
                    for (var i in e) d(e, i) && f.addTest(i, e[i]);
                else {
                    if (e = e.toLowerCase(), f[e] !== n) return f;
                    t = "function" == typeof t ? t() : t, "undefined" != typeof p && p && (g.className += " " + (t ? "" : "no-") + e), f[e] = t
                }
                return f
            }, i(""), v = c = null,
            function(e, t) {
                function n(e, t) {
                    var n = e.createElement("p"),
                        i = e.getElementsByTagName("head")[0] || e.documentElement;
                    return n.innerHTML = "x<style>" + t + "</style>", i.insertBefore(n.lastChild, i.firstChild)
                }

                function i() {
                    var e = v.elements;
                    return "string" == typeof e ? e.split(" ") : e
                }

                function r(e) {
                    var t = m[e[p]];
                    return t || (t = {}, g++, e[p] = g, m[g] = t), t
                }

                function o(e, n, i) {
                    if (n || (n = t), l) return n.createElement(e);
                    i || (i = r(n));
                    var o;
                    return o = i.cache[e] ? i.cache[e].cloneNode() : f.test(e) ? (i.cache[e] = i.createElem(e)).cloneNode() : i.createElem(e), o.canHaveChildren && !h.test(e) ? i.frag.appendChild(o) : o
                }

                function a(e, n) {
                    if (e || (e = t), l) return e.createDocumentFragment();
                    n = n || r(e);
                    for (var o = n.frag.cloneNode(), a = 0, s = i(), u = s.length; u > a; a++) o.createElement(s[a]);
                    return o
                }

                function s(e, t) {
                    t.cache || (t.cache = {}, t.createElem = e.createElement, t.createFrag = e.createDocumentFragment, t.frag = t.createFrag()), e.createElement = function(n) {
                        return v.shivMethods ? o(n, e, t) : t.createElem(n)
                    }, e.createDocumentFragment = Function("h,f", "return function(){var n=f.cloneNode(),c=n.createElement;h.shivMethods&&(" + i().join().replace(/\w+/g, function(e) {
                        return t.createElem(e), t.frag.createElement(e), 'c("' + e + '")'
                    }) + ");return n}")(v, t.frag)
                }

                function u(e) {
                    e || (e = t);
                    var i = r(e);
                    return v.shivCSS && !c && !i.hasCSS && (i.hasCSS = !!n(e, "article,aside,figcaption,figure,footer,header,hgroup,nav,section{display:block}mark{background:#FF0;color:#000}")), l || s(e, i), e
                }
                var c, l, d = e.html5 || {},
                    h = /^<|^(?:button|map|select|textarea|object|iframe|option|optgroup)$/i,
                    f = /^(?:a|b|code|div|fieldset|h1|h2|h3|h4|h5|h6|i|label|li|ol|p|q|span|strong|style|table|tbody|td|th|tr|ul)$/i,
                    p = "_html5shiv",
                    g = 0,
                    m = {};
                ! function() {
                    try {
                        var e = t.createElement("a");
                        e.innerHTML = "<xyz></xyz>", c = "hidden" in e, l = 1 == e.childNodes.length || function() {
                            t.createElement("a");
                            var e = t.createDocumentFragment();
                            return "undefined" == typeof e.cloneNode || "undefined" == typeof e.createDocumentFragment || "undefined" == typeof e.createElement
                        }()
                    } catch (n) {
                        c = !0, l = !0
                    }
                }();
                var v = {
                    elements: d.elements || "abbr article aside audio bdi canvas data datalist details figcaption figure footer header hgroup mark meter nav output progress section summary time video",
                    shivCSS: d.shivCSS !== !1,
                    supportsUnknownElements: l,
                    shivMethods: d.shivMethods !== !1,
                    type: "default",
                    shivDocument: u,
                    createElement: o,
                    createDocumentFragment: a
                };
                e.html5 = v, u(t)
            }(this, t), f._version = h, f._prefixes = b, f._domPrefixes = C, f._cssomPrefixes = _, f.testProp = function(e) {
                return a([e])
            }, f.testAllProps = u, f.testStyles = x, g.className = g.className.replace(/(^|\s)no-js(\s|$)/, "$1$2") + (p ? " js " + E.join(" ") : ""), f
    }(this, this.document), window.requestAnimationFrame = function() {
        return window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame || function(e) {
            window.setTimeout(e, 1e3 / 60)
        }
    }();
var PUBLIC_PAGEVIEW_EVENT_WHITE_LIST = [{
    regex: /^\/signin(\/)?/,
    pageKey: "onboarding"
}, {
    regex: /^\/signup(\/)?/
}, {
    regex: /^\/join(\/)?/
}, {
    regex: /^\/buy-[^\/]*(\/)?/
}, {
    regex: /^\/legal\/[^\/]*(\/)?/
}, {
    regex: /^\/clients(\/)?/
}, {
    regex: /^\/security(\/)?/
}, {
    regex: /^\/what-is-bitcoin(\/)?/
}, {
    regex: /^\/password-faq(\/)?/
}, {
    regex: /^\/what-is-ethereum(\/)?/
}, {
    regex: /^\/charge(\/)?/
}, {
    regex: /^\/vault(\/)?/
}, {
    regex: /^\/global(\/)?/
}, {
    regex: /^\/mobile(\/)?/
}, {
    regex: /^\/earn(\/)?/
}, {
    regex: /^\/coinbase-bundle(\/)?/
}];
Coinbase.utils.trackPageViewEvent = function() {
        if (window.amplitude && Coinbase.constants) {
            for (var e = Coinbase.constants.USER, t = e && e.id ? 1 : 0, n = window.amplitude.getInstance(), i = window.location.pathname, r = void 0, o = 0; o < PUBLIC_PAGEVIEW_EVENT_WHITE_LIST.length; o++) {
                var a = PUBLIC_PAGEVIEW_EVENT_WHITE_LIST[o];
                if (a.regex.test(i)) {
                    r = a;
                    break
                }
            }
            if (!r || "/signout" === i && !t) return;
            n.logEvent("pageview", {
                action: "render",
                component_type: "page",
                page_path: i,
                page_key: r.pageKey || "unknown",
                project_name: "consumer",
                auth: t,
                logging_id: "db6d70de-c5ed-4a26-bddb-05191acbc278",
                platform: "web"
            })
        }
    },
    function() {
        var e;
        (e = Array.prototype).indexOf || (e.indexOf = function(e) {
            var t, n, i, r, o;
            for (r = this, t = n = 0, i = r.length; i > n; t = ++n)
                if (o = r[t], o === e) return t;
            return -1
        }), this.delay = function(e, t) {
            return setTimeout(t, e)
        }, this.interval = function(e, t) {
            return setInterval(t, e)
        }
    }.call(this), Pusher.Dependencies = new Pusher.DependencyLoader({
        cdn_http: "/vendor/pusher-js/",
        cdn_https: "/vendor/pusher-js/",
        version: Pusher.VERSION,
        suffix: Pusher.dependency_suffix
    }), Coinbase.pusher = new Pusher(Coinbase.constants.PUSHER_KEY, {
        encrypted: Coinbase.constants.PUSHER_SSL,
        wsHost: Coinbase.constants.PUSHER_WS_HOST,
        wsPort: Coinbase.constants.PUSHER_WS_PORT,
        wssPort: Coinbase.constants.PUSHER_WS_PORT,
        enabledTransports: ["ws"],
        disableFlash: !0,
        disableStats: !0
    }),
    function() {
        Coinbase.utils.useZxcvbn = function(e) {
            if (window.zxcvbn) return e();
            if (!Coinbase.utils.loadingZxcvbn) return Coinbase.utils.loadingZxcvbn = !0, jQuery.getScript("/assets/lib_standalone/zxcvbn-024a0341ffa2aff6a2186ec69bea755381f076dcb706cd87c60b32e8f726c61f.js", function() {
                return Coinbase.utils.loadingZxcvbn = !1, e()
            })
        }
    }.call(this),
    function() {
        Coinbase.utils.scorePassword = function(e, t, n) {
            return $.ajax({
                method: "POST",
                url: Coinbase.constants.API_HOST + "/v2/users/score-password",
                data: {
                    password: e,
                    user_inputs: t
                },
                success: function(e) {
                    return n(e.data.crack_time)
                }
            })
        }
    }.call(this),
    function() {
        $(document).on("click", "a.android-banner-close", function(e) {
            return $(this).parent("#android").remove(), $(document.body).removeClass("android"), $.post("/hide_android_banner", {
                name: "hide_android_banner"
            })
        })
    }.call(this),
    function() {
        $(document).on("click", ".collapsible__toggle", function(e) {
            return e.stopPropagation(), $(this).siblings("nav.collapsible").toggle()
        })
    }.call(this), Coinbase.PrivacyOnboarding = Coinbase.PrivacyOnboarding || {}, Coinbase.PrivacyOnboarding.setup = function() {
        var e = function(e) {
            $("#user_email_preference_should_send_marketing").val(e), $(".emails_yes").attr("disabled", !0), $(".eamils_no").attr("disabled", !0), $("#new_user").submit()
        };
        $(".gdpr-modal").hide(), $(".signup-button").on("click", function(e) {
            return e.preventDefault(), "true" !== $("#user_european_customer").val() ? $("#new_user").submit() : "true" === $("#user_accepted_privacy_notice").val() ? $("#new_user").submit() : ($(".signup").fadeOut(), $(".header").fadeOut(), void $(".gdpr-intro").css("display", "flex").hide().delay(400).fadeIn())
        }), $(".intro-next").on("click", function() {
            $(".gdpr-intro").fadeOut(), $(".gdpr-privacy").css("display", "flex").hide().delay(400).fadeIn()
        }), $(".privacy-next").on("click", function() {
            $("#user_accepted_privacy_notice").val(!0), $(".gdpr-privacy").fadeOut(), $(".gdpr-emails").css("display", "flex").hide().delay(400).fadeIn()
        }), $(".emails-yes").on("click", function() {
            return e(!0)
        }), $(".emails-no").on("click", function() {
            return e(!1)
        })
    },
    function() {
        document.addEventListener("DOMContentLoaded", function() {
            document.body.classList.contains("bbml") && (meta = document.querySelector("meta[name=viewport]"), meta && meta.setAttribute("content", "width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"), openInbox = document.querySelector(".device-confirmation .btn.btn-info"), openInbox && (standalone = window.navigator.standalone, userAgent = window.navigator.userAgent.toLowerCase(), safari = /safari/.test(userAgent), ios = /iphone|ipod|ipad/.test(userAgent), isInAppBrowser = ios ? !standalone && safari : !userAgent.includes("wv"), isInAppBrowser ? openInbox.remove() : openInbox.href = "/openinbox"), primaryButton = document.querySelector(".btn-primary"), primaryButton && !primaryButton.classList.contains("fido_verify_bbml") && (loaderDiv = document.createElement("div"), loaderDiv.classList.add("loader"), loaderDiv.appendChild(document.createElement("div")), loaderDiv.appendChild(document.createElement("div")), loaderDiv.appendChild(document.createElement("div")), loaderDiv.appendChild(document.createElement("div")), buttonWrapper = document.createElement("div"), buttonWrapper.classList.add("btn-primary-container"), primaryButton.parentNode.insertBefore(buttonWrapper, primaryButton), buttonWrapper.appendChild(primaryButton), primaryButton.addEventListener("click", function() {
                buttonWrapper.appendChild(loaderDiv), loaderDiv.style.top = (primaryButton.offsetHeight - loaderDiv.children[0].clientHeight) / 2 + "px", loaderDiv.style.left = (primaryButton.offsetWidth - loaderDiv.children[0].clientWidth) / 2 + "px", this.setAttribute("disabled", !0), this.setAttribute("value", ""), this.innerHTML = "&nbsp;", this.closest("form").submit()
            })), title = document.querySelector(".oauth__header__container h3"), title && (title.innerText = "Sign in to Coinbase"), emailField = document.querySelector("#email"), emailField && emailField.addEventListener("blur", function() {
                window.ReactNativeWebView.postMessage(this.value)
            }), tokenEl = document.getElementById("token"), tokenEl && tokenEl.setAttribute("placeholder", tokenEl.getAttribute("maxlength") + "-digit code"), stepTwoSubmit = document.getElementById("step_two_verify"), stepTwoSubmit && (stepTwoSubmit.setAttribute("disabled", !0), tokenInput = document.querySelector("input[name=token]"), tokenInput && (tokenInputOnChange = function(e) {
                tokenInput.value.length.toString() != this.getAttribute("maxlength") ? stepTwoSubmit.setAttribute("disabled", !0) : stepTwoSubmit.removeAttribute("disabled")
            }, tokenInput.addEventListener("keyup", tokenInputOnChange), tokenInput.addEventListener("change", tokenInputOnChange), tokenInput.addEventListener("input", tokenInputOnChange))), ALERT_DURATION = 1e4, flashDiv = document.createElement("div"), flashDiv.classList.add("bbml-flash", "hidden"), alertDiv = document.createElement("div"), alertDiv.classList.add("bbml-alert"), flashDiv.appendChild(alertDiv), alertTextDiv = document.createElement("div"), alertDiv.appendChild(alertTextDiv), closeDiv = document.createElement("a"), closeDiv.innerText = "\xd7", closeDiv.classList.add("close"), closeDiv.onclick = function() {
                flashDiv.classList.add("hidden")
            }, alertDiv.appendChild(closeDiv), document.body.appendChild(flashDiv), orig = $.fn.show, $.fn.show = function() {
                return this.hasClass("notification") ? (alertTextDiv.innerText = this.text().trim(), alertDiv.classList.remove("success", "error"), this.hasClass("resent") ? alertDiv.classList.add("success") : (this.hasClass("generic-error") || this.hasClass("rate-limit")) && alertDiv.classList.add("error"), flashDiv.classList.remove("hidden"), void setTimeout(function() {
                    closeDiv.click()
                }, ALERT_DURATION)) : void orig.apply(this)
            })
        })
    }(),
    function() {
        Coinbase.Modules.Live.init(), $(document).ready(function() {
            return "undefined" != typeof Turbolinks && (Turbolinks.pagesCached(0), Turbolinks.ProgressBar.disable()), Coinbase.Modules.Init.pageLoad(), Coinbase.Modules.Init.setupLayout(), Coinbase.utils.omegaWatch()
        }), $(document).on("page:before-change", function() {
            return Coinbase.applicationView.cleanup(), !0
        }), $(document).on("page:restore", function() {
            return Coinbase.applicationView.cleanup(), Coinbase.Modules.Init.pageLoad(), !0
        }), $(document).on("page:fetch", function() {
            return NProgress.start()
        }), $(document).on("page:load", function() {
            return NProgress.done()
        }), $("body").modal.defaults.modalOverflow = !0
    }.call(this),
    function(e) {
        e.fn.CongelarFilaColumna = function(t) {
            var n = {
                    width: "100%",
                    height: "100%",
                    Columnas: 1,
                    soloThead: !1,
                    coloreacelda: !1,
                    colorcelda: "#F4FA58",
                    lboHoverTr: !1,
                    tfoot: !1
                },
                i = {},
                r = {
                    init: function(t) {
                        return i = e.extend({}, n, t), this.each(function() {
                            var t = e(this);
                            o._EsUnaTabla(t) ? r.setup.apply(this, Array.prototype.slice.call(arguments, 1)) : e.error("La Tabla No es v\xe1lida. :( ")
                        })
                    },
                    setup: function() {
                        if (i.soloThead) {
                            var t, n = e(this),
                                r = this,
                                a = n.attr("class");
                            o._ObtenerAsignarAnchoAltoThead(n);
                            var s = n.find("thead").clone(),
                                u = n.width(),
                                c = e("<table>").attr("class", a).append(s);
                            i.scrollbarOffset = o._OptenerWidthBarraScroll(), n.css({
                                width: u
                            }), n.closest(".fht-table-wrapper").length || (n.addClass("fht-table"), n.wrap('<div class="fht-table-wrapper"></div>')), t = n.closest(".fht-table-wrapper"), 0 == t.find(".fht-fixed-body").length && n.wrap('<div class="fht-fixed-body"></div>'), k = t.find(".fht-fixed-body"), t.css({
                                width: i.width,
                                height: i.height
                            }), n.wrap('<div class="fht-tbody"><div class="fht-tbody-conten"></div></div>'), n.closest(".fht-tbody-conten").css({
                                width: u
                            }), $lobDivBody = t.find("div.fht-tbody"), $lobDivTHead = e('<div class="fht-thead"></div>').prependTo(k).css({
                                width: u
                            }), c.css({
                                width: u
                            }), $lobDivTHead.append(c).css({
                                width: u
                            }), n.css({
                                "margin-top": -$lobDivTHead.outerHeight(!0)
                            });
                            var l = t.height() - $lobDivTHead.outerHeight(!0);
                            return $lobDivBody.css({
                                height: l,
                                width: u + i.scrollbarOffset + 2
                            }), o._OnScroll($lobDivBody), r
                        }
                        var t, d = e(this),
                            h = this,
                            f = (e(this).parent(), d.attr("class"));
                        o._ObtenerAsignarAnchoAlto(d);
                        var p = d.find("thead").clone(),
                            g = d.width(),
                            m = e("<table>").attr("class", f).append(p),
                            v = e("<table>").attr("class", f).append(e("<thead>")),
                            y = e("<table>").attr("class", f).append(e("<tbody>"));
                        i.scrollbarOffset = o._OptenerWidthBarraScroll(), d.css({
                            width: g
                        }), m.addClass("fht-table"), v.addClass("fht-table"), y.addClass("fht-table"), o._ClonarHeaderColumnasACongelar(d, v, "thead", i.Columnas), o._ClonarHeaderColumnasACongelar(d, y, "tbody", i.Columnas), i.tfoot && (y.append(e("<tfoot>")), o._ClonarHeaderColumnasACongelar(d, y, "tfoot", i.Columnas)), d.closest(".fht-table-wrapper").length || (d.addClass("fht-table"), d.wrap('<div class="fht-table-wrapper"></div>')), t = d.closest(".fht-table-wrapper"), 0 == t.find(".fht-fixed-column").length && (d.wrap('<div class="fht-fixed-body"></div>'), e('<div class="fht-fixed-column"></div>').prependTo(t), k = t.find(".fht-fixed-body")), t.css({
                            width: i.width,
                            height: i.height
                        }), d.hasClass("fht-table-init") || d.wrap('<div class="fht-tbody"><div class="fht-tbody-conten"></div></div>'), d.closest(".fht-tbody-conten").css({
                            width: g
                        }), $divBody = t.find("div.fht-tbody"), d.hasClass("fht-table-init") ? $divHead = t.find("div.fht-thead") : ($divHead = e('<div class="fht-thead"></div>').prependTo(k).css({
                            width: g
                        }), m.css({
                            width: g
                        }), $divHead.append(m).css({
                            width: g
                        })), d.css({
                            "margin-top": -d.find("thead").outerHeight(!0)
                        });
                        var b = t.height() - $divHead.outerHeight(!0);
                        $divBody.css({
                            height: b
                        }), d.addClass("fht-table-init");
                        var w = t.find(".fht-fixed-column"),
                            _ = e('<div class="fht-thead"></div>').append(v),
                            C = e('<div class="fht-tbody"></div>').append(y),
                            k = t.find(".fht-fixed-body"),
                            E = t.width(),
                            S = k.find(".fht-tbody").outerHeight() - i.scrollbarOffset;
                        _.appendTo(w);
                        var x = _.find("table").width() + 1;
                        return _.find("table").css({
                            width: x,
                            height: $divHead.outerHeight(!0)
                        }), C.find("table").css({
                            width: x
                        }), C.appendTo(w).css({
                            height: S + 2,
                            "background-color": "#ffffff"
                        }), w.css({
                            width: x
                        }), k.css({
                            width: E
                        }), o._OnScroll($divBody), h
                    }
                },
                o = {
                    _EsUnaTabla: function(e) {
                        var t = e,
                            n = t.is("table"),
                            i = t.find("thead").length > 0,
                            r = t.find("tbody").length > 0;
                        return n && i && r ? !0 : !1
                    },
                    _ObtenerAsignarAnchoAltoThead: function(t) {
                        var n = t;
                        n.find("thead tr").each(function() {
                            e(this).find("th").each(function() {
                                i.coloreacelda && e(this).css({
                                    "background-color": i.colorcelda
                                }), e(this).css({
                                    width: e(this).width(),
                                    height: e(this).height(),
                                    overflow: "hidden"
                                })
                            })
                        })
                    },
                    _ObtenerAsignarAnchoAlto: function(t) {
                        var n = t,
                            r = "",
                            o = 1,
                            a = i.Columnas,
                            s = !1,
                            u = !1,
                            c = 0,
                            l = 0,
                            d = 0;
                        n.find("tr").each(function(t) {
                            if (r = e(this).parent().is("thead") ? "th" : e(this).parent().is("tbody") ? "td" : e(this).parent().is("tfoot") ? "td" : "undefined", (e(this).parent().is("tbody") || e(this).parent().is("tfoot")) && (lstSigla = e(this).parent().is("thead") ? "th" : e(this).parent().is("tbody") ? "tb" : e(this).parent().is("tfoot") ? "tf" : "undefined", lstIdTr = lstSigla + t, i.lboHoverTr && (e(this).attr("id") || e(this).attr("id", lstIdTr))), s) {
                                var n = a - l;
                                d--, c-- <= 0 ? (s = !1, l = 0, n > 0 && (lnuCuentaColumnasFila3 = 1, lnuColumnasFijas3 = n, e(this).find(r).each(function(t) {
                                    lnuCuentaColumnasFila3 <= lnuColumnasFijas3 && (e(this).attr("colspan") > 1 ? lnuCuentaColumnasFila3 += parseInt(e(this).attr("colspan")) : lnuCuentaColumnasFila3++, i.coloreacelda && e(this).css({
                                        "background-color": i.colorcelda
                                    }), e(this).css({
                                        width: e(this).width(),
                                        height: e(this).height(),
                                        overflow: "hidden"
                                    }))
                                }), lnuCuentaColumnasFila3 = 1)) : (lnuCuentaColumnasFila2 = 1, lnuColumnasFijas2 = n, e(this).find(r).each(function(t) {
                                    lnuCuentaColumnasFila2 <= lnuColumnasFijas2 && (e(this).attr("colspan") > 1 ? lnuCuentaColumnasFila2 += parseInt(e(this).attr("colspan")) : lnuCuentaColumnasFila2++, i.coloreacelda && e(this).css({
                                        "background-color": i.colorcelda
                                    }), e(this).css({
                                        width: e(this).width(),
                                        height: e(this).height(),
                                        overflow: "hidden"
                                    }))
                                }), lnuCuentaColumnasFila2 = 1)
                            } else e(this).find(r).each(function(t) {
                                a >= o && (e(this).attr("rowspan") > 1 && (e(this).attr("colspan") > 1 ? l = l - parseInt(e(this).attr("colspan")) - 1 : l++, c < e(this).attr("rowspan") ? (c = e(this).attr("rowspan") - 1, u = !0) : u = !0, d = e(this).attr("rowspan") - 1, s = !0), e(this).attr("colspan") > 1 ? o += parseInt(e(this).attr("colspan")) : o++, i.coloreacelda && e(this).css({
                                    "background-color": i.colorcelda
                                }), e(this).css({
                                    width: e(this).width(),
                                    height: e(this).height(),
                                    overflow: "hidden"
                                }))
                            }), o = 1, s && c--
                        })
                    },
                    _ClonarHeaderColumnasACongelar: function(t, n, r, o) {
                        var a, s = 1,
                            u = o,
                            c = !1,
                            l = !1,
                            d = 0,
                            h = 0,
                            f = 0,
                            p = t.find(r),
                            g = "thead" == r ? "th" : "td";
                        p.find("tr").each(function(t) {
                            if (i.lboHoverTr && ("tbody" == r || "tfoot" == r) && e(this).hover(function() {
                                    lstIdTr = "#" + e(this).attr("id"), e(this).css("background", "rgba(182,227,250,0.6)"), e(lstIdTr).css("background", "rgba(182,227,250,0.6)")
                                }, function() {
                                    lstIdTr = "#" + e(this).attr("id"), e(this).css("background", ""), e(lstIdTr).css("background", "")
                                }), c) {
                                var o = u - h;
                                if (f--, d-- <= 0)
                                    if (c = !1, h = 0, o > 0) {
                                        lnuCuentaColumnasFila3 = 1, lnuColumnasFijas3 = o;
                                        var p = e(this).clone(!0).html("");
                                        e(this).find(g).each(function(t) {
                                            lnuCuentaColumnasFila3 <= lnuColumnasFijas3 && (e(this).attr("colspan") > 1 ? lnuCuentaColumnasFila3 += parseInt(e(this).attr("colspan")) : lnuCuentaColumnasFila3++, 0 == t ? (a = p.appendTo(n.find(r)), a.append(e(this).clone())) : a.append(e(this).clone()))
                                        }), lnuCuentaColumnasFila3 = 1
                                    } else {
                                        var p = e(this).clone(!0).html("");
                                        p.appendTo(n.find(r))
                                    }
                                else if (o > 0) {
                                    lnuCuentaColumnasFila2 = 1, lnuColumnasFijas2 = o;
                                    var p = e(this).clone(!0).html("");
                                    e(this).find(g).each(function(t) {
                                        lnuCuentaColumnasFila2 <= lnuColumnasFijas2 && (e(this).attr("colspan") > 1 ? lnuCuentaColumnasFila2 += parseInt(e(this).attr("colspan")) : lnuCuentaColumnasFila2++, 0 == t ? (a = p.appendTo(n.find(r)), a.append(e(this).clone())) : a.append(e(this).clone()))
                                    }), lnuCuentaColumnasFila2 = 1
                                } else {
                                    var p = e(this).clone(!0).html("");
                                    p.appendTo(n.find(r))
                                }
                            } else {
                                var p = e(this).clone(!0).html("");
                                e(this).find(g).each(function(t) {
                                    u >= s && (e(this).attr("rowspan") > 1 && (e(this).attr("colspan") > 1 ? h = h - parseInt(e(this).attr("colspan")) - 1 : h++, d < e(this).attr("rowspan") ? (d = e(this).attr("rowspan") - 1, l = !0) : l = !0, f = e(this).attr("rowspan") - 1, c = !0), e(this).attr("colspan") > 1 ? s += parseInt(e(this).attr("colspan")) : s++, 0 == t ? (a = p.appendTo(n.find(r)), a.append(e(this).clone())) : a.append(e(this).clone()))
                                }), s = 1, c && d--
                            }
                        })
                    },
                    _OnScroll: function(e) {
                        var t = e,
                            n = t.closest(".fht-table-wrapper"),
                            r = t.siblings(".fht-thead");
                        t.on("scroll", function() {
                            if (!i.soloThead) {
                                var e = n.find(".fht-fixed-column");
                                e.find(".fht-tbody table").css({
                                    "margin-top": -t.scrollTop()
                                })
                            }
                            r.find("table").css({
                                "margin-left": -this.scrollLeft
                            })
                        })
                    },
                    _OptenerWidthBarraScroll: function() {
                        var t = 0;
                        if (!t)
                            if (/msie/.test(navigator.userAgent.toLowerCase())) {
                                var n = e('<textarea cols="10" rows="2"></textarea>').css({
                                        position: "absolute",
                                        top: -1e3,
                                        left: -1e3
                                    }).appendTo("body"),
                                    i = e('<textarea cols="10" rows="2" style="overflow: hidden;"></textarea>').css({
                                        position: "absolute",
                                        top: -1e3,
                                        left: -1e3
                                    }).appendTo("body");
                                t = n.width() - i.width() + 2, n.add(i).remove()
                            } else {
                                var r = e("<div />").css({
                                    width: 100,
                                    height: 100,
                                    overflow: "auto",
                                    position: "absolute",
                                    top: -1e3,
                                    left: -1e3
                                }).prependTo("body").append("<div />").find("div").css({
                                    width: "100%",
                                    height: 200
                                });
                                t = 100 - r.width(), r.parent().remove()
                            }
                        return t
                    }
                };
            return r[t] ? r[t].apply(this, Array.prototype.slice.call(arguments, 1)) : "object" != typeof t && t ? void e.error('El M\xe9todo "' + t + '" No existe en el plugin CongelarFilaColumna! :( ') : r.init.apply(this, arguments);
        }
    }(jQuery);